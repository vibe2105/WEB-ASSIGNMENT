CREATE DATABASE IF NOT EXISTS event_ticketing_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE event_ticketing_db;
CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('Administrator','Organiser','Customer') NOT NULL DEFAULT 'Customer',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS venues (
  venue_id INT AUTO_INCREMENT PRIMARY KEY,
  venue_name VARCHAR(200) NOT NULL,
  location VARCHAR(255) NOT NULL,
  capacity INT NOT NULL,
  status ENUM('Available','Unavailable') NOT NULL DEFAULT 'Available',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_capacity CHECK (capacity > 0)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS events (
  event_id INT AUTO_INCREMENT PRIMARY KEY,
  organiser_id INT NOT NULL,
  venue_id INT NOT NULL,
  event_name VARCHAR(200) NOT NULL,
  category VARCHAR(50) NOT NULL DEFAULT 'General',
  description TEXT,
  event_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  ticket_price DECIMAL(10,2) NOT NULL DEFAULT 0,
  total_tickets INT NOT NULL,
  available_tickets INT NOT NULL,
  status ENUM('Upcoming','Ongoing','Completed','Cancelled') NOT NULL DEFAULT 'Upcoming',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_event_organiser FOREIGN KEY (organiser_id) REFERENCES users(user_id),
  CONSTRAINT fk_event_venue FOREIGN KEY (venue_id) REFERENCES venues(venue_id),
  INDEX idx_venue_schedule (venue_id,event_date,start_time,end_time),
  INDEX idx_category_status_date (category,status,event_date),
  CONSTRAINT chk_total_tickets CHECK (total_tickets >= 1),
  CONSTRAINT chk_available_tickets CHECK (available_tickets >= 0 AND available_tickets <= total_tickets)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  event_id INT NOT NULL,
  quantity INT NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  booking_status ENUM('Pending','Confirmed','Cancelled') NOT NULL DEFAULT 'Pending',
  booking_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES users(user_id),
  CONSTRAINT fk_booking_event FOREIGN KEY (event_id) REFERENCES events(event_id),
  INDEX idx_user_bookings (user_id,booking_date),
  CONSTRAINT chk_booking_quantity CHECK (quantity >= 1)
) ENGINE=InnoDB;
