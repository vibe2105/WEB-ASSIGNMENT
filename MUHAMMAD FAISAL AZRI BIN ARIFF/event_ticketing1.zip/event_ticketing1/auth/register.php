<?php
require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();



ini_set("display_errors", 0);
ini_set("log_errors", 1);
error_reporting(E_ALL);



header("Content-Type: application/json; charset=utf-8");
header("Cache-Control: no-store");




require_once __DIR__ . "/../config/database.php";

$database = new Database();
$db = $database->getConnection();


if (!$db) {

    http_response_code(500);

    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed"
    ]);

    exit;
}




if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);
    header("Allow: POST");

    echo json_encode([
        "status" => "error",
        "message" => "Method not allowed"
    ]);

    exit;
}




$data = json_decode(
    file_get_contents("php://input"),
    true
);


if (!is_array($data)) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "Invalid JSON request body"
    ]);

    exit;
}





foreach (["name", "email", "password", "confirm_password"] as $field) {
    if (!is_string($data[$field] ?? null)) {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "All fields are required"
        ]);
        exit;
    }
}

$name = trim($data["name"]);
$email = strtolower(trim($data["email"]));
$password = $data["password"];
$confirm_password = $data["confirm_password"];




if (
    $name === "" ||
    $email === "" ||
    $password === "" ||
    $confirm_password === ""
) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "All fields are required"
    ]);

    exit;
}




if (strlen($name) < 3) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" =>
            "Name must contain at least 3 characters"
    ]);

    exit;
}




if (
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "Invalid email address"
    ]);

    exit;
}




if (strlen($password) < 6) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" =>
            "Password must contain at least 6 characters"
    ]);

    exit;
}




if ($password !== $confirm_password) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "Passwords do not match"
    ]);

    exit;
}



try {

    

    $checkQuery = "
        SELECT
            user_id

        FROM users

        WHERE email = :email

        LIMIT 1
    ";


    $checkStmt =
        $db->prepare(
            $checkQuery
        );


    $checkStmt->execute([
        ":email" => $email
    ]);


    if ($checkStmt->fetch()) {

        http_response_code(409);

        echo json_encode([
            "status" => "error",
            "message" =>
                "An account with this email already exists"
        ]);

        exit;
    }


    

    $password_hash =
        password_hash(
            $password,
            PASSWORD_DEFAULT
        );


    

    $query = "
        INSERT INTO users
        (
            name,
            email,
            password_hash,
            role
        )

        VALUES
        (
            :name,
            :email,
            :password_hash,
            'Customer'
        )
    ";


    $stmt =
        $db->prepare(
            $query
        );


    $stmt->execute([

        ":name" =>
            $name,

        ":email" =>
            $email,

        ":password_hash" =>
            $password_hash

    ]);


    $user_id =
        $db->lastInsertId();


    

    http_response_code(201);


    echo json_encode([

        "status" =>
            "success",

        "message" =>
            "Account created successfully",

        "data" => [

            "user_id" =>
                $user_id,

            "name" =>
                $name,

            "email" =>
                $email,

            "role" =>
                "Customer"

        ]

    ]);


} catch (Throwable $error) {
    error_log("Eventify registration error: " . $error->getMessage());

    
    if ($error instanceof PDOException && $error->getCode() === "23000") {
        http_response_code(409);
        echo json_encode([
            "status" => "error",
            "message" => "An account with this email already exists"
        ]);
        exit;
    }

    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Unable to create account"
    ]);
}

?>