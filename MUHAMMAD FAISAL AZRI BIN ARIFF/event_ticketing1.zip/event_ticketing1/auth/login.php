<?php
require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();



ini_set("display_errors", 0);
ini_set("log_errors", 1);
error_reporting(E_ALL);




header("Content-Type: application/json; charset=utf-8");
header("Cache-Control: no-store");




require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/jwt.php";




$database =
    new Database();


$db =
    $database->getConnection();


if (!$db) {

    http_response_code(500);

    echo json_encode([
        "status" => "error",
        "message" =>
            "Database connection failed"
    ]);

    exit;
}




if (
    $_SERVER["REQUEST_METHOD"]
    !== "POST"
) {

    http_response_code(405);
    header("Allow: POST");

    echo json_encode([
        "status" => "error",
        "message" =>
            "Method not allowed"
    ]);

    exit;
}




$data =
    json_decode(
        file_get_contents(
            "php://input"
        ),
        true
    );


if (!is_array($data)) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" =>
            "Invalid JSON request body"
    ]);

    exit;
}




if (!is_string($data["email"] ?? null) ||
    !is_string($data["password"] ?? null)) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Email and password are required"
    ]);
    exit;
}

$email = strtolower(trim($data["email"]));
$password = $data["password"];




if (
    $email === "" ||
    $password === ""
) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" =>
            "Email and password are required"
    ]);

    exit;
}


if (
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" =>
            "Invalid email address"
    ]);

    exit;
}



try {

    

    $query = "
        SELECT
            user_id,
            name,
            email,
            password_hash,
            role

        FROM users

        WHERE email = :email

        LIMIT 1
    ";


    $stmt =
        $db->prepare($query);


    $stmt->execute([
        ":email" => $email
    ]);


    $user =
        $stmt->fetch();


    

    if (!$user) {

        http_response_code(401);

        echo json_encode([
            "status" => "error",
            "message" =>
                "Invalid email or password"
        ]);

        exit;
    }


    if (
        !password_verify(
            $password,
            $user["password_hash"]
        )
    ) {

        http_response_code(401);

        echo json_encode([
            "status" => "error",
            "message" =>
                "Invalid email or password"
        ]);

        exit;
    }


    

    $token =
        createJWT($user);


    

    http_response_code(200);


    echo json_encode([

        "status" =>
            "success",

        "message" =>
            "Login successful",

        "token" =>
            $token,

        "expires_in" =>
            JWT_EXPIRY,

        "user" => [

            "user_id" =>
                intval(
                    $user["user_id"]
                ),

            "name" =>
                $user["name"],

            "email" =>
                $user["email"],

            "role" =>
                $user["role"]

        ]

    ]);


} catch (Throwable $error) {
    error_log("Eventify login error: " . $error->getMessage());

    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Unable to login"
    ]);
}

?>