<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Book Tickets | Eventify</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >


    <style>

        .booking-page {
            min-height: 100vh;

            background:
                linear-gradient(
                    180deg,
                    #f7f7fb,
                    #f1eff8
                );
        }


        .booking-page-header {

            padding:
                70px 0 45px;

            color:
                white;

            background:
                radial-gradient(
                    circle at 75% 15%,
                    rgba(117,89,255,.25),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #11101d,
                    #211943
                );

        }


        .booking-page-header a {

            color:
                #b9b5c7;

            font-size:
                13px;

            font-weight:
                700;

        }


        .booking-page-header h1 {

            margin-top:
                22px;

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                clamp(
                    40px,
                    5vw,
                    60px
                );

            letter-spacing:
                -2px;

        }


        .booking-page-header p {

            color:
                #aaa7b8;

            margin-top:
                10px;

        }


        .booking-section {

            padding:
                55px 0 100px;

        }


        .booking-layout {

            display:
                grid;

            grid-template-columns:
                minmax(0,1.3fr)
                minmax(320px,.7fr);

            gap:
                30px;

            align-items:
                start;

        }


        .ticket-card,
        .summary-card {

            background:
                white;

            border:
                1px solid #eae8f0;

            border-radius:
                20px;

            box-shadow:
                0 18px 45px
                rgba(20,18,38,.06);

        }


        .ticket-card {

            padding:
                34px;

        }


        .small-title {

            color:
                #7559ff;

            font-size:
                11px;

            font-weight:
                800;

            letter-spacing:
                1.5px;

        }


        .ticket-card h2 {

            margin-top:
                8px;

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                28px;

        }


        .selected-event {

            display:
                flex;

            gap:
                18px;

            margin-top:
                28px;

            padding:
                20px;

            border:
                1px solid #eceaf2;

            background:
                #f8f7fc;

            border-radius:
                15px;

        }


        .event-icon {

            width:
                62px;

            height:
                62px;

            flex-shrink:
                0;

            display:
                grid;

            place-items:
                center;

            border-radius:
                14px;

            color:
                white;

            font-size:
                24px;

            background:
                linear-gradient(
                    135deg,
                    #8065ff,
                    #5d43dc
                );

        }


        .selected-event h3 {

            font-family:
                "Manrope",
                sans-serif;

            margin-bottom:
                6px;

        }


        .selected-event p {

            color:
                #858191;

            font-size:
                13px;

            line-height:
                1.6;

        }


        .quantity-area {

            margin-top:
                35px;

        }


        .quantity-area h3 {

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                18px;

            margin-bottom:
                6px;

        }


        .quantity-area > p {

            color:
                #8c8897;

            font-size:
                13px;

        }


        .quantity-control {

            display:
                flex;

            width:
                max-content;

            margin-top:
                20px;

            overflow:
                hidden;

            border:
                1px solid #dfdde8;

            border-radius:
                12px;

        }


        .quantity-control button {

            width:
                50px;

            height:
                50px;

            border:
                none;

            cursor:
                pointer;

            background:
                #f6f5fa;

            font-size:
                21px;

        }


        .quantity-control input {

            width:
                75px;

            border:
                none;

            border-left:
                1px solid #dfdde8;

            border-right:
                1px solid #dfdde8;

            outline:
                none;

            text-align:
                center;

            font-size:
                16px;

            font-weight:
                800;

        }


        .availability-note {

            margin-top:
                10px;

            color:
                #9995a4;

            font-size:
                11px;

        }


        .customer-box {

            display:
                flex;

            align-items:
                center;

            gap:
                13px;

            margin-top:
                35px;

            padding:
                17px;

            background:
                #f8f7fc;

            border:
                1px solid #eceaf2;

            border-radius:
                13px;

        }


        .customer-avatar {

            width:
                44px;

            height:
                44px;

            display:
                grid;

            place-items:
                center;

            border-radius:
                50%;

            background:
                #ebe7ff;

            color:
                #7559ff;

            font-weight:
                800;

        }


        .customer-box small {

            display:
                block;

            color:
                #9995a4;

            margin-bottom:
                3px;

        }


        .summary-card {

            position:
                sticky;

            top:
                105px;

            overflow:
                hidden;

        }


        .summary-header {

            padding:
                28px;

            color:
                white;

            background:
                linear-gradient(
                    135deg,
                    #171529,
                    #292050
                );

        }


        .summary-header span {

            color:
                #aaa5bb;

            font-size:
                10px;

            letter-spacing:
                1.3px;

        }


        .summary-header h2 {

            margin-top:
                7px;

            font-family:
                "Manrope",
                sans-serif;

        }


        .summary-body {

            padding:
                27px;

        }


        .summary-row {

            display:
                flex;

            justify-content:
                space-between;

            gap:
                20px;

            padding:
                13px 0;

            border-bottom:
                1px solid #efedf3;

            font-size:
                13px;

        }


        .summary-row span {

            color:
                #8b8797;

        }


        .summary-row strong {

            text-align:
                right;

        }


        .summary-total {

            display:
                flex;

            justify-content:
                space-between;

            align-items:
                center;

            margin-top:
                23px;

        }


        .summary-total span {

            color:
                #777384;

        }


        .summary-total strong {

            color:
                #7559ff;

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                28px;

        }


        .confirm-btn {

            width:
                100%;

            margin-top:
                22px;

            padding:
                15px;

            border:
                none;

            border-radius:
                11px;

            cursor:
                pointer;

            background:
                #7559ff;

            color:
                white;

            font-size:
                14px;

            font-weight:
                800;

        }


        .confirm-btn:disabled {

            opacity:
                .6;

            cursor:
                not-allowed;

        }


        .booking-message {

            display:
                none;

            margin-top:
                15px;

            padding:
                14px;

            border-radius:
                10px;

            font-size:
                12px;

            line-height:
                1.6;

        }


        .booking-message.success {

            display:
                block;

            background:
                #edf9f4;

            color:
                #177657;

        }


        .booking-message.error {

            display:
                block;

            background:
                #fff0f0;

            color:
                #ad3d3d;

        }


        .loading {

            padding:
                80px;

            text-align:
                center;

            color:
                #8b8797;

        }


        @media (
            max-width: 850px
        ) {

            .booking-layout {

                grid-template-columns:
                    1fr;

            }


            .summary-card {

                position:
                    static;

            }

        }

    



.booking-page { background: linear-gradient(180deg,#fff8fc,#fff1f7 60%,#f5f1ff) !important; }
.booking-page-header h1 { color: #2a173b !important; }
.booking-page-header h1 span { color: #e63f86 !important; }
.booking-page-header a { color: #d9347b !important; }
.ticket-card, .summary-card { border: 1px solid rgba(240,79,145,.13) !important; border-radius: 24px !important; box-shadow: 0 16px 38px rgba(74,29,79,.08) !important; }
.ticket-card { background: linear-gradient(145deg,#fff,#fffafd) !important; }
.summary-card { background: #fff !important; }
.small-title { color: #e03b81 !important; }
.selected-event { background: linear-gradient(120deg,#fff0f6,#fff4e9) !important; border: 1px solid #f7d6e6 !important; border-radius: 18px !important; }
.event-icon { background: linear-gradient(135deg,#6654f0,#f04f91) !important; box-shadow: 0 8px 17px rgba(102,84,240,.18) !important; }
.quantity-control { border: 1px solid #f0d8e7 !important; border-radius: 15px !important; overflow: hidden !important; }
.quantity-control button { background: #fff0f6 !important; color: #d9347b !important; }
.quantity-control button:hover { background: #fbd6e7 !important; }
.availability-note { background: #e8fbf6 !important; color: #168573 !important; border-radius: 14px !important; }
.customer-box { background: #fff7fb !important; border: 1px solid #f3deea !important; border-radius: 18px !important; }
.customer-avatar { background: linear-gradient(135deg,#ff9855,#f04f91) !important; }
.summary-header { background: linear-gradient(115deg,#38204f,#663275) !important; border-radius: 22px 22px 0 0 !important; }
.summary-total { background: #fff0f6 !important; border: 1px dashed #f1a8c9 !important; border-radius: 15px !important; }
.summary-total strong { color: #d9347b !important; }
.confirm-btn { background: linear-gradient(115deg,#f04f91,#ff795f) !important; box-shadow: 0 11px 25px rgba(240,79,145,.22) !important; border-radius: 14px !important; }
.confirm-btn:not(:disabled):hover { transform: translateY(-2px) !important; }
.booking-message.success { background: #e4faef !important; color: #14784e !important; }
.booking-message.error { background: #fff0f2 !important; color: #be3252 !important; }


</style>

    <link rel="stylesheet" href="css/golive-inspired.css">

</head>


<body class="booking-page">


<header class="navbar">

    <div class="container nav-container">


        <a href="index.php"
           class="brand">

            <div class="brand-icon">
                E
            </div>

            <span>
                Event<span class="brand-purple">ify</span>
            </span>

        </a>


        <nav class="nav-links">

            <a href="index.php">
                Home
            </a>

            <a href="events.php">
                Events
            </a>

            <a href="bookings.php">
                My Bookings
            </a>

        </nav>


        <div
            class="nav-actions"
            id="authNavigation"
        >
        </div>

    </div>

</header>



<section class="booking-page-header">

    <div class="container">

        <a
            href="#"
            id="backLink"
        >
            ← Back to Event
        </a>

        <h1>
            Reserve your tickets.
        </h1>

        <p>
            Your booking will be securely linked
            to your Eventify account.
        </p>

    </div>

</section>



<main class="booking-section">

    <div class="container">

        <div id="bookingContainer">

            <div class="loading">
                Checking your account...
            </div>

        </div>

    </div>

</main>



<footer class="footer">

    <div class="container footer-content">

        <a href="index.php"
           class="brand footer-brand">

            <div class="brand-icon">
                E
            </div>

            <span>
                Event<span class="brand-purple">ify</span>
            </span>

        </a>

        <p>
            Event Ticketing & Venue Booking System
        </p>

        <p class="copyright">
            © 2026 Eventify
        </p>

    </div>

</footer>



<script>





const token =
    localStorage.getItem(
        "eventify_token"
    );


const storedUser =
    JSON.parse(
        localStorage.getItem(
            "eventify_user"
        ) || "null"
    );


const params =
    new URLSearchParams(
        window.location.search
    );


const eventId =
    params.get("event_id");


const bookingContainer =
    document.getElementById(
        "bookingContainer"
    );


const backLink =
    document.getElementById(
        "backLink"
    );


const authNavigation =
    document.getElementById(
        "authNavigation"
    );


let currentEvent = null;

let currentUser = null;







async function initialisePage() {


    if (!token) {

        redirectToLogin();

        return;

    }


    if (!eventId) {

        showError(
            "No event was selected."
        );

        return;

    }


    backLink.href =
        "event-details.php?id="
        + encodeURIComponent(
            eventId
        );


    



    try {


        const authResponse =
            await fetch(
                "auth/me.php",
                {
                    headers: {

                        Authorization:
                            "Bearer "
                            + token

                    }
                }
            );


        const authResult =
            await authResponse.json();


        if (
            !authResponse.ok ||
            authResult.status
            !== "success"
        ) {

            clearLogin();

            redirectToLogin();

            return;

        }


        currentUser =
            authResult.user;


        if (
            currentUser.role
            !== "Customer"
        ) {

            showError(
                "Only customer accounts can book tickets."
            );

            return;

        }


        updateNavbar();


        await loadEvent();


    } catch (error) {


        showError(
            "Unable to verify your account."
        );

    }

}







async function loadEvent() {


    try {


        const response =
            await fetch(
                "api/events.php?event_id="
                + encodeURIComponent(
                    eventId
                )
            );


        const result =
            await response.json();


        if (
            !response.ok ||
            result.status
            !== "success"
        ) {

            throw new Error(
                result.message ||
                "Event unavailable"
            );

        }


        currentEvent =
            result.data;


        displayBookingForm();


    } catch (error) {


        showError(
            error.message
        );

    }

}







function displayBookingForm() {


    const eventDate =
        new Date(
            currentEvent.event_date
            + "T00:00:00"
        );


    const formattedDate =
        eventDate.toLocaleDateString(
            "en-MY",
            {
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        );


    const ticketPrice =
        Number(
            currentEvent.ticket_price
        );


    const initial =
        currentUser.name
            .charAt(0)
            .toUpperCase();


    bookingContainer.innerHTML = `

        <div class="booking-layout">


            <section class="ticket-card">


                <span class="small-title">
                    YOUR BOOKING
                </span>


                <h2>
                    Select your tickets
                </h2>


                <div class="selected-event">


                    <div class="event-icon">
                        🎟
                    </div>


                    <div>

                        <h3>

                            ${escapeHTML(
                                currentEvent.event_name
                            )}

                        </h3>

                        <p>

                            ${formattedDate}

                            <br>

                            ${escapeHTML(
                                currentEvent.venue_name
                            )}

                        </p>

                    </div>

                </div>



                <div class="quantity-area">

                    <h3>
                        Ticket Quantity
                    </h3>

                    <p>
                        Maximum 10 tickets per booking.
                    </p>


                    <div class="quantity-control">

                        <button
                            type="button"
                            id="minusBtn"
                        >
                            −
                        </button>

                        <input
                            type="number"
                            id="quantity"
                            value="1"
                            min="1"
                            max="10"
                        >

                        <button
                            type="button"
                            id="plusBtn"
                        >
                            +
                        </button>

                    </div>


                    <div class="availability-note">

                        ${Number(
                            currentEvent.available_tickets
                        ).toLocaleString()}

                        tickets currently available.

                    </div>

                </div>



                <div class="customer-box">

                    <div class="customer-avatar">

                        ${initial}

                    </div>

                    <div>

                        <small>
                            Booking as
                        </small>

                        <strong>

                            ${escapeHTML(
                                currentUser.name
                            )}

                        </strong>

                    </div>

                </div>


            </section>



            <aside class="summary-card">


                <div class="summary-header">

                    <span>
                        ORDER
                    </span>

                    <h2>
                        Booking Summary
                    </h2>

                </div>


                <div class="summary-body">


                    <div class="summary-row">

                        <span>
                            Price per ticket
                        </span>

                        <strong>

                            RM ${ticketPrice.toFixed(2)}

                        </strong>

                    </div>


                    <div class="summary-row">

                        <span>
                            Quantity
                        </span>

                        <strong id="summaryQuantity">
                            1
                        </strong>

                    </div>


                    <div class="summary-row">

                        <span>
                            Event
                        </span>

                        <strong>

                            ${escapeHTML(
                                currentEvent.event_name
                            )}

                        </strong>

                    </div>


                    <div class="summary-total">

                        <span>
                            Total
                        </span>

                        <strong id="totalPrice">

                            RM ${ticketPrice.toFixed(2)}

                        </strong>

                    </div>


                    <button
                        type="button"
                        class="confirm-btn"
                        id="confirmBtn"
                    >

                        Confirm Booking →

                    </button>


                    <div
                        class="booking-message"
                        id="bookingMessage"
                    >
                    </div>

                </div>


            </aside>


        </div>

    `;


    setupControls();

}







function setupControls() {


    const quantity =
        document.getElementById(
            "quantity"
        );


    const minus =
        document.getElementById(
            "minusBtn"
        );


    const plus =
        document.getElementById(
            "plusBtn"
        );


    const maximum =
        Math.min(
            10,
            Number(
                currentEvent.available_tickets
            )
        );


    minus.addEventListener(
        "click",
        function () {

            let value =
                Number(
                    quantity.value
                );


            if (value > 1) {

                quantity.value =
                    value - 1;

                updateTotal();

            }

        }
    );


    plus.addEventListener(
        "click",
        function () {

            let value =
                Number(
                    quantity.value
                );


            if (value < maximum) {

                quantity.value =
                    value + 1;

                updateTotal();

            }

        }
    );


    quantity.addEventListener(
        "input",
        function () {

            let value =
                Number(
                    quantity.value
                );


            if (
                !Number.isInteger(value)
                ||
                value < 1
            ) {

                value = 1;

            }


            if (value > maximum) {

                value =
                    maximum;

            }


            quantity.value =
                value;


            updateTotal();

        }
    );


    document
        .getElementById(
            "confirmBtn"
        )
        .addEventListener(
            "click",
            createBooking
        );

}







function updateTotal() {


    const quantity =
        Number(
            document
                .getElementById(
                    "quantity"
                )
                .value
        );


    const total =
        quantity *
        Number(
            currentEvent.ticket_price
        );


    document
        .getElementById(
            "summaryQuantity"
        )
        .textContent =
            quantity;


    document
        .getElementById(
            "totalPrice"
        )
        .textContent =
            "RM "
            + total.toFixed(2);

}







async function createBooking() {


    const quantity =
        Number(
            document
                .getElementById(
                    "quantity"
                )
                .value
        );


    const button =
        document.getElementById(
            "confirmBtn"
        );


    const message =
        document.getElementById(
            "bookingMessage"
        );


    button.disabled =
        true;


    button.textContent =
        "Confirming...";


    try {


        const response =
            await fetch(
                "api/bookings.php",
                {

                    method:
                        "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        Authorization:
                            "Bearer "
                            + token

                    },

                    body:
                        JSON.stringify({

                            event_id:
                                Number(eventId),

                            quantity:
                                quantity

                        })

                }
            );


        const result =
            await response.json();


        if (response.status === 401) {

            clearLogin();

            redirectToLogin();

            return;

        }


        if (
            response.ok &&
            result.status
            === "success"
        ) {


            message.className =
                "booking-message success";


            message.innerHTML = `

                ✓ Booking confirmed!

                <br><br>

                Booking ID:
                <strong>
                    #${result.booking_id}
                </strong>

                <br>

                Customer:
                <strong>
                    ${escapeHTML(
                        result.customer
                    )}
                </strong>

                <br>

                Total:
                <strong>
                    RM ${result.total_amount}
                </strong>

            `;


            button.textContent =
                "Booking Confirmed ✓";


            setTimeout(
                function () {

                    window.location.href =
                        "bookings.php";

                },
                1700
            );


        } else {


            throw new Error(
                result.message ||
                "Unable to create booking"
            );

        }


    } catch (error) {


        message.className =
            "booking-message error";


        message.textContent =
            error.message;


        button.disabled =
            false;


        button.textContent =
            "Confirm Booking →";

    }

}







function updateNavbar() {


    authNavigation.innerHTML = `

        <span
            style="
                font-size:13px;
                font-weight:700;
                color:#555263;
            "
        >

            ${escapeHTML(
                currentUser.name
            )}

        </span>

        <button
            type="button"
            onclick="logout()"
            style="
                border:none;
                background:#11101d;
                color:white;
                padding:11px 17px;
                border-radius:9px;
                cursor:pointer;
                font-weight:700;
            "
        >

            Logout

        </button>

    `;

}



function logout() {


    clearLogin();


    window.location.href =
        "login.php";

}



function clearLogin() {


    localStorage.removeItem(
        "eventify_token"
    );


    localStorage.removeItem(
        "eventify_user"
    );

}







function redirectToLogin() {


    const returnUrl =
        encodeURIComponent(
            window.location.href
        );


    window.location.href =
        "login.php?return="
        + returnUrl;

}







function showError(message) {


    bookingContainer.innerHTML = `

        <div class="ticket-card">

            <h2>
                Booking unavailable
            </h2>

            <p
                style="
                    color:#777;
                    margin-top:10px;
                "
            >

                ${escapeHTML(message)}

            </p>

        </div>

    `;

}







function escapeHTML(value) {


    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replaceAll("&", "&amp;")

        .replaceAll("<", "&lt;")

        .replaceAll(">", "&gt;")

        .replaceAll('"', "&quot;")

        .replaceAll("'", "&#039;");

}



initialisePage();

</script>


</body>

</html>