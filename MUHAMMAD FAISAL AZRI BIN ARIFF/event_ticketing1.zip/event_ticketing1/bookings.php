<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Bookings | Eventify</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >


    <style>

        .bookings-page {

            min-height:
                100vh;

            background:
                #f7f7fb;

        }


        .bookings-hero {

            padding:
                75px 0 55px;

            color:
                white;

            background:
                radial-gradient(
                    circle at 80% 15%,
                    rgba(117,89,255,.25),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #11101d,
                    #211943
                );

        }


        .bookings-hero .eyebrow {

            color:
                #a99bff;

        }


        .bookings-hero h1 {

            margin-top:
                10px;

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                58px;

            letter-spacing:
                -2px;

        }


        .bookings-hero p {

            color:
                #aaa7b9;

            margin-top:
                10px;

        }


        .bookings-section {

            padding:
                55px 0 100px;

        }


        .bookings-header {

            display:
                flex;

            justify-content:
                space-between;

            align-items:
                center;

            margin-bottom:
                30px;

        }


        .bookings-header h2 {

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                30px;

        }


        .booking-count {

            background:
                white;

            border:
                1px solid #e8e6ee;

            border-radius:
                10px;

            padding:
                10px 15px;

            color:
                #777485;

            font-size:
                13px;

        }


        .booking-count strong {

            color:
                #7559ff;

        }


        .bookings-grid {

            display:
                grid;

            gap:
                22px;

        }


        .booking-item {

            display:
                grid;

            grid-template-columns:
                120px 1fr auto;

            background:
                white;

            border:
                1px solid #ebe9f0;

            border-radius:
                18px;

            overflow:
                hidden;

            box-shadow:
                0 15px 35px
                rgba(24,20,50,.05);

            transition:
                .3s;

        }


        .booking-item:hover {

            transform:
                translateY(-4px);

        }


        .booking-item.cancelled {

            opacity:
                .65;

        }


        .booking-date {

            display:
                flex;

            flex-direction:
                column;

            align-items:
                center;

            justify-content:
                center;

            min-height:
                160px;

            color:
                white;

            background:
                linear-gradient(
                    145deg,
                    #7257f1,
                    #4a35b7
                );

        }


        .booking-date strong {

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                32px;

        }


        .booking-date span {

            font-size:
                11px;

            font-weight:
                800;

        }


        .booking-info {

            padding:
                26px 28px;

        }


        .booking-top {

            display:
                flex;

            align-items:
                center;

            gap:
                10px;

            margin-bottom:
                10px;

        }


        .booking-id {

            color:
                #9692a1;

            font-size:
                11px;

        }


        .status {

            padding:
                5px 9px;

            border-radius:
                100px;

            font-size:
                10px;

            font-weight:
                800;

        }


        .confirmed {

            color:
                #18815e;

            background:
                #eaf8f2;

        }


        .cancelled-status {

            color:
                #b54c4c;

            background:
                #fff0f0;

        }


        .pending {

            color:
                #987010;

            background:
                #fff6df;

        }


        .booking-info h3 {

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                21px;

            margin-bottom:
                13px;

        }


        .booking-details {

            display:
                flex;

            flex-wrap:
                wrap;

            gap:
                18px;

            color:
                #7e7a8a;

            font-size:
                13px;

        }


        .booking-side {

            min-width:
                200px;

            padding:
                25px;

            border-left:
                1px solid #efedf3;

            display:
                flex;

            flex-direction:
                column;

            justify-content:
                center;

            align-items:
                flex-end;

        }


        .booking-side small {

            color:
                #9996a5;

            font-size:
                10px;

            text-transform:
                uppercase;

        }


        .booking-side strong {

            color:
                #7559ff;

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                24px;

            margin-top:
                4px;

        }


        .cancel-btn {

            margin-top:
                15px;

            border:
                none;

            border-radius:
                9px;

            padding:
                10px 14px;

            background:
                #fff0f0;

            color:
                #b74343;

            font-weight:
                700;

            font-size:
                11px;

            cursor:
                pointer;

        }


        .empty-state {

            min-height:
                270px;

            display:
                flex;

            flex-direction:
                column;

            align-items:
                center;

            justify-content:
                center;

            text-align:
                center;

            background:
                white;

            border:
                1px solid #ebe9f0;

            border-radius:
                18px;

            color:
                #898595;

        }


        .empty-state h3 {

            color:
                #282632;

            margin-bottom:
                7px;

        }


        .browse-btn {

            margin-top:
                17px;

            padding:
                11px 16px;

            border-radius:
                9px;

            background:
                #7559ff;

            color:
                white;

            font-weight:
                700;

        }


        .modal {

            position:
                fixed;

            inset:
                0;

            z-index:
                5000;

            display:
                none;

            align-items:
                center;

            justify-content:
                center;

            background:
                rgba(10,9,17,.68);

            backdrop-filter:
                blur(5px);

        }


        .modal.show {

            display:
                flex;

        }


        .modal-card {

            width:
                min(
                    420px,
                    90%
                );

            padding:
                32px;

            text-align:
                center;

            background:
                white;

            border-radius:
                20px;

        }


        .modal-card h2 {

            font-family:
                "Manrope",
                sans-serif;

        }


        .modal-card p {

            margin-top:
                9px;

            color:
                #807c8c;

            font-size:
                13px;

            line-height:
                1.6;

        }


        .modal-actions {

            display:
                flex;

            gap:
                10px;

            margin-top:
                24px;

        }


        .modal-actions button {

            flex:
                1;

            padding:
                12px;

            border:
                none;

            border-radius:
                9px;

            cursor:
                pointer;

            font-weight:
                700;

        }


        .keep-btn {

            background:
                #f2f1f6;

        }


        .confirm-cancel {

            background:
                #c24848;

            color:
                white;

        }


        @media (
            max-width: 800px
        ) {

            .booking-item {

                grid-template-columns:
                    90px 1fr;

            }


            .booking-side {

                grid-column:
                    1 / -1;

                align-items:
                    flex-start;

                border-left:
                    none;

                border-top:
                    1px solid #efedf3;

            }

        }

    
.pdf-ticket-btn {
    border: 0;
    border-radius: 999px;
    background: linear-gradient(115deg, #6654f0, #f04f91);
    color: #fff;
    font: inherit;
    font-size: 12px;
    font-weight: 800;
    cursor: pointer;
    padding: 11px 13px;
    margin: 10px 0;
    display: block;
    width: 100%;
    box-shadow: 0 8px 18px rgba(102, 84, 240, .2);
    transition: transform .2s ease, opacity .2s ease;
}
.pdf-ticket-btn:hover { transform: translateY(-1px); }
.pdf-ticket-btn:disabled { opacity: .65; cursor: wait; transform: none; }



.bookings-page { background: linear-gradient(180deg,#fff8fc,#fff4f8 54%,#f6f2ff) !important; }
.bookings-hero { background: radial-gradient(circle at 87% 12%,rgba(255,152,85,.35),transparent 26%),linear-gradient(120deg,#2b173f,#512466 65%,#6a327d) !important; }
.bookings-hero .eyebrow { color: #ffb8d6 !important; }
.bookings-hero h1 span { color: #ffb8d6 !important; }
.bookings-section { background: transparent !important; }
.booking-count { background: #fff0f6 !important; color: #bc2869 !important; border-color: #ffd1e3 !important; }
.booking-item { background: #fff !important; border: 1px solid rgba(240,79,145,.13) !important; border-radius: 22px !important; box-shadow: 0 12px 30px rgba(74,29,79,.06) !important; }
.booking-item:hover { border-color: #f1a5c8 !important; box-shadow: 0 19px 35px rgba(74,29,79,.11) !important; }
.booking-date { background: linear-gradient(145deg,#fff0f6,#fff5e9) !important; border: 1px solid #f8dbe9 !important; border-radius: 16px !important; }
.booking-date strong { color: #d9347b !important; }
.booking-id { background: #f4f0ff !important; color: #6654f0 !important; }
.status.confirmed { color: #13784f !important; background: #e4f9ef !important; }
.status.cancelled-status { color: #bc3152 !important; background: #fff0f3 !important; }
.status.pending { color: #9b620d !important; background: #fff5dd !important; }
.booking-side strong { color: #d9347b !important; }
.cancel-btn { background: #fff0f3 !important; color: #c93f5d !important; border-radius: 999px !important; }
.empty-state { background: #fff !important; border: 1px dashed #efb4d0 !important; border-radius: 24px !important; }
.empty-state h3 { color: #321d47 !important; }
.browse-btn { background: linear-gradient(115deg,#f04f91,#ff795f) !important; border-radius: 999px !important; box-shadow: 0 9px 22px rgba(240,79,145,.2) !important; }
.modal-card { border: 1px solid #f2dbe8 !important; border-radius: 24px !important; box-shadow: 0 25px 65px rgba(39,13,52,.24) !important; }
.keep-btn { background: #f4effa !important; color: #4c375d !important; border-radius: 999px !important; }
.confirm-cancel { background: linear-gradient(115deg,#f04f91,#ff795f) !important; border-radius: 999px !important; }


</style>

    <link rel="stylesheet" href="css/golive-inspired.css">

</head>


<body class="bookings-page">


<header class="navbar">

    <div class="container nav-container">

        <a
            href="index.php"
            class="brand"
        >

            <div class="brand-icon">
                E
            </div>

            <span>
                Event<span class="brand-purple">ify</span>
            </span>

        </a>


        <nav class="nav-links">

            <a href="index.php">
                Home
            </a>

            <a href="events.php">
                Events
            </a>

            <a
                href="bookings.php"
                class="active"
            >
                My Bookings
            </a>

        </nav>


        <div
            class="nav-actions"
            id="authNavigation"
        >
        </div>

    </div>

</header>



<section class="bookings-hero">

    <div class="container">

        <span class="eyebrow">
            YOUR EXPERIENCES
        </span>

        <h1>
            My Bookings
        </h1>

        <p id="welcomeText">
            Loading your reservations...
        </p>

    </div>

</section>



<main class="bookings-section">

    <div class="container">


        <div class="bookings-header">

            <h2>
                Your Reservations
            </h2>


            <div class="booking-count">

                <strong id="bookingCount">
                    0
                </strong>

                bookings

            </div>

        </div>


        <div
            class="bookings-grid"
            id="bookingsGrid"
        >

            <div class="empty-state">
                Loading your bookings...
            </div>

        </div>


    </div>

</main>



<footer class="footer">

    <div class="container footer-content">

        <a
            href="index.php"
            class="brand footer-brand"
        >

            <div class="brand-icon">
                E
            </div>

            <span>
                Event<span class="brand-purple">ify</span>
            </span>

        </a>

        <p>
            Event Ticketing & Venue Booking System
        </p>

        <p class="copyright">
            © 2026 Eventify
        </p>

    </div>

</footer>



<div
    class="modal"
    id="cancelModal"
>

    <div class="modal-card">

        <h2>
            Cancel booking?
        </h2>

        <p>
            Your tickets will be returned
            to the event's availability.
        </p>


        <div class="modal-actions">

            <button
                class="keep-btn"
                id="keepBtn"
            >
                Keep Booking
            </button>

            <button
                class="confirm-cancel"
                id="confirmCancel"
            >
                Yes, Cancel
            </button>

        </div>

    </div>

</div>



<script>

const token =
    localStorage.getItem(
        "eventify_token"
    );


const authNavigation =
    document.getElementById(
        "authNavigation"
    );


const bookingsGrid =
    document.getElementById(
        "bookingsGrid"
    );


const bookingCount =
    document.getElementById(
        "bookingCount"
    );


const welcomeText =
    document.getElementById(
        "welcomeText"
    );


const modal =
    document.getElementById(
        "cancelModal"
    );


const keepBtn =
    document.getElementById(
        "keepBtn"
    );


const confirmCancel =
    document.getElementById(
        "confirmCancel"
    );


let currentUser = null;

let selectedBooking = null;








async function downloadBookingPDF(bookingId, button) {
    const originalText = button ? button.textContent : 'Download PDF';
    if (button) {
        button.disabled = true;
        button.textContent = 'Preparing PDF...';
    }

    try {
        const response = await fetch(
            'api/ticket-pdf.php?booking_id=' + encodeURIComponent(bookingId),
            {
                headers: { Authorization: 'Bearer ' + token },
                cache: 'no-store'
            }
        );

        const contentType = (response.headers.get('Content-Type') || '').toLowerCase();
        if (!response.ok || !contentType.includes('application/pdf')) {
            const error = await response.json().catch(() => ({}));
            throw new Error(error.message || 'Unable to generate the PDF confirmation.');
        }

        const blob = await response.blob();
        const objectUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = objectUrl;
        link.download = 'Eventify-Booking-' + Number(bookingId) + '.pdf';
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    } catch (error) {
        alert(error.message || 'Unable to download the PDF confirmation.');
    } finally {
        if (button) {
            button.disabled = false;
            button.textContent = originalText;
        }
    }
}





async function initialise() {


    if (!token) {

        window.location.href =
            "login.php";

        return;

    }


    try {


        const response =
            await fetch(
                "auth/me.php",
                {
                    headers: {

                        Authorization:
                            "Bearer "
                            + token

                    }
                }
            );


        const result =
            await response.json();


        if (
            !response.ok ||
            result.status !== "success"
        ) {

            logout();

            return;

        }


        currentUser =
            result.user;


        updateNavbar();


        welcomeText.textContent =
            "Welcome back, "
            + currentUser.name
            + ". Here are your reservations.";


        await loadBookings();


    } catch (error) {


        bookingsGrid.innerHTML = `

            <div class="empty-state">

                Unable to verify your account.

            </div>

        `;

    }

}







async function loadBookings() {


    try {


        const response =
            await fetch(
                "api/bookings.php",
                {
                    headers: {

                        Authorization:
                            "Bearer "
                            + token

                    }
                }
            );


        const result =
            await response.json();


        if (response.status === 401) {

            logout();

            return;

        }


        if (
            !response.ok ||
            result.status !== "success"
        ) {

            throw new Error(
                result.message
            );

        }


        displayBookings(
            result.data
        );


    } catch (error) {


        bookingsGrid.innerHTML = `

            <div class="empty-state">

                <h3>
                    Unable to load bookings
                </h3>

                <p>
                    ${escapeHTML(
                        error.message
                    )}
                </p>

            </div>

        `;

    }

}







function displayBookings(bookings) {


    bookingsGrid.innerHTML = "";


    bookingCount.textContent =
        bookings.length;


    if (bookings.length === 0) {


        bookingsGrid.innerHTML = `

            <div class="empty-state">

                <h3>
                    No bookings yet
                </h3>

                <p>
                    Find your next experience.
                </p>

                <a
                    href="events.php"
                    class="browse-btn"
                >
                    Browse Events
                </a>

            </div>

        `;


        return;

    }



    bookings.forEach(
        booking => {


            const date =
                new Date(
                    booking.event_date
                    + "T00:00:00"
                );


            const day =
                String(
                    date.getDate()
                ).padStart(
                    2,
                    "0"
                );


            const month =
                date.toLocaleString(
                    "en-US",
                    {
                        month: "short"
                    }
                ).toUpperCase();


            const fullDate =
                date.toLocaleDateString(
                    "en-MY",
                    {
                        day: "numeric",
                        month: "long",
                        year: "numeric"
                    }
                );


            const cancelled =
                booking.booking_status
                === "Cancelled";


            let statusClass =
                "pending";


            if (
                booking.booking_status
                === "Confirmed"
            ) {

                statusClass =
                    "confirmed";

            }


            if (cancelled) {

                statusClass =
                    "cancelled-status";

            }


            const card =
                document.createElement(
                    "article"
                );


            card.className =
                "booking-item"
                +
                (
                    cancelled
                    ? " cancelled"
                    : ""
                );


            card.innerHTML = `

                <div class="booking-date">

                    <strong>
                        ${day}
                    </strong>

                    <span>
                        ${month}
                    </span>

                </div>


                <div class="booking-info">


                    <div class="booking-top">

                        <span class="booking-id">

                            Booking
                            #${booking.booking_id}

                        </span>


                        <span
                            class="
                                status
                                ${statusClass}
                            "
                        >

                            ${escapeHTML(
                                booking.booking_status
                            )}

                        </span>

                    </div>


                    <h3>

                        ${escapeHTML(
                            booking.event_name
                        )}

                    </h3>


                    <div class="booking-details">

                        <span>
                            ◷ ${fullDate}
                        </span>

                        <span>

                            ⌖
                            ${escapeHTML(
                                booking.venue_name
                            )}

                        </span>

                        <span>

                            🎟
                            ${booking.quantity}
                            ticket(s)

                        </span>

                    </div>

                </div>


                <div class="booking-side">

                    <small>
                        Total
                    </small>

                    <strong>

                        RM ${Number(
                            booking.total_amount
                        ).toFixed(2)}

                    </strong>


                    <button class="pdf-ticket-btn" type="button"
                        onclick="downloadBookingPDF(${Number(booking.booking_id)}, this)">
                        ${booking.booking_status === "Confirmed" ? "Download PDF Ticket" : "Download PDF Confirmation"}
                    </button>

                    ${
                        !cancelled

                        ?

                        `

                        <button
                            class="cancel-btn"
                            onclick="
                                openCancel(
                                    ${booking.booking_id}
                                )
                            "
                        >

                            Cancel Booking

                        </button>

                        `

                        :

                        ""

                    }

                </div>

            `;


            bookingsGrid.appendChild(
                card
            );

        }
    );

}







function openCancel(bookingId) {


    selectedBooking =
        bookingId;


    modal.classList.add(
        "show"
    );

}



keepBtn.addEventListener(
    "click",
    function () {

        selectedBooking =
            null;


        modal.classList.remove(
            "show"
        );

    }
);



confirmCancel.addEventListener(
    "click",
    async function () {


        if (!selectedBooking) {

            return;

        }


        confirmCancel.disabled =
            true;


        confirmCancel.textContent =
            "Cancelling...";


        try {


            const response =
                await fetch(
                    "api/bookings.php",
                    {

                        method:
                            "DELETE",

                        headers: {

                            "Content-Type":
                                "application/json",

                            Authorization:
                                "Bearer "
                                + token

                        },

                        body:
                            JSON.stringify({

                                booking_id:
                                    selectedBooking

                            })

                    }
                );


            const result =
                await response.json();


            if (
                !response.ok ||
                result.status !== "success"
            ) {

                throw new Error(
                    result.message
                );

            }


            modal.classList.remove(
                "show"
            );


            selectedBooking =
                null;


            await loadBookings();


        } catch (error) {


            alert(
                error.message
            );


        } finally {


            confirmCancel.disabled =
                false;


            confirmCancel.textContent =
                "Yes, Cancel";

        }

    }
);







function updateNavbar() {


    authNavigation.innerHTML = `

        <span
            style="
                font-weight:700;
                font-size:13px;
                color:#555263;
            "
        >

            ${escapeHTML(
                currentUser.name
            )}

        </span>


        <button
            onclick="logout()"
            style="
                border:none;
                padding:11px 17px;
                background:#11101d;
                color:white;
                border-radius:9px;
                cursor:pointer;
                font-weight:700;
            "
        >

            Logout

        </button>

    `;

}



function logout() {


    localStorage.removeItem(
        "eventify_token"
    );


    localStorage.removeItem(
        "eventify_user"
    );


    window.location.href =
        "login.php";

}







function escapeHTML(value) {


    return String(
        value ?? ""
    )

        .replaceAll("&", "&amp;")

        .replaceAll("<", "&lt;")

        .replaceAll(">", "&gt;")

        .replaceAll('"', "&quot;")

        .replaceAll("'", "&#039;");

}



initialise();

</script>


</body>

</html>