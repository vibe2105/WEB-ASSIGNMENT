<?php


declare(strict_types=1);

function eventifyPdfError(int $statusCode, string $message): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private');
    echo json_encode(['status' => 'error', 'message' => $message], JSON_UNESCAPED_SLASHES);
    exit;
}

function eventifyPdfBaseUrl(): string
{
    
    $configuredBaseUrl = trim((string) getenv('EVENTIFY_BASE_URL'));
    if ($configuredBaseUrl !== '') {
        return rtrim($configuredBaseUrl, '/');
    }

    $serverName = (string) ($_SERVER['SERVER_NAME'] ?? '');
    if ($serverName === '' || preg_match('/^[A-Za-z0-9.\-:\[\]]+$/', $serverName) !== 1) {
        eventifyPdfError(500, 'Unable to determine the application host. Set EVENTIFY_BASE_URL in the server environment.');
    }

    $isHttps = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
        || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
    $scheme = $isHttps ? 'https' : 'http';
    $port = (int) ($_SERVER['SERVER_PORT'] ?? ($isHttps ? 443 : 80));
    $portSuffix = (($isHttps && $port === 443) || (!$isHttps && $port === 80) || $port <= 0)
        ? ''
        : ':' . $port;

    
    $scriptName = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/api/ticket-pdf.php'));
    $applicationPath = dirname(dirname($scriptName));
    $applicationPath = ($applicationPath === '/' || $applicationPath === '.' || $applicationPath === '\\')
        ? ''
        : '/' . trim($applicationPath, '/');

    return $scheme . '://' . $serverName . $portSuffix . $applicationPath;
}


function eventifyFetchAuthenticatedUser(string $authorizationHeader): array
{
    $url = eventifyPdfBaseUrl() . '/auth/me.php';
    $responseBody = false;

    if (function_exists('curl_init')) {
        $handle = curl_init($url);
        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: ' . $authorizationHeader,
                'Accept: application/json',
                'Cache-Control: no-cache',
            ],
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_FOLLOWLOCATION => false,
        ]);
        $responseBody = curl_exec($handle);
        $statusCode = (int) curl_getinfo($handle, CURLINFO_HTTP_CODE);
        curl_close($handle);
        if ($responseBody === false || $statusCode < 200 || $statusCode >= 300) {
            return [];
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => "Authorization: " . $authorizationHeader . "\r\nAccept: application/json\r\nCache-Control: no-cache\r\n",
                'timeout' => 8,
                'ignore_errors' => true,
                'follow_location' => 0,
                'max_redirects' => 0,
            ],
        ]);
        $responseBody = @file_get_contents($url, false, $context);
        if ($responseBody === false) {
            return [];
        }
        $statusCode = 0;
        foreach (($http_response_header ?? []) as $responseHeader) {
            if (preg_match('/^HTTP\/\S+\s+(\d{3})/', $responseHeader, $matches) === 1) {
                $statusCode = (int) $matches[1];
            }
        }
        if ($statusCode < 200 || $statusCode >= 300) {
            return [];
        }
    }

    $decoded = json_decode((string) $responseBody, true);
    if (!is_array($decoded) || ($decoded['status'] ?? '') !== 'success' || !is_array($decoded['user'] ?? null)) {
        return [];
    }
    return $decoded['user'];
}


function eventifyFetchAuthorizedBookings(string $authorizationHeader): array
{
    $url = eventifyPdfBaseUrl() . '/api/bookings.php';
    $headers = "Authorization: " . $authorizationHeader . "\r\nAccept: application/json\r\nCache-Control: no-cache\r\n";
    $responseBody = false;
    $statusCode = 0;

    
    if (function_exists('curl_init')) {
        $handle = curl_init($url);
        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: ' . $authorizationHeader,
                'Accept: application/json',
                'Cache-Control: no-cache',
            ],
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_FOLLOWLOCATION => false,
        ]);
        $responseBody = curl_exec($handle);
        $statusCode = (int) curl_getinfo($handle, CURLINFO_HTTP_CODE);
        $curlError = curl_error($handle);
        curl_close($handle);
        if ($responseBody === false) {
            error_log('Eventify PDF endpoint failed to call bookings API: ' . $curlError);
            eventifyPdfError(502, 'Could not retrieve booking details. Please try again.');
        }
    } else {
        
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => $headers,
                'timeout' => 12,
                'ignore_errors' => true,
                'follow_location' => 0,
                'max_redirects' => 0,
            ],
        ]);
        $responseBody = @file_get_contents($url, false, $context);
        foreach (($http_response_header ?? []) as $responseHeader) {
            if (preg_match('/^HTTP\/\S+\s+(\d{3})/', $responseHeader, $matches) === 1) {
                $statusCode = (int) $matches[1];
            }
        }
        if ($responseBody === false) {
            error_log('Eventify PDF endpoint could not reach ' . $url);
            eventifyPdfError(502, 'Could not retrieve booking details. Check that api/bookings.php is available and EVENTIFY_BASE_URL is configured correctly.');
        }
    }

    $decoded = json_decode((string) $responseBody, true);
    if (!is_array($decoded)) {
        eventifyPdfError(502, 'The bookings API returned an unreadable response.');
    }

    if ($statusCode === 401 || $statusCode === 403) {
        eventifyPdfError($statusCode, (string) ($decoded['message'] ?? 'Your session is not authorised to access this booking.'));
    }
    if ($statusCode >= 400 || ($decoded['status'] ?? '') !== 'success') {
        $safeStatus = ($statusCode >= 400 && $statusCode < 600) ? $statusCode : 502;
        eventifyPdfError($safeStatus, (string) ($decoded['message'] ?? 'Unable to retrieve booking details.'));
    }

    if (!isset($decoded['data']) || !is_array($decoded['data'])) {
        eventifyPdfError(502, 'The bookings API response did not contain a booking list.');
    }

    return $decoded['data'];
}

function eventifyPdfValue(array $record, array $possibleKeys, string $fallback = 'Not provided'): string
{
    foreach ($possibleKeys as $key) {
        if (isset($record[$key]) && is_scalar($record[$key]) && trim((string) $record[$key]) !== '') {
            return trim((string) $record[$key]);
        }
    }
    return $fallback;
}

function eventifyPdfMoney($value): string
{
    return 'RM ' . number_format(is_numeric($value) ? (float) $value : 0.0, 2, '.', ',');
}

function eventifyPdfFormatDate(string $value): string
{
    $timestamp = strtotime($value);
    return $timestamp === false ? $value : date('d M Y', $timestamp);
}

function eventifyPdfFormatTime(string $value): string
{
    if ($value === '' || $value === 'Not provided') {
        return 'Not provided';
    }
    $timestamp = strtotime($value);
    return $timestamp === false ? $value : date('g:i A', $timestamp);
}

function eventifyPdfText(string $text, float $x, float $y, int $size = 11, string $font = 'F1', array $color = [0.17, 0.13, 0.22]): string
{
    $converted = function_exists('iconv')
        ? iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text)
        : $text;
    if ($converted === false) {
        $converted = preg_replace('/[^\x20-\x7E]/', '?', $text) ?? '';
    }
    $converted = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', ' ', $converted) ?? '';
    $escaped = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $converted);
    return sprintf(
        "BT /%s %d Tf %.3f %.3f %.3f rg %.2f %.2f Td (%s) Tj ET\n",
        $font,
        $size,
        $color[0], $color[1], $color[2],
        $x, $y, $escaped
    );
}

function eventifyPdfRect(float $x, float $y, float $width, float $height, array $color): string
{
    return sprintf(
        "q %.3f %.3f %.3f rg %.2f %.2f %.2f %.2f re f Q\n",
        $color[0], $color[1], $color[2], $x, $y, $width, $height
    );
}

function eventifyPdfLine(float $x1, float $y1, float $x2, float $y2, array $color = [0.90, 0.87, 0.91], float $width = 1): string
{
    return sprintf(
        "q %.3f %.3f %.3f RG %.2f w %.2f %.2f m %.2f %.2f l S Q\n",
        $color[0], $color[1], $color[2], $width, $x1, $y1, $x2, $y2
    );
}

function eventifyPdfWrap(string $text, int $maxCharacters): array
{
    $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
    if ($text === '') {
        return ['Not provided'];
    }
    $words = preg_split('/\s+/u', $text) ?: [$text];
    $lines = [];
    $line = '';
    foreach ($words as $word) {
        $candidate = ($line === '') ? $word : $line . ' ' . $word;
        if (strlen($candidate) > $maxCharacters && $line !== '') {
            $lines[] = $line;
            $line = $word;
        } else {
            $line = $candidate;
        }
    }
    if ($line !== '') {
        $lines[] = $line;
    }
    return $lines ?: ['Not provided'];
}

function eventifyBuildBookingPdf(array $booking): string
{
    $bookingId = (int) ($booking['booking_id'] ?? 0);
    $status = eventifyPdfValue($booking, ['booking_status', 'status'], 'Pending');
    $isConfirmed = strcasecmp($status, 'Confirmed') === 0;
    $isCancelled = strcasecmp($status, 'Cancelled') === 0;

    $eventName = eventifyPdfValue($booking, ['event_name'], 'Event booking');
    $eventDateRaw = eventifyPdfValue($booking, ['event_date'], 'Not provided');
    $eventDate = ($eventDateRaw === 'Not provided') ? $eventDateRaw : eventifyPdfFormatDate($eventDateRaw);
    $startTime = eventifyPdfFormatTime(eventifyPdfValue($booking, ['start_time', 'event_start_time'], 'Not provided'));
    $endTimeRaw = eventifyPdfValue($booking, ['end_time', 'event_end_time'], '');
    $eventTime = ($startTime === 'Not provided') ? $startTime : $startTime;
    if ($endTimeRaw !== '') {
        $eventTime .= ' - ' . eventifyPdfFormatTime($endTimeRaw);
    }
    $venue = eventifyPdfValue($booking, ['venue_name'], 'Not provided');
    $venueAddress = eventifyPdfValue($booking, ['venue_address', 'venue_location'], '');
    if ($venueAddress !== '') {
        $venue .= ' — ' . $venueAddress;
    }
    $customer = eventifyPdfValue($booking, ['customer_name', 'customer_full_name', 'booker_name', 'booking_holder', 'user_name', 'user_full_name', 'full_name', 'name'], 'Booking holder');
    $email = eventifyPdfValue($booking, ['customer_email', 'contact_email', 'booker_email', 'user_email', 'email'], 'Not provided');
    $quantity = max(1, (int) ($booking['quantity'] ?? $booking['ticket_quantity'] ?? 1));
    $total = is_numeric($booking['total_amount'] ?? null) ? (float) $booking['total_amount'] : 0.0;
    $unitPrice = is_numeric($booking['ticket_price'] ?? null)
        ? (float) $booking['ticket_price']
        : (is_numeric($booking['unit_price'] ?? null) ? (float) $booking['unit_price'] : $total / $quantity);
    $issuedRaw = eventifyPdfValue($booking, ['booking_date', 'created_at', 'booking_created_at'], date('Y-m-d'));
    $issuedDate = eventifyPdfFormatDate($issuedRaw);

    $purple = [0.17, 0.09, 0.25];
    $purpleLight = [0.32, 0.14, 0.40];
    $pink = [0.94, 0.31, 0.57];
    $coral = [1.00, 0.47, 0.37];
    $text = [0.18, 0.15, 0.22];
    $muted = [0.48, 0.44, 0.52];
    $line = [0.91, 0.87, 0.92];

    $content = '';
    $content .= eventifyPdfRect(0, 0, 595, 842, [1, 1, 1]);
    $content .= eventifyPdfRect(0, 836, 595, 6, $pink);
    $content .= eventifyPdfRect(0, 685, 595, 151, $purple);
    $content .= eventifyPdfRect(48, 776, 30, 30, $pink);
    $content .= eventifyPdfText('E', 58, 783, 17, 'F2', [1, 1, 1]);
    $content .= eventifyPdfText('EVENTIFY', 88, 791, 20, 'F2', [1, 1, 1]);
    $content .= eventifyPdfText('EVENT TICKETING & VENUE BOOKING', 88, 775, 8, 'F1', [0.88, 0.82, 0.91]);
    $content .= eventifyPdfText($isConfirmed ? 'EVENT TICKET & BOOKING RECEIPT' : 'BOOKING CONFIRMATION', 48, 728, 17, 'F2', [1, 1, 1]);
    $content .= eventifyPdfText('Generated ' . $issuedDate, 48, 706, 9, 'F1', [0.88, 0.82, 0.91]);
    $content .= eventifyPdfRect(430, 708, 117, 28, $purpleLight);
    $content .= eventifyPdfText('BOOKING DOCUMENT', 440, 718, 7, 'F2', [1, 1, 1]);

    $content .= eventifyPdfText('BOOKING REFERENCE', 48, 654, 8, 'F2', $muted);
    $content .= eventifyPdfText('#' . $bookingId, 48, 628, 21, 'F2', $purple);
    $statusColor = $isConfirmed ? [0.08, 0.48, 0.31] : ($isCancelled ? [0.72, 0.15, 0.29] : [0.58, 0.37, 0.05]);
    $statusFill = $isConfirmed ? [0.87, 0.97, 0.91] : ($isCancelled ? [1.00, 0.91, 0.93] : [1.00, 0.96, 0.85]);
    $content .= eventifyPdfRect(420, 622, 127, 28, $statusFill);
    $content .= eventifyPdfText(strtoupper($status), 431, 632, 9, 'F2', $statusColor);

    $content .= eventifyPdfText('YOUR EVENT', 48, 594, 8, 'F2', $pink);
    $titleLines = eventifyPdfWrap($eventName, 43);
    if (count($titleLines) > 2) {
        $titleLines = array_slice($titleLines, 0, 2);
        $last = rtrim($titleLines[1], '. ');
        $titleLines[1] = substr($last, 0, max(0, 40)) . '...';
    }
    $titleY = 566;
    foreach ($titleLines as $titleLine) {
        $content .= eventifyPdfText($titleLine, 48, $titleY, 19, 'F2', $text);
        $titleY -= 25;
    }

    $content .= eventifyPdfRect(42, 412, 511, 94, [0.99, 0.97, 0.99]);
    $content .= eventifyPdfText('DATE', 60, 482, 8, 'F2', $muted);
    $content .= eventifyPdfText(substr($eventDate, 0, 24), 60, 461, 11, 'F2', $text);
    $content .= eventifyPdfText('TIME', 253, 482, 8, 'F2', $muted);
    $content .= eventifyPdfText(substr($eventTime, 0, 25), 253, 461, 10, 'F2', $text);
    $content .= eventifyPdfText('VENUE', 60, 439, 8, 'F2', $muted);
    $venueLines = eventifyPdfWrap($venue, 78);
    $content .= eventifyPdfText(substr($venueLines[0], 0, 88), 60, 422, 9, 'F1', $text);

    $content .= eventifyPdfText('BOOKING SUMMARY', 48, 381, 10, 'F2', $purple);
    $content .= eventifyPdfLine(48, 366, 547, 366, $line, 1);
    $content .= eventifyPdfText('ITEM', 48, 348, 8, 'F2', $muted);
    $content .= eventifyPdfText('QTY', 340, 348, 8, 'F2', $muted);
    $content .= eventifyPdfText('UNIT PRICE', 397, 348, 8, 'F2', $muted);
    $content .= eventifyPdfText('AMOUNT', 491, 348, 8, 'F2', $muted);
    $content .= eventifyPdfLine(48, 336, 547, 336, $line, 0.6);
    $content .= eventifyPdfText('Event ticket', 48, 315, 10, 'F2', $text);
    $content .= eventifyPdfText((string) $quantity, 347, 315, 10, 'F1', $text);
    $content .= eventifyPdfText(number_format($unitPrice, 2), 397, 315, 9, 'F1', $text);
    $content .= eventifyPdfText(number_format($total, 2), 491, 315, 9, 'F2', $text);
    $content .= eventifyPdfLine(48, 302, 547, 302, $line, 0.6);
    $content .= eventifyPdfText('TOTAL', 397, 277, 9, 'F2', $muted);
    $content .= eventifyPdfText(eventifyPdfMoney($total), 397, 252, 18, 'F2', $pink);

    $content .= eventifyPdfRect(42, 130, 511, 88, [0.99, 0.97, 0.99]);
    $content .= eventifyPdfText('BOOKING HOLDER', 60, 196, 8, 'F2', $muted);
    $content .= eventifyPdfText(substr($customer, 0, 65), 60, 178, 10, 'F2', $text);
    $content .= eventifyPdfText('CONTACT', 60, 158, 8, 'F2', $muted);
    $content .= eventifyPdfText(substr($email, 0, 78), 60, 143, 9, 'F1', $text);

    $notice = $isConfirmed
        ? 'Confirmed booking. Keep this PDF as your ticket and proof of purchase. Present booking reference at check-in; admission remains subject to organizer validation.'
        : ($isCancelled
            ? 'This booking has been cancelled. This document is for your records only and is not valid for event entry.'
            : 'Booking status is not confirmed. This PDF records the booking details only; it is not proof of payment or a valid admission ticket.');
    $content .= eventifyPdfText('IMPORTANT', 48, 107, 8, 'F2', $pink);
    $noticeLines = eventifyPdfWrap($notice, 94);
    $noticeY = 91;
    foreach (array_slice($noticeLines, 0, 2) as $noticeLine) {
        $content .= eventifyPdfText($noticeLine, 48, $noticeY, 8, 'F1', $muted);
        $noticeY -= 12;
    }
    $content .= eventifyPdfLine(48, 64, 547, 64, $line, 0.7);
    $content .= eventifyPdfText('Generated electronically by Eventify. Keep this document for your records.', 48, 47, 8, 'F1', $muted);
    $content .= eventifyPdfText('eventify', 505, 47, 8, 'F2', $pink);

    $objects = [];
    $objects[] = '<< /Type /Catalog /Pages 2 0 R >>';
    $objects[] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
    $objects[] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>';
    $objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
    $objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
    $objects[] = '<< /Length ' . strlen($content) . " >>\nstream\n" . $content . "endstream";

    $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
    $offsets = [0];
    foreach ($objects as $index => $object) {
        $objectNumber = $index + 1;
        $offsets[] = strlen($pdf);
        $pdf .= $objectNumber . " 0 obj\n" . $object . "\nendobj\n";
    }
    $xrefOffset = strlen($pdf);
    $pdf .= 'xref' . "\n0 " . (count($objects) + 1) . "\n";
    $pdf .= "0000000000 65535 f \n";
    for ($i = 1; $i < count($offsets); $i++) {
        $pdf .= sprintf('%010d 00000 n ', $offsets[$i]) . "\n";
    }
    $pdf .= 'trailer' . "\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\n";
    $pdf .= "startxref\n" . $xrefOffset . "\n%%EOF\n";
    return $pdf;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    header('Allow: GET');
    eventifyPdfError(405, 'Use GET to download a booking PDF.');
}

$bookingId = filter_input(INPUT_GET, 'booking_id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if (!$bookingId) {
    eventifyPdfError(400, 'A valid booking_id is required.');
}

$authorizationHeader = trim((string) ($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ''));
if ($authorizationHeader === '' && function_exists('getallheaders')) {
    $incomingHeaders = getallheaders();
    $authorizationHeader = trim((string) ($incomingHeaders['Authorization'] ?? $incomingHeaders['authorization'] ?? ''));
}
if (preg_match('/^Bearer\s+\S.+$/i', $authorizationHeader) !== 1) {
    eventifyPdfError(401, 'Sign in before downloading a booking PDF.');
}

$bookings = eventifyFetchAuthorizedBookings($authorizationHeader);
$selectedBooking = null;
foreach ($bookings as $booking) {
    if (is_array($booking) && (int) ($booking['booking_id'] ?? 0) === (int) $bookingId) {
        $selectedBooking = $booking;
        break;
    }
}
if ($selectedBooking === null) {
    
    eventifyPdfError(404, 'Booking not found or you do not have access to it.');
}





$nameKeys = ['customer_name', 'customer_full_name', 'booker_name', 'booking_holder', 'user_name', 'user_full_name', 'full_name', 'name'];
$emailKeys = ['customer_email', 'contact_email', 'booker_email', 'user_email', 'email'];
$bookingHolderName = eventifyPdfValue($selectedBooking, $nameKeys, '');
$bookingHolderEmail = eventifyPdfValue($selectedBooking, $emailKeys, '');

if ($bookingHolderName === '' || $bookingHolderEmail === '') {
    $authenticatedUser = eventifyFetchAuthenticatedUser($authorizationHeader);
    $role = strtolower(trim((string) ($authenticatedUser['role'] ?? '')));
    $isManagementAccount = in_array($role, ['administrator', 'admin', 'organiser', 'organizer'], true);
    $hasKnownRole = $role !== '';

    if ($hasKnownRole && !$isManagementAccount) {
        if ($bookingHolderName === '') {
            $bookingHolderName = eventifyPdfValue($authenticatedUser, ['name', 'full_name', 'user_name'], '');
            if ($bookingHolderName !== '') {
                $selectedBooking['customer_name'] = $bookingHolderName;
            }
        }
        if ($bookingHolderEmail === '') {
            $bookingHolderEmail = eventifyPdfValue($authenticatedUser, ['email', 'user_email', 'customer_email'], '');
            if ($bookingHolderEmail !== '') {
                $selectedBooking['customer_email'] = $bookingHolderEmail;
            }
        }
    }
}

$pdf = eventifyBuildBookingPdf($selectedBooking);
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="Eventify-Booking-' . (int) $bookingId . '.pdf"');
header('Content-Length: ' . strlen($pdf));
header('Cache-Control: no-store, private, max-age=0');
header('Pragma: no-cache');
echo $pdf;
