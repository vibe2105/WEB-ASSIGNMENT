<?php

require_once __DIR__ . '/../middleware/api.php';
eventifyApiInit();

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/database.php';

function eventImageRespond(int $statusCode, array $payload)
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function eventImageDatabase(): PDO
{
    $database = new Database();
    $db = $database->getConnection();
    if (!$db instanceof PDO) {
        throw new RuntimeException('Database connection unavailable');
    }
    return $db;
}

function removeManagedEventImage(?string $relativePath, string $uploadDir): void
{
    if (!$relativePath || strpos($relativePath, 'uploads/events/') !== 0) {
        return;
    }
    $fileName = basename($relativePath);
    if ($fileName === '' || $fileName === '.' || $fileName === '..') {
        return;
    }
    $candidate = $uploadDir . DIRECTORY_SEPARATOR . $fileName;
    $baseReal = realpath($uploadDir);
    $fileReal = realpath($candidate);
    if ($baseReal !== false && $fileReal !== false && str_starts_with($fileReal, $baseReal . DIRECTORY_SEPARATOR) && is_file($fileReal)) {
        @unlink($fileReal);
    }
}

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

try {
    $db = eventImageDatabase();

    if ($method === 'GET') {
        if (isset($_GET['event_id'])) {
            $eventId = filter_var($_GET['event_id'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($eventId === false) {
                eventImageRespond(400, ['status' => 'error', 'message' => 'Invalid event ID']);
            }
            $stmt = $db->prepare('SELECT event_id, image_path FROM events WHERE event_id = :event_id');
            $stmt->execute([':event_id' => $eventId]);
            $image = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$image) {
                eventImageRespond(404, ['status' => 'error', 'message' => 'Event not found']);
            }
            eventImageRespond(200, ['status' => 'success', 'data' => $image]);
        }

        $stmt = $db->query("SELECT event_id, image_path FROM events WHERE image_path IS NOT NULL AND image_path <> '' ORDER BY event_id ASC");
        eventImageRespond(200, ['status' => 'success', 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    if ($method !== 'POST') {
        header('Allow: GET, POST');
        eventImageRespond(405, ['status' => 'error', 'message' => 'Method not allowed']);
    }

    require_once __DIR__ . '/../middleware/auth.php';
    $currentUser = requireAuth();
    requireRole($currentUser, ['Administrator', 'Organiser']);

    $eventId = filter_var($_POST['event_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($eventId === false || $eventId === null) {
        eventImageRespond(400, ['status' => 'error', 'message' => 'Event ID is required']);
    }
    if (!isset($_FILES['event_image']) || !is_array($_FILES['event_image'])) {
        eventImageRespond(400, ['status' => 'error', 'message' => 'Choose an event poster to upload']);
    }

    $file = $_FILES['event_image'];
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $messages = [
            UPLOAD_ERR_INI_SIZE => 'The image exceeds the server upload limit',
            UPLOAD_ERR_FORM_SIZE => 'The image is too large',
            UPLOAD_ERR_PARTIAL => 'The image upload was incomplete',
            UPLOAD_ERR_NO_FILE => 'Choose an event poster to upload',
            UPLOAD_ERR_NO_TMP_DIR => 'Server upload temporary directory is unavailable',
            UPLOAD_ERR_CANT_WRITE => 'Server could not save the uploaded image',
            UPLOAD_ERR_EXTENSION => 'The server blocked the image upload',
        ];
        eventImageRespond(400, ['status' => 'error', 'message' => $messages[$file['error']] ?? 'Image upload failed']);
    }

    $maxBytes = 5 * 1024 * 1024;
    if (!isset($file['size']) || (int)$file['size'] < 1 || (int)$file['size'] > $maxBytes) {
        eventImageRespond(400, ['status' => 'error', 'message' => 'Image must be no larger than 5 MB']);
    }
    if (!is_uploaded_file($file['tmp_name'] ?? '')) {
        eventImageRespond(400, ['status' => 'error', 'message' => 'Invalid uploaded file']);
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];
    if (!isset($allowedMimeTypes[$mime])) {
        eventImageRespond(415, ['status' => 'error', 'message' => 'Use a JPG, PNG or WebP image']);
    }

    $imageInfo = @getimagesize($file['tmp_name']);
    if ($imageInfo === false || empty($imageInfo[0]) || empty($imageInfo[1]) || $imageInfo[0] > 6000 || $imageInfo[1] > 6000) {
        eventImageRespond(400, ['status' => 'error', 'message' => 'The image is invalid or its dimensions exceed 6000 × 6000 pixels']);
    }
    if (($imageInfo['mime'] ?? '') !== $mime) {
        eventImageRespond(415, ['status' => 'error', 'message' => 'The image content does not match its file type']);
    }

    $db->beginTransaction();
    $eventStmt = $db->prepare('SELECT event_id, organiser_id, image_path FROM events WHERE event_id = :event_id FOR UPDATE');
    $eventStmt->execute([':event_id' => $eventId]);
    $event = $eventStmt->fetch(PDO::FETCH_ASSOC);
    if (!$event) {
        $db->rollBack();
        eventImageRespond(404, ['status' => 'error', 'message' => 'Event not found']);
    }
    if (($currentUser['role'] ?? '') === 'Organiser' && (int)$event['organiser_id'] !== (int)($currentUser['user_id'] ?? 0)) {
        $db->rollBack();
        eventImageRespond(403, ['status' => 'error', 'message' => "You cannot change another organiser's event poster"]);
    }

    $uploadDir = __DIR__ . '/../uploads/events';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
        $db->rollBack();
        eventImageRespond(500, ['status' => 'error', 'message' => 'Unable to prepare image storage']);
    }
    if (!is_writable($uploadDir)) {
        $db->rollBack();
        eventImageRespond(500, ['status' => 'error', 'message' => 'Event image folder is not writable by PHP']);
    }

    $fileName = 'event-' . (int)$eventId . '-' . bin2hex(random_bytes(12)) . '.' . $allowedMimeTypes[$mime];
    $destination = $uploadDir . DIRECTORY_SEPARATOR . $fileName;
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        $db->rollBack();
        eventImageRespond(500, ['status' => 'error', 'message' => 'Unable to save the uploaded poster']);
    }

    $relativePath = 'uploads/events/' . $fileName;
    try {
        $update = $db->prepare('UPDATE events SET image_path = :image_path WHERE event_id = :event_id');
        $update->execute([':image_path' => $relativePath, ':event_id' => $eventId]);
        $db->commit();
    } catch (Throwable $error) {
        if ($db->inTransaction()) $db->rollBack();
        @unlink($destination);
        throw $error;
    }

    removeManagedEventImage($event['image_path'] ?? null, $uploadDir);
    eventImageRespond(200, [
        'status' => 'success',
        'message' => 'Event poster uploaded successfully',
        'event_id' => (int)$eventId,
        'image_path' => $relativePath,
    ]);
} catch (Throwable $error) {
    if (isset($db) && $db instanceof PDO && $db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Event image API error: ' . $error->getMessage());
    eventImageRespond(500, ['status' => 'error', 'message' => 'Internal server error']);
}
