<?php
require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();

ini_set("display_errors", 0);
ini_set("log_errors", 1);
error_reporting(E_ALL);

header("Content-Type: application/json");

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../middleware/auth.php";


try {
    $database = new Database();
    $db = $database->getConnection();
} catch (Throwable $error) {
    error_log($error->getMessage());
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Internal server error"
    ]);
    exit;
}


if (!$db) {

    http_response_code(500);

    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed"
    ]);

    exit;
}


$currentUser = requireAuth();

$currentUserId =
    intval($currentUser["user_id"]);

$currentRole =
    $currentUser["role"];

$method =
    $_SERVER["REQUEST_METHOD"];





function getBookingJsonBody()
{
    $data = json_decode(
        file_get_contents("php://input"),
        true
    );

    return is_array($data)
        ? $data
        : null;
}



try {

    

    if ($method === "GET") {


        

        if (isset($_GET["booking_id"])) {

            $bookingId =
                intval($_GET["booking_id"]);


            $query = "
                SELECT
                    b.booking_id,
                    b.user_id,
                    b.event_id,
                    b.quantity,
                    b.total_amount,
                    b.booking_status,
                    b.booking_date,

                    u.name AS customer_name,
                    u.email AS customer_email,

                    e.event_name,
                    e.event_date,
                    e.start_time,
                    e.end_time,
                    e.ticket_price,
                    e.organiser_id,

                    v.venue_name,
                    v.location

                FROM bookings b

                INNER JOIN users u
                    ON b.user_id = u.user_id

                INNER JOIN events e
                    ON b.event_id = e.event_id

                INNER JOIN venues v
                    ON e.venue_id = v.venue_id

                WHERE b.booking_id = :booking_id
            ";


            $stmt = $db->prepare($query);

            $stmt->execute([
                ":booking_id" => $bookingId
            ]);

            $booking = $stmt->fetch();


            if (!$booking) {

                http_response_code(404);

                echo json_encode([
                    "status" => "error",
                    "message" => "Booking not found"
                ]);

                exit;
            }


            

            if (
                $currentRole === "Customer"
                &&
                intval($booking["user_id"])
                !== $currentUserId
            ) {

                http_response_code(403);

                echo json_encode([
                    "status" => "error",
                    "message" =>
                        "You cannot access another customer's booking"
                ]);

                exit;
            }


            

            if (
                $currentRole === "Organiser"
                &&
                intval($booking["organiser_id"])
                !== $currentUserId
            ) {

                http_response_code(403);

                echo json_encode([
                    "status" => "error",
                    "message" =>
                        "You cannot access bookings for another organiser's event"
                ]);

                exit;
            }


            http_response_code(200);

            echo json_encode([
                "status" => "success",
                "data" => $booking
            ]);

            exit;
        }



        

        if ($currentRole === "Customer") {

            $query = "
                SELECT
                    b.booking_id,
                    b.user_id,
                    b.event_id,
                    b.quantity,
                    b.total_amount,
                    b.booking_status,
                    b.booking_date,

                    e.event_name,
                    e.event_date,
                    e.start_time,
                    e.end_time,
                    e.ticket_price,

                    v.venue_name,
                    v.location

                FROM bookings b

                INNER JOIN events e
                    ON b.event_id = e.event_id

                INNER JOIN venues v
                    ON e.venue_id = v.venue_id

                WHERE b.user_id = :user_id

                ORDER BY b.booking_date DESC
            ";


            $stmt =
                $db->prepare($query);


            $stmt->execute([
                ":user_id" =>
                    $currentUserId
            ]);


            $bookings =
                $stmt->fetchAll();


            http_response_code(200);

            echo json_encode([
                "status" => "success",
                "total" => count($bookings),
                "data" => $bookings
            ]);

            exit;
        }



        

        if ($currentRole === "Organiser") {

            $query = "
                SELECT
                    b.booking_id,
                    b.user_id,
                    b.event_id,
                    b.quantity,
                    b.total_amount,
                    b.booking_status,
                    b.booking_date,

                    u.name AS customer_name,
                    u.email AS customer_email,

                    e.event_name,
                    e.event_date,
                    e.start_time,
                    e.end_time,
                    e.ticket_price,
                    e.organiser_id,

                    v.venue_name,
                    v.location

                FROM bookings b

                INNER JOIN users u
                    ON b.user_id = u.user_id

                INNER JOIN events e
                    ON b.event_id = e.event_id

                INNER JOIN venues v
                    ON e.venue_id = v.venue_id

                WHERE e.organiser_id = :organiser_id

                ORDER BY b.booking_date DESC
            ";


            $stmt =
                $db->prepare($query);


            $stmt->execute([
                ":organiser_id" =>
                    $currentUserId
            ]);


            $bookings =
                $stmt->fetchAll();


            http_response_code(200);

            echo json_encode([
                "status" => "success",
                "total" => count($bookings),
                "data" => $bookings
            ]);

            exit;
        }



        

        requireRole(
            $currentUser,
            ["Administrator"]
        );


        $query = "
            SELECT
                b.booking_id,
                b.user_id,
                b.event_id,
                b.quantity,
                b.total_amount,
                b.booking_status,
                b.booking_date,

                u.name AS customer_name,
                u.email AS customer_email,

                e.event_name,
                e.event_date,
                e.start_time,
                e.end_time,
                e.ticket_price,
                e.organiser_id,

                v.venue_name,
                v.location

            FROM bookings b

            INNER JOIN users u
                ON b.user_id = u.user_id

            INNER JOIN events e
                ON b.event_id = e.event_id

            INNER JOIN venues v
                ON e.venue_id = v.venue_id

            ORDER BY b.booking_date DESC
        ";


        $stmt =
            $db->prepare($query);

        $stmt->execute();

        $bookings =
            $stmt->fetchAll();


        http_response_code(200);

        echo json_encode([
            "status" => "success",
            "total" => count($bookings),
            "data" => $bookings
        ]);

        exit;
    }



    

    elseif ($method === "POST") {


        requireRole(
            $currentUser,
            ["Customer"]
        );


        $data =
            getBookingJsonBody();


        if (!$data) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Invalid JSON request body"
            ]);

            exit;
        }


        if (
            empty($data["event_id"]) ||
            empty($data["quantity"])
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Event ID and quantity are required"
            ]);

            exit;
        }


        
        if (
            filter_var($data["event_id"], FILTER_VALIDATE_INT,
                ["options" => ["min_range" => 1]]) === false ||
            filter_var($data["quantity"], FILTER_VALIDATE_INT,
                ["options" => ["min_range" => 1]]) === false
        ) {
            http_response_code(400);
            echo json_encode([
                "status" => "error",
                "message" => "Event ID and quantity must be positive whole numbers"
            ]);
            exit;
        }

        $eventId =
            intval($data["event_id"]);

        $quantity =
            intval($data["quantity"]);


        if ($quantity < 1) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Quantity must be at least 1"
            ]);

            exit;
        }


        if ($quantity > 10) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Maximum 10 tickets per booking"
            ]);

            exit;
        }


        $db->beginTransaction();


        $eventQuery = "
            SELECT
                event_id,
                event_name,
                ticket_price,
                available_tickets,
                status

            FROM events

            WHERE event_id = :event_id

            FOR UPDATE
        ";


        $eventStmt =
            $db->prepare($eventQuery);


        $eventStmt->execute([
            ":event_id" => $eventId
        ]);


        $event =
            $eventStmt->fetch();


        if (!$event) {

            $db->rollBack();

            http_response_code(404);

            echo json_encode([
                "status" => "error",
                "message" => "Event not found"
            ]);

            exit;
        }


        if ($event["status"] !== "Upcoming") {

            $db->rollBack();

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "This event is not available for booking"
            ]);

            exit;
        }


        if (
            $quantity >
            intval($event["available_tickets"])
        ) {

            $db->rollBack();

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Not enough tickets available"
            ]);

            exit;
        }


        $ticketPrice =
            floatval($event["ticket_price"]);


        $totalAmount =
            $ticketPrice * $quantity;



        

        $bookingQuery = "
            INSERT INTO bookings
            (
                user_id,
                event_id,
                quantity,
                total_amount,
                booking_status
            )

            VALUES
            (
                :user_id,
                :event_id,
                :quantity,
                :total_amount,
                'Confirmed'
            )
        ";


        $bookingStmt =
            $db->prepare($bookingQuery);


        $bookingStmt->execute([

            ":user_id" =>
                $currentUserId,

            ":event_id" =>
                $eventId,

            ":quantity" =>
                $quantity,

            ":total_amount" =>
                $totalAmount

        ]);


        $bookingId =
            $db->lastInsertId();



        

        $ticketStmt =
            $db->prepare(
                "
                UPDATE events

                SET available_tickets =
                    available_tickets - :quantity

                WHERE event_id =
                    :event_id
                "
            );


        $ticketStmt->execute([

            ":quantity" =>
                $quantity,

            ":event_id" =>
                $eventId

        ]);


        $db->commit();


        http_response_code(201);


        echo json_encode([

            "status" =>
                "success",

            "message" =>
                "Booking created successfully",

            "booking_id" =>
                $bookingId,

            "customer" =>
                $currentUser["name"],

            "event_name" =>
                $event["event_name"],

            "quantity" =>
                $quantity,

            "total_amount" =>
                number_format(
                    $totalAmount,
                    2,
                    ".",
                    ""
                ),

            "booking_status" =>
                "Confirmed"

        ]);


        exit;
    }



    

    elseif ($method === "PUT") {


        requireRole(
            $currentUser,
            [
                "Administrator",
                "Organiser"
            ]
        );


        $data =
            getBookingJsonBody();


        if (
            !$data ||
            empty($data["booking_id"]) ||
            empty($data["booking_status"])
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Booking ID and booking status are required"
            ]);

            exit;
        }


        $bookingId =
            intval($data["booking_id"]);


        $newStatus =
            trim(
                $data["booking_status"]
            );


        $allowedStatuses = [
            "Confirmed",
            "Cancelled"
        ];


        if (
            !in_array(
                $newStatus,
                $allowedStatuses,
                true
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Booking status must be Confirmed or Cancelled"
            ]);

            exit;
        }


        $db->beginTransaction();


        $query = "
            SELECT
                b.booking_id,
                b.user_id,
                b.event_id,
                b.quantity,
                b.booking_status,

                e.organiser_id,
                e.available_tickets,
                e.total_tickets

            FROM bookings b

            INNER JOIN events e
                ON b.event_id =
                   e.event_id

            WHERE b.booking_id =
                :booking_id

            FOR UPDATE
        ";


        $stmt =
            $db->prepare($query);


        $stmt->execute([
            ":booking_id" =>
                $bookingId
        ]);


        $booking =
            $stmt->fetch();


        if (!$booking) {

            $db->rollBack();

            http_response_code(404);

            echo json_encode([
                "status" => "error",
                "message" => "Booking not found"
            ]);

            exit;
        }



        

        if (
            $currentRole === "Organiser"
            &&
            intval($booking["organiser_id"])
            !== $currentUserId
        ) {

            $db->rollBack();

            http_response_code(403);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "You cannot manage bookings for another organiser's event"
            ]);

            exit;
        }


        $oldStatus =
            $booking["booking_status"];


        $quantity =
            intval($booking["quantity"]);



        

        if (
            $oldStatus === "Confirmed"
            &&
            $newStatus === "Cancelled"
        ) {

            $ticketStmt =
                $db->prepare(
                    "
                    UPDATE events

                    SET available_tickets =
                        LEAST(
                            total_tickets,
                            available_tickets
                            + :quantity
                        )

                    WHERE event_id =
                        :event_id
                    "
                );


            $ticketStmt->execute([

                ":quantity" =>
                    $quantity,

                ":event_id" =>
                    intval(
                        $booking["event_id"]
                    )

            ]);
        }



        

        if (
            $oldStatus !== "Confirmed"
            &&
            $newStatus === "Confirmed"
        ) {


            if (
                intval(
                    $booking["available_tickets"]
                )
                < $quantity
            ) {

                $db->rollBack();

                http_response_code(409);

                echo json_encode([
                    "status" => "error",
                    "message" =>
                        "There are not enough available tickets to confirm this booking"
                ]);

                exit;
            }


            $ticketStmt =
                $db->prepare(
                    "
                    UPDATE events

                    SET available_tickets =
                        available_tickets
                        - :quantity

                    WHERE event_id =
                        :event_id
                    "
                );


            $ticketStmt->execute([

                ":quantity" =>
                    $quantity,

                ":event_id" =>
                    intval(
                        $booking["event_id"]
                    )

            ]);
        }



        

        $updateStmt =
            $db->prepare(
                "
                UPDATE bookings

                SET booking_status =
                    :booking_status

                WHERE booking_id =
                    :booking_id
                "
            );


        $updateStmt->execute([

            ":booking_status" =>
                $newStatus,

            ":booking_id" =>
                $bookingId

        ]);


        $db->commit();


        http_response_code(200);


        echo json_encode([

            "status" =>
                "success",

            "message" =>
                "Booking status updated successfully",

            "booking_id" =>
                $bookingId,

            "booking_status" =>
                $newStatus

        ]);


        exit;
    }



    

    elseif ($method === "DELETE") {


        $data =
            getBookingJsonBody();


        if (
            !$data ||
            empty($data["booking_id"])
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Booking ID is required"
            ]);

            exit;
        }


        $bookingId =
            intval(
                $data["booking_id"]
            );


        $db->beginTransaction();


        $query = "
            SELECT
                b.booking_id,
                b.user_id,
                b.event_id,
                b.quantity,
                b.booking_status,

                e.organiser_id

            FROM bookings b

            INNER JOIN events e
                ON b.event_id =
                   e.event_id

            WHERE b.booking_id =
                :booking_id

            FOR UPDATE
        ";


        $stmt =
            $db->prepare($query);


        $stmt->execute([
            ":booking_id" =>
                $bookingId
        ]);


        $booking =
            $stmt->fetch();


        if (!$booking) {

            $db->rollBack();

            http_response_code(404);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Booking not found"
            ]);

            exit;
        }



        

        if (
            $currentRole === "Customer"
            &&
            intval($booking["user_id"])
            !== $currentUserId
        ) {

            $db->rollBack();

            http_response_code(403);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "You cannot cancel another customer's booking"
            ]);

            exit;
        }



        

        if (
            $currentRole === "Organiser"
            &&
            intval($booking["organiser_id"])
            !== $currentUserId
        ) {

            $db->rollBack();

            http_response_code(403);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "You cannot cancel bookings for another organiser's event"
            ]);

            exit;
        }



        if (
            $booking["booking_status"]
            === "Cancelled"
        ) {

            $db->rollBack();

            http_response_code(409);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "This booking is already cancelled"
            ]);

            exit;
        }



        $cancelStmt =
            $db->prepare(
                "
                UPDATE bookings

                SET booking_status =
                    'Cancelled'

                WHERE booking_id =
                    :booking_id
                "
            );


        $cancelStmt->execute([
            ":booking_id" =>
                $bookingId
        ]);



        

        if (
            $booking["booking_status"]
            === "Confirmed"
        ) {

            $ticketStmt =
                $db->prepare(
                    "
                    UPDATE events

                    SET available_tickets =
                        LEAST(
                            total_tickets,
                            available_tickets
                            + :quantity
                        )

                    WHERE event_id =
                        :event_id
                    "
                );


            $ticketStmt->execute([

                ":quantity" =>
                    intval(
                        $booking["quantity"]
                    ),

                ":event_id" =>
                    intval(
                        $booking["event_id"]
                    )

            ]);
        }


        $db->commit();


        http_response_code(200);


        echo json_encode([

            "status" =>
                "success",

            "message" =>
                "Booking cancelled successfully",

            "booking_id" =>
                $bookingId,

            "booking_status" =>
                "Cancelled"

        ]);


        exit;
    }



    

    else {

        http_response_code(405);

        echo json_encode([
            "status" => "error",
            "message" =>
                "Method not allowed"
        ]);

        exit;
    }


} catch (Throwable $error) {

    if (isset($db) && $db && $db->inTransaction()) {
        $db->rollBack();
    }

    error_log($error->getMessage());

    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Internal server error"
    ]);

}

?>