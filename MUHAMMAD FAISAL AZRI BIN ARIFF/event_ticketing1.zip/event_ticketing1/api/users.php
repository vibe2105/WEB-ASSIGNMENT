<?php
require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();

ini_set("display_errors", 0);
ini_set("log_errors", 1);
error_reporting(E_ALL);

header("Content-Type: application/json");

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../middleware/auth.php";


try {
    $database = new Database();
    $db = $database->getConnection();
} catch (Throwable $error) {
    error_log($error->getMessage());
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Internal server error"
    ]);
    exit;
}


if (!$db) {

    http_response_code(500);

    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed"
    ]);

    exit;
}




$currentUser = requireAuth();

requireRole(
    $currentUser,
    ["Administrator"]
);


$currentUserId =
    intval($currentUser["user_id"]);


$method =
    $_SERVER["REQUEST_METHOD"];





function getUserJsonBody()
{
    $data = json_decode(
        file_get_contents("php://input"),
        true
    );

    return is_array($data)
        ? $data
        : null;
}




function validUserRole($role)
{
    return in_array(
        $role,
        [
            "Administrator",
            "Organiser",
            "Customer"
        ],
        true
    );
}



try {

    

    if ($method === "GET") {


        

        if (
            isset(
                $_GET["user_id"]
            )
        ) {

            $userId =
                intval(
                    $_GET["user_id"]
                );


            $query = "
                SELECT
                    u.user_id,
                    u.name,
                    u.email,
                    u.role,
                    u.created_at,

                    (
                        SELECT COUNT(*)

                        FROM events e

                        WHERE e.organiser_id =
                            u.user_id
                    )
                    AS event_count,

                    (
                        SELECT COUNT(*)

                        FROM bookings b

                        WHERE b.user_id =
                            u.user_id
                    )
                    AS booking_count

                FROM users u

                WHERE u.user_id =
                    :user_id
            ";


            $stmt =
                $db->prepare($query);


            $stmt->execute([
                ":user_id" =>
                    $userId
            ]);


            $user =
                $stmt->fetch();


            if (!$user) {

                http_response_code(404);

                echo json_encode([
                    "status" => "error",
                    "message" =>
                        "User not found"
                ]);

                exit;
            }


            http_response_code(200);


            echo json_encode([
                "status" => "success",
                "data" => $user
            ]);


            exit;
        }



        

        $query = "
            SELECT
                u.user_id,
                u.name,
                u.email,
                u.role,
                u.created_at,

                (
                    SELECT COUNT(*)

                    FROM events e

                    WHERE e.organiser_id =
                        u.user_id
                )
                AS event_count,

                (
                    SELECT COUNT(*)

                    FROM bookings b

                    WHERE b.user_id =
                        u.user_id
                )
                AS booking_count

            FROM users u

            ORDER BY
                u.created_at DESC,
                u.user_id DESC
        ";


        $stmt =
            $db->prepare($query);


        $stmt->execute();


        $users =
            $stmt->fetchAll();


        http_response_code(200);


        echo json_encode([
            "status" => "success",
            "total" => count($users),
            "data" => $users
        ]);


        exit;
    }



    

    elseif ($method === "POST") {


        $data =
            getUserJsonBody();


        if (!$data) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Invalid JSON request body"
            ]);

            exit;
        }


        
        foreach (['name','email','role'] as $field) {
            if (!is_string($data[$field] ?? null)) {
                http_response_code(400);
                echo json_encode(['status'=>'error','message'=>'Invalid user field type']);
                exit;
            }
        }
        if (isset($data['password']) && !is_string($data['password'])) {
            http_response_code(400);
            echo json_encode(['status'=>'error','message'=>'Invalid password field type']);
            exit;
        }

        $name =
            trim(
                $data["name"] ?? ""
            );


        $email =
            strtolower(
                trim(
                    $data["email"] ?? ""
                )
            );


        $password =
            $data["password"] ?? "";


        $role =
            trim(
                $data["role"] ?? ""
            );



        

        if (
            $name === "" ||
            $email === "" ||
            $password === "" ||
            $role === ""
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Name, email, password and role are required"
            ]);

            exit;
        }


        if (strlen($name) < 3) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Name must contain at least 3 characters"
            ]);

            exit;
        }


        if (
            !filter_var(
                $email,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Invalid email address"
            ]);

            exit;
        }


        if (strlen($password) < 6) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Password must contain at least 6 characters"
            ]);

            exit;
        }


        if (!validUserRole($role)) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Invalid user role"
            ]);

            exit;
        }



        

        $checkStmt =
            $db->prepare(
                "
                SELECT user_id

                FROM users

                WHERE email = :email

                LIMIT 1
                "
            );


        $checkStmt->execute([
            ":email" =>
                $email
        ]);


        if ($checkStmt->fetch()) {

            http_response_code(409);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "An account with this email already exists"
            ]);

            exit;
        }



        

        $passwordHash =
            password_hash(
                $password,
                PASSWORD_DEFAULT
            );



        

        $query = "
            INSERT INTO users
            (
                name,
                email,
                password_hash,
                role
            )

            VALUES
            (
                :name,
                :email,
                :password_hash,
                :role
            )
        ";


        $stmt =
            $db->prepare($query);


        $stmt->execute([

            ":name" =>
                $name,

            ":email" =>
                $email,

            ":password_hash" =>
                $passwordHash,

            ":role" =>
                $role

        ]);


        $userId =
            $db->lastInsertId();


        http_response_code(201);


        echo json_encode([

            "status" =>
                "success",

            "message" =>
                "User created successfully",

            "user_id" =>
                $userId

        ]);


        exit;
    }



    

    elseif ($method === "PUT") {


        $data =
            getUserJsonBody();


        if (!$data) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Invalid JSON request body"
            ]);

            exit;
        }


        if (
            empty(
                $data["user_id"]
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "User ID is required"
            ]);

            exit;
        }


        $userId =
            intval(
                $data["user_id"]
            );


        
        foreach (['name','email','role'] as $field) {
            if (!is_string($data[$field] ?? null)) {
                http_response_code(400);
                echo json_encode(['status'=>'error','message'=>'Invalid user field type']);
                exit;
            }
        }
        if (isset($data['password']) && !is_string($data['password'])) {
            http_response_code(400);
            echo json_encode(['status'=>'error','message'=>'Invalid password field type']);
            exit;
        }

        $name =
            trim(
                $data["name"] ?? ""
            );


        $email =
            strtolower(
                trim(
                    $data["email"] ?? ""
                )
            );


        $role =
            trim(
                $data["role"] ?? ""
            );


        $password =
            $data["password"] ?? "";



        if (
            $name === "" ||
            $email === "" ||
            $role === ""
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Name, email and role are required"
            ]);

            exit;
        }


        if (
            !filter_var(
                $email,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Invalid email address"
            ]);

            exit;
        }


        if (!validUserRole($role)) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Invalid user role"
            ]);

            exit;
        }


        if (
            $password !== ""
            &&
            strlen($password) < 6
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "New password must contain at least 6 characters"
            ]);

            exit;
        }



        

        $existingStmt =
            $db->prepare(
                "
                SELECT
                    user_id,
                    role

                FROM users

                WHERE user_id =
                    :user_id
                "
            );


        $existingStmt->execute([
            ":user_id" =>
                $userId
        ]);


        $existingUser =
            $existingStmt->fetch();


        if (!$existingUser) {

            http_response_code(404);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "User not found"
            ]);

            exit;
        }



        

        if (
            $userId ===
            $currentUserId
            &&
            $role !==
            "Administrator"
        ) {

            http_response_code(409);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "You cannot remove your own Administrator role"
            ]);

            exit;
        }



        

        if (
            $existingUser["role"]
            === "Organiser"
            &&
            $role !==
            "Organiser"
        ) {

            $eventStmt =
                $db->prepare(
                    "
                    SELECT COUNT(*)
                        AS total

                    FROM events

                    WHERE organiser_id =
                        :user_id
                    "
                );


            $eventStmt->execute([
                ":user_id" =>
                    $userId
            ]);


            $eventCount =
                intval(
                    $eventStmt->fetch()[
                        "total"
                    ]
                );


            if ($eventCount > 0) {

                http_response_code(409);

                echo json_encode([
                    "status" => "error",
                    "message" =>
                        "This Organiser owns event records. Reassign or remove those events before changing the role."
                ]);

                exit;
            }
        }



        

        $duplicateStmt =
            $db->prepare(
                "
                SELECT user_id

                FROM users

                WHERE email = :email

                AND user_id != :user_id

                LIMIT 1
                "
            );


        $duplicateStmt->execute([

            ":email" =>
                $email,

            ":user_id" =>
                $userId

        ]);


        if ($duplicateStmt->fetch()) {

            http_response_code(409);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "Another account already uses this email"
            ]);

            exit;
        }



        

        if ($password !== "") {


            $passwordHash =
                password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );


            $query = "
                UPDATE users

                SET
                    name =
                        :name,

                    email =
                        :email,

                    password_hash =
                        :password_hash,

                    role =
                        :role

                WHERE user_id =
                    :user_id
            ";


            $stmt =
                $db->prepare($query);


            $stmt->execute([

                ":name" =>
                    $name,

                ":email" =>
                    $email,

                ":password_hash" =>
                    $passwordHash,

                ":role" =>
                    $role,

                ":user_id" =>
                    $userId

            ]);

        }

        else {


            

            $query = "
                UPDATE users

                SET
                    name =
                        :name,

                    email =
                        :email,

                    role =
                        :role

                WHERE user_id =
                    :user_id
            ";


            $stmt =
                $db->prepare($query);


            $stmt->execute([

                ":name" =>
                    $name,

                ":email" =>
                    $email,

                ":role" =>
                    $role,

                ":user_id" =>
                    $userId

            ]);

        }



        http_response_code(200);


        echo json_encode([

            "status" =>
                "success",

            "message" =>
                "User updated successfully",

            "user_id" =>
                $userId

        ]);


        exit;
    }



    

    elseif ($method === "DELETE") {


        $data =
            getUserJsonBody();


        if (
            !$data ||
            empty(
                $data["user_id"]
            )
        ) {

            http_response_code(400);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "User ID is required"
            ]);

            exit;
        }


        $userId =
            intval(
                $data["user_id"]
            );



        

        if (
            $userId ===
            $currentUserId
        ) {

            http_response_code(409);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "You cannot delete your own Administrator account"
            ]);

            exit;
        }



        

        $userStmt =
            $db->prepare(
                "
                SELECT
                    user_id,
                    name,
                    role

                FROM users

                WHERE user_id =
                    :user_id
                "
            );


        $userStmt->execute([
            ":user_id" =>
                $userId
        ]);


        $user =
            $userStmt->fetch();


        if (!$user) {

            http_response_code(404);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "User not found"
            ]);

            exit;
        }



        

        $eventStmt =
            $db->prepare(
                "
                SELECT COUNT(*)
                    AS total

                FROM events

                WHERE organiser_id =
                    :user_id
                "
            );


        $eventStmt->execute([
            ":user_id" =>
                $userId
        ]);


        $eventCount =
            intval(
                $eventStmt->fetch()[
                    "total"
                ]
            );



        if ($eventCount > 0) {

            http_response_code(409);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "This user cannot be deleted because they own event records"
            ]);

            exit;
        }



        

        $bookingStmt =
            $db->prepare(
                "
                SELECT COUNT(*)
                    AS total

                FROM bookings

                WHERE user_id =
                    :user_id
                "
            );


        $bookingStmt->execute([
            ":user_id" =>
                $userId
        ]);


        $bookingCount =
            intval(
                $bookingStmt->fetch()[
                    "total"
                ]
            );


        if ($bookingCount > 0) {

            http_response_code(409);

            echo json_encode([
                "status" => "error",
                "message" =>
                    "This user cannot be deleted because booking records belong to the account"
            ]);

            exit;
        }



        

        $deleteStmt =
            $db->prepare(
                "
                DELETE FROM users

                WHERE user_id =
                    :user_id
                "
            );


        $deleteStmt->execute([
            ":user_id" =>
                $userId
        ]);


        http_response_code(200);


        echo json_encode([

            "status" =>
                "success",

            "message" =>
                "User deleted successfully",

            "user_id" =>
                $userId

        ]);


        exit;
    }



    else {

        http_response_code(405);

        echo json_encode([
            "status" => "error",
            "message" =>
                "Method not allowed"
        ]);

        exit;
    }


} catch (Throwable $error) {

    error_log($error->getMessage());

    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Internal server error"
    ]);

}

?>