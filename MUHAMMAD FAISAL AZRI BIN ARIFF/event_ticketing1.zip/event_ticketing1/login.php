<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Sign In | Eventify</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >


    <style>

        .login-page {

            min-height: 100vh;

            position: relative;

            overflow-x: hidden;

            background:
                linear-gradient(
                    135deg,
                    #11101d 0%,
                    #19162e 45%,
                    #241b4b 100%
                );

        }


        .login-page::before {

            content: "";

            position: fixed;

            inset: 0;

            pointer-events: none;

            background-image:

                linear-gradient(
                    rgba(255,255,255,.035) 1px,
                    transparent 1px
                ),

                linear-gradient(
                    90deg,
                    rgba(255,255,255,.035) 1px,
                    transparent 1px
                );

            background-size:
                60px 60px;

        }


        .login-glow {

            position: fixed;

            width: 550px;

            height: 550px;

            right: -180px;

            top: -180px;

            border-radius: 50%;

            pointer-events: none;

            background:
                radial-gradient(
                    circle,
                    rgba(117,89,255,.34),
                    transparent 65%
                );

        }


        .login-wrapper {

            min-height:
                calc(100vh - 78px);

            display: grid;

            grid-template-columns:
                1fr 460px;

            align-items: center;

            gap: 85px;

            padding: 70px 0;

            position: relative;

            z-index: 2;

        }


        

        .login-intro {

            color: white;

            max-width: 610px;

        }


        .login-eyebrow {

            display: inline-block;

            padding: 8px 13px;

            border-radius: 100px;

            background:
                rgba(255,255,255,.06);

            border:
                1px solid
                rgba(255,255,255,.12);

            color: #b7abff;

            font-size: 11px;

            letter-spacing: 2px;

            font-weight: 800;

            margin-bottom: 25px;

        }


        .login-intro h1 {

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                clamp(
                    48px,
                    6vw,
                    74px
                );

            line-height: 1.05;

            letter-spacing: -3px;

        }


        .login-intro h1 span {

            display: block;

            background:
                linear-gradient(
                    90deg,
                    #947fff,
                    #d1c8ff
                );

            -webkit-background-clip: text;

            color: transparent;

        }


        .login-intro > p {

            margin-top: 23px;

            max-width: 530px;

            color: #aaa7b9;

            font-size: 16px;

            line-height: 1.8;

        }


        .login-feature {

            margin-top: 38px;

            display: flex;

            gap: 18px;

        }


        .login-feature-box {

            padding: 17px;

            min-width: 150px;

            border-radius: 13px;

            color: #c4bfce;

            background:
                rgba(255,255,255,.05);

            border:
                1px solid
                rgba(255,255,255,.08);

        }


        .login-feature-box strong {

            display: block;

            color: white;

            font-size: 18px;

            margin-bottom: 4px;

        }


        .login-feature-box span {

            font-size: 11px;

        }


        

        .login-card {

            padding: 40px;

            border-radius: 24px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    .98
                );

            box-shadow:
                0 30px 80px
                rgba(
                    0,
                    0,
                    0,
                    .28
                );

        }


        .login-card-header {

            margin-bottom: 30px;

        }


        .login-card-header span {

            color: #7559ff;

            font-size: 10px;

            font-weight: 800;

            letter-spacing: 1.8px;

        }


        .login-card-header h2 {

            margin-top: 7px;

            font-family:
                "Manrope",
                sans-serif;

            font-size: 31px;

            color: #201e2b;

        }


        .login-card-header p {

            margin-top: 7px;

            color: #898595;

            font-size: 13px;

        }


        

        .login-form-group {

            margin-bottom: 19px;

        }


        .login-form-group label {

            display: block;

            margin-bottom: 8px;

            color: #4c4958;

            font-size: 12px;

            font-weight: 700;

        }


        .login-input-wrap {

            position: relative;

        }


        .login-input-icon {

            position: absolute;

            left: 15px;

            top: 50%;

            transform:
                translateY(-50%);

            color: #aaa6b5;

        }


        .login-input {

            width: 100%;

            height: 53px;

            padding:
                0 46px;

            border:
                1px solid #e5e3eb;

            border-radius: 11px;

            outline: none;

            background: #fafafd;

            color: #292633;

            font-size: 13px;

            transition: .25s;

        }


        .login-input:focus {

            background: white;

            border-color: #9887f6;

            box-shadow:
                0 0 0 4px
                rgba(
                    117,
                    89,
                    255,
                    .08
                );

        }


        .password-toggle {

            position: absolute;

            right: 15px;

            top: 50%;

            transform:
                translateY(-50%);

            border: none;

            background: transparent;

            color: #8d8998;

            font-size: 11px;

            font-weight: 700;

            cursor: pointer;

        }


        

        .login-submit {

            width: 100%;

            height: 53px;

            margin-top: 8px;

            border: none;

            border-radius: 11px;

            color: white;

            cursor: pointer;

            font-size: 13px;

            font-weight: 800;

            background:
                linear-gradient(
                    135deg,
                    #8064ff,
                    #6347e8
                );

            box-shadow:
                0 12px 25px
                rgba(
                    117,
                    89,
                    255,
                    .25
                );

            transition: .25s;

        }


        .login-submit:hover {

            transform:
                translateY(-2px);

        }


        .login-submit:disabled {

            opacity: .65;

            cursor: not-allowed;

            transform: none;

        }


        

        .login-message {

            display: none;

            margin-top: 16px;

            padding: 13px 15px;

            border-radius: 10px;

            font-size: 12px;

            line-height: 1.5;

        }


        .login-message.error {

            display: block;

            background: #fff0f0;

            border:
                1px solid #ffdada;

            color: #ad3d3d;

        }


        .login-message.success {

            display: block;

            background: #edf9f4;

            border:
                1px solid #d6f0e5;

            color: #177657;

        }


        .register-link {

            text-align: center;

            margin-top: 25px;

            color: #85818f;

            font-size: 12px;

        }


        .register-link a {

            color: #7559ff;

            font-weight: 800;

        }


        @media (max-width: 950px) {

            .login-wrapper {

                grid-template-columns: 1fr;

                max-width: 580px;

            }


            .login-intro {

                text-align: center;

                margin: auto;

            }


            .login-feature {

                justify-content: center;

            }

        }


        @media (max-width: 550px) {

            .login-card {

                padding: 28px 22px;

            }


            .login-feature {

                display: none;

            }

        }

    





:root {
    --auth-pink: #ff5b9a;
    --auth-coral: #ff845d;
    --auth-violet: #a77bff;
    --auth-ink: #30213f;
}
.login-page {
    background:
        radial-gradient(circle at 10% 100%, rgba(255, 132, 93, .19), transparent 34%),
        radial-gradient(circle at 90% 8%, rgba(255, 91, 154, .27), transparent 32%),
        linear-gradient(135deg, #211331 0%, #321743 48%, #522144 100%) !important;
}
.login-page::before {
    opacity: .5;
    background-image:
        linear-gradient(rgba(255, 255, 255, .045) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, .045) 1px, transparent 1px) !important;
}
.login-glow {
    background: radial-gradient(circle, rgba(255, 91, 154, .34), transparent 67%) !important;
}
.login-page .navbar {
    background: rgba(255, 255, 255, .94) !important;
    box-shadow: 0 8px 30px rgba(32, 8, 39, .12);
    border-bottom: 1px solid rgba(255, 255, 255, .35) !important;
}
.login-page .brand-icon {
    background: linear-gradient(135deg, var(--auth-pink), var(--auth-coral)) !important;
    box-shadow: 0 9px 20px rgba(255, 91, 154, .25) !important;
}
.login-page .brand-purple, .login-page .nav-links a:hover { color: var(--auth-pink) !important; }
.login-page .nav-button {
    background: linear-gradient(115deg, var(--auth-pink), var(--auth-coral)) !important;
    box-shadow: 0 9px 20px rgba(255, 91, 154, .17);
}
.login-eyebrow {
    color: #ffd1e2 !important;
    background: rgba(255, 91, 154, .12) !important;
    border-color: rgba(255, 199, 220, .22) !important;
}
.login-intro h1 span {
    background: linear-gradient(90deg, #ff8bbb, #ffc184) !important;
    -webkit-background-clip: text !important;
    background-clip: text !important;
}
.login-intro > p { color: #d0bfd4 !important; }
.login-feature-box {
    background: rgba(255, 255, 255, .07) !important;
    border-color: rgba(255, 255, 255, .12) !important;
    backdrop-filter: blur(12px);
}
.login-feature-box strong { color: #fff1f7 !important; }
.login-feature-box span { color: #d0bfd4 !important; }
.login-card {
    border: 1px solid rgba(255, 255, 255, .78) !important;
    border-radius: 26px !important;
    box-shadow: 0 32px 90px rgba(16, 5, 23, .32) !important;
}
.login-card-header span, .register-link a { color: var(--auth-pink) !important; }
.login-input {
    border-color: #eadce8 !important;
    border-radius: 12px !important;
    background: #fff9fc !important;
}
.login-input:focus {
    border-color: var(--auth-pink) !important;
    box-shadow: 0 0 0 4px rgba(255, 91, 154, .12) !important;
}
.login-submit {
    background: linear-gradient(115deg, var(--auth-pink), var(--auth-coral)) !important;
    box-shadow: 0 13px 27px rgba(255, 91, 154, .25) !important;
    border-radius: 12px !important;
}
.login-submit:hover { box-shadow: 0 17px 32px rgba(255, 91, 154, .32) !important; }
.login-message.error { background: #fff0f3 !important; border-color: #ffd2df !important; }
.login-message.success { background: #e9fbf3 !important; border-color: #c8efdf !important; }
@media (max-width: 550px) {
    .login-card { border-radius: 20px !important; }
    .login-intro h1 { letter-spacing: -1.7px !important; }
}

</style>

    <link rel="stylesheet" href="css/golive-inspired.css">

</head>


<body class="login-page">


<div class="login-glow"></div>





<header class="navbar">

    <div class="container nav-container">

        <a
            href="index.php"
            class="brand"
        >

            <div class="brand-icon">
                E
            </div>

            <span>
                Event<span class="brand-purple">ify</span>
            </span>

        </a>


        <nav class="nav-links">

            <a href="index.php">
                Home
            </a>

            <a href="events.php">
                Events
            </a>

            <a href="bookings.php">
                My Bookings
            </a>

        </nav>


        <div class="nav-actions">

            <a
                href="register.php"
                class="nav-button"
            >
                Create Account
            </a>

        </div>

    </div>

</header>





<main>

    <div class="container login-wrapper">


        <section class="login-intro">

            <div class="login-eyebrow">

                ✦ WELCOME BACK

            </div>


            <h1>

                Experiences are

                <span>
                    waiting for you.
                </span>

            </h1>


            <p>

                Sign in to manage your tickets,
                discover upcoming events and continue
                creating unforgettable memories.

            </p>


            <div class="login-feature">

                <div class="login-feature-box">

                    <strong>
                        Easy
                    </strong>

                    <span>
                        Ticket booking
                    </span>

                </div>


                <div class="login-feature-box">

                    <strong>
                        Secure
                    </strong>

                    <span>
                        JWT authentication
                    </span>

                </div>


                <div class="login-feature-box">

                    <strong>
                        Simple
                    </strong>

                    <span>
                        Booking management
                    </span>

                </div>

            </div>

        </section>



        <section class="login-card">


            <div class="login-card-header">

                <span>
                    SIGN IN
                </span>

                <h2>
                    Welcome back
                </h2>

                <p>
                    Enter your account details below.
                </p>

            </div>



            <form
                id="loginForm"
                novalidate
            >


                <div class="login-form-group">

                    <label for="email">
                        Email Address
                    </label>


                    <div class="login-input-wrap">

                        <span class="login-input-icon">
                            @
                        </span>

                        <input
                            type="email"
                            id="email"
                            class="login-input"
                            placeholder="you@example.com"
                            autocomplete="email"
                        >

                    </div>

                </div>



                <div class="login-form-group">

                    <label for="password">
                        Password
                    </label>


                    <div class="login-input-wrap">

                        <span class="login-input-icon">
                            ◈
                        </span>

                        <input
                            type="password"
                            id="password"
                            class="login-input"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                        >


                        <button
                            type="button"
                            class="password-toggle"
                            id="passwordToggle"
                        >
                            SHOW
                        </button>

                    </div>

                </div>



                <button
                    type="submit"
                    class="login-submit"
                    id="loginButton"
                >

                    Sign In →

                </button>


                <div
                    class="login-message"
                    id="loginMessage"
                >
                </div>


            </form>



            <div class="register-link">

                New to Eventify?

                <a href="register.php">
                    Create Account
                </a>

            </div>


        </section>


    </div>

</main>



<script>





const loginForm =
    document.getElementById(
        "loginForm"
    );


const loginButton =
    document.getElementById(
        "loginButton"
    );


const loginMessage =
    document.getElementById(
        "loginMessage"
    );


const passwordInput =
    document.getElementById(
        "password"
    );


const passwordToggle =
    document.getElementById(
        "passwordToggle"
    );







const params =
    new URLSearchParams(
        window.location.search
    );


if (
    params.get("registered")
    === "1"
) {

    showMessage(
        "✓ Account created successfully. Please sign in.",
        "success"
    );

}







passwordToggle.addEventListener(
    "click",
    function () {


        if (
            passwordInput.type
            === "password"
        ) {

            passwordInput.type =
                "text";

            passwordToggle.textContent =
                "HIDE";

        } else {

            passwordInput.type =
                "password";

            passwordToggle.textContent =
                "SHOW";

        }

    }
);







loginForm.addEventListener(
    "submit",
    async function (event) {


        event.preventDefault();


        const email =
            document
                .getElementById(
                    "email"
                )
                .value
                .trim();


        const password =
            passwordInput.value;


        if (
            email === "" ||
            password === ""
        ) {

            showMessage(
                "Please enter your email and password.",
                "error"
            );

            return;
        }


        loginButton.disabled =
            true;


        loginButton.textContent =
            "Signing In...";


        try {


            const response =
                await fetch(
                    "auth/login.php",
                    {

                        method:
                            "POST",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body:
                            JSON.stringify({

                                email:
                                    email,

                                password:
                                    password

                            })

                    }
                );


            const result =
                await response.json();



            if (
                response.ok &&
                result.status === "success"
            ) {


                



                localStorage.setItem(
                    "eventify_token",
                    result.token
                );


                



                localStorage.setItem(
                    "eventify_user",
                    JSON.stringify(
                        result.user
                    )
                );


                showMessage(
                    "✓ Login successful. Redirecting...",
                    "success"
                );


                loginButton.textContent =
                    "Signed In ✓";


                setTimeout(
                    function () {


                        



                        if (
                            result.user.role
                            === "Administrator"
                            ||
                            result.user.role
                            === "Organiser"
                        ) {

                            window.location.href =
                                "dashboard.php";

                        } else {

                            window.location.href =
                                "events.php";

                        }

                    },
                    1000
                );


            } else {


                throw new Error(
                    result.message ||
                    "Login failed"
                );

            }


        } catch (error) {


            showMessage(
                error.message,
                "error"
            );


            loginButton.disabled =
                false;


            loginButton.textContent =
                "Sign In →";

        }

    }
);







function showMessage(
    message,
    type
) {

    loginMessage.textContent =
        message;


    loginMessage.className =
        "login-message "
        + type;

}

</script>


</body>
<script src="js/auth.js"></script>

</html>