<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Manage Users | Eventify</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >


    <style>

        body {
            background: #f5f5fa;
        }


        



        .users-hero {

            padding: 55px 0;

            color: white;

            background:
                radial-gradient(
                    circle at 82% 15%,
                    rgba(117,89,255,.28),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #11101d,
                    #211943
                );
        }


        .users-hero-content {

            display: flex;

            justify-content: space-between;

            align-items: end;

            gap: 25px;
        }


        .users-hero .eyebrow {
            color: #a997ff;
        }


        .users-hero h1 {

            margin-top: 8px;

            font-family:
                "Manrope",
                sans-serif;

            font-size: 48px;

            letter-spacing: -2px;
        }


        .users-hero p {

            margin-top: 9px;

            color: #aaa6b8;
        }


        .add-user-btn {

            padding: 14px 20px;

            border: none;

            border-radius: 11px;

            color: white;

            background: #7559ff;

            cursor: pointer;

            font-weight: 800;

            transition: .25s;
        }


        .add-user-btn:hover {

            transform: translateY(-2px);

            background: #6449e8;
        }


        



        .users-section {

            padding: 45px 0 100px;
        }


        .user-stats {

            display: grid;

            grid-template-columns:
                repeat(4, 1fr);

            gap: 18px;

            margin-bottom: 30px;
        }


        .user-stat {

            padding: 22px;

            background: white;

            border:
                1px solid #e8e6ee;

            border-radius: 16px;

            box-shadow:
                0 12px 30px
                rgba(24,20,50,.035);
        }


        .user-stat span {

            color: #9995a4;

            font-size: 10px;

            font-weight: 700;

            text-transform: uppercase;

            letter-spacing: .8px;
        }


        .user-stat strong {

            display: block;

            margin-top: 7px;

            font-family:
                "Manrope",
                sans-serif;

            font-size: 28px;
        }


        



        .user-toolbar {

            display: flex;

            gap: 12px;

            padding: 17px;

            margin-bottom: 22px;

            background: white;

            border:
                1px solid #e8e6ee;

            border-radius: 15px;
        }


        .user-toolbar input {

            flex: 1;

            height: 48px;

            padding: 0 15px;

            border:
                1px solid #e3e1e8;

            border-radius: 10px;

            outline: none;

            font-family: inherit;
        }


        .user-toolbar input:focus {
            border-color: #9987f4;
        }


        .user-toolbar select {

            min-width: 190px;

            height: 48px;

            padding: 0 13px;

            border:
                1px solid #e3e1e8;

            border-radius: 10px;

            background: white;
        }


        



        .users-table-card {

            overflow: hidden;

            background: white;

            border:
                1px solid #e8e6ee;

            border-radius: 18px;

            box-shadow:
                0 14px 35px
                rgba(24,20,50,.05);
        }


        .table-scroll {
            overflow-x: auto;
        }


        .users-table {

            width: 100%;

            min-width: 950px;

            border-collapse: collapse;
        }


        .users-table th {

            padding: 15px 18px;

            background: #f8f7fb;

            color: #918e9d;

            text-align: left;

            text-transform: uppercase;

            letter-spacing: .7px;

            font-size: 9px;

            border-bottom:
                1px solid #eceaf0;
        }


        .users-table td {

            padding: 18px;

            vertical-align: middle;

            border-bottom:
                1px solid #f0eef3;

            font-size: 12px;
        }


        .users-table tr:last-child td {
            border-bottom: none;
        }


        .user-cell {

            display: flex;

            align-items: center;

            gap: 12px;
        }


        .table-avatar {

            width: 40px;

            height: 40px;

            display: grid;

            place-items: center;

            flex-shrink: 0;

            border-radius: 11px;

            color: white;

            background:
                linear-gradient(
                    135deg,
                    #8166ff,
                    #6044dc
                );

            font-weight: 800;
        }


        .user-cell strong {

            display: block;

            color: #292633;

            font-size: 12px;
        }


        .user-cell span {

            display: block;

            margin-top: 4px;

            color: #9995a4;

            font-size: 10px;
        }


        



        .role-badge {

            display: inline-block;

            padding: 6px 10px;

            border-radius: 100px;

            font-size: 9px;

            font-weight: 800;
        }


        .role-admin {

            color: #6848d6;

            background: #eeeaff;
        }


        .role-organiser {

            color: #27689b;

            background: #eaf4fc;
        }


        .role-customer {

            color: #187a58;

            background: #eaf8f2;
        }


        



        .user-actions {

            display: flex;

            gap: 7px;
        }


        .edit-user-btn,
        .delete-user-btn {

            padding: 8px 11px;

            border: none;

            border-radius: 8px;

            cursor: pointer;

            font-size: 10px;

            font-weight: 800;
        }


        .edit-user-btn {

            color: #654be0;

            background: #eeeaff;
        }


        .delete-user-btn {

            color: #b64545;

            background: #fff0f0;
        }


        .empty-users {

            padding: 70px;

            text-align: center;

            color: #898595;
        }


        



        .modal-overlay {

            position: fixed;

            inset: 0;

            z-index: 5000;

            display: none;

            align-items: center;

            justify-content: center;

            padding: 20px;

            background:
                rgba(10,9,17,.7);

            backdrop-filter: blur(6px);
        }


        .modal-overlay.show {
            display: flex;
        }


        .user-modal {

            width: min(580px, 100%);

            max-height: 90vh;

            overflow-y: auto;

            background: white;

            border-radius: 22px;

            box-shadow:
                0 35px 90px
                rgba(0,0,0,.3);
        }


        .user-modal-header {

            padding: 25px 27px;

            display: flex;

            align-items: center;

            justify-content: space-between;

            border-bottom:
                1px solid #eeecf2;
        }


        .user-modal-header span {

            color: #7559ff;

            font-size: 10px;

            font-weight: 800;

            letter-spacing: 1.4px;
        }


        .user-modal-header h2 {

            margin-top: 5px;

            font-family:
                "Manrope",
                sans-serif;
        }


        .close-modal {

            width: 36px;

            height: 36px;

            border: none;

            border-radius: 9px;

            background: #f3f2f6;

            cursor: pointer;

            font-size: 18px;
        }


        .user-form {
            padding: 27px;
        }


        .form-group {
            margin-bottom: 18px;
        }


        .form-group label {

            display: block;

            margin-bottom: 7px;

            color: #4e4a59;

            font-size: 11px;

            font-weight: 700;
        }


        .form-group input,
        .form-group select {

            width: 100%;

            height: 49px;

            padding: 0 13px;

            border:
                1px solid #e2e0e8;

            border-radius: 10px;

            background: #fafafd;

            outline: none;

            font-family: inherit;
        }


        .form-group input:focus,
        .form-group select:focus {

            border-color: #9d8cf5;

            background: white;

            box-shadow:
                0 0 0 4px
                rgba(117,89,255,.07);
        }


        .password-note {

            margin-top: 6px;

            color: #9995a4;

            font-size: 10px;

            line-height: 1.5;
        }


        .form-message {

            display: none;

            margin-bottom: 17px;

            padding: 12px 14px;

            border-radius: 9px;

            font-size: 11px;
        }


        .form-message.error {

            display: block;

            color: #ae4141;

            background: #fff0f0;
        }


        .form-message.success {

            display: block;

            color: #187858;

            background: #edf9f4;
        }


        .form-actions {

            display: flex;

            justify-content: flex-end;

            gap: 10px;

            padding-top: 20px;

            border-top:
                1px solid #efedf3;
        }


        .cancel-btn,
        .save-user-btn {

            padding: 12px 18px;

            border: none;

            border-radius: 9px;

            cursor: pointer;

            font-weight: 700;
        }


        .cancel-btn {

            background: #f1f0f5;

            color: #5d5968;
        }


        .save-user-btn {

            color: white;

            background: #7559ff;
        }


        .save-user-btn:disabled {

            opacity: .6;

            cursor: not-allowed;
        }


        



        .delete-modal {

            width: min(420px, 100%);

            padding: 32px;

            text-align: center;

            background: white;

            border-radius: 20px;
        }


        .delete-icon {

            width: 58px;

            height: 58px;

            display: grid;

            place-items: center;

            margin: auto;

            border-radius: 50%;

            color: #b84545;

            background: #fff0f0;

            font-size: 24px;
        }


        .delete-modal h2 {

            margin-top: 17px;

            font-family:
                "Manrope",
                sans-serif;
        }


        .delete-modal p {

            margin-top: 9px;

            color: #807c8d;

            font-size: 12px;

            line-height: 1.6;
        }


        .delete-buttons {

            display: flex;

            gap: 10px;

            margin-top: 24px;
        }


        .delete-buttons button {

            flex: 1;

            padding: 12px;

            border: none;

            border-radius: 9px;

            cursor: pointer;

            font-weight: 700;
        }


        .confirm-delete {

            background: #c34848;

            color: white;
        }


        



        .toast {

            position: fixed;

            z-index: 7000;

            right: 25px;

            bottom: 25px;

            min-width: 280px;

            padding: 15px 19px;

            color: white;

            border-radius: 11px;

            opacity: 0;

            transform: translateY(80px);

            pointer-events: none;

            transition: .3s;

            font-size: 12px;

            box-shadow:
                0 18px 45px
                rgba(0,0,0,.2);
        }


        .toast.show {

            opacity: 1;

            transform: translateY(0);
        }


        .toast.success {
            background: #207b5c;
        }


        .toast.error {
            background: #b34343;
        }


        @media (max-width: 900px) {

            .user-stats {

                grid-template-columns:
                    repeat(2, 1fr);
            }


            .user-toolbar {

                flex-direction: column;
            }


            .user-toolbar input,
            .user-toolbar select {

                width: 100%;
            }

        }


        @media (max-width: 600px) {

            .users-hero-content {

                flex-direction: column;

                align-items: flex-start;
            }


            .user-stats {

                grid-template-columns: 1fr;
            }

        }

    





:root {
    --vibrant-pink: #f04483;
    --vibrant-coral: #ff7548;
    --vibrant-orange: #ffb347;
    --vibrant-violet: #7958f5;
    --vibrant-ink: #30213f;
    --vibrant-muted: #87798f;
    --vibrant-line: #f2dce9;
    --vibrant-soft: #fff7fb;
}

body {
    background: #fff8fc !important;
    color: var(--vibrant-ink);
}

.navbar {
    background: rgba(255, 255, 255, .94) !important;
    border-bottom: 1px solid rgba(240, 79, 145, .12) !important;
    box-shadow: 0 8px 28px rgba(84, 33, 83, .055);
}
.brand-icon {
    background: linear-gradient(135deg, var(--vibrant-pink), var(--vibrant-coral)) !important;
    box-shadow: 0 9px 20px rgba(240, 68, 131, .25) !important;
}
.brand-purple { color: var(--vibrant-pink) !important; }
.nav-links a:hover, .nav-links .active { color: var(--vibrant-pink) !important; }
.nav-links .active::after { background: linear-gradient(90deg, var(--vibrant-pink), var(--vibrant-coral)) !important; }
.nav-button { background: linear-gradient(120deg, var(--vibrant-pink), var(--vibrant-coral)) !important; }

.booking-management-hero,
.management-hero,
.users-hero,
.venue-hero {
    position: relative;
    overflow: hidden;
    isolation: isolate;
    padding-top: clamp(42px, 5.2vw, 62px) !important;
    padding-bottom: clamp(42px, 5.2vw, 62px) !important;
    color: #fff !important;
    background:
        radial-gradient(circle at 84% 18%, rgba(255, 125, 173, .48), transparent 28%),
        radial-gradient(circle at 12% 108%, rgba(255, 179, 71, .24), transparent 35%),
        linear-gradient(128deg, #2c183d 0%, #54234f 54%, #8f315c 100%) !important;
}
.booking-management-hero::after,
.management-hero::after,
.users-hero::after,
.venue-hero::after {
    content: "";
    position: absolute;
    z-index: -1;
    width: 290px;
    height: 290px;
    right: 7%;
    top: -205px;
    border: 1px solid rgba(255,255,255,.17);
    border-radius: 50%;
    box-shadow: 0 0 0 30px rgba(255,255,255,.035), 0 0 0 62px rgba(255,255,255,.025);
    pointer-events: none;
}
.booking-management-hero h1,
.management-hero h1,
.users-hero h1,
.venue-hero h1 {
    color: #fff !important;
    font-size: clamp(34px, 4.2vw, 49px) !important;
    line-height: 1.1;
    letter-spacing: -1.8px !important;
}
.booking-management-hero p,
.management-hero p,
.users-hero p,
.venue-hero p { color: rgba(255, 244, 251, .78) !important; }
.booking-management-hero .eyebrow,
.management-hero .eyebrow,
.users-hero .eyebrow,
.venue-hero .eyebrow {
    color: #ffc1d8 !important;
    letter-spacing: 1.8px;
}

.create-event-btn, .add-user-btn, .new-venue-btn,
.save-status-btn, .save-event-btn, .save-user-btn, .venue-save-btn,
.register-submit, .login-submit {
    color: #fff !important;
    background: linear-gradient(115deg, var(--vibrant-pink), var(--vibrant-coral)) !important;
    border: 0 !important;
    box-shadow: 0 12px 25px rgba(240, 68, 131, .22);
    transition: transform .2s ease, box-shadow .2s ease, filter .2s ease;
}
.create-event-btn:hover, .add-user-btn:hover, .new-venue-btn:hover,
.save-status-btn:hover:not(:disabled), .save-event-btn:hover:not(:disabled),
.save-user-btn:hover:not(:disabled), .venue-save-btn:hover:not(:disabled) {
    filter: saturate(1.08);
    transform: translateY(-2px);
    box-shadow: 0 15px 29px rgba(240, 68, 131, .28);
}

.management-section, .users-section, .venue-section { padding-top: 38px !important; }
.booking-stats, .management-stats, .user-stats, .venue-stats { gap: 16px !important; }
.booking-stat, .management-stat, .user-stat, .venue-stat {
    position: relative;
    overflow: hidden;
    border: 1px solid var(--vibrant-line) !important;
    border-radius: 18px !important;
    background: linear-gradient(150deg, #fff 0%, #fffafd 100%) !important;
    box-shadow: 0 13px 32px rgba(88, 35, 78, .055) !important;
    transition: transform .22s ease, box-shadow .22s ease;
}
.booking-stat::before, .management-stat::before, .user-stat::before, .venue-stat::before {
    content: "";
    position: absolute;
    inset: 0 0 auto;
    height: 4px;
    background: linear-gradient(90deg, var(--vibrant-pink), var(--vibrant-coral));
}
.booking-stat:nth-child(4n + 2)::before, .management-stat:nth-child(4n + 2)::before,
.user-stat:nth-child(4n + 2)::before, .venue-stat:nth-child(4n + 2)::before { background: linear-gradient(90deg, #7958f5, #b26bff); }
.booking-stat:nth-child(4n + 3)::before, .management-stat:nth-child(4n + 3)::before,
.user-stat:nth-child(4n + 3)::before, .venue-stat:nth-child(4n + 3)::before { background: linear-gradient(90deg, #0bbfa6, #72d9b8); }
.booking-stat:nth-child(4n)::before, .management-stat:nth-child(4n)::before,
.user-stat:nth-child(4n)::before, .venue-stat:nth-child(4n)::before { background: linear-gradient(90deg, #ff9a44, #ffd16b); }
.booking-stat:hover, .management-stat:hover, .user-stat:hover, .venue-stat:hover {
    transform: translateY(-3px);
    box-shadow: 0 18px 35px rgba(88, 35, 78, .09) !important;
}
.booking-stat span, .management-stat span, .user-stat span, .venue-stat span {
    color: #94849a !important;
    letter-spacing: 1px !important;
}
.booking-stat strong, .management-stat strong, .user-stat strong, .venue-stat strong {
    color: #362242 !important;
}

.booking-toolbar, .management-toolbar, .user-toolbar, .venue-toolbar {
    border: 1px solid var(--vibrant-line) !important;
    border-radius: 17px !important;
    background: rgba(255,255,255,.94) !important;
    box-shadow: 0 9px 25px rgba(88, 35, 78, .035);
}
.booking-toolbar input, .booking-toolbar select,
.management-toolbar input, .management-toolbar select,
.user-toolbar input, .user-toolbar select,
.venue-toolbar input, .venue-toolbar select,
.form-field input, .form-field select, .form-field textarea,
.form-group input, .form-group select,
.venue-form-group input, .venue-form-group select,
.status-field select {
    border-color: #eadce8 !important;
    border-radius: 11px !important;
    background-color: #fffafd;
    color: var(--vibrant-ink);
    transition: border-color .18s ease, box-shadow .18s ease, background .18s ease;
}
.booking-toolbar input:focus, .booking-toolbar select:focus,
.management-toolbar input:focus, .management-toolbar select:focus,
.user-toolbar input:focus, .user-toolbar select:focus,
.venue-toolbar input:focus, .venue-toolbar select:focus,
.form-field input:focus, .form-field select:focus, .form-field textarea:focus,
.form-group input:focus, .form-group select:focus,
.venue-form-group input:focus, .venue-form-group select:focus,
.status-field select:focus {
    outline: none;
    border-color: var(--vibrant-pink) !important;
    box-shadow: 0 0 0 4px rgba(240, 68, 131, .10) !important;
    background: #fff !important;
}

.booking-table-card, .event-management-card, .users-table-card {
    border: 1px solid var(--vibrant-line) !important;
    border-radius: 19px !important;
    box-shadow: 0 15px 38px rgba(88, 35, 78, .055) !important;
}
.booking-table th, .event-table th, .users-table th {
    background: #fff0f7 !important;
    color: #947087 !important;
    border-bottom: 1px solid #f3dce8 !important;
}
.booking-table td, .event-table td, .users-table td { border-bottom-color: #f8eaf1 !important; }
.booking-table tbody tr:hover, .event-table tbody tr:hover, .users-table tbody tr:hover { background: #fffafd; }
.customer-cell strong, .event-cell strong, .event-name strong, .user-cell strong { color: #382443 !important; }
.customer-cell span, .event-cell span, .event-name span, .user-cell span { color: #95849a !important; }
.table-avatar { background: linear-gradient(135deg, var(--vibrant-pink), var(--vibrant-coral)) !important; box-shadow: 0 7px 14px rgba(240, 68, 131, .17); }

.manage-btn, .edit-btn, .edit-user-btn, .venue-edit {
    color: #a62b68 !important;
    background: #ffedf5 !important;
}
.manage-btn:hover, .edit-btn:hover, .edit-user-btn:hover, .venue-edit:hover { background: #ffdeec !important; }
.status-badge, .status-pill, .role-badge, .venue-status { border-radius: 100px !important; }
.role-admin { color: #6944c1 !important; background: #f0eaff !important; }
.role-organiser { color: #176f9a !important; background: #e5f6ff !important; }
.role-customer { color: #167858 !important; background: #e4fbf1 !important; }

.venue-card {
    border: 1px solid var(--vibrant-line) !important;
    border-radius: 20px !important;
    box-shadow: 0 13px 32px rgba(88, 35, 78, .065) !important;
}
.venue-card:hover { box-shadow: 0 23px 45px rgba(88, 35, 78, .13) !important; }
.venue-cover {
    background:
        radial-gradient(circle at 76% 22%, rgba(255, 184, 111, .52), transparent 30%),
        linear-gradient(135deg, #4a2054, #b13b76 68%, #f07968) !important;
}
.venue-info-box { background: #fff6fb !important; border-color: #f5e1ed !important; }

.modal-overlay { background: rgba(34, 15, 42, .68) !important; backdrop-filter: blur(9px) !important; }
.booking-modal, .event-modal, .user-modal, .venue-modal, .delete-modal {
    border: 1px solid rgba(255,255,255,.75) !important;
    border-radius: 24px !important;
    box-shadow: 0 34px 95px rgba(29, 8, 35, .32) !important;
}
.booking-modal-header, .modal-header, .user-modal-header, .venue-modal-header {
    border-bottom-color: #f3dfe9 !important;
    background: linear-gradient(110deg, #fff8fc, #fff2f8) !important;
}
.booking-modal-header span, .modal-header span, .user-modal-header span, .venue-modal-header span { color: var(--vibrant-pink) !important; }
.booking-summary { background: #fff6fb !important; border-color: #f4dfeb !important; }
.close-modal, .modal-close { background: #fff0f7 !important; color: #a62b68 !important; }
.close-modal:hover, .modal-close:hover { background: #ffdeec !important; }
.cancel-modal-btn, .cancel-btn, .venue-cancel-btn { background: #f5f0f5 !important; color: #69596e !important; }
.save-status-btn, .save-event-btn, .save-user-btn, .venue-save-btn, .confirm-delete { border-radius: 10px !important; }
.delete-icon, .delete-modal-icon { background: #fff0f5 !important; color: var(--vibrant-pink) !important; }
.delete-modal h2 { color: #382443 !important; }
.empty-bookings, .empty-events, .empty-users, .empty-venues {
    color: #95849a !important;
}
.toast { border-radius: 13px !important; box-shadow: 0 15px 40px rgba(48, 20, 51, .16) !important; }

@media (max-width: 980px) {
    .booking-stats, .management-stats, .user-stats, .venue-stats { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
    .venue-grid { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
    .booking-management-hero h1, .management-hero h1, .users-hero h1, .venue-hero h1 { letter-spacing: -1.2px !important; }
}
@media (max-width: 650px) {
    .booking-stats, .management-stats, .user-stats, .venue-stats, .venue-grid { grid-template-columns: 1fr !important; }
    .booking-toolbar, .management-toolbar, .user-toolbar, .venue-toolbar { flex-direction: column; align-items: stretch; }
    .booking-toolbar select, .management-toolbar select, .user-toolbar select, .venue-toolbar select { width: 100%; min-width: 0; }
    .booking-management-hero, .management-hero, .users-hero, .venue-hero { padding: 38px 0 !important; }
    .management-hero-content, .users-hero-content, .venue-hero-content { align-items: flex-start !important; flex-direction: column; }
    .empty-bookings, .empty-events, .empty-users, .empty-venues { padding: 38px 20px !important; }
}

</style>

    <link rel="stylesheet" href="css/golive-inspired.css">

</head>


<body>




<header class="navbar">

    <div class="container nav-container">

        <a
            href="index.php"
            class="brand"
        >

            <div class="brand-icon">
                E
            </div>

            <span>
                Event<span class="brand-purple">ify</span>
            </span>

        </a>


        <nav class="nav-links">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="manage-events.php">
                Events
            </a>

            <a href="manage-venues.php">
                Venues
            </a>

            <a href="manage-bookings.php">
                Bookings
            </a>

            <a
                href="manage-users.php"
                class="active"
            >
                Users
            </a>

        </nav>


        <div
            class="nav-actions"
            id="authNavigation"
        >
        </div>

    </div>

</header>





<section class="users-hero">

    <div
        class="
            container
            users-hero-content
        "
    >

        <div>

            <span class="eyebrow">
                ADMINISTRATION
            </span>

            <h1>
                Manage Users
            </h1>

            <p>
                Manage customer, organiser and
                administrator accounts.
            </p>

        </div>


        <button
            type="button"
            class="add-user-btn"
            id="addUserButton"
        >
            + Create User
        </button>

    </div>

</section>





<main class="users-section">

    <div class="container">


        

        <section class="user-stats">


            <article class="user-stat">

                <span>
                    Total Users
                </span>

                <strong id="totalUsers">
                    0
                </strong>

            </article>


            <article class="user-stat">

                <span>
                    Customers
                </span>

                <strong id="customerCount">
                    0
                </strong>

            </article>


            <article class="user-stat">

                <span>
                    Organisers
                </span>

                <strong id="organiserCount">
                    0
                </strong>

            </article>


            <article class="user-stat">

                <span>
                    Administrators
                </span>

                <strong id="adminCount">
                    0
                </strong>

            </article>


        </section>



        

        <section class="user-toolbar">


            <input
                type="text"
                id="userSearch"
                placeholder="Search name, email or user ID..."
            >


            <select id="roleFilter">

                <option value="">
                    All Roles
                </option>

                <option value="Administrator">
                    Administrator
                </option>

                <option value="Organiser">
                    Organiser
                </option>

                <option value="Customer">
                    Customer
                </option>

            </select>


        </section>



        

        <section class="users-table-card">

            <div class="table-scroll">

                <table class="users-table">


                    <thead>

                        <tr>

                            <th>
                                User
                            </th>

                            <th>
                                Role
                            </th>

                            <th>
                                Events
                            </th>

                            <th>
                                Bookings
                            </th>

                            <th>
                                Joined
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>


                    <tbody id="userTableBody">

                        <tr>

                            <td
                                colspan="6"
                                class="empty-users"
                            >
                                Loading users...
                            </td>

                        </tr>

                    </tbody>


                </table>

            </div>

        </section>


    </div>

</main>





<div
    class="modal-overlay"
    id="userModal"
>

    <div class="user-modal">


        <div class="user-modal-header">

            <div>

                <span id="modalEyebrow">
                    CREATE USER
                </span>

                <h2 id="modalTitle">
                    New User
                </h2>

            </div>


            <button
                type="button"
                class="close-modal"
                id="closeUserModal"
            >
                ×
            </button>

        </div>



        <form
            class="user-form"
            id="userForm"
        >


            <input
                type="hidden"
                id="userId"
            >


            <div
                class="form-message"
                id="formMessage"
            >
            </div>



            <div class="form-group">

                <label for="userName">
                    Full Name
                </label>

                <input
                    type="text"
                    id="userName"
                    placeholder="Enter full name"
                    required
                >

            </div>



            <div class="form-group">

                <label for="userEmail">
                    Email Address
                </label>

                <input
                    type="email"
                    id="userEmail"
                    placeholder="example@email.com"
                    required
                >

            </div>



            <div class="form-group">

                <label for="userRole">
                    Role
                </label>

                <select
                    id="userRole"
                    required
                >

                    <option value="Customer">
                        Customer
                    </option>

                    <option value="Organiser">
                        Organiser
                    </option>

                    <option value="Administrator">
                        Administrator
                    </option>

                </select>

            </div>



            <div class="form-group">

                <label for="userPassword">
                    Password
                </label>

                <input
                    type="password"
                    id="userPassword"
                    placeholder="Enter password"
                >

                <p
                    class="password-note"
                    id="passwordNote"
                >
                    Minimum 6 characters.
                </p>

            </div>



            <div class="form-actions">


                <button
                    type="button"
                    class="cancel-btn"
                    id="cancelUserButton"
                >
                    Cancel
                </button>


                <button
                    type="submit"
                    class="save-user-btn"
                    id="saveUserButton"
                >
                    Create User
                </button>


            </div>


        </form>


    </div>

</div>





<div
    class="modal-overlay"
    id="deleteModal"
>

    <div class="delete-modal">


        <div class="delete-icon">
            !
        </div>


        <h2>
            Delete User?
        </h2>


        <p id="deleteText">

            This account will be permanently deleted.
        </p>


        <div class="delete-buttons">


            <button
                type="button"
                class="cancel-btn"
                id="keepUserButton"
            >
                Keep User
            </button>


            <button
                type="button"
                class="confirm-delete"
                id="confirmDeleteButton"
            >
                Delete User
            </button>


        </div>


    </div>

</div>



<div
    class="toast"
    id="toast"
>
</div>



<script>





const token =
    localStorage.getItem(
        "eventify_token"
    );


let currentUser =
    null;


let users =
    [];


let formMode =
    "create";


let selectedDeleteId =
    null;



const userTableBody =
    document.getElementById(
        "userTableBody"
    );


const userModal =
    document.getElementById(
        "userModal"
    );


const deleteModal =
    document.getElementById(
        "deleteModal"
    );


const userForm =
    document.getElementById(
        "userForm"
    );


const formMessage =
    document.getElementById(
        "formMessage"
    );


const saveUserButton =
    document.getElementById(
        "saveUserButton"
    );


const toast =
    document.getElementById(
        "toast"
    );







async function initialise() {


    if (!token) {

        window.location.href =
            "login.php";

        return;
    }


    try {


        const response =
            await fetch(
                "auth/me.php",
                {
                    headers: {

                        Authorization:
                            "Bearer "
                            + token

                    }
                }
            );


        const result =
            await response.json();


        if (
            !response.ok ||
            result.status !== "success"
        ) {

            logout();

            return;
        }


        currentUser =
            result.user;



        

        if (
            currentUser.role !==
            "Administrator"
        ) {

            alert(
                "Administrator access is required."
            );


            window.location.href =
                currentUser.role ===
                "Organiser"

                ?

                "dashboard.php"

                :

                "events.php";


            return;
        }


        updateNavbar();


        await loadUsers();


    } catch (error) {


        showToast(
            "Unable to load user management.",
            "error"
        );

    }

}







async function loadUsers() {


    const response =
        await fetch(
            "api/users.php",
            {
                headers: {

                    Authorization:
                        "Bearer "
                        + token

                }
            }
        );


    const result =
        await response.json();


    if (
        response.status === 401
    ) {

        logout();

        return;
    }


    if (
        !response.ok ||
        result.status !== "success"
    ) {

        throw new Error(
            result.message ||
            "Unable to load users"
        );
    }


    users =
        result.data;


    displayUsers(
        users
    );


    updateStatistics();

}







function displayUsers(
    userList
) {


    userTableBody.innerHTML =
        "";


    if (
        userList.length === 0
    ) {


        userTableBody.innerHTML = `

            <tr>

                <td
                    colspan="6"
                    class="empty-users"
                >

                    No users found.

                </td>

            </tr>

        `;


        return;
    }



    userList.forEach(
        user => {


            const initial =
                String(
                    user.name
                )
                .charAt(0)
                .toUpperCase();


            const joined =
                new Date(
                    String(
                        user.created_at
                    ).replace(
                        " ",
                        "T"
                    )
                );


            const joinedText =
                isNaN(
                    joined.getTime()
                )

                ?

                user.created_at

                :

                joined.toLocaleDateString(
                    "en-MY",
                    {
                        day: "numeric",
                        month: "short",
                        year: "numeric"
                    }
                );


            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>

                    <div class="user-cell">

                        <div class="table-avatar">

                            ${initial}

                        </div>


                        <div>

                            <strong>

                                ${escapeHTML(
                                    user.name
                                )}

                            </strong>

                            <span>

                                #${user.user_id}
                                •
                                ${escapeHTML(
                                    user.email
                                )}

                            </span>

                        </div>

                    </div>

                </td>


                <td>

                    <span
                        class="
                            role-badge
                            ${getRoleClass(
                                user.role
                            )}
                        "
                    >

                        ${escapeHTML(
                            user.role
                        )}

                    </span>

                </td>


                <td>

                    ${Number(
                        user.event_count
                    )}

                </td>


                <td>

                    ${Number(
                        user.booking_count
                    )}

                </td>


                <td>

                    ${joinedText}

                </td>


                <td>

                    <div class="user-actions">


                        <button
                            type="button"
                            class="edit-user-btn"
                            onclick="
                                editUser(
                                    ${user.user_id}
                                )
                            "
                        >

                            Edit

                        </button>


                        ${
                            Number(
                                user.user_id
                            )
                            !==
                            Number(
                                currentUser.user_id
                            )

                            ?

                            `

                            <button
                                type="button"
                                class="delete-user-btn"

                                onclick="
                                    askDelete(
                                        ${user.user_id}
                                    )
                                "
                            >

                                Delete

                            </button>

                            `

                            :

                            ""

                        }


                    </div>

                </td>

            `;


            userTableBody
                .appendChild(
                    row
                );

        }
    );

}







function updateStatistics() {


    const customers =
        users.filter(
            user =>
                user.role ===
                "Customer"
        ).length;


    const organisers =
        users.filter(
            user =>
                user.role ===
                "Organiser"
        ).length;


    const administrators =
        users.filter(
            user =>
                user.role ===
                "Administrator"
        ).length;


    document
        .getElementById(
            "totalUsers"
        )
        .textContent =
            users.length;


    document
        .getElementById(
            "customerCount"
        )
        .textContent =
            customers;


    document
        .getElementById(
            "organiserCount"
        )
        .textContent =
            organisers;


    document
        .getElementById(
            "adminCount"
        )
        .textContent =
            administrators;

}







document
    .getElementById(
        "userSearch"
    )
    .addEventListener(
        "input",
        filterUsers
    );


document
    .getElementById(
        "roleFilter"
    )
    .addEventListener(
        "change",
        filterUsers
    );


function filterUsers() {


    const search =
        document
            .getElementById(
                "userSearch"
            )
            .value
            .toLowerCase();


    const role =
        document
            .getElementById(
                "roleFilter"
            )
            .value;


    const filtered =
        users.filter(
            user => {


                const text =
                    (
                        user.user_id
                        + " "
                        + user.name
                        + " "
                        + user.email
                    )
                    .toLowerCase();


                const searchMatch =
                    text.includes(
                        search
                    );


                const roleMatch =
                    role === ""
                    ||
                    user.role === role;


                return (
                    searchMatch &&
                    roleMatch
                );

            }
        );


    displayUsers(
        filtered
    );

}







document
    .getElementById(
        "addUserButton"
    )
    .addEventListener(
        "click",
        openCreateUser
    );


function openCreateUser() {


    formMode =
        "create";


    userForm.reset();


    document
        .getElementById(
            "userId"
        )
        .value =
            "";


    document
        .getElementById(
            "modalEyebrow"
        )
        .textContent =
            "CREATE USER";


    document
        .getElementById(
            "modalTitle"
        )
        .textContent =
            "New User";


    document
        .getElementById(
            "passwordNote"
        )
        .textContent =
            "Password is required. Minimum 6 characters.";


    document
        .getElementById(
            "userPassword"
        )
        .required =
            true;


    saveUserButton.textContent =
        "Create User";


    clearMessage();


    userModal.classList.add(
        "show"
    );

}







function editUser(
    userId
) {


    const user =
        users.find(
            item =>
                Number(
                    item.user_id
                )
                ===
                Number(userId)
        );


    if (!user) {

        return;
    }


    formMode =
        "edit";


    document
        .getElementById(
            "userId"
        )
        .value =
            user.user_id;


    document
        .getElementById(
            "userName"
        )
        .value =
            user.name;


    document
        .getElementById(
            "userEmail"
        )
        .value =
            user.email;


    document
        .getElementById(
            "userRole"
        )
        .value =
            user.role;


    document
        .getElementById(
            "userPassword"
        )
        .value =
            "";


    document
        .getElementById(
            "userPassword"
        )
        .required =
            false;


    document
        .getElementById(
            "passwordNote"
        )
        .textContent =
            "Leave blank to keep the existing password. Enter at least 6 characters to reset it.";


    document
        .getElementById(
            "modalEyebrow"
        )
        .textContent =
            "EDIT USER";


    document
        .getElementById(
            "modalTitle"
        )
        .textContent =
            "Update User";


    saveUserButton.textContent =
        "Save Changes";


    clearMessage();


    userModal.classList.add(
        "show"
    );

}







userForm.addEventListener(
    "submit",
    async function (
        event
    ) {


        event.preventDefault();


        const password =
            document
                .getElementById(
                    "userPassword"
                )
                .value;


        const payload = {

            name:
                document
                    .getElementById(
                        "userName"
                    )
                    .value
                    .trim(),

            email:
                document
                    .getElementById(
                        "userEmail"
                    )
                    .value
                    .trim(),

            role:
                document
                    .getElementById(
                        "userRole"
                    )
                    .value,

            password:
                password

        };


        if (
            formMode === "edit"
        ) {

            payload.user_id =
                Number(
                    document
                        .getElementById(
                            "userId"
                        )
                        .value
                );

        }


        if (
            formMode === "create"
            &&
            password.length < 6
        ) {

            showMessage(
                "Password must contain at least 6 characters.",
                "error"
            );

            return;
        }


        if (
            formMode === "edit"
            &&
            password !== ""
            &&
            password.length < 6
        ) {

            showMessage(
                "New password must contain at least 6 characters.",
                "error"
            );

            return;
        }


        saveUserButton.disabled =
            true;


        saveUserButton.textContent =
            formMode === "create"
            ?
            "Creating..."
            :
            "Saving...";


        try {


            const response =
                await fetch(
                    "api/users.php",
                    {

                        method:
                            formMode ===
                            "create"
                            ?
                            "POST"
                            :
                            "PUT",

                        headers: {

                            "Content-Type":
                                "application/json",

                            Authorization:
                                "Bearer "
                                + token

                        },

                        body:
                            JSON.stringify(
                                payload
                            )

                    }
                );


            const result =
                await response.json();


            if (
                response.status === 401
            ) {

                logout();

                return;
            }


            if (
                !response.ok ||
                result.status !==
                "success"
            ) {

                throw new Error(
                    result.message ||
                    "Unable to save user"
                );

            }


            showMessage(
                result.message,
                "success"
            );


            await loadUsers();


            setTimeout(
                function () {


                    userModal.classList.remove(
                        "show"
                    );


                    showToast(
                        result.message,
                        "success"
                    );


                },
                600
            );


        } catch (error) {


            showMessage(
                error.message,
                "error"
            );


        } finally {


            saveUserButton.disabled =
                false;


            saveUserButton.textContent =
                formMode === "create"
                ?
                "Create User"
                :
                "Save Changes";

        }

    }
);







function askDelete(
    userId
) {


    selectedDeleteId =
        userId;


    const user =
        users.find(
            item =>
                Number(
                    item.user_id
                )
                ===
                Number(userId)
        );


    document
        .getElementById(
            "deleteText"
        )
        .textContent =

            user

            ?

            'Delete "'
            +
            user.name
            +
            '"? Accounts linked to events or bookings cannot be deleted.'

            :

            "Delete this user?";


    deleteModal.classList.add(
        "show"
    );

}



document
    .getElementById(
        "confirmDeleteButton"
    )
    .addEventListener(
        "click",
        async function () {


            if (
                !selectedDeleteId
            ) {

                return;
            }


            this.disabled =
                true;


            this.textContent =
                "Deleting...";


            try {


                const response =
                    await fetch(
                        "api/users.php",
                        {

                            method:
                                "DELETE",

                            headers: {

                                "Content-Type":
                                    "application/json",

                                Authorization:
                                    "Bearer "
                                    + token

                            },

                            body:
                                JSON.stringify({

                                    user_id:
                                        selectedDeleteId

                                })

                        }
                    );


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    "success"
                ) {

                    throw new Error(
                        result.message ||
                        "Unable to delete user"
                    );

                }


                deleteModal.classList.remove(
                    "show"
                );


                selectedDeleteId =
                    null;


                await loadUsers();


                showToast(
                    result.message,
                    "success"
                );


            } catch (error) {


                deleteModal.classList.remove(
                    "show"
                );


                showToast(
                    error.message,
                    "error"
                );


            } finally {


                this.disabled =
                    false;


                this.textContent =
                    "Delete User";

            }

        }
    );







function closeUserModal() {


    userModal.classList.remove(
        "show"
    );

}



document
    .getElementById(
        "closeUserModal"
    )
    .addEventListener(
        "click",
        closeUserModal
    );


document
    .getElementById(
        "cancelUserButton"
    )
    .addEventListener(
        "click",
        closeUserModal
    );


document
    .getElementById(
        "keepUserButton"
    )
    .addEventListener(
        "click",
        function () {


            selectedDeleteId =
                null;


            deleteModal.classList.remove(
                "show"
            );

        }
    );







function clearMessage() {


    formMessage.className =
        "form-message";


    formMessage.textContent =
        "";

}



function showMessage(
    message,
    type
) {


    formMessage.textContent =
        message;


    formMessage.className =
        "form-message "
        + type;

}







function getRoleClass(
    role
) {


    if (
        role === "Administrator"
    ) {

        return "role-admin";
    }


    if (
        role === "Organiser"
    ) {

        return "role-organiser";
    }


    return "role-customer";

}







function updateNavbar() {


    document
        .getElementById(
            "authNavigation"
        )
        .innerHTML = `

            <span
                style="
                    color:#555263;
                    font-size:13px;
                    font-weight:700;
                "
            >

                ${escapeHTML(
                    currentUser.name
                )}

                <small
                    style="
                        color:#9995a4;
                    "
                >

                    (Administrator)

                </small>

            </span>


            <button
                type="button"
                onclick="logout()"

                style="
                    border:none;
                    padding:11px 17px;
                    border-radius:9px;
                    background:#11101d;
                    color:white;
                    cursor:pointer;
                    font-weight:700;
                "
            >

                Logout

            </button>

        `;

}







function logout() {


    localStorage.removeItem(
        "eventify_token"
    );


    localStorage.removeItem(
        "eventify_user"
    );


    window.location.href =
        "login.php";

}







function showToast(
    message,
    type
) {


    toast.textContent =
        message;


    toast.className =
        "toast "
        + type
        + " show";


    setTimeout(
        function () {


            toast.classList.remove(
                "show"
            );


        },
        3500
    );

}







function escapeHTML(
    value
) {


    return String(
        value ?? ""
    )

        .replaceAll("&", "&amp;")

        .replaceAll("<", "&lt;")

        .replaceAll(">", "&gt;")

        .replaceAll('"', "&quot;")

        .replaceAll("'", "&#039;");

}







initialise();

</script>


</body>

</html>