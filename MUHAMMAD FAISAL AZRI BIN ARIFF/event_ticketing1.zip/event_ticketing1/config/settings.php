<?php

function eventifySetting(string $name, $default = null) {
    static $local = null;
    if ($local === null) {
        $path = __DIR__ . '/local.php';
        $loaded = is_file($path) ? require $path : [];
        $local = is_array($loaded) ? $loaded : [];
    }
    $environment = getenv($name);
    if ($environment !== false && $environment !== '') return $environment;
    return array_key_exists($name, $local) ? $local[$name] : $default;
}
