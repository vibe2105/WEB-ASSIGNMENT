<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta

        name="viewport"

        content="width=device-width, initial-scale=1.0"

    >

    <title>Management Dashboard | Eventify</title>

    <link

        rel="stylesheet"

        href="css/style.css"

    >

    <style>

        body {

            background: #f5f5fa;

        }

        





        .dashboard-layout {

            display: grid;

            grid-template-columns:

                255px 1fr;

            min-height:

                calc(100vh - 78px);

        }

        





        .dashboard-sidebar {

            background:

                linear-gradient(

                    180deg,

                    #11101d,

                    #17142b

                );

            color: white;

            padding: 28px 19px;

            position: relative;

        }

        .sidebar-user {

            padding: 16px;

            margin-bottom: 28px;

            border-radius: 14px;

            background:

                rgba(255,255,255,.055);

            border:

                1px solid

                rgba(255,255,255,.08);

        }

        .sidebar-avatar {

            width: 45px;

            height: 45px;

            display: grid;

            place-items: center;

            margin-bottom: 12px;

            border-radius: 12px;

            color: white;

            background:

                linear-gradient(

                    135deg,

                    #856cff,

                    #6043d8

                );

            font-weight: 800;

            font-size: 17px;

        }

        .sidebar-user small {

            display: block;

            color: #888494;

            font-size: 9px;

            text-transform: uppercase;

            letter-spacing: 1px;

        }

        .sidebar-user strong {

            display: block;

            margin-top: 5px;

            font-size: 13px;

        }

        .sidebar-menu {

            display: grid;

            gap: 7px;

        }

        .sidebar-menu a {

            display: flex;

            align-items: center;

            gap: 12px;

            padding: 13px 14px;

            border-radius: 10px;

            color: #aaa6b9;

            font-size: 12px;

            font-weight: 650;

            transition: .2s;

        }

        .sidebar-menu a:hover,

        .sidebar-menu a.active {

            color: #c2b8ff;

            background:

                rgba(117,89,255,.15);

        }

        .sidebar-menu-icon {

            width: 23px;

            text-align: center;

            color: #9283f5;

            font-weight: 800;

        }

        .sidebar-section-label {

            margin:

                27px 12px 10px;

            color: #656170;

            font-size: 8px;

            font-weight: 800;

            letter-spacing: 1.4px;

            text-transform: uppercase;

        }

        .sidebar-divider {

            height: 1px;

            margin: 22px 0;

            background:

                rgba(255,255,255,.07);

        }

        .logout-sidebar {

            width: 100%;

            padding: 12px;

            border:

                1px solid

                rgba(255,255,255,.08);

            border-radius: 9px;

            background:

                rgba(255,255,255,.04);

            color: #aaa6b7;

            cursor: pointer;

            font-weight: 700;

            transition: .2s;

        }

        .logout-sidebar:hover {

            background:

                rgba(255,255,255,.09);

            color: white;

        }

        





        .dashboard-main {

            padding: 38px;

            min-width: 0;

        }

        .dashboard-header {

            display: flex;

            justify-content: space-between;

            align-items: center;

            gap: 25px;

            margin-bottom: 32px;

        }

        .dashboard-eyebrow {

            color: #7559ff;

            font-size: 10px;

            font-weight: 800;

            letter-spacing: 1.6px;

        }

        .dashboard-header h1 {

            margin-top: 6px;

            font-family:

                "Manrope",

                sans-serif;

            font-size: 35px;

            letter-spacing: -1px;

        }

        .dashboard-header p {

            margin-top: 6px;

            color: #898595;

            font-size: 13px;

        }

        .dashboard-user-chip {

            display: flex;

            align-items: center;

            gap: 11px;

            padding: 10px 13px;

            background: white;

            border:

                1px solid #e8e6ee;

            border-radius: 13px;

        }

        .chip-avatar {

            width: 40px;

            height: 40px;

            display: grid;

            place-items: center;

            border-radius: 11px;

            color: white;

            background:

                linear-gradient(

                    135deg,

                    #8166ff,

                    #6245dc

                );

            font-weight: 800;

        }

        .dashboard-user-chip small {

            display: block;

            color: #9995a4;

            font-size: 9px;

            text-transform: uppercase;

        }

        .dashboard-user-chip strong {

            display: block;

            margin-top: 3px;

            color: #302d39;

            font-size: 12px;

        }

        





        .dashboard-stats {

            display: grid;

            grid-template-columns:

                repeat(4, 1fr);

            gap: 19px;

            margin-bottom: 28px;

        }

        .dashboard-stat-card {

            padding: 23px;

            background: white;

            border:

                1px solid #e9e7ef;

            border-radius: 17px;

            box-shadow:

                0 12px 30px

                rgba(24,20,50,.04);

        }

        .stat-top {

            display: flex;

            justify-content: space-between;

            align-items: start;

            gap: 10px;

        }

        .dashboard-stat-card small {

            color: #9995a4;

            font-size: 9px;

            font-weight: 750;

            letter-spacing: .7px;

            text-transform: uppercase;

        }

        .dashboard-stat-card h2 {

            margin-top: 8px;

            font-family:

                "Manrope",

                sans-serif;

            font-size: 30px;

        }

        .dashboard-stat-card p {

            margin-top: 6px;

            color: #918d9c;

            font-size: 10px;

        }

        .stat-icon {

            width: 41px;

            height: 41px;

            display: grid;

            place-items: center;

            border-radius: 11px;

            background: #eeeaff;

            color: #7559ff;

            font-weight: 800;

        }

        





        .management-heading {

            display: flex;

            justify-content: space-between;

            align-items: end;

            margin:

                34px 0 17px;

        }

        .management-heading h2 {

            font-family:

                "Manrope",

                sans-serif;

            font-size: 22px;

        }

        .management-heading p {

            margin-top: 4px;

            color: #918d9c;

            font-size: 11px;

        }

        .management-grid {

            display: grid;

            grid-template-columns:

                repeat(3, 1fr);

            gap: 19px;

            margin-bottom: 29px;

        }

        .management-card {

            position: relative;

            overflow: hidden;

            min-height: 210px;

            padding: 24px;

            display: flex;

            flex-direction: column;

            justify-content: space-between;

            background: white;

            border:

                1px solid #e9e7ef;

            border-radius: 18px;

            color: #292633;

            box-shadow:

                0 13px 32px

                rgba(24,20,50,.04);

            transition: .3s;

        }

        .management-card:hover {

            transform: translateY(-5px);

            border-color: #c7befd;

            box-shadow:

                0 22px 45px

                rgba(24,20,50,.09);

        }

        .management-card::after {

            content: "";

            position: absolute;

            width: 130px;

            height: 130px;

            border-radius: 50%;

            right: -55px;

            top: -50px;

            background:

                radial-gradient(

                    circle,

                    rgba(117,89,255,.15),

                    transparent 70%

                );

        }

        .management-icon {

            width: 47px;

            height: 47px;

            display: grid;

            place-items: center;

            border-radius: 13px;

            background: #eeeaff;

            color: #7559ff;

            font-size: 18px;

            font-weight: 800;

        }

        .management-card h3 {

            margin-top: 19px;

            font-family:

                "Manrope",

                sans-serif;

            font-size: 18px;

        }

        .management-card p {

            margin-top: 7px;

            max-width: 260px;

            color: #8b8797;

            font-size: 11px;

            line-height: 1.65;

        }

        .management-link {

            display: flex;

            justify-content: space-between;

            align-items: center;

            margin-top: 25px;

            color: #7559ff;

            font-size: 11px;

            font-weight: 800;

        }

        





        .dashboard-content-grid {

            display: grid;

            grid-template-columns:

                1fr 1fr;

            gap: 22px;

        }

        .dashboard-panel {

            overflow: hidden;

            background: white;

            border:

                1px solid #e9e7ef;

            border-radius: 18px;

            box-shadow:

                0 13px 32px

                rgba(24,20,50,.04);

        }

        .panel-header {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 15px;

            padding: 20px 22px;

            border-bottom:

                1px solid #efedf3;

        }

        .panel-header h2 {

            font-family:

                "Manrope",

                sans-serif;

            font-size: 17px;

        }

        .panel-header span {

            display: block;

            margin-top: 3px;

            color: #9995a4;

            font-size: 10px;

        }

        .panel-header a {

            color: #7559ff;

            font-size: 10px;

            font-weight: 800;

        }

        .dashboard-list {

            display: grid;

        }

        .dashboard-row {

            display: flex;

            justify-content: space-between;

            align-items: center;

            gap: 15px;

            padding: 17px 22px;

            border-bottom:

                1px solid #f0eef3;

        }

        .dashboard-row:last-child {

            border-bottom: none;

        }

        .row-content {

            min-width: 0;

        }

        .row-content strong {

            display: block;

            overflow: hidden;

            white-space: nowrap;

            text-overflow: ellipsis;

            font-size: 12px;

        }

        .row-content span {

            display: block;

            margin-top: 4px;

            color: #9995a4;

            font-size: 10px;

        }

        .status-pill {

            flex-shrink: 0;

            padding: 6px 9px;

            border-radius: 100px;

            font-size: 8px;

            font-weight: 800;

        }

        .status-green {

            color: #187b59;

            background: #eaf8f2;

        }

        .status-red {

            color: #b54b4b;

            background: #fff0f0;

        }

        .status-gray {

            color: #686474;

            background: #f0eff3;

        }

        .empty-data {

            padding: 45px;

            text-align: center;

            color: #918d9c;

            font-size: 11px;

        }

        





        .access-denied {

            grid-column: 1 / -1;

            min-height:

                calc(100vh - 80px);

            display: flex;

            flex-direction: column;

            justify-content: center;

            align-items: center;

            padding: 30px;

            text-align: center;

        }

        .access-denied-icon {

            width: 70px;

            height: 70px;

            display: grid;

            place-items: center;

            margin-bottom: 20px;

            border-radius: 50%;

            background: #fff0f0;

            color: #b74747;

            font-size: 27px;

        }

        .access-denied h1 {

            font-family:

                "Manrope",

                sans-serif;

        }

        .access-denied p {

            max-width: 450px;

            margin-top: 10px;

            color: #898595;

            line-height: 1.6;

        }

        .access-denied a {

            margin-top: 20px;

            padding: 11px 17px;

            border-radius: 9px;

            color: white;

            background: #7559ff;

            font-weight: 700;

        }

        





        @media (max-width: 1150px) {

            .dashboard-stats {

                grid-template-columns:

                    repeat(2, 1fr);

            }

            .management-grid {

                grid-template-columns:

                    1fr;

            }

        }

        @media (max-width: 900px) {

            .dashboard-layout {

                grid-template-columns: 1fr;

            }

            .dashboard-sidebar {

                display: none;

            }

            .dashboard-content-grid {

                grid-template-columns: 1fr;

            }

        }

        @media (max-width: 650px) {

            .dashboard-main {

                padding: 24px;

            }

            .dashboard-stats {

                grid-template-columns: 1fr;

            }

            .dashboard-header {

                flex-direction: column;

                align-items: flex-start;

            }

        }

    
        
        .management-grid.organiser-view {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        @media (max-width: 1150px) {
            .management-grid.organiser-view {
                grid-template-columns: 1fr;
            }
        }

    



body { background: #fff8fc !important; }
.dashboard-layout { background: #fff8fc !important; }
.dashboard-sidebar {
  background: radial-gradient(circle at 0% 0%,rgba(240,79,145,.28),transparent 32%),linear-gradient(180deg,#28163d,#39204f 65%,#4c245d) !important;
  box-shadow: 12px 0 35px rgba(44,18,55,.08) !important;
}
.sidebar-avatar { background: linear-gradient(135deg,#ff9855,#f04f91) !important; box-shadow: 0 7px 18px rgba(240,79,145,.24) !important; }
.sidebar-menu a:hover, .sidebar-menu a.active { background: rgba(255,255,255,.13) !important; color: #fff !important; }
.sidebar-menu a.active { box-shadow: inset 3px 0 #ff9855 !important; }
.sidebar-menu-icon { color: #ffb7d5 !important; }
.logout-sidebar:hover { background: rgba(240,79,145,.18) !important; }
.dashboard-main { background: #fff8fc !important; }
.dashboard-eyebrow { color: #df3a80 !important; }
.dashboard-user-chip { background: #fff !important; border: 1px solid #f4dce9 !important; box-shadow: 0 7px 20px rgba(74,29,79,.05) !important; }
.chip-avatar { background: linear-gradient(135deg,#6654f0,#f04f91) !important; }
.dashboard-stat-card {
  border: 1px solid rgba(240,79,145,.12) !important; border-radius: 22px !important;
  box-shadow: 0 12px 30px rgba(74,29,79,.06) !important; background: linear-gradient(145deg,#fff,#fff7fb) !important;
}
.dashboard-stat-card:nth-child(2) { background: linear-gradient(145deg,#fff,#fff3e9) !important; }
.dashboard-stat-card:nth-child(3) { background: linear-gradient(145deg,#fff,#f4f1ff) !important; }
.dashboard-stat-card:nth-child(4) { background: linear-gradient(145deg,#fff,#eafbf8) !important; }
.stat-icon { border-radius: 15px !important; background: #fff0f6 !important; color: #e33d84 !important; }
.dashboard-stat-card:nth-child(2) .stat-icon { background: #fff0df !important; color: #d46c26 !important; }
.dashboard-stat-card:nth-child(3) .stat-icon { background: #efecff !important; color: #6654f0 !important; }
.dashboard-stat-card:nth-child(4) .stat-icon { background: #e3faf6 !important; color: #139b8d !important; }
.management-card { border: 1px solid #f1deeb !important; border-radius: 22px !important; box-shadow: 0 10px 28px rgba(74,29,79,.05) !important; }
.management-card:hover { border-color: #f3a9cb !important; box-shadow: 0 20px 38px rgba(74,29,79,.11) !important; }
.management-icon { background: linear-gradient(135deg,#f04f91,#ff9855) !important; box-shadow: 0 9px 20px rgba(240,79,145,.2) !important; }
.management-card:nth-child(2) .management-icon { background: linear-gradient(135deg,#6654f0,#a15eff) !important; }
.management-card:nth-child(3) .management-icon { background: linear-gradient(135deg,#23bdb0,#4c9ce8) !important; }
.management-link, .panel-header a { color: #d9347b !important; }
.dashboard-panel { border: 1px solid #f1deeb !important; border-radius: 22px !important; box-shadow: 0 10px 28px rgba(74,29,79,.05) !important; }
.panel-header { border-bottom-color: #f5e5ee !important; }
.status-green { background: #e4f9ef !important; color: #147c54 !important; }
.status-red { background: #fff0f3 !important; color: #ca3a5c !important; }
.status-gray { background: #f4f0f8 !important; color: #76677f !important; }
.access-denied-icon { background: #fff0f6 !important; color: #e33d84 !important; }


</style>

    <link rel="stylesheet" href="css/golive-inspired.css">

</head>

<body>



<header class="navbar">

    <div class="container nav-container">

        <a

            href="index.php"

            class="brand"

        >

            <div class="brand-icon">

                E

            </div>

            <span>

                Event<span class="brand-purple">ify</span>

            </span>

        </a>

        <nav class="nav-links" id="dashboardTopLinks">

            <a

                href="dashboard.php"

                class="active"

            >

                Dashboard

            </a>

            <a href="manage-events.php">

                Events

            </a>

            <a href="manage-venues.php" style="display:none;">

                Venues

            </a>

            <a href="manage-bookings.php">

                Bookings

            </a>

            <a href="manage-users.php" id="adminUsersTop" style="display:none;">

                Users

            </a>

            <a href="events.php">

                Website

            </a>

        </nav>

        <div

            class="nav-actions"

            id="topNavigation"

        >

        </div>

    </div>

</header>



<div

    class="dashboard-layout"

    id="dashboardRoot"

>

    

    <aside class="dashboard-sidebar">

        <div

            class="sidebar-user"

            id="sidebarUser"

        >

            <div class="sidebar-avatar">

                E

            </div>

            <small>

                Loading

            </small>

            <strong>

                Please wait...

            </strong>

        </div>

        <div class="sidebar-section-label">

            Management

        </div>

        <nav class="sidebar-menu">

            <a

                href="dashboard.php"

                class="active"

            >

                <span class="sidebar-menu-icon">

                    ◈

                </span>

                Dashboard

            </a>

            <a href="manage-events.php">

                <span class="sidebar-menu-icon">

                    ◇

                </span>

                Manage Events

            </a>

            <a href="manage-venues.php" style="display:none;">

                <span class="sidebar-menu-icon">

                    ⌖

                </span>

                Manage Venues

            </a>

            <a href="manage-bookings.php">

                <span class="sidebar-menu-icon">

                    🎟

                </span>

                Manage Bookings

            </a>

            <a href="manage-users.php" id="adminUsersSidebar" style="display:none;">

                <span class="sidebar-menu-icon">♙</span>

                Manage Users

            </a>

        </nav>

        <div class="sidebar-section-label">

            Website

        </div>

        <nav class="sidebar-menu">

            <a href="events.php">

                <span class="sidebar-menu-icon">

                    →

                </span>

                Browse Events

            </a>

            <a href="index.php">

                <span class="sidebar-menu-icon">

                    ⌂

                </span>

                Homepage

            </a>

        </nav>

        <div class="sidebar-divider"></div>

        <button

            type="button"

            class="logout-sidebar"

            onclick="logout()"

        >

            Logout

        </button>

    </aside>

    

    <main class="dashboard-main">

        

        <section class="dashboard-header">

            <div>

                <span class="dashboard-eyebrow">

                    EVENTIFY MANAGEMENT

                </span>

                <h1>

                    Management Dashboard

                </h1>

                <p id="dashboardWelcome">

                    Loading your account...

                </p>

            </div>

            <div

                class="dashboard-user-chip"

                id="dashboardUser"

            >

                <div class="chip-avatar">

                    E

                </div>

            </div>

        </section>

        

        <section class="dashboard-stats">

            <article class="dashboard-stat-card">

                <div class="stat-top">

                    <div>

                        <small>

                            Events

                        </small>

                        <h2 id="totalEvents">

                            —

                        </h2>

                    </div>

                    <div class="stat-icon">

                        ◇

                    </div>

                </div>

                <p id="eventsDescription">

                    Events managed

                </p>

            </article>

            <article class="dashboard-stat-card">

                <div class="stat-top">

                    <div>

                        <small>

                            Bookings

                        </small>

                        <h2 id="totalBookings">

                            —

                        </h2>

                    </div>

                    <div class="stat-icon">

                        🎟

                    </div>

                </div>

                <p>

                    Reservations received

                </p>

            </article>

            <article class="dashboard-stat-card">

                <div class="stat-top">

                    <div>

                        <small>

                            Confirmed

                        </small>

                        <h2 id="confirmedBookings">

                            —

                        </h2>

                    </div>

                    <div class="stat-icon">

                        ✓

                    </div>

                </div>

                <p>

                    Active reservations

                </p>

            </article>

            <article class="dashboard-stat-card">

                <div class="stat-top">

                    <div>

                        <small>

                            Booking Value

                        </small>

                        <h2 id="bookingValue">

                            —

                        </h2>

                    </div>

                    <div class="stat-icon">

                        RM

                    </div>

                </div>

                <p>

                    Confirmed reservations

                </p>

            </article>

        </section>

        

        <section class="management-heading">

            <div>

                <h2>

                    Management Centre

                </h2>

                <p>

                    Access your event management tools.

                </p>

            </div>

        </section>

        <section class="management-grid">

            

            <a

                href="manage-events.php"

                class="management-card"

            >

                <div>

                    <div class="management-icon">

                        ◇

                    </div>

                    <h3>

                        Manage Events

                    </h3>

                    <p>

                        Create new events, edit event details,

                        ticket prices, dates, status and capacity.

                    </p>

                </div>

                <div class="management-link">

                    Open Event Management

                    <span>

                        →

                    </span>

                </div>

            </a>

            

            <a

                href="manage-venues.php"

                class="management-card"

             style="display:none;">

                <div>

                    <div class="management-icon">

                        ⌖

                    </div>

                    <h3>

                        Manage Venues

                    </h3>

                    <p>

                        Create and maintain venue records,

                        locations, capacities and availability.

                    </p>

                </div>

                <div class="management-link">

                    Open Venue Management

                    <span>

                        →

                    </span>

                </div>

            </a>

            

            <a

                href="manage-bookings.php"

                class="management-card"

            >

                <div>

                    <div class="management-icon">

                        🎟

                    </div>

                    <h3>

                        Manage Bookings

                    </h3>

                    <p>

                        Review customer reservations and

                        manage booking confirmation status.

                    </p>

                </div>

                <div class="management-link">

                    Open Booking Management

                    <span>

                        →

                    </span>

                </div>

            </a>

        </section>

        

        <section class="dashboard-content-grid">

            

            <article class="dashboard-panel">

                <div class="panel-header">

                    <div>

                        <h2>

                            Upcoming Events

                        </h2>

                        <span id="eventPanelSubtitle">

                            Your latest events

                        </span>

                    </div>

                    <a href="manage-events.php">

                        View All →

                    </a>

                </div>

                <div

                    class="dashboard-list"

                    id="eventList"

                >

                    <div class="empty-data">

                        Loading events...

                    </div>

                </div>

            </article>

            

            <article class="dashboard-panel">

                <div class="panel-header">

                    <div>

                        <h2>

                            Recent Bookings

                        </h2>

                        <span>

                            Latest customer reservations

                        </span>

                    </div>

                    <a href="manage-bookings.php">

                        View All →

                    </a>

                </div>

                <div

                    class="dashboard-list"

                    id="bookingList"

                >

                    <div class="empty-data">

                        Loading bookings...

                    </div>

                </div>

            </article>

        </section>

    </main>

</div>

<script>







const token =

    localStorage.getItem(

        "eventify_token"

    );

let currentUser = null;

let allEvents = [];

let dashboardEvents = [];

let allBookings = [];







async function initialiseDashboard() {

    if (!token) {

        window.location.href =

            "login.php";

        return;

    }

    try {

        

        const authResponse =

            await fetch(

                "auth/me.php",

                {

                    headers: {

                        Authorization:

                            "Bearer "

                            + token

                    }

                }

            );

        const authResult =

            await authResponse.json();

        if (

            !authResponse.ok ||

            authResult.status !== "success"

        ) {

            logout();

            return;

        }

        currentUser =

            authResult.user;

        

        if (

            currentUser.role !== "Administrator"

            &&

            currentUser.role !== "Organiser"

        ) {

            showAccessDenied();

            return;

        }

        updateUserInterface();

        await Promise.all([

            loadEvents(),

            loadBookings()

        ]);

        prepareDashboardEvents();

        displayEvents();

        displayBookings();

        updateStatistics();

    } catch (error) {

        console.error(

            "Dashboard error:",

            error

        );

        document

            .getElementById(

                "dashboardRoot"

            )

            .innerHTML = `

                <div class="access-denied">

                    <div class="access-denied-icon">

                        !

                    </div>

                    <h1>

                        Dashboard unavailable

                    </h1>

                    <p>

                        Eventify could not load the

                        management dashboard.

                    </p>

                    <a href="login.php">

                        Return to Login

                    </a>

                </div>

            `;

    }

}







async function loadEvents() {

    const response =

        await fetch(

            "api/events.php"

        );

    const result =

        await response.json();

    if (

        !response.ok ||

        result.status !== "success"

    ) {

        throw new Error(

            result.message ||

            "Unable to load events"

        );

    }

    allEvents =

        result.data;

}







function prepareDashboardEvents() {

    if (

        currentUser.role ===

        "Organiser"

    ) {

        dashboardEvents =

            allEvents.filter(

                event =>

                    Number(

                        event.organiser_id

                    )

                    ===

                    Number(

                        currentUser.user_id

                    )

            );

        document

            .getElementById(

                "eventsDescription"

            )

            .textContent =

                "Events organised by you";

        document

            .getElementById(

                "eventPanelSubtitle"

            )

            .textContent =

                "Events organised by "

                + currentUser.name;

    }

    else {

        dashboardEvents =

            allEvents;

        document

            .getElementById(

                "eventsDescription"

            )

            .textContent =

                "All events in the system";

        document

            .getElementById(

                "eventPanelSubtitle"

            )

            .textContent =

                "Latest system events";

    }

}







async function loadBookings() {

    const response =

        await fetch(

            "api/bookings.php",

            {

                headers: {

                    Authorization:

                        "Bearer "

                        + token

                }

            }

        );

    const result =

        await response.json();

    if (response.status === 401) {

        logout();

        return;

    }

    if (

        !response.ok ||

        result.status !== "success"

    ) {

        throw new Error(

            result.message ||

            "Unable to load bookings"

        );

    }

    









    allBookings =

        result.data;

}







function updateStatistics() {

    const confirmed =

        allBookings.filter(

            booking =>

                booking.booking_status

                === "Confirmed"

        );

    const value =

        confirmed.reduce(

            (

                total,

                booking

            ) => {

                return total +

                    Number(

                        booking.total_amount

                    );

            },

            0

        );

    document

        .getElementById(

            "totalEvents"

        )

        .textContent =

            dashboardEvents.length;

    document

        .getElementById(

            "totalBookings"

        )

        .textContent =

            allBookings.length;

    document

        .getElementById(

            "confirmedBookings"

        )

        .textContent =

            confirmed.length;

    document

        .getElementById(

            "bookingValue"

        )

        .textContent =

            "RM "

            +

            value.toFixed(2);

}







function displayEvents() {

    const container =

        document.getElementById(

            "eventList"

        );

    container.innerHTML =

        "";

    const sortedEvents =

        [...dashboardEvents]

            .sort(

                (a, b) => {

                    return new Date(

                        a.event_date

                    )

                    -

                    new Date(

                        b.event_date

                    );

                }

            );

    const events =

        sortedEvents.slice(

            0,

            5

        );

    if (

        events.length === 0

    ) {

        container.innerHTML = `

            <div class="empty-data">

                No events found.

                <br><br>

                <a

                    href="manage-events.php"

                    style="

                        color:#7559ff;

                        font-weight:700;

                    "

                >

                    Create an event →

                </a>

            </div>

        `;

        return;

    }

    events.forEach(

        event => {

            const date =

                new Date(

                    event.event_date

                    +

                    "T00:00:00"

                );

            const formattedDate =

                date.toLocaleDateString(

                    "en-MY",

                    {

                        day: "numeric",

                        month: "short",

                        year: "numeric"

                    }

                );

            const row =

                document.createElement(

                    "div"

                );

            row.className =

                "dashboard-row";

            row.innerHTML = `

                <div class="row-content">

                    <strong>

                        ${escapeHTML(

                            event.event_name

                        )}

                    </strong>

                    <span>

                        ${formattedDate}

                        •

                        ${escapeHTML(

                            event.venue_name

                        )}

                    </span>

                </div>

                <span

                    class="

                        status-pill

                        ${getEventStatusClass(

                            event.status

                        )}

                    "

                >

                    ${escapeHTML(

                        event.status

                    )}

                </span>

            `;

            container.appendChild(

                row

            );

        }

    );

}







function displayBookings() {

    const container =

        document.getElementById(

            "bookingList"

        );

    container.innerHTML =

        "";

    const bookings =

        allBookings.slice(

            0,

            5

        );

    if (

        bookings.length === 0

    ) {

        container.innerHTML = `

            <div class="empty-data">

                No bookings found.

            </div>

        `;

        return;

    }

    bookings.forEach(

        booking => {

            const row =

                document.createElement(

                    "div"

                );

            row.className =

                "dashboard-row";

            row.innerHTML = `

                <div class="row-content">

                    <strong>

                        ${escapeHTML(

                            booking.customer_name

                            ||

                            "Customer"

                        )}

                    </strong>

                    <span>

                        ${escapeHTML(

                            booking.event_name

                        )}

                        •

                        ${booking.quantity}

                        ticket(s)

                        •

                        RM

                        ${Number(

                            booking.total_amount

                        ).toFixed(2)}

                    </span>

                </div>

                <span

                    class="

                        status-pill

                        ${

                            booking.booking_status

                            === "Confirmed"

                            ?

                            "status-green"

                            :

                            booking.booking_status

                            === "Cancelled"

                            ?

                            "status-red"

                            :

                            "status-gray"

                        }

                    "

                >

                    ${escapeHTML(

                        booking.booking_status

                    )}

                </span>

            `;

            container.appendChild(

                row

            );

        }

    );

}







function updateUserInterface() {

    const isAdministrator = currentUser.role === "Administrator";

    
    
    document.querySelectorAll('a[href="manage-venues.php"]').forEach(function (link) {
        link.style.display = isAdministrator ? "" : "none";
    });

    const managementGrid = document.querySelector(".management-grid");
    if (managementGrid) {
        managementGrid.classList.toggle("organiser-view", !isAdministrator);
    }

    const adminSidebar = document.getElementById("adminUsersSidebar");

    const adminTopLink = document.getElementById("adminUsersTop");

    if (adminSidebar) {

        adminSidebar.style.display = isAdministrator ? "flex" : "none";

    }

    if (adminTopLink) {

        adminTopLink.style.display = isAdministrator ? "inline-flex" : "none";

    }

    const initial =

        currentUser.name

            .charAt(0)

            .toUpperCase();

    document

        .getElementById(

            "dashboardWelcome"

        )

        .textContent =

            currentUser.role

            === "Administrator"

            ?

            "Welcome back, "

            + currentUser.name

            + ". You have full system access."

            :

            "Welcome back, "

            + currentUser.name

            + ". Manage your events and reservations.";

    document

        .getElementById(

            "sidebarUser"

        )

        .innerHTML = `

            <div class="sidebar-avatar">

                ${escapeHTML(initial)}

            </div>

            <small>

                ${escapeHTML(

                    currentUser.role

                )}

            </small>

            <strong>

                ${escapeHTML(

                    currentUser.name

                )}

            </strong>

        `;

    document

        .getElementById(

            "dashboardUser"

        )

        .innerHTML = `

            <div class="chip-avatar">

                ${escapeHTML(initial)}

            </div>

            <div>

                <small>

                    ${escapeHTML(

                        currentUser.role

                    )}

                </small>

                <strong>

                    ${escapeHTML(

                        currentUser.name

                    )}

                </strong>

            </div>

        `;

    document

        .getElementById(

            "topNavigation"

        )

        .innerHTML = `

            <span

                style="

                    font-size:13px;

                    font-weight:700;

                    color:#555263;

                "

            >

                ${escapeHTML(

                    currentUser.name

                )}

            </span>

            <button

                type="button"

                onclick="logout()"

                style="

                    border:none;

                    background:#11101d;

                    color:white;

                    padding:11px 17px;

                    border-radius:9px;

                    cursor:pointer;

                    font-weight:700;

                "

            >

                Logout

            </button>

        `;

}







function showAccessDenied() {

    document

        .getElementById(

            "dashboardRoot"

        )

        .innerHTML = `

            <div class="access-denied">

                <div class="access-denied-icon">

                    !

                </div>

                <h1>

                    Access Denied

                </h1>

                <p>

                    Your account is registered as a

                    ${escapeHTML(

                        currentUser.role

                    )}.

                    Only Administrator and Organiser

                    accounts can access Eventify's

                    management dashboard.

                </p>

                <a href="events.php">

                    Return to Events

                </a>

            </div>

        `;

}







function getEventStatusClass(

    status

) {

    if (

        status === "Upcoming"

        ||

        status === "Ongoing"

    ) {

        return "status-green";

    }

    if (

        status === "Cancelled"

    ) {

        return "status-red";

    }

    return "status-gray";

}







function logout() {

    localStorage.removeItem(

        "eventify_token"

    );

    localStorage.removeItem(

        "eventify_user"

    );

    window.location.href =

        "login.php";

}







function escapeHTML(

    value

) {

    return String(

        value ?? ""

    )

        .replaceAll(

            "&",

            "&amp;"

        )

        .replaceAll(

            "<",

            "&lt;"

        )

        .replaceAll(

            ">",

            "&gt;"

        )

        .replaceAll(

            '"',

            "&quot;"

        )

        .replaceAll(

            "'",

            "&#039;"

        );

}







initialiseDashboard();

</script>

</body>

</html>
