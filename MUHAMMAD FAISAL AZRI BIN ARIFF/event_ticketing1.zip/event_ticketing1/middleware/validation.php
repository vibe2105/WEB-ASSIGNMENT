<?php

function eventifyQueryText(string $key, int $maxLength = 100, string $default = ''): ?string {
    $value = $_GET[$key] ?? $default;
    if (!is_string($value)) return null;
    $value = trim($value);
    return strlen($value) <= $maxLength ? $value : null;
}
function eventifyQueryPositiveInt(string $key, int $default, int $max = PHP_INT_MAX) {
    if (!isset($_GET[$key])) return $default;
    return filter_var($_GET[$key], FILTER_VALIDATE_INT,
        ['options'=>['min_range'=>1,'max_range'=>$max]]);
}
function eventifyDecodedJsonBody(): ?array {
    $json = json_decode(file_get_contents('php://input'), true);
    return is_array($json) && !array_is_list($json) ? $json : null;
}
