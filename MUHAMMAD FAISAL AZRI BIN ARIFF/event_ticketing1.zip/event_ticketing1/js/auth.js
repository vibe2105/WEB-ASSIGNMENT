








(function () {
  "use strict";

  function startNavbar() {
    const nav =
      document.getElementById("authNavigation") ||
      document.querySelector(".nav-actions");

    



    function setBookingsVisibility(isCustomer) {
      document.body.classList.toggle("eventify-customer-logged-in", isCustomer);

      const bookingLinks = document.querySelectorAll(
        '.nav-links a[href="bookings.php"]',
      );

      bookingLinks.forEach(function (link) {
        link.style.display = isCustomer ? "inline-flex" : "none";
      });
    }

    




    setBookingsVisibility(false);

    
    if (!nav) {
      return;
    }

    



    function makeLink(label, href, className) {
      const link = document.createElement("a");

      link.href = href;
      link.className = className;
      link.textContent = label;

      return link;
    }

    



    function showGuest() {
      setBookingsVisibility(false);

      nav.replaceChildren(
        makeLink("Sign In", "login.php", "sign-in"),
        makeLink("Create Account", "register.php", "nav-button"),
      );
    }

    



    function showLoggedIn(user) {
      const role = String(user.role || "");

      




      setBookingsVisibility(role === "Customer");

      nav.replaceChildren();

      

      if (role === "Administrator" || role === "Organiser") {
        nav.appendChild(makeLink("Dashboard", "dashboard.php", "sign-in"));
      }

      

      const userDetails = document.createElement("span");

      userDetails.style.cssText = `
                font-size: 13px;
                font-weight: 700;
                color: #555263;
                line-height: 1.3;
            `;

      userDetails.textContent = String(user.name || "Account");

      

      const roleLabel = document.createElement("small");

      roleLabel.style.cssText = `
                display: block;
                font-size: 10px;
                font-weight: 500;
                color: #9995a4;
                margin-top: 3px;
            `;

      roleLabel.textContent = role;

      userDetails.appendChild(roleLabel);

      nav.appendChild(userDetails);

      

      const logout = document.createElement("button");

      logout.type = "button";
      logout.className = "nav-button";
      logout.textContent = "Logout";

      logout.style.cssText = `
                border: none;
                cursor: pointer;
                background: #11101d;
                color: white;
                padding: 11px 17px;
                border-radius: 9px;
                font-weight: 700;
            `;

      logout.addEventListener("click", function () {
        localStorage.removeItem("eventify_token");

        localStorage.removeItem("eventify_user");

        setBookingsVisibility(false);

        window.location.href = "login.php";
      });

      nav.appendChild(logout);
    }

    



    async function checkLogin() {
      const token = localStorage.getItem("eventify_token");

      

      if (!token) {
        showGuest();

        return;
      }

      try {
        const response = await fetch("auth/me.php", {
          headers: {
            Authorization: "Bearer " + token,
          },
          cache: "no-store",
        });

        

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("eventify_token");

          localStorage.removeItem("eventify_user");

          showGuest();

          return;
        }

        if (!response.ok) {
          showGuest();

          return;
        }

        const result = await response.json();

        if (result.status !== "success" || !result.user) {
          showGuest();

          return;
        }

        

        localStorage.setItem("eventify_user", JSON.stringify(result.user));

        

        showLoggedIn(result.user);
      } catch (error) {
        





        showGuest();
      }
    }

    



    checkLogin();
  }

  



  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startNavbar);
  } else {
    startNavbar();
  }
})();
