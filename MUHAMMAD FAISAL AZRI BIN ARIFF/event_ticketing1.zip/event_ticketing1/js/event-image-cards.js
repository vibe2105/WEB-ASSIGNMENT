



(function () {
    'use strict';

    const grid = document.getElementById('eventGrid');
    if (!grid) return;

    let eventRecords = [];
    let imageById = Object.create(null);

    function getEventForCard(card) {
        const idCandidates = [];
        if (card.dataset && card.dataset.eventId) idCandidates.push(card.dataset.eventId);
        const link = card.matches('a[href*="event_id="]')
            ? card
            : card.querySelector('a[href*="event_id="]');
        if (link) {
            try {
                const url = new URL(link.href, window.location.href);
                const queryId = url.searchParams.get('event_id');
                if (queryId) idCandidates.push(queryId);
            } catch (_) {
                
            }
        }

        for (const candidate of idCandidates) {
            const match = eventRecords.find(item => Number(item.event_id) === Number(candidate));
            if (match) return match;
        }

        const text = (card.textContent || '').replace(/\s+/g, ' ').trim();
        return eventRecords
            .slice()
            .sort((a, b) => String(b.event_name || '').length - String(a.event_name || '').length)
            .find(item => item.event_name && text.includes(String(item.event_name))) || null;
    }

    function applyPosters() {
        const cards = grid.querySelectorAll('.premium-event-card, .event-card, article');
        cards.forEach(card => {
            if (card.dataset.eventPosterDone === '1') return;
            const event = getEventForCard(card);
            if (!event) return;
            const imagePath = imageById[Number(event.event_id)] || event.image_path || '';
            if (!imagePath) {
                card.dataset.eventPosterDone = '1';
                return;
            }

            const cover = card.querySelector('.event-cover');
            if (cover) {
                if (cover.querySelector('.event-uploaded-poster')) {
                    card.dataset.eventPosterDone = '1';
                    return;
                }
                const image = document.createElement('img');
                image.className = 'event-uploaded-poster';
                image.src = imagePath;
                image.alt = String(event.event_name || 'Event') + ' poster';
                image.loading = 'lazy';
                cover.classList.add('has-uploaded-poster');
                cover.prepend(image);
            } else {
                const image = document.createElement('img');
                image.className = 'event-image-card-poster';
                image.src = imagePath;
                image.alt = String(event.event_name || 'Event') + ' poster';
                image.loading = 'lazy';
                card.prepend(image);
            }
            card.dataset.eventPosterDone = '1';
        });
    }

    const observer = new MutationObserver(applyPosters);
    observer.observe(grid, { childList: true, subtree: true });

    Promise.allSettled([
        fetch('api/events.php', { cache: 'no-store' }).then(response => {
            if (!response.ok) throw new Error('Events request failed');
            return response.json();
        }),
        fetch('api/event-image.php', { cache: 'no-store' }).then(response => {
            if (!response.ok) throw new Error('Event image request failed');
            return response.json();
        })
    ]).then(results => {
        if (results[0].status === 'fulfilled' && results[0].value.status === 'success' && Array.isArray(results[0].value.data)) {
            eventRecords = results[0].value.data;
        }
        if (results[1].status === 'fulfilled' && results[1].value.status === 'success' && Array.isArray(results[1].value.data)) {
            results[1].value.data.forEach(item => {
                if (item && item.event_id && item.image_path) imageById[Number(item.event_id)] = item.image_path;
            });
        }
        applyPosters();
    }).catch(() => {
        
    });
})();
