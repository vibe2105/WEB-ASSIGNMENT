







const eventGrid = document.getElementById("eventGrid");

const eventCount = document.getElementById("eventCount");

const searchInput = document.getElementById("searchInput");

const categoryFilter = document.getElementById("categoryFilter");

const searchButton = document.getElementById("searchButton");

let allEvents = [];





async function loadEvents() {
  if (!eventGrid) {
    return;
  }

  try {
    const response = await fetch("api/events.php");

    if (!response.ok) {
      throw new Error("Server returned status " + response.status);
    }

    const result = await response.json();

    if (result.status === "success" && Array.isArray(result.data)) {
      allEvents = result.data;

      displayEvents(allEvents);
    } else {
      showError("Unable to load events.");
    }
  } catch (error) {
    console.error("Events API Error:", error);

    showError("Unable to connect to the event server.");
  }
}





function displayEvents(events) {
  if (!eventGrid) {
    return;
  }

  eventGrid.innerHTML = "";

  if (eventCount) {
    eventCount.textContent = events.length;
  }

  if (events.length === 0) {
    eventGrid.innerHTML = `

            <div class="no-events">

                <div class="no-events-icon">
                    ◌
                </div>

                <h3>
                    No events found
                </h3>

                <p>
                    Try another search or category.
                </p>

            </div>

        `;

    return;
  }

  events.forEach((event) => {
    const date = new Date(event.event_date + "T00:00:00");

    const day = String(date.getDate()).padStart(2, "0");

    const month = date
      .toLocaleString("en-US", {
        month: "short",
      })
      .toUpperCase();

    const startTime = formatTime(event.start_time);

    const endTime = formatTime(event.end_time);

    const coverClass = getCoverClass(event.category);

    const categorySymbol = getCategorySymbol(event.category);

    const statusClass = getStatusClass(event.status);

    const card = document.createElement("article");

    card.className = "premium-event-card";

    card.innerHTML = `

            <div class="event-cover ${coverClass}">


                <div
                    class="cover-decoration circle-a">
                </div>


                <div
                    class="cover-decoration circle-b">
                </div>



                <span class="category-pill">

                    ${escapeHTML(event.category)}

                </span>



                <div class="cover-symbol">

                    ${categorySymbol}

                </div>



                <div class="date-floating">

                    <strong>
                        ${day}
                    </strong>

                    <span>
                        ${month}
                    </span>

                </div>


            </div>



            <div class="event-card-content">


                <div class="event-top-row">


                    <span
                        class="event-status ${statusClass}"
                    >

                        ●
                        ${escapeHTML(event.status)}

                    </span>



                    <span class="ticket-left">

                        ${Number(event.available_tickets).toLocaleString()}

                        tickets left

                    </span>


                </div>



                <h3>

                    ${escapeHTML(event.event_name)}

                </h3>



                <div class="event-meta">


                    <div>

                        <span class="meta-icon">
                            ⌖
                        </span>

                        <span>

                            ${escapeHTML(event.venue_name)}

                        </span>

                    </div>



                    <div>

                        <span class="meta-icon">
                            ◷
                        </span>

                        <span>

                            ${startTime}
                            —
                            ${endTime}

                        </span>

                    </div>


                </div>



                <div class="event-card-footer">


                    <div class="price">

                        <span>
                            From
                        </span>

                        <strong>

                            RM ${Number(event.ticket_price).toFixed(2)}

                        </strong>

                    </div>



                    <a
                        href="event-details.php?id=${event.event_id}"
                        class="view-event-btn"
                    >

                        View Event

                        <span>
                            →
                        </span>

                    </a>


                </div>


            </div>

        `;

    eventGrid.appendChild(card);
  });
}





function filterEvents() {
  if (!searchInput || !categoryFilter) {
    return;
  }

  const searchValue = searchInput.value.trim().toLowerCase();

  const categoryValue = categoryFilter.value.trim().toLowerCase();

  const filteredEvents = allEvents.filter((event) => {
    const eventName = String(event.event_name ?? "").toLowerCase();

    const venueName = String(event.venue_name ?? "").toLowerCase();

    const description = String(event.description ?? "").toLowerCase();

    const category = String(event.category ?? "").toLowerCase();

    const matchesSearch =
      eventName.includes(searchValue) ||
      venueName.includes(searchValue) ||
      description.includes(searchValue);

    const matchesCategory = categoryValue === "" || category === categoryValue;

    return matchesSearch && matchesCategory;
  });

  displayEvents(filteredEvents);
}





function formatTime(time) {
  if (!time) {
    return "Time unavailable";
  }

  const timeParts = time.split(":");

  const hour = Number(timeParts[0]);

  const minute = Number(timeParts[1]);

  const date = new Date();

  date.setHours(hour);

  date.setMinutes(minute);

  date.setSeconds(0);

  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
}





function getCoverClass(category) {
  const value = String(category ?? "").toLowerCase();

  switch (value) {
    case "technology":
      return "cover-tech";

    case "workshop":
      return "cover-workshop";

    case "music":
      return "cover-music";

    case "seminar":
      return "cover-security";

    case "food":
      return "cover-food";

    default:
      return "cover-tech";
  }
}





function getCategorySymbol(category) {
  const value = String(category ?? "").toLowerCase();

  switch (value) {
    case "technology":
      return "&lt;/&gt;";

    case "workshop":
      return "{ }";

    case "music":
      return "♪";

    case "seminar":
      return "◈";

    case "food":
      return "✦";

    default:
      return "◆";
  }
}





function getStatusClass(status) {
  const value = String(status ?? "").toLowerCase();

  if (value === "cancelled") {
    return "status-cancelled";
  }

  if (value === "completed") {
    return "status-completed";
  }

  return "status-upcoming";
}





function showError(message) {
  if (!eventGrid) {
    return;
  }

  if (eventCount) {
    eventCount.textContent = "0";
  }

  eventGrid.innerHTML = `

        <div class="no-events">

            <div class="no-events-icon">
                !
            </div>

            <h3>
                Something went wrong
            </h3>

            <p>
                ${escapeHTML(message)}
            </p>

        </div>

    `;
}





function escapeHTML(value) {
  if (value === null || value === undefined) {
    return "";
  }

  return String(value)
    .replaceAll("&", "&amp;")

    .replaceAll("<", "&lt;")

    .replaceAll(">", "&gt;")

    .replaceAll('"', "&quot;")

    .replaceAll("'", "&#039;");
}





if (searchInput) {
  searchInput.addEventListener("input", filterEvents);
}

if (categoryFilter) {
  categoryFilter.addEventListener("change", filterEvents);
}

if (searchButton) {
  searchButton.addEventListener("click", filterEvents);
}





loadEvents();
