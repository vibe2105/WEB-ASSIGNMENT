<?php
require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();

/* ==========================================
   ERROR LOGGING
========================================== */

ini_set("display_errors", 0);
ini_set("log_errors", 1);
error_reporting(E_ALL);

/* ==========================================
   HEADERS
========================================== */

header("Content-Type: application/json; charset=utf-8");
header("Cache-Control: no-store");


/* ==========================================
   DATABASE CONNECTION
========================================== */

require_once __DIR__ . "/../config/database.php";

$database = new Database();
$db = $database->getConnection();


if (!$db) {

    http_response_code(500);

    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed"
    ]);

    exit;
}


/* ==========================================
   ONLY ALLOW POST
========================================== */

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);
    header("Allow: POST");

    echo json_encode([
        "status" => "error",
        "message" => "Method not allowed"
    ]);

    exit;
}


/* ==========================================
   READ JSON BODY
========================================== */

$data = json_decode(
    file_get_contents("php://input"),
    true
);


if (!is_array($data)) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "Invalid JSON request body"
    ]);

    exit;
}


/* ==========================================
   GET VALUES
========================================== */

// Validate JSON field types before calling string functions.
foreach (["name", "email", "password", "confirm_password"] as $field) {
    if (!is_string($data[$field] ?? null)) {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "All fields are required"
        ]);
        exit;
    }
}

$name = trim($data["name"]);
$email = strtolower(trim($data["email"]));
$password = $data["password"];
$confirm_password = $data["confirm_password"];


/* ==========================================
   VALIDATION
========================================== */

if (
    $name === "" ||
    $email === "" ||
    $password === "" ||
    $confirm_password === ""
) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "All fields are required"
    ]);

    exit;
}


/* NAME */

if (strlen($name) < 3) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" =>
            "Name must contain at least 3 characters"
    ]);

    exit;
}


/* EMAIL */

if (
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "Invalid email address"
    ]);

    exit;
}


/* PASSWORD */

if (strlen($password) < 6) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" =>
            "Password must contain at least 6 characters"
    ]);

    exit;
}


/* CONFIRM PASSWORD */

if ($password !== $confirm_password) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "Passwords do not match"
    ]);

    exit;
}



try {

    /* ==========================================
       CHECK EMAIL
    ========================================== */

    $checkQuery = "
        SELECT
            user_id

        FROM users

        WHERE email = :email

        LIMIT 1
    ";


    $checkStmt =
        $db->prepare(
            $checkQuery
        );


    $checkStmt->execute([
        ":email" => $email
    ]);


    if ($checkStmt->fetch()) {

        http_response_code(409);

        echo json_encode([
            "status" => "error",
            "message" =>
                "An account with this email already exists"
        ]);

        exit;
    }


    /* ==========================================
       HASH PASSWORD
    ========================================== */

    $password_hash =
        password_hash(
            $password,
            PASSWORD_DEFAULT
        );


    /* ==========================================
       CREATE CUSTOMER

       Public registration is always Customer.
       Users cannot register themselves as
       Administrator or Organiser.
    ========================================== */

    $query = "
        INSERT INTO users
        (
            name,
            email,
            password_hash,
            role
        )

        VALUES
        (
            :name,
            :email,
            :password_hash,
            'Customer'
        )
    ";


    $stmt =
        $db->prepare(
            $query
        );


    $stmt->execute([

        ":name" =>
            $name,

        ":email" =>
            $email,

        ":password_hash" =>
            $password_hash

    ]);


    $user_id =
        $db->lastInsertId();


    /* ==========================================
       SUCCESS
    ========================================== */

    http_response_code(201);


    echo json_encode([

        "status" =>
            "success",

        "message" =>
            "Account created successfully",

        "data" => [

            "user_id" =>
                $user_id,

            "name" =>
                $name,

            "email" =>
                $email,

            "role" =>
                "Customer"

        ]

    ]);


} catch (Throwable $error) {
    error_log("Eventify registration error: " . $error->getMessage());

    // Handles a race where another registration used the same email.
    if ($error instanceof PDOException && $error->getCode() === "23000") {
        http_response_code(409);
        echo json_encode([
            "status" => "error",
            "message" => "An account with this email already exists"
        ]);
        exit;
    }

    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Unable to create account"
    ]);
}

?>