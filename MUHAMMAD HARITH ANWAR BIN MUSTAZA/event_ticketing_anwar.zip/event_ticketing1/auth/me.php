<?php
require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();

ini_set("display_errors", 0);
ini_set("log_errors", 1);
error_reporting(E_ALL);

header("Content-Type: application/json; charset=utf-8");
header("Cache-Control: no-store");

require_once __DIR__ . "/../middleware/auth.php";


/* ==========================================
   ONLY GET
========================================== */

if (
    $_SERVER["REQUEST_METHOD"]
    !== "GET"
) {

    http_response_code(405);
    header("Allow: GET");

    echo json_encode([
        "status" => "error",
        "message" =>
            "Method not allowed"
    ]);

    exit;
}



/* ==========================================
   CHECK JWT
========================================== */

$user =
    requireAuth();



/* ==========================================
   SUCCESS
========================================== */

http_response_code(200);


echo json_encode([

    "status" =>
        "success",

    "message" =>
        "Authenticated successfully",

    "user" => [

        "user_id" =>
            intval(
                $user["user_id"]
            ),

        "name" =>
            $user["name"],

        "email" =>
            $user["email"],

        "role" =>
            $user["role"]

    ]

]);

?>