<?php
require_once __DIR__ . '/../middleware/api.php';
require_once __DIR__ . '/../middleware/validation.php';
eventifyApiInit();
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST'); http_response_code(405);
    echo json_encode(['status'=>'error','message'=>'Method not allowed']); exit;
}
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../config/database.php';
$user=requireAuth();
requireRole($user,['Administrator','Organiser']);
$data=eventifyDecodedJsonBody();
$code=is_array($data) ? ($data['ticket_code'] ?? '') : '';
if (!is_string($code) || !preg_match('/^EVF1\|([1-9][0-9]*)\|([a-f0-9]{24})$/D',$code,$parts)) {
    http_response_code(400);
    echo json_encode(['status'=>'error','message'=>'Invalid ticket code format']); exit;
}
try {
    $message='EVF1|' . $parts[1];
    $expected=substr(hash_hmac('sha256',$message,eventifyTicketSecret()),0,24);
    if (!hash_equals($expected,$parts[2])) {
        http_response_code(400);
        echo json_encode(['status'=>'error','message'=>'Ticket signature invalid']); exit;
    }
    $db=(new Database())->getConnection();
    if (!$db) throw new RuntimeException('Database unavailable');
    $stmt=$db->prepare('SELECT b.booking_id,b.booking_status,b.quantity,e.event_name,e.organiser_id
        FROM bookings b JOIN events e ON b.event_id=e.event_id WHERE b.booking_id=:id LIMIT 1');
    $stmt->execute([':id'=>(int)$parts[1]]);
    $booking=$stmt->fetch();
    if (!$booking) {
        http_response_code(404);
        echo json_encode(['status'=>'error','message'=>'Ticket not found']); exit;
    }
    if ($user['role']==='Organiser' && (int)$booking['organiser_id'] !== (int)$user['user_id']) {
        http_response_code(403);
        echo json_encode(['status'=>'error','message'=>'Ticket belongs to another organiser']); exit;
    }
    echo json_encode(['status'=>'success', 'valid'=>$booking['booking_status']==='Confirmed',
        'data'=>['booking_id'=>(int)$booking['booking_id'],
        'event_name'=>$booking['event_name'],
        'quantity'=>(int)$booking['quantity'],
        'booking_status'=>$booking['booking_status']]]);
} catch(Throwable $error) {
    error_log('Eventify ticket verification: '.$error->getMessage());
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>'Unable to verify ticket']);
}
