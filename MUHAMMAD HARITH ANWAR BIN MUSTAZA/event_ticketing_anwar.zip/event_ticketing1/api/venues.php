<?php
require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();

ini_set("display_errors", 0);

ini_set("log_errors", 1);

error_reporting(E_ALL);

header("Content-Type: application/json");

require_once __DIR__ . "/../config/database.php";

try {

    $database = new Database();

    $db = $database->getConnection();

} catch (Throwable $error) {

    error_log($error->getMessage());

    http_response_code(500);

    echo json_encode([

        "status" => "error",

        "message" => "Internal server error"

    ]);

    exit;

}

if (!$db) {

    http_response_code(500);

    echo json_encode([

        "status" => "error",

        "message" => "Database connection failed"

    ]);

    exit;

}

$method = $_SERVER["REQUEST_METHOD"];

$currentUser = null;

/* =====================================================

   PROTECT MANAGEMENT METHODS

===================================================== */

if (

    $method === "POST" ||

    $method === "PUT" ||

    $method === "DELETE"

) {

    require_once __DIR__ . "/../middleware/auth.php";

    $currentUser = requireAuth();

    requireRole(

    $currentUser,

    ["Administrator"]

);

}

/* =====================================================

   READ JSON BODY

===================================================== */

function getVenueJsonBody()

{

    $data = json_decode(

        file_get_contents("php://input"),

        true

    );

    if (!is_array($data)) {

        return null;

    }

    return $data;

}

/* =====================================================

   VALIDATION

===================================================== */

function validateVenue($data)

{
    if (!is_array($data) || !is_string($data['venue_name'] ?? null) ||
        !is_string($data['location'] ?? null) || !is_string($data['status'] ?? null)) {
        return 'Venue name, location and status must be text';
    }
    if (strlen($data['venue_name']) > 200 || strlen($data['location']) > 255) {
        return 'Venue name or location is too long';
    }


    if (

        empty($data["venue_name"]) ||

        trim($data["venue_name"]) === ""

    ) {

        return "Venue name is required";

    }

    if (

        empty($data["location"]) ||

        trim($data["location"]) === ""

    ) {

        return "Location is required";

    }

    if (

        !isset($data["capacity"]) ||

        filter_var($data["capacity"], FILTER_VALIDATE_INT) === false

    ) {

        return "Capacity is required";

    }

    if (

        intval($data["capacity"]) < 1

    ) {

        return "Capacity must be at least 1";

    }

    $allowedStatuses = [

        "Available",

        "Unavailable"

    ];

    if (

        empty($data["status"]) ||

        !in_array(

            $data["status"],

            $allowedStatuses,

            true

        )

    ) {

        return "Invalid venue status";

    }

    return null;

}

try {

    /* =================================================

       GET

    ================================================= */

    if ($method === "GET") {

        /* GET ONE VENUE */

        if (

            isset(

                $_GET["venue_id"]

            )

        ) {

            $venueId =

                intval(

                    $_GET["venue_id"]

                );

            $query = "

                SELECT

                    v.venue_id,

                    v.venue_name,

                    v.location,

                    v.capacity,

                    v.status,

                    v.created_at,

                    COUNT(e.event_id)

                        AS event_count

                FROM venues v

                LEFT JOIN events e

                    ON v.venue_id =

                       e.venue_id

                WHERE v.venue_id =

                    :venue_id

                GROUP BY

                    v.venue_id,

                    v.venue_name,

                    v.location,

                    v.capacity,

                    v.status,

                    v.created_at

            ";

            $stmt =

                $db->prepare($query);

            $stmt->execute([

                ":venue_id" =>

                    $venueId

            ]);

            $venue =

                $stmt->fetch();

            if (!$venue) {

                http_response_code(404);

                echo json_encode([

                    "status" => "error",

                    "message" =>

                        "Venue not found"

                ]);

                exit;

            }

            http_response_code(200);

            echo json_encode([

                "status" => "success",

                "data" => $venue

            ]);

            exit;

        }

        /* GET ALL VENUES */

        $query = "

            SELECT

                v.venue_id,

                v.venue_name,

                v.location,

                v.capacity,

                v.status,

                v.created_at,

                COUNT(e.event_id)

                    AS event_count

            FROM venues v

            LEFT JOIN events e

                ON v.venue_id =

                   e.venue_id

            GROUP BY

                v.venue_id,

                v.venue_name,

                v.location,

                v.capacity,

                v.status,

                v.created_at

            ORDER BY

                v.venue_name ASC

        ";

        $stmt =

            $db->prepare($query);

        $stmt->execute();

        $venues =

            $stmt->fetchAll();

        http_response_code(200);

        echo json_encode([

            "status" => "success",

            "total" => count($venues),

            "data" => $venues

        ]);

        exit;

    }

    /* =================================================

       POST - CREATE VENUE

    ================================================= */

    elseif ($method === "POST") {

        $data =

            getVenueJsonBody();

        if (!$data) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Invalid JSON request body"

            ]);

            exit;

        }

        $validationError =

            validateVenue($data);

        if ($validationError) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    $validationError

            ]);

            exit;

        }

        /* CHECK DUPLICATE NAME */

        $checkStmt =

            $db->prepare(

                "

                SELECT venue_id

                FROM venues

                WHERE venue_name =

                    :venue_name

                LIMIT 1

                "

            );

        $checkStmt->execute([

            ":venue_name" =>

                trim(

                    $data["venue_name"]

                )

        ]);

        if ($checkStmt->fetch()) {

            http_response_code(409);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "A venue with this name already exists"

            ]);

            exit;

        }

        $query = "

            INSERT INTO venues

            (

                venue_name,

                location,

                capacity,

                status

            )

            VALUES

            (

                :venue_name,

                :location,

                :capacity,

                :status

            )

        ";

        $stmt =

            $db->prepare($query);

        $stmt->execute([

            ":venue_name" =>

                trim(

                    $data["venue_name"]

                ),

            ":location" =>

                trim(

                    $data["location"]

                ),

            ":capacity" =>

                intval(

                    $data["capacity"]

                ),

            ":status" =>

                $data["status"]

        ]);

        $venueId =

            $db->lastInsertId();

        http_response_code(201);

        echo json_encode([

            "status" =>

                "success",

            "message" =>

                "Venue created successfully",

            "venue_id" =>

                $venueId

        ]);

        exit;

    }

    /* =================================================

       PUT - UPDATE VENUE

    ================================================= */

    elseif ($method === "PUT") {

        $data =

            getVenueJsonBody();

        if (!$data) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Invalid JSON request body"

            ]);

            exit;

        }

        if (

            empty(

                $data["venue_id"]

            )

        ) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Venue ID is required"

            ]);

            exit;

        }

        $venueId =

            intval(

                $data["venue_id"]

            );

        $validationError =

            validateVenue($data);

        if ($validationError) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    $validationError

            ]);

            exit;

        }

        /* CHECK VENUE EXISTS */

        $venueStmt =

            $db->prepare(

                "

                SELECT venue_id

                FROM venues

                WHERE venue_id =

                    :venue_id

                "

            );

        $venueStmt->execute([

            ":venue_id" =>

                $venueId

        ]);

        if (!$venueStmt->fetch()) {

            http_response_code(404);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Venue not found"

            ]);

            exit;

        }

        /* CHECK DUPLICATE NAME */

        $duplicateStmt =

            $db->prepare(

                "

                SELECT venue_id

                FROM venues

                WHERE venue_name =

                    :venue_name

                AND venue_id !=

                    :venue_id

                LIMIT 1

                "

            );

        $duplicateStmt->execute([

            ":venue_name" =>

                trim(

                    $data["venue_name"]

                ),

            ":venue_id" =>

                $venueId

        ]);

        if ($duplicateStmt->fetch()) {

            http_response_code(409);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Another venue already uses this name"

            ]);

            exit;

        }

        $query = "

            UPDATE venues

            SET

                venue_name =

                    :venue_name,

                location =

                    :location,

                capacity =

                    :capacity,

                status =

                    :status

            WHERE venue_id =

                :venue_id

        ";

        $stmt =

            $db->prepare($query);

        $stmt->execute([

            ":venue_name" =>

                trim(

                    $data["venue_name"]

                ),

            ":location" =>

                trim(

                    $data["location"]

                ),

            ":capacity" =>

                intval(

                    $data["capacity"]

                ),

            ":status" =>

                $data["status"],

            ":venue_id" =>

                $venueId

        ]);

        http_response_code(200);

        echo json_encode([

            "status" =>

                "success",

            "message" =>

                "Venue updated successfully",

            "venue_id" =>

                $venueId

        ]);

        exit;

    }

    /* =================================================

       DELETE VENUE

    ================================================= */

    elseif ($method === "DELETE") {

        $data =

            getVenueJsonBody();

        if (

            !$data ||

            empty(

                $data["venue_id"]

            )

        ) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Venue ID is required"

            ]);

            exit;

        }

        $venueId =

            intval(

                $data["venue_id"]

            );

        /* CHECK VENUE */

        $venueStmt =

            $db->prepare(

                "

                SELECT

                    venue_id,

                    venue_name

                FROM venues

                WHERE venue_id =

                    :venue_id

                "

            );

        $venueStmt->execute([

            ":venue_id" =>

                $venueId

        ]);

        $venue =

            $venueStmt->fetch();

        if (!$venue) {

            http_response_code(404);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Venue not found"

            ]);

            exit;

        }

        /* CHECK EVENTS USING VENUE */

        $eventStmt =

            $db->prepare(

                "

                SELECT COUNT(*)

                    AS event_count

                FROM events

                WHERE venue_id =

                    :venue_id

                "

            );

        $eventStmt->execute([

            ":venue_id" =>

                $venueId

        ]);

        $eventCount =

            intval(

                $eventStmt

                    ->fetch()[

                        "event_count"

                    ]

            );

        if ($eventCount > 0) {

            http_response_code(409);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "This venue cannot be deleted because events are assigned to it. Change its status to Unavailable instead."

            ]);

            exit;

        }

        $deleteStmt =

            $db->prepare(

                "

                DELETE FROM venues

                WHERE venue_id =

                    :venue_id

                "

            );

        $deleteStmt->execute([

            ":venue_id" =>

                $venueId

        ]);

        http_response_code(200);

        echo json_encode([

            "status" =>

                "success",

            "message" =>

                "Venue deleted successfully",

            "venue_id" =>

                $venueId

        ]);

        exit;

    }

    /* =================================================

       METHOD NOT ALLOWED

    ================================================= */

    else {

        http_response_code(405);

        echo json_encode([

            "status" => "error",

            "message" =>

                "Method not allowed"

        ]);

        exit;

    }

} catch (Throwable $error) {

    error_log($error->getMessage());

    http_response_code(500);

    echo json_encode([

        "status" => "error",

        "message" => "Internal server error"

    ]);

}

?>