<?php
require_once __DIR__ . '/../middleware/api.php';
eventifyApiInit();
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET'); http_response_code(405);
    echo json_encode(['status'=>'error','message'=>'Method not allowed']); exit;
}
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../middleware/apikey.php';
require_once __DIR__ . '/../config/database.php';
$user=requireAuth();
requireRole($user,['Administrator']);
eventifyRequireInternalApiKey();
try {
    $db=(new Database())->getConnection();
    if (!$db) throw new RuntimeException('Database unavailable');
    $metrics=[];
    foreach (['users','events','venues','bookings'] as $table) {
        // Table names are hardcoded in the array, not user-controlled.
        $metrics[$table]=(int)$db->query('SELECT COUNT(*) FROM '.$table)->fetchColumn();
    }
    echo json_encode(['status'=>'success','data'=>$metrics]);
} catch (Throwable $error) {
    error_log('Eventify metrics: '.$error->getMessage());
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>'Unable to retrieve metrics']);
}
