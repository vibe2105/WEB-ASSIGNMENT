<?php
require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    http_response_code(405);
    echo json_encode(['status'=>'error','message'=>'Method not allowed']);
    exit;
}
// No internal database credentials, path information or secrets are disclosed.
echo json_encode(['status'=>'success','message'=>'Eventify API is running']);
