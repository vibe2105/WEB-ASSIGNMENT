<?php
require_once __DIR__ . '/../middleware/api.php';
require_once __DIR__ . '/../middleware/validation.php';
eventifyApiInit();
header('Cache-Control: private, no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    http_response_code(405);
    header('Content-Type: application/json');
    echo json_encode(['status'=>'error','message'=>'Method not allowed']);
    exit;
}
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../config/database.php';
$user = requireAuth();
$id = eventifyQueryPositiveInt('booking_id', 0);
if ($id === false || $id < 1) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['status'=>'error','message'=>'Valid booking_id is required']);
    exit;
}
$db = (new Database())->getConnection();
if (!$db) {
    http_response_code(503);
    header('Content-Type: application/json');
    echo json_encode(['status'=>'error','message'=>'Database unavailable']);
    exit;
}
try {
    $stmt = $db->prepare('SELECT b.booking_id,b.user_id,b.booking_status,e.organiser_id
        FROM bookings b JOIN events e ON b.event_id=e.event_id
        WHERE b.booking_id=:id LIMIT 1');
    $stmt->execute([':id'=>$id]);
    $booking = $stmt->fetch();
    if (!$booking) {
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode(['status'=>'error','message'=>'Booking not found']);
        exit;
    }
    $role = $user['role'];
    if ($role !== 'Administrator' &&
        !($role === 'Customer' && (int)$booking['user_id'] === (int)$user['user_id']) &&
        !($role === 'Organiser' && (int)$booking['organiser_id'] === (int)$user['user_id'])) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['status'=>'error','message'=>'Access denied']);
        exit;
    }
    if ($booking['booking_status'] !== 'Confirmed') {
        http_response_code(409);
        header('Content-Type: application/json');
        echo json_encode(['status'=>'error','message'=>'Only confirmed bookings have valid tickets']);
        exit;
    }
    // External provider receives no email, name, password, or JWT.
    $payload = 'EVF1|' . $id;
    $signature = substr(hash_hmac('sha256', $payload, eventifyTicketSecret()), 0, 24);
    $ticketCode = $payload . '|' . $signature;
    $url = 'https://api.qrserver.com/v1/create-qr-code/?'
        . http_build_query(['data'=>$ticketCode,'size'=>'240x240','format'=>'png','qzone'=>'4']);
    if (!function_exists('curl_init')) {
        error_log('Eventify ticket QR requires PHP cURL extension');
        http_response_code(503);
        header('Content-Type: application/json');
        echo json_encode(['status'=>'error','message'=>'QR service unavailable']);
        exit;
    }
    $curl = curl_init($url);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT => 'EventifyTicketing/1.0',
    ]);
    $image = curl_exec($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curlError = curl_error($curl);
    curl_close($curl);
    if ($image === false || $status !== 200 || strlen((string)$image) > 300000 ||
        substr((string)$image, 0, 8) !== "\x89PNG\r\n\x1a\n") {
        error_log('Eventify QR provider failure HTTP ' . $status . ': ' . $curlError);
        http_response_code(502);
        header('Content-Type: application/json');
        echo json_encode(['status'=>'error','message'=>'External QR provider unavailable']);
        exit;
    }
    header('Content-Type: image/png');
    header('X-Content-Type-Options: nosniff');
    echo $image;
} catch (Throwable $error) {
    error_log('Eventify ticket QR: ' . $error->getMessage());
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['status'=>'error','message'=>'Unable to generate ticket QR']);
}
