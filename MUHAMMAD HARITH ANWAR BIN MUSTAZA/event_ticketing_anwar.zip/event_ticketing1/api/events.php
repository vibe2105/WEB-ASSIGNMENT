<?php
require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();

ini_set("display_errors", 0);

ini_set("log_errors", 1);

error_reporting(E_ALL);

header("Content-Type: application/json");

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../middleware/validation.php";

try {

    $database = new Database();

    $db = $database->getConnection();

} catch (Throwable $error) {

    error_log($error->getMessage());

    http_response_code(500);

    echo json_encode([

        "status" => "error",

        "message" => "Internal server error"

    ]);

    exit;

}

if (!$db) {

    http_response_code(500);

    echo json_encode([

        "status" => "error",

        "message" => "Database connection failed"

    ]);

    exit;

}

$method = $_SERVER["REQUEST_METHOD"];

$currentUser = null;

/* =====================================================

   PROTECT MANAGEMENT METHODS

===================================================== */

if (

    $method === "POST" ||

    $method === "PUT" ||

    $method === "DELETE"

) {

    require_once __DIR__ . "/../middleware/auth.php";

    $currentUser = requireAuth();

    requireRole(

        $currentUser,

        [

            "Administrator",

            "Organiser"

        ]

    );

}

/* =====================================================

   READ JSON BODY

===================================================== */

function getJsonBody()

{

    $data = json_decode(

        file_get_contents("php://input"),

        true

    );

    if (!is_array($data)) {

        return null;

    }

    return $data;

}

/* =====================================================

   VALIDATE EVENT DATA

===================================================== */

function validateEventData(

    $data,

    $db,

    $existingVenueId = null,
    $existingEventId = null

) {

    $required = [

        "event_name",

        "category",

        "venue_id",

        "event_date",

        "start_time",

        "end_time",

        "ticket_price",

        "total_tickets",

        "status"

    ];

    foreach ($required as $field) {

        if (

            !isset($data[$field]) ||
            !is_scalar($data[$field]) ||
            trim((string)$data[$field]) === ""

        ) {

            return ucfirst(

                str_replace(

                    "_",

                    " ",

                    $field

                )

            ) . " is required";

        }

    }

    if (!is_string($data['event_name']) || !is_string($data['category']) ||
        !is_string($data['event_date']) || !is_string($data['start_time']) ||
        !is_string($data['end_time']) || !is_string($data['status']) ||
        (isset($data['description']) && !is_string($data['description']))) {
        return 'Invalid event field type';
    }
    if (strlen($data['category']) > 50 || strlen($data['event_name']) > 200) {
        return 'Event name or category is too long';
    }

    /* EVENT NAME */

    if (

        strlen(

            trim($data["event_name"])

        ) < 3

    ) {

        return

            "Event name must contain at least 3 characters";

    }

    /* PRICE */

    if (

        !is_numeric(

            $data["ticket_price"]

        ) ||

        floatval(

            $data["ticket_price"]

        ) < 0

    ) {

        return

            "Ticket price must be 0 or greater";

    }

    /* TOTAL TICKETS */

    if (

        filter_var(

            $data["total_tickets"],

            FILTER_VALIDATE_INT,

            ["options" => ["min_range" => 1]]

        ) === false

    ) {

        return

            "Total tickets must be at least 1";

    }

    /* DATE */

    $date =

        DateTime::createFromFormat(

            "Y-m-d",

            $data["event_date"]

        );

    if (

        !$date ||

        $date->format("Y-m-d")

        !== $data["event_date"]

    ) {

        return

            "Invalid event date";

    }

    /* TIME */

    $start =

        strtotime(

            "1970-01-01 "

            . $data["start_time"]

        );

    $end =

        strtotime(

            "1970-01-01 "

            . $data["end_time"]

        );

    if (

        $start === false ||

        $end === false

    ) {

        return

            "Invalid event time";

    }

    if ($end <= $start) {

        return

            "End time must be later than start time";

    }

    /* STATUS */

    $allowedStatuses = [

        "Upcoming",

        "Ongoing",

        "Completed",

        "Cancelled"

    ];

    if (

        !in_array(

            $data["status"],

            $allowedStatuses,

            true

        )

    ) {

        return

            "Invalid event status";

    }

    /* VENUE: it must exist and have adequate capacity. */

    $venueId = filter_var(
        $data["venue_id"],
        FILTER_VALIDATE_INT,
        ["options" => ["min_range" => 1]]
    );

    if ($venueId === false) {
        return "Please select a valid venue";
    }

    $venueStmt =

        $db->prepare(

            "

            SELECT

                venue_id,

                capacity,

                status

            FROM venues

            WHERE venue_id =

                :venue_id

            FOR UPDATE

            "

        );

    $venueStmt->execute([

        ":venue_id" =>

            $venueId

    ]);

    $venue =

        $venueStmt->fetch();

    if (!$venue) {
        return "Selected venue does not exist";
    }

    // Editing the same assigned venue is allowed if an Administrator
    // has since marked it unavailable. A new assignment is not.
    $sameExistingVenue = $existingVenueId !== null
        && (int) $venueId === (int) $existingVenueId;

    if ($venue["status"] !== "Available" && !$sameExistingVenue) {
        return "Selected venue is unavailable. Choose an available venue";
    }

    if ((int) $data["total_tickets"] > (int) $venue["capacity"]) {
        return "Total tickets cannot exceed the selected venue capacity of "
            . (int) $venue["capacity"];
    }

    // A venue may not have overlapping, non-cancelled events.
    // Validation runs within POST/PUT database transactions. The venue row
    // is SELECTed FOR UPDATE above to serialize competing assignments.
    if ($data['status'] !== 'Cancelled') {
        $conflictSql = "SELECT COUNT(*) FROM events
            WHERE venue_id = :venue_id AND event_date = :event_date
            AND status <> 'Cancelled'
            AND start_time < :new_end AND end_time > :new_start";
        if ($existingEventId !== null) {
            $conflictSql .= ' AND event_id <> :existing_event_id';
        }
        $conflict = $db->prepare($conflictSql);
        $params = [
            ':venue_id' => $venueId,
            ':event_date' => $data['event_date'],
            ':new_end' => $data['end_time'],
            ':new_start' => $data['start_time'],
        ];
        if ($existingEventId !== null) {
            $params[':existing_event_id'] = (int) $existingEventId;
        }
        $conflict->execute($params);
        if ((int) $conflict->fetchColumn() > 0) {
            return 'The selected venue already has an overlapping event at this date and time';
        }
    }

    return null;

}

try {

    /* =================================================

       GET EVENTS

    ================================================= */

    if ($method === "GET") {

        /* =============================================

           GET ONE EVENT

        ============================================= */

        if (

            isset(

                $_GET["event_id"]

            )

        ) {

            $eventId =

                intval(

                    $_GET["event_id"]

                );

            $query = "

                SELECT

                    e.event_id,

                    e.organiser_id,

                    e.venue_id,

                    e.event_name,

                    e.category,

                    e.description,

                    e.event_date,

                    e.start_time,

                    e.end_time,

                    e.ticket_price,

                    e.total_tickets,

                    e.available_tickets,

                    e.status,

                    e.created_at,

                    v.venue_name,

                    v.location,

                    v.capacity,

                    u.name AS organiser_name

                FROM events e

                INNER JOIN venues v

                    ON e.venue_id =

                       v.venue_id

                INNER JOIN users u

                    ON e.organiser_id =

                       u.user_id

                WHERE e.event_id =

                    :event_id

            ";

            $stmt =

                $db->prepare($query);

            $stmt->execute([

                ":event_id" =>

                    $eventId

            ]);

            $event =

                $stmt->fetch();

            if (!$event) {

                http_response_code(404);

                echo json_encode([

                    "status" => "error",

                    "message" =>

                        "Event not found"

                ]);

                exit;

            }

            http_response_code(200);

            echo json_encode([

                "status" => "success",

                "data" => $event

            ]);

            exit;

        }

        /* =============================================
           GET ALL EVENTS: API search, filtering, sorting
           and optional backwards-compatible pagination.
        ============================================= */
        $search = eventifyQueryText('search', 100);
        $category = eventifyQueryText('category', 50);
        $status = eventifyQueryText('status', 20);
        $sort = eventifyQueryText('sort', 30, 'event_date');
        $requestedOrder = eventifyQueryText('order', 4, 'asc');
        $order = $requestedOrder === null ? null : strtolower($requestedOrder);
        $sortFields = [
            'event_date' => 'e.event_date',
            'event_name' => 'e.event_name',
            'ticket_price' => 'e.ticket_price',
        ];
        $withPages = isset($_GET['page']) || isset($_GET['limit']);
        $page = eventifyQueryPositiveInt('page', 1);
        $limit = eventifyQueryPositiveInt('limit', 10, 100);
        $allowedStatuses = ['Upcoming', 'Ongoing', 'Completed', 'Cancelled'];
        if ($search === null || $category === null || $status === null ||
            ($status !== '' && !in_array($status, $allowedStatuses, true)) ||
            $sort === null || !isset($sortFields[$sort]) ||
            !in_array($order, ['asc','desc'], true) ||
            $page === false || $limit === false) {
            http_response_code(400);
            echo json_encode(['status'=>'error','message'=>'Invalid search, filter, sort or pagination parameters']);
            exit;
        }
        $where = [];
        $params = [];
        if ($search !== '') {
            $where[] = '(e.event_name LIKE :search OR e.description LIKE :description_search OR v.venue_name LIKE :venue_search)';
            $params[':search'] = '%' . $search . '%';
            $params[':description_search'] = '%' . $search . '%';
            $params[':venue_search'] = '%' . $search . '%';
        }
        if ($category !== '') {
            $where[] = 'e.category = :category';
            $params[':category'] = $category;
        }
        if ($status !== '') {
            $where[] = 'e.status = :status';
            $params[':status'] = $status;
        }
        $from = ' FROM events e
            INNER JOIN venues v ON e.venue_id = v.venue_id
            INNER JOIN users u ON e.organiser_id = u.user_id';
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        $countStmt = $db->prepare('SELECT COUNT(*)' . $from . $whereSql);
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $sql = 'SELECT e.event_id,e.organiser_id,e.venue_id,e.event_name,
            e.category,e.description,e.event_date,e.start_time,e.end_time,
            e.ticket_price,e.total_tickets,e.available_tickets,e.status,e.created_at,
            v.venue_name,v.location,v.capacity,u.name AS organiser_name'
            . $from . $whereSql
            . ' ORDER BY ' . $sortFields[$sort] . ' ' . strtoupper($order)
            . ', e.event_id ASC';
        if ($withPages) {
            $sql .= ' LIMIT :limit OFFSET :offset';
        }
        $stmt = $db->prepare($sql);
        foreach ($params as $key=>$value) $stmt->bindValue($key, $value, PDO::PARAM_STR);
        if ($withPages) {
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', ($page - 1) * $limit, PDO::PARAM_INT);
        }
        $stmt->execute();
        $response = ['status'=>'success','total'=>$total,'data'=>$stmt->fetchAll()];
        if ($withPages) {
            $response['pagination'] = [
                'page'=>$page, 'limit'=>$limit,
                'total_pages'=>$total === 0 ? 0 : (int)ceil($total/$limit),
            ];
        }
        http_response_code(200);
        echo json_encode($response);
        exit;
    }

    /* =================================================

       POST - CREATE EVENT

    ================================================= */

    elseif ($method === "POST") {

        $data =

            getJsonBody();

        if (!$data) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Invalid JSON request body"

            ]);

            exit;

        }

        // Lock venue availability while validating and creating the event.
        $db->beginTransaction();

        $validationError =

            validateEventData(

                $data,

                $db

            );

        if ($validationError) {

            $db->rollBack();

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    $validationError

            ]);

            exit;

        }

        /*

           IMPORTANT:

           The organiser is taken from JWT.

           The client cannot choose another user ID.

        */

        $organiserId =

            intval(

                $currentUser["user_id"]

            );

        $venueId =

            intval(

                $data["venue_id"]

            );

        $ticketPrice =

            floatval(

                $data["ticket_price"]

            );

        $totalTickets =

            intval(

                $data["total_tickets"]

            );

        $description =

            trim(

                $data["description"]

                ?? ""

            );

        $query = "

            INSERT INTO events

            (

                organiser_id,

                venue_id,

                event_name,

                category,

                description,

                event_date,

                start_time,

                end_time,

                ticket_price,

                total_tickets,

                available_tickets,

                status

            )

            VALUES

            (

                :organiser_id,

                :venue_id,

                :event_name,

                :category,

                :description,

                :event_date,

                :start_time,

                :end_time,

                :ticket_price,

                :total_tickets,

                :available_tickets,

                :status

            )

        ";

        $stmt =

            $db->prepare($query);

        $stmt->execute([

            ":organiser_id" =>

                $organiserId,

            ":venue_id" =>

                $venueId,

            ":event_name" =>

                trim(

                    $data["event_name"]

                ),

            ":category" =>

                trim(

                    $data["category"]

                ),

            ":description" =>

                $description,

            ":event_date" =>

                $data["event_date"],

            ":start_time" =>

                $data["start_time"],

            ":end_time" =>

                $data["end_time"],

            ":ticket_price" =>

                $ticketPrice,

            ":total_tickets" =>

                $totalTickets,

            ":available_tickets" =>

                $totalTickets,

            ":status" =>

                $data["status"]

        ]);

        $eventId =

            $db->lastInsertId();

        $db->commit();

        http_response_code(201);

        echo json_encode([

            "status" =>

                "success",

            "message" =>

                "Event created successfully",

            "event_id" =>

                $eventId

        ]);

        exit;

    }

    /* =================================================

       PUT - UPDATE EVENT

    ================================================= */

    elseif ($method === "PUT") {

        $data =

            getJsonBody();

        if (!$data) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Invalid JSON request body"

            ]);

            exit;

        }

        if (

            empty(

                $data["event_id"]

            )

        ) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Event ID is required"

            ]);

            exit;

        }

        $eventId =

            intval(

                $data["event_id"]

            );

        /* =============================================

           GET EXISTING EVENT

        ============================================= */

        $db->beginTransaction();

        $existingStmt =

            $db->prepare(

                "

                SELECT

                    event_id,

                    organiser_id,

                    venue_id,

                    total_tickets,

                    available_tickets

                FROM events

                WHERE event_id =

                    :event_id

                FOR UPDATE

                "

            );

        $existingStmt->execute([

            ":event_id" =>

                $eventId

        ]);

        $existingEvent =

            $existingStmt->fetch();

        if (!$existingEvent) {

            $db->rollBack();

            http_response_code(404);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Event not found"

            ]);

            exit;

        }

        /* =============================================

           ORGANISER OWNERSHIP CHECK

        ============================================= */

        if (

            $currentUser["role"]

            === "Organiser"

            &&

            intval(

                $existingEvent[

                    "organiser_id"

                ]

            )

            !==

            intval(

                $currentUser[

                    "user_id"

                ]

            )

        ) {

            $db->rollBack();

            http_response_code(403);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "You cannot edit another organiser's event"

            ]);

            exit;

        }

        /* =============================================

           VALIDATE NEW DATA

        ============================================= */

        $validationError =

            validateEventData(

                $data,

                $db,

                $existingEvent["venue_id"],
                $eventId

            );

        if ($validationError) {

            $db->rollBack();

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    $validationError

            ]);

            exit;

        }

        /*

           PRESERVE SOLD TICKETS

           Example:

           Original total:     500

           Available:          480

           Already booked:      20

           New total:          600

           New available:      580

        */

        $oldTotal =

            intval(

                $existingEvent[

                    "total_tickets"

                ]

            );

        $oldAvailable =

            intval(

                $existingEvent[

                    "available_tickets"

                ]

            );

        $soldTickets =

            max(

                0,

                $oldTotal -

                $oldAvailable

            );

        $newTotal =

            intval(

                $data["total_tickets"]

            );

        if (

            $newTotal <

            $soldTickets

        ) {

            $db->rollBack();

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Total tickets cannot be lower than the number of tickets already booked"

            ]);

            exit;

        }

        $newAvailable =

            $newTotal -

            $soldTickets;

        /* =============================================

           UPDATE EVENT

        ============================================= */

        $query = "

            UPDATE events

            SET

                venue_id =

                    :venue_id,

                event_name =

                    :event_name,

                category =

                    :category,

                description =

                    :description,

                event_date =

                    :event_date,

                start_time =

                    :start_time,

                end_time =

                    :end_time,

                ticket_price =

                    :ticket_price,

                total_tickets =

                    :total_tickets,

                available_tickets =

                    :available_tickets,

                status =

                    :status

            WHERE event_id =

                :event_id

        ";

        $stmt =

            $db->prepare($query);

        $stmt->execute([

            ":venue_id" =>

                intval(

                    $data["venue_id"]

                ),

            ":event_name" =>

                trim(

                    $data["event_name"]

                ),

            ":category" =>

                trim(

                    $data["category"]

                ),

            ":description" =>

                trim(

                    $data["description"]

                    ?? ""

                ),

            ":event_date" =>

                $data["event_date"],

            ":start_time" =>

                $data["start_time"],

            ":end_time" =>

                $data["end_time"],

            ":ticket_price" =>

                floatval(

                    $data["ticket_price"]

                ),

            ":total_tickets" =>

                $newTotal,

            ":available_tickets" =>

                $newAvailable,

            ":status" =>

                $data["status"],

            ":event_id" =>

                $eventId

        ]);

        $db->commit();

        http_response_code(200);

        echo json_encode([

            "status" =>

                "success",

            "message" =>

                "Event updated successfully",

            "event_id" =>

                $eventId,

            "available_tickets" =>

                $newAvailable

        ]);

        exit;

    }

    /* =================================================

       DELETE EVENT

    ================================================= */

    elseif ($method === "DELETE") {

        $data =

            getJsonBody();

        if (

            !$data ||

            empty(

                $data["event_id"]

            )

        ) {

            http_response_code(400);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Event ID is required"

            ]);

            exit;

        }

        $eventId =

            intval(

                $data["event_id"]

            );

        /* =============================================

           GET EVENT

        ============================================= */

        $eventStmt =

            $db->prepare(

                "

                SELECT

                    event_id,

                    event_name,

                    organiser_id

                FROM events

                WHERE event_id =

                    :event_id

                "

            );

        $eventStmt->execute([

            ":event_id" =>

                $eventId

        ]);

        $event =

            $eventStmt->fetch();

        if (!$event) {

            http_response_code(404);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "Event not found"

            ]);

            exit;

        }

        /* =============================================

           ORGANISER OWNERSHIP CHECK

        ============================================= */

        if (

            $currentUser["role"]

            === "Organiser"

            &&

            intval(

                $event[

                    "organiser_id"

                ]

            )

            !==

            intval(

                $currentUser[

                    "user_id"

                ]

            )

        ) {

            http_response_code(403);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "You cannot delete another organiser's event"

            ]);

            exit;

        }

        /* =============================================

           CHECK EXISTING BOOKINGS

        ============================================= */

        $bookingStmt =

            $db->prepare(

                "

                SELECT

                    COUNT(*)

                    AS booking_count

                FROM bookings

                WHERE event_id =

                    :event_id

                "

            );

        $bookingStmt->execute([

            ":event_id" =>

                $eventId

        ]);

        $bookingResult =

            $bookingStmt->fetch();

        $bookingCount =

            intval(

                $bookingResult[

                    "booking_count"

                ]

            );

        if ($bookingCount > 0) {

            http_response_code(409);

            echo json_encode([

                "status" => "error",

                "message" =>

                    "This event cannot be deleted because booking records already exist. Change its status to Cancelled instead."

            ]);

            exit;

        }

        /* =============================================

           DELETE EVENT

        ============================================= */

        $deleteStmt =

            $db->prepare(

                "

                DELETE FROM events

                WHERE event_id =

                    :event_id

                "

            );

        $deleteStmt->execute([

            ":event_id" =>

                $eventId

        ]);

        http_response_code(200);

        echo json_encode([

            "status" =>

                "success",

            "message" =>

                "Event deleted successfully",

            "event_id" =>

                $eventId

        ]);

        exit;

    }

    /* =================================================

       METHOD NOT ALLOWED

    ================================================= */

    else {

        http_response_code(405);

        echo json_encode([

            "status" => "error",

            "message" =>

                "Method not allowed"

        ]);

        exit;

    }

} catch (Throwable $error) {

    if (isset($db) && $db && $db->inTransaction()) {

        $db->rollBack();

    }

    error_log(

        $error->getMessage()

    );

    http_response_code(500);

    echo json_encode([

        "status" =>

            "error",

        "message" =>

            "Internal server error"

    ]);

}

?>