<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta

        name="viewport"

        content="width=device-width, initial-scale=1.0"

    >

    <title>Manage Events | Eventify</title>

    <link

        rel="stylesheet"

        href="css/style.css"

    >

    <style>

        body {

            background:

                #f5f5fa;

        }

        /* ==========================================

           HEADER

        ========================================== */

        .management-hero {

            padding:

                55px 0;

            color:

                white;

            background:

                radial-gradient(

                    circle at 80% 20%,

                    rgba(117,89,255,.25),

                    transparent 35%

                ),

                linear-gradient(

                    135deg,

                    #11101d,

                    #211943

                );

        }

        .management-hero-content {

            display:

                flex;

            align-items:

                end;

            justify-content:

                space-between;

            gap:

                30px;

        }

        .management-hero .eyebrow {

            color:

                #a997ff;

        }

        .management-hero h1 {

            font-family:

                "Manrope",

                sans-serif;

            font-size:

                48px;

            letter-spacing:

                -2px;

            margin-top:

                8px;

        }

        .management-hero p {

            color:

                #aaa6b9;

            margin-top:

                9px;

        }

        .create-event-btn {

            border:

                none;

            padding:

                14px 20px;

            border-radius:

                11px;

            color:

                white;

            background:

                #7559ff;

            cursor:

                pointer;

            font-size:

                13px;

            font-weight:

                800;

            transition:

                .25s;

        }

        .create-event-btn:hover {

            transform:

                translateY(-2px);

            background:

                #6449e8;

        }

        /* ==========================================

           CONTENT

        ========================================== */

        .management-section {

            padding:

                45px 0 100px;

        }

        .management-stats {

            display:

                grid;

            grid-template-columns:

                repeat(

                    4,

                    1fr

                );

            gap:

                18px;

            margin-bottom:

                30px;

        }

        .management-stat {

            padding:

                21px;

            background:

                white;

            border:

                1px solid

                #e8e6ee;

            border-radius:

                15px;

        }

        .management-stat span {

            color:

                #9995a4;

            font-size:

                10px;

            text-transform:

                uppercase;

            letter-spacing:

                .8px;

        }

        .management-stat strong {

            display:

                block;

            margin-top:

                7px;

            font-family:

                "Manrope",

                sans-serif;

            font-size:

                27px;

        }

        /* ==========================================

           TOOLBAR

        ========================================== */

        .management-toolbar {

            padding:

                17px;

            display:

                flex;

            align-items:

                center;

            gap:

                12px;

            margin-bottom:

                22px;

            background:

                white;

            border:

                1px solid

                #e8e6ee;

            border-radius:

                15px;

        }

        .management-toolbar input {

            flex:

                1;

            height:

                47px;

            border:

                1px solid

                #e4e2e9;

            border-radius:

                10px;

            padding:

                0 15px;

            outline:

                none;

        }

        .management-toolbar input:focus {

            border-color:

                #9d8df7;

        }

        .management-toolbar select {

            height:

                47px;

            min-width:

                170px;

            border:

                1px solid

                #e4e2e9;

            border-radius:

                10px;

            padding:

                0 13px;

            background:

                white;

        }

        /* ==========================================

           EVENT TABLE

        ========================================== */

        .event-management-card {

            background:

                white;

            border:

                1px solid

                #e8e6ee;

            border-radius:

                18px;

            overflow:

                hidden;

            box-shadow:

                0 14px 35px

                rgba(

                    25,

                    20,

                    55,

                    .05

                );

        }

        .table-wrapper {

            overflow-x:

                auto;

        }

        .event-table {

            width:

                100%;

            border-collapse:

                collapse;

            min-width:

                950px;

        }

        .event-table th {

            padding:

                15px 18px;

            background:

                #f8f7fb;

            color:

                #918e9d;

            font-size:

                10px;

            text-transform:

                uppercase;

            letter-spacing:

                .7px;

            text-align:

                left;

            border-bottom:

                1px solid

                #eceaf0;

        }

        .event-table td {

            padding:

                18px;

            border-bottom:

                1px solid

                #f0eef3;

            font-size:

                12px;

            vertical-align:

                middle;

        }

        .event-table tr:last-child td {

            border-bottom:

                none;

        }

        .event-name {

            max-width:

                240px;

        }

        .event-name strong {

            display:

                block;

            color:

                #282532;

            font-size:

                13px;

        }

        .event-name span {

            display:

                block;

            color:

                #9995a4;

            margin-top:

                4px;

            font-size:

                10px;

        }

        .status-pill {

            display:

                inline-block;

            padding:

                6px 10px;

            border-radius:

                100px;

            font-size:

                9px;

            font-weight:

                800;

        }

        .status-upcoming {

            color:

                #197d5c;

            background:

                #eaf8f2;

        }

        .status-ongoing {

            color:

                #3569a7;

            background:

                #edf4ff;

        }

        .status-completed {

            color:

                #666273;

            background:

                #f0eff3;

        }

        .status-cancelled {

            color:

                #b64b4b;

            background:

                #fff0f0;

        }

        .action-buttons {

            display:

                flex;

            gap:

                7px;

        }

        .edit-btn,

        .delete-btn {

            padding:

                8px 11px;

            border:

                none;

            border-radius:

                8px;

            cursor:

                pointer;

            font-size:

                10px;

            font-weight:

                800;

        }

        .edit-btn {

            color:

                #664ce2;

            background:

                #eeeaff;

        }

        .edit-btn:hover {

            background:

                #e2dcff;

        }

        .delete-btn {

            color:

                #b44545;

            background:

                #fff0f0;

        }

        .delete-btn:hover {

            background:

                #ffdddd;

        }

        .empty-events {

            padding:

                70px;

            text-align:

                center;

            color:

                #8d8998;

        }

        /* ==========================================

           MODAL

        ========================================== */

        .modal-overlay {

            position:

                fixed;

            inset:

                0;

            z-index:

                5000;

            display:

                none;

            align-items:

                center;

            justify-content:

                center;

            padding:

                20px;

            background:

                rgba(

                    11,

                    10,

                    18,

                    .7

                );

            backdrop-filter:

                blur(6px);

        }

        .modal-overlay.show {

            display:

                flex;

        }

        .event-modal {

            width:

                min(

                    780px,

                    100%

                );

            max-height:

                90vh;

            overflow-y:

                auto;

            background:

                white;

            border-radius:

                22px;

            box-shadow:

                0 35px 90px

                rgba(

                    0,

                    0,

                    0,

                    .3

                );

        }

        .modal-header {

            padding:

                25px 28px;

            display:

                flex;

            align-items:

                center;

            justify-content:

                space-between;

            border-bottom:

                1px solid

                #eeecf2;

        }

        .modal-header span {

            color:

                #7559ff;

            font-size:

                10px;

            font-weight:

                800;

            letter-spacing:

                1.4px;

        }

        .modal-header h2 {

            font-family:

                "Manrope",

                sans-serif;

            margin-top:

                5px;

        }

        .modal-close {

            width:

                36px;

            height:

                36px;

            border:

                none;

            border-radius:

                9px;

            background:

                #f3f2f6;

            color:

                #777482;

            cursor:

                pointer;

            font-size:

                17px;

        }

        .event-form {

            padding:

                28px;

        }

        .form-grid {

            display:

                grid;

            grid-template-columns:

                repeat(

                    2,

                    1fr

                );

            gap:

                18px;

        }

        .form-field.full {

            grid-column:

                1 / -1;

        }

        .form-field label {

            display:

                block;

            margin-bottom:

                7px;

            color:

                #4d4959;

            font-size:

                11px;

            font-weight:

                700;

        }

        .form-field input,

        .form-field select,

        .form-field textarea {

            width:

                100%;

            border:

                1px solid

                #e2e0e8;

            border-radius:

                10px;

            background:

                #fafafd;

            color:

                #292633;

            outline:

                none;

            font-family:

                inherit;

            font-size:

                12px;

        }

        .form-field input,

        .form-field select {

            height:

                48px;

            padding:

                0 13px;

        }

        .form-field textarea {

            min-height:

                110px;

            padding:

                13px;

            resize:

                vertical;

        }

        .form-field input:focus,

        .form-field select:focus,

        .form-field textarea:focus {

            border-color:

                #9d8cf5;

            background:

                white;

            box-shadow:

                0 0 0 4px

                rgba(

                    117,

                    89,

                    255,

                    .07

                );

        }

        .modal-actions {

            display:

                flex;

            justify-content:

                flex-end;

            gap:

                10px;

            margin-top:

                28px;

            padding-top:

                22px;

            border-top:

                1px solid

                #efedf3;

        }

        .cancel-modal-btn {

            padding:

                12px 17px;

            border:

                none;

            border-radius:

                9px;

            background:

                #f1f0f5;

            color:

                #5d5968;

            cursor:

                pointer;

            font-weight:

                700;

        }

        .save-event-btn {

            padding:

                12px 18px;

            border:

                none;

            border-radius:

                9px;

            background:

                #7559ff;

            color:

                white;

            cursor:

                pointer;

            font-weight:

                800;

        }

        .save-event-btn:disabled {

            opacity:

                .6;

            cursor:

                not-allowed;

        }

        .form-message {

            display:

                none;

            padding:

                13px;

            margin-top:

                17px;

            border-radius:

                9px;

            font-size:

                11px;

        }

        .form-message.error {

            display:

                block;

            color:

                #ae4141;

            background:

                #fff0f0;

        }

        .form-message.success {

            display:

                block;

            color:

                #197859;

            background:

                #edf9f4;

        }

        /* DELETE MODAL */

        .delete-modal {

            width:

                min(

                    420px,

                    100%

                );

            padding:

                32px;

            background:

                white;

            border-radius:

                20px;

            text-align:

                center;

        }

        .delete-icon {

            width:

                58px;

            height:

                58px;

            display:

                grid;

            place-items:

                center;

            margin:

                auto;

            border-radius:

                50%;

            color:

                #b84444;

            background:

                #fff0f0;

            font-size:

                23px;

        }

        .delete-modal h2 {

            margin-top:

                18px;

            font-family:

                "Manrope",

                sans-serif;

        }

        .delete-modal p {

            color:

                #807c8d;

            margin-top:

                9px;

            font-size:

                12px;

            line-height:

                1.6;

        }

        .delete-actions {

            display:

                flex;

            gap:

                10px;

            margin-top:

                24px;

        }

        .delete-actions button {

            flex:

                1;

            padding:

                12px;

            border:

                none;

            border-radius:

                9px;

            cursor:

                pointer;

            font-weight:

                700;

        }

        .confirm-delete {

            background:

                #c34848;

            color:

                white;

        }

        /* TOAST */

        .toast {

            position:

                fixed;

            z-index:

                7000;

            right:

                25px;

            bottom:

                25px;

            padding:

                15px 19px;

            min-width:

                270px;

            border-radius:

                11px;

            color:

                white;

            font-size:

                12px;

            box-shadow:

                0 18px 45px

                rgba(

                    0,

                    0,

                    0,

                    .2

                );

            opacity:

                0;

            transform:

                translateY(

                    80px

                );

            pointer-events:

                none;

            transition:

                .3s;

        }

        .toast.show {

            opacity:

                1;

            transform:

                translateY(0);

        }

        .toast.success {

            background:

                #207b5c;

        }

        .toast.error {

            background:

                #b34343;

        }

        @media (

            max-width: 850px

        ) {

            .management-stats {

                grid-template-columns:

                    repeat(

                        2,

                        1fr

                    );

            }

            .management-toolbar {

                flex-direction:

                    column;

            }

            .management-toolbar input,

            .management-toolbar select {

                width:

                    100%;

            }

            .form-grid {

                grid-template-columns:

                    1fr;

            }

            .form-field.full {

                grid-column:

                    auto;

            }

        }

        @media (

            max-width: 600px

        ) {

            .management-hero-content {

                flex-direction:

                    column;

                align-items:

                    flex-start;

            }

            .management-stats {

                grid-template-columns:

                    1fr;

            }

        }

    </style>

</head>

<body>

<!-- ==========================================

     NAVBAR

========================================== -->

<header class="navbar">

    <div class="container nav-container">

        <a

            href="index.php"

            class="brand"

        >

            <div class="brand-icon">

                E

            </div>

            <span>

                Event<span class="brand-purple">ify</span>

            </span>

        </a>

        <nav class="nav-links">

            <a href="dashboard.php">

                Dashboard

            </a>

            <a

                href="manage-events.php"

                class="active"

            >

                Manage Events

            </a>

            <a href="events.php">

                View Website

            </a>

        </nav>

        <div

            class="nav-actions"

            id="authNavigation"

        >

        </div>

    </div>

</header>

<!-- ==========================================

     HERO

========================================== -->

<section class="management-hero">

    <div

        class="

            container

            management-hero-content

        "

    >

        <div>

            <span class="eyebrow">

                EVENT MANAGEMENT

            </span>

            <h1>

                Manage Events

            </h1>

            <p>

                Create, edit and maintain

                your Eventify event catalogue.

            </p>

        </div>

        <button

            type="button"

            class="create-event-btn"

            id="createEventButton"

        >

            + Create New Event

        </button>

    </div>

</section>

<!-- ==========================================

     CONTENT

========================================== -->

<main class="management-section">

    <div class="container">

        <!-- STATS -->

        <section class="management-stats">

            <article class="management-stat">

                <span>

                    Total Events

                </span>

                <strong id="totalEvents">

                    0

                </strong>

            </article>

            <article class="management-stat">

                <span>

                    Upcoming

                </span>

                <strong id="upcomingEvents">

                    0

                </strong>

            </article>

            <article class="management-stat">

                <span>

                    Total Tickets

                </span>

                <strong id="totalTickets">

                    0

                </strong>

            </article>

            <article class="management-stat">

                <span>

                    Available Tickets

                </span>

                <strong id="availableTickets">

                    0

                </strong>

            </article>

        </section>

        <!-- SEARCH -->

        <section class="management-toolbar">

            <input

                type="text"

                id="eventSearch"

                placeholder="Search event name, venue or organiser..."

            >

            <select id="statusFilter">

                <option value="">

                    All Statuses

                </option>

                <option value="Upcoming">

                    Upcoming

                </option>

                <option value="Ongoing">

                    Ongoing

                </option>

                <option value="Completed">

                    Completed

                </option>

                <option value="Cancelled">

                    Cancelled

                </option>

            </select>

        </section>

        <!-- TABLE -->

        <section class="event-management-card">

            <div class="table-wrapper">

                <table class="event-table">

                    <thead>

                        <tr>

                            <th>

                                Event

                            </th>

                            <th>

                                Date

                            </th>

                            <th>

                                Venue

                            </th>

                            <th>

                                Tickets

                            </th>

                            <th>

                                Price

                            </th>

                            <th>

                                Status

                            </th>

                            <th>

                                Actions

                            </th>

                        </tr>

                    </thead>

                    <tbody id="eventTableBody">

                        <tr>

                            <td

                                colspan="7"

                                class="empty-events"

                            >

                                Loading events...

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </section>

    </div>

</main>

<!-- ==========================================

     CREATE / EDIT MODAL

========================================== -->

<div

    class="modal-overlay"

    id="eventModal"

>

    <div class="event-modal">

        <div class="modal-header">

            <div>

                <span id="modalEyebrow">

                    CREATE EVENT

                </span>

                <h2 id="modalTitle">

                    New Event

                </h2>

            </div>

            <button

                type="button"

                class="modal-close"

                id="closeEventModal"

            >

                ×

            </button>

        </div>

        <form

            class="event-form"

            id="eventForm"

        >

            <input

                type="hidden"

                id="eventId"

            >

            <div class="form-grid">

                <div class="form-field full">

                    <label for="eventName">

                        Event Name

                    </label>

                    <input

                        type="text"

                        id="eventName"

                        placeholder="Enter event name"

                        required

                    >

                </div>

                <div class="form-field">

                    <label for="category">

                        Category

                    </label>

                    <select

                        id="category"

                        required

                    >

                        <option value="">

                            Select category

                        </option>

                        <option value="Technology">

                            Technology

                        </option>

                        <option value="Workshop">

                            Workshop

                        </option>

                        <option value="Music">

                            Music

                        </option>

                        <option value="Seminar">

                            Seminar

                        </option>

                        <option value="Food">

                            Food

                        </option>

                        <option value="Conference">

                            Conference

                        </option>

                        <option value="Other">

                            Other

                        </option>

                    </select>

                </div>

                <div class="form-field">

                    <label for="venue">

                        Venue

                    </label>

                    <select

                        id="venue"

                        required

                    >

                        <option value="">

                            Loading venues...

                        </option>

                    </select>

                </div>

                <div class="form-field">

                    <label for="eventDate">

                        Event Date

                    </label>

                    <input

                        type="date"

                        id="eventDate"

                        required

                    >

                </div>

                <div class="form-field">

                    <label for="status">

                        Status

                    </label>

                    <select

                        id="status"

                        required

                    >

                        <option value="Upcoming">

                            Upcoming

                        </option>

                        <option value="Ongoing">

                            Ongoing

                        </option>

                        <option value="Completed">

                            Completed

                        </option>

                        <option value="Cancelled">

                            Cancelled

                        </option>

                    </select>

                </div>

                <div class="form-field">

                    <label for="startTime">

                        Start Time

                    </label>

                    <input

                        type="time"

                        id="startTime"

                        required

                    >

                </div>

                <div class="form-field">

                    <label for="endTime">

                        End Time

                    </label>

                    <input

                        type="time"

                        id="endTime"

                        required

                    >

                </div>

                <div class="form-field">

                    <label for="ticketPrice">

                        Ticket Price (RM)

                    </label>

                    <input

                        type="number"

                        id="ticketPrice"

                        min="0"

                        step="0.01"

                        placeholder="0.00"

                        required

                    >

                </div>

                <div class="form-field">

                    <label for="totalTicketCount">

                        Total Tickets

                    </label>

                    <input

                        type="number"

                        id="totalTicketCount"

                        min="1"

                        placeholder="100"

                        required

                    >

                </div>

                <div class="form-field full">

                    <label for="description">

                        Description

                    </label>

                    <textarea

                        id="description"

                        placeholder="Describe the event..."

                    ></textarea>

                </div>

            </div>

            <div

                class="form-message"

                id="formMessage"

            >

            </div>

            <div class="modal-actions">

                <button

                    type="button"

                    class="cancel-modal-btn"

                    id="cancelEventModal"

                >

                    Cancel

                </button>

                <button

                    type="submit"

                    class="save-event-btn"

                    id="saveEventButton"

                >

                    Create Event

                </button>

            </div>

        </form>

    </div>

</div>

<!-- ==========================================

     DELETE MODAL

========================================== -->

<div

    class="modal-overlay"

    id="deleteModal"

>

    <div class="delete-modal">

        <div class="delete-icon">

            !

        </div>

        <h2>

            Delete this event?

        </h2>

        <p id="deleteMessage">

            This event will be permanently

            removed. Events with existing

            booking records cannot be deleted.

        </p>

        <div class="delete-actions">

            <button

                type="button"

                class="cancel-modal-btn"

                id="keepEventButton"

            >

                Keep Event

            </button>

            <button

                type="button"

                class="confirm-delete"

                id="confirmDeleteButton"

            >

                Delete Event

            </button>

        </div>

    </div>

</div>

<!-- TOAST -->

<div

    class="toast"

    id="toast"

>

</div>

<script>

/* ==========================================

   VARIABLES

========================================== */

const token =

    localStorage.getItem(

        "eventify_token"

    );

let currentUser =

    null;

let events =

    [];

let venues =

    [];

let selectedDeleteId =

    null;

let formMode =

    "create";

/* ELEMENTS */

const eventTableBody =

    document.getElementById(

        "eventTableBody"

    );

const eventModal =

    document.getElementById(

        "eventModal"

    );

const deleteModal =

    document.getElementById(

        "deleteModal"

    );

const eventForm =

    document.getElementById(

        "eventForm"

    );

const formMessage =

    document.getElementById(

        "formMessage"

    );

const saveEventButton =

    document.getElementById(

        "saveEventButton"

    );

const authNavigation =

    document.getElementById(

        "authNavigation"

    );

const toast =

    document.getElementById(

        "toast"

    );

/* ==========================================

   INITIALISE

========================================== */

async function initialise() {

    if (!token) {

        window.location.href =

            "login.php";

        return;

    }

    try {

        const authResponse =

            await fetch(

                "auth/me.php",

                {

                    headers: {

                        Authorization:

                            "Bearer "

                            + token

                    }

                }

            );

        const authResult =

            await authResponse.json();

        if (

            !authResponse.ok ||

            authResult.status

            !== "success"

        ) {

            logout();

            return;

        }

        currentUser =

            authResult.user;

        if (

            currentUser.role

            !== "Administrator"

            &&

            currentUser.role

            !== "Organiser"

        ) {

            alert(

                "You do not have permission to manage events."

            );

            window.location.href =

                "events.php";

            return;

        }

        updateNavbar();

        await Promise.all([

            loadEvents(),

            loadVenues()

        ]);

    } catch (error) {

        console.error(error);

        showToast(

            "Unable to load event management.",

            "error"

        );

    }

}

/* ==========================================

   LOAD EVENTS

========================================== */

async function loadEvents() {

    const response =

        await fetch(

            "api/events.php"

        );

    const result =

        await response.json();

    if (

        !response.ok ||

        result.status !== "success"

    ) {

        throw new Error(

            result.message ||

            "Unable to load events"

        );

    }

if (currentUser.role === "Organiser") {

    events = result.data.filter(

        event =>

            Number(event.organiser_id) ===

            Number(currentUser.user_id)

    );

} else {

    events = result.data;

}

displayEvents(events);

updateStats();

}

/* ==========================================

   LOAD VENUES

========================================== */

async function loadVenues() {

    const response =

        await fetch(

            "api/venues.php"

        );

    const result =

        await response.json();

    if (

        !response.ok ||

        result.status !== "success"

    ) {

        throw new Error(

            result.message ||

            "Unable to load venues"

        );

    }

    venues =

        result.data;

    populateVenues();

}

/* ==========================================

   DISPLAY EVENTS

========================================== */

function displayEvents(

    eventList

) {

    eventTableBody.innerHTML =

        "";

    if (

        eventList.length === 0

    ) {

        eventTableBody.innerHTML = `

            <tr>

                <td

                    colspan="7"

                    class="empty-events"

                >

                    No events found.

                </td>

            </tr>

        `;

        return;

    }

    eventList.forEach(

        event => {

            const date =

                new Date(

                    event.event_date

                    + "T00:00:00"

                );

            const formattedDate =

                date.toLocaleDateString(

                    "en-MY",

                    {

                        day:

                            "numeric",

                        month:

                            "short",

                        year:

                            "numeric"

                    }

                );

            const row =

                document.createElement(

                    "tr"

                );

            row.innerHTML = `

                <td>

                    <div class="event-name">

                        <strong>

                            ${escapeHTML(

                                event.event_name

                            )}

                        </strong>

                        <span>

                            ${escapeHTML(

                                event.category

                            )}

                            •

                            ${escapeHTML(

                                event.organiser_name

                            )}

                        </span>

                    </div>

                </td>

                <td>

                    ${formattedDate}

                    <br>

                    <span

                        style="

                            color:#9995a4;

                            font-size:10px;

                        "

                    >

                        ${formatTime(

                            event.start_time

                        )}

                    </span>

                </td>

                <td>

                    ${escapeHTML(

                        event.venue_name

                    )}

                </td>

                <td>

                    ${Number(

                        event.available_tickets

                    ).toLocaleString()}

                    /

                    ${Number(

                        event.total_tickets

                    ).toLocaleString()}

                </td>

                <td>

                    RM

                    ${Number(

                        event.ticket_price

                    ).toFixed(2)}

                </td>

                <td>

                    <span

                        class="

                            status-pill

                            ${getStatusClass(

                                event.status

                            )}

                        "

                    >

                        ${escapeHTML(

                            event.status

                        )}

                    </span>

                </td>

                <td>

                    <div class="action-buttons">

                        <button

                            type="button"

                            class="edit-btn"

                            onclick="

                                editEvent(

                                    ${event.event_id}

                                )

                            "

                        >

                            Edit

                        </button>

                        <button

                            type="button"

                            class="delete-btn"

                            onclick="

                                askDelete(

                                    ${event.event_id}

                                )

                            "

                        >

                            Delete

                        </button>

                    </div>

                </td>

            `;

            eventTableBody.appendChild(

                row

            );

        }

    );

}

/* ==========================================

   STATISTICS

========================================== */

function updateStats() {

    const upcoming =

        events.filter(

            event =>

                event.status ===

                "Upcoming"

        ).length;

    const totalTickets =

        events.reduce(

            (

                total,

                event

            ) =>

                total +

                Number(

                    event.total_tickets

                ),

            0

        );

    const available =

        events.reduce(

            (

                total,

                event

            ) =>

                total +

                Number(

                    event.available_tickets

                ),

            0

        );

    document

        .getElementById(

            "totalEvents"

        )

        .textContent =

            events.length;

    document

        .getElementById(

            "upcomingEvents"

        )

        .textContent =

            upcoming;

    document

        .getElementById(

            "totalTickets"

        )

        .textContent =

            totalTickets

                .toLocaleString();

    document

        .getElementById(

            "availableTickets"

        )

        .textContent =

            available

                .toLocaleString();

}

/* ==========================================

   VENUE OPTIONS

========================================== */

function populateVenues(selectedVenueId = null) {
    const venueSelect = document.getElementById("venue");
    venueSelect.replaceChildren();

    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Select an available venue";
    venueSelect.appendChild(placeholder);

    const eligibleVenues = venues.filter(venue =>
        venue.status === "Available" ||
        (selectedVenueId !== null &&
         Number(venue.venue_id) === Number(selectedVenueId))
    );

    eligibleVenues.forEach(venue => {
        const option = document.createElement("option");
        option.value = venue.venue_id;

        const label = `${venue.venue_name} — ${venue.location} (Capacity: ${venue.capacity})`;
        const isUnavailable = venue.status !== "Available";
        option.textContent = isUnavailable
            ? `${label} — Currently unavailable (existing event only)`
            : label;
        venueSelect.appendChild(option);
    });

    if (selectedVenueId !== null) {
        venueSelect.value = String(selectedVenueId);
    } else {
        venueSelect.value = "";
    }

    if (eligibleVenues.length === 0) {
        placeholder.textContent = "No available venues — contact an Administrator";
    }
}

/* ==========================================

   CREATE EVENT

========================================== */

document

    .getElementById(

        "createEventButton"

    )

    .addEventListener(

        "click",

        openCreateModal

    );

function openCreateModal() {

    formMode =

        "create";

    eventForm.reset();

    // Remove any unavailable venue retained from a previous edit.
    populateVenues();

    document

        .getElementById(

            "eventId"

        )

        .value =

            "";

    document

        .getElementById(

            "modalEyebrow"

        )

        .textContent =

            "CREATE EVENT";

    document

        .getElementById(

            "modalTitle"

        )

        .textContent =

            "New Event";

    saveEventButton.textContent =

        "Create Event";

    clearFormMessage();

    eventModal.classList.add(

        "show"

    );

}

/* ==========================================

   EDIT EVENT

========================================== */

function editEvent(

    eventId

) {

    const event =

        events.find(

            item =>

                Number(

                    item.event_id

                )

                ===

                Number(eventId)

        );

    if (!event) {

        return;

    }

    formMode =

        "edit";

    document

        .getElementById(

            "eventId"

        )

        .value =

            event.event_id;

    document

        .getElementById(

            "eventName"

        )

        .value =

            event.event_name;

    document

        .getElementById(

            "category"

        )

        .value =

            event.category;

    // Existing events may keep their venue if Admin later marks it unavailable.
    populateVenues(event.venue_id);

    document

        .getElementById(

            "venue"

        )

        .value =

            event.venue_id;

    document

        .getElementById(

            "eventDate"

        )

        .value =

            event.event_date;

    document

        .getElementById(

            "startTime"

        )

        .value =

            event.start_time

                .substring(

                    0,

                    5

                );

    document

        .getElementById(

            "endTime"

        )

        .value =

            event.end_time

                .substring(

                    0,

                    5

                );

    document

        .getElementById(

            "ticketPrice"

        )

        .value =

            event.ticket_price;

    document

        .getElementById(

            "totalTicketCount"

        )

        .value =

            event.total_tickets;

    document

        .getElementById(

            "status"

        )

        .value =

            event.status;

    document

        .getElementById(

            "description"

        )

        .value =

            event.description || "";

    document

        .getElementById(

            "modalEyebrow"

        )

        .textContent =

            "EDIT EVENT";

    document

        .getElementById(

            "modalTitle"

        )

        .textContent =

            "Update Event";

    saveEventButton.textContent =

        "Save Changes";

    clearFormMessage();

    eventModal.classList.add(

        "show"

    );

}

/* ==========================================

   SAVE EVENT

========================================== */

eventForm.addEventListener(

    "submit",

    async function (

        event

    ) {

        event.preventDefault();

        const payload = {

            event_name:

                document

                    .getElementById(

                        "eventName"

                    )

                    .value

                    .trim(),

            category:

                document

                    .getElementById(

                        "category"

                    )

                    .value,

            venue_id:

                Number(

                    document

                        .getElementById(

                            "venue"

                        )

                        .value

                ),

            event_date:

                document

                    .getElementById(

                        "eventDate"

                    )

                    .value,

            start_time:

                document

                    .getElementById(

                        "startTime"

                    )

                    .value,

            end_time:

                document

                    .getElementById(

                        "endTime"

                    )

                    .value,

            ticket_price:

                Number(

                    document

                        .getElementById(

                            "ticketPrice"

                        )

                        .value

                ),

            total_tickets:

                Number(

                    document

                        .getElementById(

                            "totalTicketCount"

                        )

                        .value

                ),

            status:

                document

                    .getElementById(

                        "status"

                    )

                    .value,

            description:

                document

                    .getElementById(

                        "description"

                    )

                    .value

                    .trim()

        };

        if (

            formMode ===

            "edit"

        ) {

            payload.event_id =

                Number(

                    document

                        .getElementById(

                            "eventId"

                        )

                        .value

                );

        }

        saveEventButton.disabled =

            true;

        saveEventButton.textContent =

            formMode === "create"

            ?

            "Creating..."

            :

            "Saving...";

        try {

            const response =

                await fetch(

                    "api/events.php",

                    {

                        method:

                            formMode ===

                            "create"

                            ?

                            "POST"

                            :

                            "PUT",

                        headers: {

                            "Content-Type":

                                "application/json",

                            Authorization:

                                "Bearer "

                                + token

                        },

                        body:

                            JSON.stringify(

                                payload

                            )

                    }

                );

            const result =

                await response.json();

            if (

                response.status ===

                401

            ) {

                logout();

                return;

            }

            if (

                !response.ok ||

                result.status !==

                "success"

            ) {

                throw new Error(

                    result.message ||

                    "Unable to save event"

                );

            }

            showFormMessage(

                result.message,

                "success"

            );

            await loadEvents();

            setTimeout(

                function () {

                    eventModal

                        .classList

                        .remove(

                            "show"

                        );

                    showToast(

                        result.message,

                        "success"

                    );

                },

                650

            );

        } catch (error) {

            showFormMessage(

                error.message,

                "error"

            );

        } finally {

            saveEventButton.disabled =

                false;

            saveEventButton.textContent =

                formMode ===

                "create"

                ?

                "Create Event"

                :

                "Save Changes";

        }

    }

);

/* ==========================================

   DELETE EVENT

========================================== */

function askDelete(

    eventId

) {

    selectedDeleteId =

        eventId;

    const event =

        events.find(

            item =>

                Number(

                    item.event_id

                )

                ===

                Number(eventId)

        );

    document

        .getElementById(

            "deleteMessage"

        )

        .textContent =

            event

            ?

            'Delete "'

            +

            event.event_name

            +

            '"? Events with booking records cannot be deleted.'

            :

            "Delete this event?";

    deleteModal.classList.add(

        "show"

    );

}

document

    .getElementById(

        "confirmDeleteButton"

    )

    .addEventListener(

        "click",

        async function () {

            if (

                !selectedDeleteId

            ) {

                return;

            }

            this.disabled =

                true;

            this.textContent =

                "Deleting...";

            try {

                const response =

                    await fetch(

                        "api/events.php",

                        {

                            method:

                                "DELETE",

                            headers: {

                                "Content-Type":

                                    "application/json",

                                Authorization:

                                    "Bearer "

                                    + token

                            },

                            body:

                                JSON.stringify({

                                    event_id:

                                        selectedDeleteId

                                })

                        }

                    );

                const result =

                    await response.json();

                if (

                    !response.ok ||

                    result.status !==

                    "success"

                ) {

                    throw new Error(

                        result.message ||

                        "Unable to delete event"

                    );

                }

                deleteModal

                    .classList

                    .remove(

                        "show"

                    );

                selectedDeleteId =

                    null;

                await loadEvents();

                showToast(

                    result.message,

                    "success"

                );

            } catch (error) {

                deleteModal

                    .classList

                    .remove(

                        "show"

                    );

                showToast(

                    error.message,

                    "error"

                );

            } finally {

                this.disabled =

                    false;

                this.textContent =

                    "Delete Event";

            }

        }

    );

/* ==========================================

   SEARCH + FILTER

========================================== */

document

    .getElementById(

        "eventSearch"

    )

    .addEventListener(

        "input",

        filterEvents

    );

document

    .getElementById(

        "statusFilter"

    )

    .addEventListener(

        "change",

        filterEvents

    );

function filterEvents() {

    const search =

        document

            .getElementById(

                "eventSearch"

            )

            .value

            .toLowerCase();

    const status =

        document

            .getElementById(

                "statusFilter"

            )

            .value;

    const filtered =

        events.filter(

            event => {

                const searchable =

                    (

                        event.event_name

                        + " "

                        + event.venue_name

                        + " "

                        + event.organiser_name

                        + " "

                        + event.category

                    )

                    .toLowerCase();

                const searchMatch =

                    searchable.includes(

                        search

                    );

                const statusMatch =

                    status === ""

                    ||

                    event.status ===

                    status;

                return (

                    searchMatch &&

                    statusMatch

                );

            }

        );

    displayEvents(

        filtered

    );

}

/* ==========================================

   MODAL CONTROLS

========================================== */

function closeEventModal() {

    eventModal

        .classList

        .remove(

            "show"

        );

}

document

    .getElementById(

        "closeEventModal"

    )

    .addEventListener(

        "click",

        closeEventModal

    );

document

    .getElementById(

        "cancelEventModal"

    )

    .addEventListener(

        "click",

        closeEventModal

    );

document

    .getElementById(

        "keepEventButton"

    )

    .addEventListener(

        "click",

        function () {

            selectedDeleteId =

                null;

            deleteModal

                .classList

                .remove(

                    "show"

                );

        }

    );

/* ==========================================

   FORM MESSAGES

========================================== */

function clearFormMessage() {

    formMessage.className =

        "form-message";

    formMessage.textContent =

        "";

}

function showFormMessage(

    message,

    type

) {

    formMessage.textContent =

        message;

    formMessage.className =

        "form-message "

        + type;

}

/* ==========================================

   NAVBAR

========================================== */

function updateNavbar() {

    authNavigation.innerHTML = `

        <span

            style="

                color:#555263;

                font-size:13px;

                font-weight:700;

            "

        >

            ${escapeHTML(

                currentUser.name

            )}

            <small

                style="

                    color:#9995a4;

                    margin-left:4px;

                "

            >

                (${escapeHTML(

                    currentUser.role

                )})

            </small>

        </span>

        <button

            type="button"

            onclick="logout()"

            style="

                border:none;

                padding:11px 17px;

                border-radius:9px;

                background:#11101d;

                color:white;

                cursor:pointer;

                font-weight:700;

            "

        >

            Logout

        </button>

    `;

}

/* ==========================================

   LOGOUT

========================================== */

function logout() {

    localStorage.removeItem(

        "eventify_token"

    );

    localStorage.removeItem(

        "eventify_user"

    );

    window.location.href =

        "login.php";

}

/* ==========================================

   STATUS

========================================== */

function getStatusClass(status) {

    switch (status) {

        case "Upcoming":

            return "status-upcoming";

        case "Ongoing":

            return "status-ongoing";

        case "Completed":

            return "status-completed";

        case "Cancelled":

            return "status-cancelled";

        default:

            return "status-completed";

    }

}

/* ==========================================

   TIME

========================================== */

function formatTime(

    time

) {

    if (!time) {

        return "";

    }

    const pieces =

        time.split(":");

    const date =

        new Date();

    date.setHours(

        Number(

            pieces[0]

        )

    );

    date.setMinutes(

        Number(

            pieces[1]

        )

    );

    return date.toLocaleTimeString(

        "en-US",

        {

            hour:

                "numeric",

            minute:

                "2-digit"

        }

    );

}

/* ==========================================

   TOAST

========================================== */

function showToast(

    message,

    type

) {

    toast.textContent =

        message;

    toast.className =

        "toast "

        +

        type

        +

        " show";

    setTimeout(

        function () {

            toast

                .classList

                .remove(

                    "show"

                );

        },

        3500

    );

}

/* ==========================================

   ESCAPE HTML

========================================== */

function escapeHTML(

    value

) {

    return String(

        value ?? ""

    )

        .replaceAll(

            "&",

            "&amp;"

        )

        .replaceAll(

            "<",

            "&lt;"

        )

        .replaceAll(

            ">",

            "&gt;"

        )

        .replaceAll(

            '"',

            "&quot;"

        )

        .replaceAll(

            "'",

            "&#039;"

        );

}

/* ==========================================

   START

========================================== */

initialise();

</script>

</body>

</html>