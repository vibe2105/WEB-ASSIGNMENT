-- OPTIONAL SYNTHETIC FIXTURES ONLY; run against a fresh, EMPTY database after schema.sql.
-- These sample accounts have RANDOM UNDISCLOSED passwords and cannot be logged into.
-- Create a real local Administrator with tools/create_admin.php.
USE event_ticketing_db;
INSERT INTO users (user_id,name,email,password_hash,role) VALUES
(1,'Demo Admin','admin@example.test','$2y$12$I2iit.JfHjNTUg.UCNuSteOxQ9m1ep7YeZv5dba3NFZkegnhZ1/XG','Administrator'),
(2,'Demo Organiser One','organiser1@example.test','$2y$12$A5E8vGdze0ohsMsALdeHK.Awefob9E9lu3qblyKi41JqAPgAB5.Z.','Organiser'),
(3,'Demo Organiser Two','organiser2@example.test','$2y$12$cDqtoFgMKY2bdsIxIy7vgeZiPZthSHkTWM3clvlNMu3hJwpI1tLNa','Organiser'),
(4,'Demo Customer One','customer1@example.test','$2y$12$3WvF80TdePXlwZ25Hh1suuPHwQBXuaHXSQmQvIRCFSX8njucp2V7a','Customer'),
(5,'Demo Customer Two','customer2@example.test','$2y$12$dyBs0OnAK7A8OWZVF7f.GOzDlK9OE7WZ4xtMcnQY7Ur5s.xA4m0He','Customer');
INSERT INTO venues (venue_id,venue_name,location,capacity,status) VALUES
 (1,'Demo Conference Room','Kuala Lumpur',150,'Available'),
 (2,'Demo Community Hall','Petaling Jaya',200,'Available'),
 (3,'Demo Exhibition Centre','Cyberjaya',850,'Available'),
 (4,'Demo Outdoor Arena','Putrajaya',2000,'Available'),
 (5,'Demo Closed Hall','Shah Alam',100,'Unavailable');
INSERT INTO events
(event_id,organiser_id,venue_id,event_name,category,description,event_date,start_time,end_time,ticket_price,total_tickets,available_tickets,status) VALUES
 (1,2,1,'Demo Java Workshop','Workshop','Synthetic sample','2027-02-10','09:00:00','12:00:00',20.00,100,98,'Upcoming'),
 (2,2,2,'Demo Design Forum','Technology','Synthetic sample','2027-02-11','10:00:00','13:00:00',30.00,80,79,'Upcoming'),
 (3,3,3,'Demo Music Expo','Music','Synthetic sample','2027-02-12','16:00:00','20:00:00',50.00,100,98,'Upcoming'),
 (4,3,4,'Demo Food Festival','Food','Synthetic sample','2027-02-13','11:00:00','19:00:00',15.00,70,69,'Upcoming'),
 (5,2,1,'Demo Cybersecurity Talk','Technology','Synthetic sample','2027-02-14','14:00:00','17:00:00',0.00,60,60,'Upcoming');
INSERT INTO bookings (booking_id,user_id,event_id,quantity,total_amount,booking_status) VALUES
 (1,4,1,1,20.00,'Confirmed'),
 (2,5,1,1,20.00,'Confirmed'),
 (3,4,2,1,30.00,'Confirmed'),
 (4,5,3,2,100.00,'Confirmed'),
 (5,4,4,1,15.00,'Confirmed');
