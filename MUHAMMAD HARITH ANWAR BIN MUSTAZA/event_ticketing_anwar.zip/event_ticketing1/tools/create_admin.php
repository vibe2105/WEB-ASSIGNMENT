<?php
// CLI-only setup: php tools/create_admin.php
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
require_once __DIR__ . '/../config/database.php';
function ask($prompt) { fwrite(STDOUT, $prompt); return trim((string)fgets(STDIN)); }
$name=ask('Administrator full name: ');
$email=strtolower(ask('Administrator email: '));
$password=ask('Administrator password (visible as you type; use only locally): ');
if (strlen($name)<3 || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<12) {
    fwrite(STDERR,"Name >=3, valid email and password >=12 characters required.\n"); exit(1);
}
$db=(new Database())->getConnection();
if (!$db) { fwrite(STDERR,"Database not available.\n"); exit(1); }
try {
    $stmt=$db->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(:name,:email,:hash,'Administrator')");
    $stmt->execute([':name'=>$name, ':email'=>$email,
        ':hash'=>password_hash($password,PASSWORD_DEFAULT)]);
    fwrite(STDOUT,"Administrator account created. Log in through Eventify.\n");
} catch (PDOException $e) {
    fwrite(STDERR,"Unable to create administrator (email may already be used).\n"); exit(1);
}
