<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Discover, explore and book amazing events with Eventify.">
    <title>Eventify | Discover Experiences Worth Remembering</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Home-specific styles. Shared navbar and typography use css/style.css. */
        body { background: #f7f6fb; }
        .home-hero {
            position: relative;
            overflow: hidden;
            color: #fff;
            background:
                radial-gradient(ellipse at 83% 28%, rgba(117,89,255,.30), transparent 40%),
                linear-gradient(115deg, #11101d 4%, #1e173b 72%, #29204e);
        }
        .home-hero::before {
            content: "";
            position: absolute;
            inset: 0;
            opacity: .18;
            pointer-events: none;
            background-image: linear-gradient(rgba(255,255,255,.11) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,.11) 1px, transparent 1px);
            background-size: 76px 76px;
            mask-image: linear-gradient(90deg, #000, transparent 88%);
        }
        .home-hero-inner {
            position: relative;
            display: grid;
            grid-template-columns: 1.08fr .92fr;
            align-items: center;
            gap: 55px;
            padding-top: 112px;
            padding-bottom: 125px;
            min-height: 570px;
        }
        .home-tag {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 9px 15px;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 1.5px;
            color: #b3a6ff;
            border: 1px solid rgba(179,166,255,.24);
            border-radius: 999px;
            background: rgba(255,255,255,.06);
        }
        .home-hero h1 {
            font-size: clamp(44px, 5vw, 78px);
            font-weight: 850;
            letter-spacing: -2.7px;
            line-height: 1.08;
            margin: 25px 0 23px;
            max-width: 740px;
            color: white;
        }
        .home-hero h1 span { color: #a894ff; }
        .home-hero-intro {
            max-width: 540px;
            color: #bcb8d0;
            font-size: 15px;
            line-height: 1.8;
        }
        .home-hero-actions { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 32px; }
        .home-primary-button, .home-secondary-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            border-radius: 11px;
            padding: 15px 21px;
            font-size: 13px;
            font-weight: 800;
            transition: transform .2s, background .2s;
        }
        .home-primary-button { color: white; background: #7559ff; box-shadow: 0 12px 26px rgba(117,89,255,.23); }
        .home-secondary-button { color: #f0edff; background: rgba(255,255,255,.09); border: 1px solid rgba(255,255,255,.16); }
        .home-primary-button:hover, .home-secondary-button:hover { transform: translateY(-2px); }
        .home-primary-button:hover { background: #6348ea; }
        .home-hero-stats { display: flex; align-items: center; gap: 24px; margin-top: 45px; }
        .home-hero-stats strong { display: block; font-size: 25px; font-weight: 850; color: #fff; }
        .home-hero-stats small { color: #a8a3bb; font-size: 10px; }
        .home-stat-separator { height: 30px; width: 1px; background: rgba(255,255,255,.20); }
        .home-visual { position: relative; width: min(100%, 490px); margin-inline: auto; }
        .home-ticket {
            position: relative;
            isolation: isolate;
            padding: 28px;
            background: linear-gradient(145deg, #f7f4ff, #ffffff);
            border-radius: 22px;
            color: #242039;
            box-shadow: 0 32px 95px rgba(5,4,15,.36);
            transform: rotate(3deg);
        }
        .home-ticket-art {
            min-height: 215px;
            border-radius: 17px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            background: linear-gradient(135deg, #3e2b83, #7956fa 70%, #a990ff);
            color: #fff;
        }
        .home-ticket-art::before, .home-ticket-art::after {
            content: "";
            position: absolute;
            width: 270px;
            height: 270px;
            border: 1px solid rgba(255,255,255,.26);
            border-radius: 50%;
        }
        .home-ticket-art::before { transform: translate(-85px, 80px); }
        .home-ticket-art::after { transform: translate(115px, -100px); }
        .home-ticket-symbol { font-size: 90px; line-height: 1; font-weight: 850; color: #ede6ff; text-shadow: 0 16px 32px rgba(26,14,69,.2); }
        .home-ticket-live { display: inline-block; padding: 6px 11px; border-radius: 100px; background: #eeeaff; color: #6e4df3; font-size: 10px; font-weight: 800; margin-top: 20px; }
        .home-ticket h2 { margin: 12px 0 6px; font-size: 24px; letter-spacing: -.6px; color: #201e30; }
        .home-ticket p { color: #827c94; font-size: 12px; line-height: 1.5; }
        .home-ticket-bottom { border-top: 1px dashed #dbd5ed; margin-top: 24px; padding-top: 20px; display: flex; justify-content: space-between; align-items: center; }
        .home-ticket-bottom small { display: block; font-size: 9px; color: #8e879b; margin-bottom: 4px; }
        .home-ticket-bottom strong { font-size: 15px; color: #25223a; }
        .home-ticket-number { letter-spacing: 2px; font-size: 21px; font-weight: 800; color: #7559ff; }
        .home-floating {
            position: absolute;
            z-index: 2;
            padding: 13px 18px;
            background: #fff;
            color: #36304e;
            border: 1px solid #ece9f6;
            border-radius: 13px;
            font-size: 12px;
            font-weight: 800;
            box-shadow: 0 20px 42px rgba(0,0,0,.18);
        }
        .home-floating-left { left: -30px; top: 21%; transform: rotate(-8deg); }
        .home-floating-right { right: -30px; bottom: 18%; transform: rotate(-6deg); }
        .home-floating b { color: #7659ff; }
        .home-section { padding: 85px 0; }
        .home-section-heading { display: flex; justify-content: space-between; align-items: end; gap: 24px; margin-bottom: 30px; }
        .home-section-eyebrow { font-size: 10px; letter-spacing: 1.6px; font-weight: 850; color: #7559ff; text-transform: uppercase; }
        .home-section-heading h2 { margin: 10px 0 7px; font-size: clamp(26px, 3vw, 37px); letter-spacing: -1px; color: #171525; }
        .home-section-heading p { color: #89849a; font-size: 13px; }
        .home-view-link { font-size: 12px; color: #7559ff; font-weight: 800; white-space: nowrap; }
        .home-event-grid { display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 21px; }
        .home-event-card { display: block; overflow: hidden; border-radius: 17px; background: #fff; border: 1px solid #e9e5f0; box-shadow: 0 12px 38px rgba(35,24,70,.04); transition: transform .2s, box-shadow .2s; }
        .home-event-card:hover { transform: translateY(-4px); box-shadow: 0 19px 48px rgba(35,24,70,.10); }
        .home-event-banner { position: relative; height: 175px; display: grid; place-items: center; color: white; background: linear-gradient(130deg, #242044, #6952d8); overflow: hidden; }
        .home-event-banner::after { content: ""; position: absolute; width: 230px; height: 230px; right: -70px; top: -95px; border: 1px solid rgba(255,255,255,.19); border-radius: 50%; }
        .home-event-card:nth-child(3n+2) .home-event-banner { background: linear-gradient(130deg, #103b41, #1d9a8f); }
        .home-event-card:nth-child(3n+3) .home-event-banner { background: linear-gradient(130deg, #4c2045, #b44780); }
        .home-event-glyph { font-size: 55px; font-weight: 850; opacity: .84; }
        .home-event-date { position: absolute; z-index: 1; bottom: 12px; right: 13px; background: white; color: #252039; text-align: center; border-radius: 10px; min-width: 50px; padding: 7px 9px; }
        .home-event-date strong { display: block; font-size: 20px; }
        .home-event-date small { color: #7559ff; font-weight: 850; font-size: 9px; text-transform: uppercase; }
        .home-event-info { padding: 22px; }
        .home-event-category { font-size: 10px; font-weight: 800; color: #7559ff; letter-spacing: 1px; text-transform: uppercase; }
        .home-event-info h3 { font-size: 18px; letter-spacing: -.4px; margin: 10px 0 9px; color: #231e35; }
        .home-event-location { color: #8a8498; font-size: 12px; line-height: 1.6; }
        .home-event-foot { display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #f1eff6; margin-top: 18px; padding-top: 17px; }
        .home-event-foot strong { color: #261e3f; font-size: 14px; }
        .home-event-foot span { color: #7559ff; font-size: 11px; font-weight: 800; }
        .home-event-empty { grid-column: 1 / -1; padding: 45px; background: #fff; border: 1px solid #ebe8f1; border-radius: 16px; color: #77718a; text-align: center; }
        .home-how { background: #fff; border-top: 1px solid #f0edf5; border-bottom: 1px solid #f0edf5; }
        .home-steps { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: 20px; }
        .home-step { background: #faf9fe; border-radius: 16px; border: 1px solid #ece9f5; padding: 28px; }
        .home-step-number { display: grid; place-items: center; width: 48px; height: 48px; background: #ece8ff; color: #7559ff; border-radius: 12px; font-size: 15px; font-weight: 850; }
        .home-step h3 { margin: 23px 0 10px; font-size: 17px; }
        .home-step p { font-size: 12px; line-height: 1.7; color: #898399; }
        .home-cta-wrap { padding: 80px 0 95px; }
        .home-cta { display: flex; align-items: center; justify-content: space-between; gap: 25px; padding: 42px 48px; border-radius: 21px; background: linear-gradient(120deg,#171329,#302256); color: white; }
        .home-cta h2 { font-size: clamp(22px,3vw,33px); margin-bottom: 8px; color: #fff; }
        .home-cta p { color: #b8aecf; font-size: 13px; }
        .home-footer { padding: 26px 0; background: #fff; border-top: 1px solid #ece9f2; }
        .home-footer-inner { display: flex; justify-content: space-between; align-items: center; gap: 16px; font-size: 11px; color: #938ca0; }
        @media (max-width: 1050px) {
            .home-hero-inner { grid-template-columns: 1fr; padding-top: 80px; gap: 75px; }
            .home-visual { width: min(80%, 440px); }
            .home-event-grid { grid-template-columns: repeat(2,minmax(0,1fr)); }
        }
        @media (max-width: 680px) {
            .home-hero-inner { padding-top: 65px; padding-bottom: 80px; gap: 48px; }
            .home-hero h1 { letter-spacing: -1.4px; }
            .home-visual { width: 86%; }
            .home-ticket { padding: 17px; }
            .home-ticket-art { min-height: 150px; }
            .home-floating { display: none; }
            .home-hero-stats { gap: 17px; }
            .home-section { padding: 60px 0; }
            .home-section-heading { align-items: start; flex-direction: column; }
            .home-event-grid, .home-steps { grid-template-columns: 1fr; }
            .home-cta { flex-direction: column; align-items: flex-start; padding: 33px 26px; }
            .home-footer-inner { flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>
    <header class="navbar">
        <div class="container nav-container">
            <a href="index.php" class="brand" aria-label="Eventify homepage">
                <div class="brand-icon">E</div>
                <span>Event<span class="brand-purple">ify</span></span>
            </a>
            <nav class="nav-links" aria-label="Main navigation">
                <a href="index.php" class="active">Home</a>
                <a href="events.php">Events</a>
                <a href="bookings.php">My Bookings</a>
            </nav>
            <!-- auth.js replaces these guest links when a valid JWT exists. -->
            <div class="nav-actions" id="authNavigation">
                <a href="login.php" class="sign-in">Sign In</a>
                <a href="register.php" class="nav-button">Create Account</a>
            </div>
        </div>
    </header>

    <main>
        <section class="home-hero">
            <div class="container home-hero-inner">
                <div>
                    <div class="home-tag">✦ YOUR NEXT EXPERIENCE AWAITS</div>
                    <h1>Great moments.<br><span>Unforgettable experiences.</span></h1>
                    <p class="home-hero-intro">
                        Discover inspiring concerts, workshops, festivals and technology showcases.
                        Find the events you love and reserve your spot with Eventify.
                    </p>
                    <div class="home-hero-actions">
                        <a class="home-primary-button" href="events.php">Explore Events <span aria-hidden="true">→</span></a>
                        <a class="home-secondary-button" href="#how-it-works">How It Works</a>
                    </div>
                    <div class="home-hero-stats" aria-label="Eventify live totals">
                        <div><strong id="homeEventCount">—</strong><small>Events</small></div>
                        <div class="home-stat-separator"></div>
                        <div><strong id="homeVenueCount">—</strong><small>Venues</small></div>
                        <div class="home-stat-separator"></div>
                        <div><strong>24/7</strong><small>Event discovery</small></div>
                    </div>
                </div>
                <div class="home-visual" aria-hidden="true">
                    <div class="home-floating home-floating-left">✦ <b>Discover</b> something new</div>
                    <div class="home-ticket">
                        <div class="home-ticket-art"><div class="home-ticket-symbol">✦</div></div>
                        <div class="home-ticket-live">THE EVENTIFY EXPERIENCE</div>
                        <h2>Make your next memory.</h2>
                        <p>All your favourite moments, all in one place.</p>
                        <div class="home-ticket-bottom">
                            <div><small>YOUR NEXT ADVENTURE</small><strong>Starts here</strong></div>
                            <div class="home-ticket-number">E / 26</div>
                        </div>
                    </div>
                    <div class="home-floating home-floating-right">✓ <b>Easy</b> ticket booking</div>
                </div>
            </div>
        </section>

        <section class="home-section" id="featured-events">
            <div class="container">
                <div class="home-section-heading">
                    <div>
                        <span class="home-section-eyebrow">COMING UP NEXT</span>
                        <h2>Featured experiences</h2>
                        <p>Take a look at what's happening and find your next experience.</p>
                    </div>
                    <a class="home-view-link" href="events.php">View All Events →</a>
                </div>
                <div class="home-event-grid" id="homeFeaturedEvents" aria-live="polite">
                    <div class="home-event-empty">Loading upcoming events...</div>
                </div>
            </div>
        </section>

        <section class="home-section home-how" id="how-it-works">
            <div class="container">
                <div class="home-section-heading">
                    <div>
                        <span class="home-section-eyebrow">THREE SIMPLE STEPS</span>
                        <h2>Easy from start to finish</h2>
                        <p>Everything you need to find events and manage your reservations.</p>
                    </div>
                </div>
                <div class="home-steps">
                    <article class="home-step"><div class="home-step-number">01</div><h3>Discover</h3><p>Explore upcoming events and find one that matches your interests.</p></article>
                    <article class="home-step"><div class="home-step-number">02</div><h3>Book your spot</h3><p>Choose the event and reserve your tickets with your customer account.</p></article>
                    <article class="home-step"><div class="home-step-number">03</div><h3>Manage bookings</h3><p>View booking details and keep track of your reservations in one place.</p></article>
                </div>
            </div>
        </section>

        <section class="home-cta-wrap">
            <div class="container">
                <div class="home-cta">
                    <div><h2>Ready to make some memories?</h2><p>Explore what's on and find an experience worth remembering.</p></div>
                    <a class="home-primary-button" href="events.php">Browse Events →</a>
                </div>
            </div>
        </section>
    </main>

    <footer class="home-footer">
        <div class="container home-footer-inner">
            <span>© 2026 Eventify. Event Ticketing &amp; Venue Booking System.</span>
            <span>Made for extraordinary experiences.</span>
        </div>
    </footer>

    <script>
    (function () {
        const featuredContainer = document.getElementById('homeFeaturedEvents');

        function escapeHTML(value) {
            return String(value ?? '')
                .replaceAll('&', '&amp;')
                .replaceAll('<', '&lt;')
                .replaceAll('>', '&gt;')
                .replaceAll('"', '&quot;')
                .replaceAll("'", '&#039;');
        }

        function formatPrice(value) {
            const price = Number(value);
            return Number.isFinite(price) ? 'RM ' + price.toFixed(2) : 'Price unavailable';
        }

        function formatDate(isoDate) {
            const date = new Date(String(isoDate) + 'T00:00:00');
            if (Number.isNaN(date.getTime())) return { day: '—', month: 'DATE' };
            return {
                day: date.toLocaleDateString('en-MY', { day: '2-digit' }),
                month: date.toLocaleDateString('en-MY', { month: 'short' })
            };
        }

        function displayFeatured(events) {
            const today = new Date();
            const todayString = today.getFullYear() + '-' +
                String(today.getMonth() + 1).padStart(2, '0') + '-' +
                String(today.getDate()).padStart(2, '0');

            const upcoming = events
                .filter(event => event.status === 'Upcoming' && String(event.event_date) >= todayString)
                .sort((a, b) => (String(a.event_date) + String(a.start_time)).localeCompare(String(b.event_date) + String(b.start_time)))
                .slice(0, 3);

            if (!upcoming.length) {
                featuredContainer.innerHTML = '<div class="home-event-empty">No upcoming events are available right now. Please check back soon.</div>';
                return;
            }

            const glyphs = ['✦', '{ }', '♫'];
            featuredContainer.innerHTML = upcoming.map((event, index) => {
                const eventId = Number(event.event_id);
                const safeId = Number.isSafeInteger(eventId) && eventId > 0 ? eventId : 0;
                const date = formatDate(event.event_date);
                const venue = event.venue_name || 'Venue to be confirmed';
                return `
                    <a href="${safeId ? 'event-details.php?event_id=' + safeId : 'events.php'}" class="home-event-card">
                        <div class="home-event-banner">
                            <span class="home-event-glyph">${glyphs[index % glyphs.length]}</span>
                            <span class="home-event-date"><strong>${escapeHTML(date.day)}</strong><small>${escapeHTML(date.month)}</small></span>
                        </div>
                        <div class="home-event-info">
                            <span class="home-event-category">${escapeHTML(event.category || 'Event')}</span>
                            <h3>${escapeHTML(event.event_name)}</h3>
                            <p class="home-event-location">⌖ ${escapeHTML(venue)}${event.location ? ' · ' + escapeHTML(event.location) : ''}</p>
                            <div class="home-event-foot"><strong>${formatPrice(event.ticket_price)}</strong><span>View Event →</span></div>
                        </div>
                    </a>`;
            }).join('');
        }

        async function loadHomeData() {
            const results = await Promise.allSettled([
                fetch('api/events.php').then(async response => {
                    if (!response.ok) throw new Error('Events request failed');
                    return response.json();
                }),
                fetch('api/venues.php').then(async response => {
                    if (!response.ok) throw new Error('Venues request failed');
                    return response.json();
                })
            ]);

            const [eventsResult, venuesResult] = results;
            if (eventsResult.status === 'fulfilled' &&
                eventsResult.value.status === 'success' &&
                Array.isArray(eventsResult.value.data)) {
                const events = eventsResult.value.data;
                document.getElementById('homeEventCount').textContent = events.length;
                displayFeatured(events);
            } else {
                featuredContainer.innerHTML = '<div class="home-event-empty">Events could not be loaded. <a href="events.php">Visit the Events page →</a></div>';
            }

            if (venuesResult.status === 'fulfilled' &&
                venuesResult.value.status === 'success' &&
                Array.isArray(venuesResult.value.data)) {
                document.getElementById('homeVenueCount').textContent = venuesResult.value.data.length;
            }
        }

        loadHomeData().catch(() => {
            featuredContainer.innerHTML = '<div class="home-event-empty">Could not load events. Please try again later.</div>';
        });
    })();
    </script>
    <script src="js/auth.js"></script>
</body>
</html>
