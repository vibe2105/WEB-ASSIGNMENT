<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Manage Users | Eventify</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >


    <style>

        body {
            background: #f5f5fa;
        }


        /* ======================================
           HERO
        ====================================== */

        .users-hero {

            padding: 55px 0;

            color: white;

            background:
                radial-gradient(
                    circle at 82% 15%,
                    rgba(117,89,255,.28),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #11101d,
                    #211943
                );
        }


        .users-hero-content {

            display: flex;

            justify-content: space-between;

            align-items: end;

            gap: 25px;
        }


        .users-hero .eyebrow {
            color: #a997ff;
        }


        .users-hero h1 {

            margin-top: 8px;

            font-family:
                "Manrope",
                sans-serif;

            font-size: 48px;

            letter-spacing: -2px;
        }


        .users-hero p {

            margin-top: 9px;

            color: #aaa6b8;
        }


        .add-user-btn {

            padding: 14px 20px;

            border: none;

            border-radius: 11px;

            color: white;

            background: #7559ff;

            cursor: pointer;

            font-weight: 800;

            transition: .25s;
        }


        .add-user-btn:hover {

            transform: translateY(-2px);

            background: #6449e8;
        }


        /* ======================================
           CONTENT
        ====================================== */

        .users-section {

            padding: 45px 0 100px;
        }


        .user-stats {

            display: grid;

            grid-template-columns:
                repeat(4, 1fr);

            gap: 18px;

            margin-bottom: 30px;
        }


        .user-stat {

            padding: 22px;

            background: white;

            border:
                1px solid #e8e6ee;

            border-radius: 16px;

            box-shadow:
                0 12px 30px
                rgba(24,20,50,.035);
        }


        .user-stat span {

            color: #9995a4;

            font-size: 10px;

            font-weight: 700;

            text-transform: uppercase;

            letter-spacing: .8px;
        }


        .user-stat strong {

            display: block;

            margin-top: 7px;

            font-family:
                "Manrope",
                sans-serif;

            font-size: 28px;
        }


        /* ======================================
           TOOLBAR
        ====================================== */

        .user-toolbar {

            display: flex;

            gap: 12px;

            padding: 17px;

            margin-bottom: 22px;

            background: white;

            border:
                1px solid #e8e6ee;

            border-radius: 15px;
        }


        .user-toolbar input {

            flex: 1;

            height: 48px;

            padding: 0 15px;

            border:
                1px solid #e3e1e8;

            border-radius: 10px;

            outline: none;

            font-family: inherit;
        }


        .user-toolbar input:focus {
            border-color: #9987f4;
        }


        .user-toolbar select {

            min-width: 190px;

            height: 48px;

            padding: 0 13px;

            border:
                1px solid #e3e1e8;

            border-radius: 10px;

            background: white;
        }


        /* ======================================
           TABLE
        ====================================== */

        .users-table-card {

            overflow: hidden;

            background: white;

            border:
                1px solid #e8e6ee;

            border-radius: 18px;

            box-shadow:
                0 14px 35px
                rgba(24,20,50,.05);
        }


        .table-scroll {
            overflow-x: auto;
        }


        .users-table {

            width: 100%;

            min-width: 950px;

            border-collapse: collapse;
        }


        .users-table th {

            padding: 15px 18px;

            background: #f8f7fb;

            color: #918e9d;

            text-align: left;

            text-transform: uppercase;

            letter-spacing: .7px;

            font-size: 9px;

            border-bottom:
                1px solid #eceaf0;
        }


        .users-table td {

            padding: 18px;

            vertical-align: middle;

            border-bottom:
                1px solid #f0eef3;

            font-size: 12px;
        }


        .users-table tr:last-child td {
            border-bottom: none;
        }


        .user-cell {

            display: flex;

            align-items: center;

            gap: 12px;
        }


        .table-avatar {

            width: 40px;

            height: 40px;

            display: grid;

            place-items: center;

            flex-shrink: 0;

            border-radius: 11px;

            color: white;

            background:
                linear-gradient(
                    135deg,
                    #8166ff,
                    #6044dc
                );

            font-weight: 800;
        }


        .user-cell strong {

            display: block;

            color: #292633;

            font-size: 12px;
        }


        .user-cell span {

            display: block;

            margin-top: 4px;

            color: #9995a4;

            font-size: 10px;
        }


        /* ======================================
           ROLE
        ====================================== */

        .role-badge {

            display: inline-block;

            padding: 6px 10px;

            border-radius: 100px;

            font-size: 9px;

            font-weight: 800;
        }


        .role-admin {

            color: #6848d6;

            background: #eeeaff;
        }


        .role-organiser {

            color: #27689b;

            background: #eaf4fc;
        }


        .role-customer {

            color: #187a58;

            background: #eaf8f2;
        }


        /* ======================================
           ACTIONS
        ====================================== */

        .user-actions {

            display: flex;

            gap: 7px;
        }


        .edit-user-btn,
        .delete-user-btn {

            padding: 8px 11px;

            border: none;

            border-radius: 8px;

            cursor: pointer;

            font-size: 10px;

            font-weight: 800;
        }


        .edit-user-btn {

            color: #654be0;

            background: #eeeaff;
        }


        .delete-user-btn {

            color: #b64545;

            background: #fff0f0;
        }


        .empty-users {

            padding: 70px;

            text-align: center;

            color: #898595;
        }


        /* ======================================
           MODAL
        ====================================== */

        .modal-overlay {

            position: fixed;

            inset: 0;

            z-index: 5000;

            display: none;

            align-items: center;

            justify-content: center;

            padding: 20px;

            background:
                rgba(10,9,17,.7);

            backdrop-filter: blur(6px);
        }


        .modal-overlay.show {
            display: flex;
        }


        .user-modal {

            width: min(580px, 100%);

            max-height: 90vh;

            overflow-y: auto;

            background: white;

            border-radius: 22px;

            box-shadow:
                0 35px 90px
                rgba(0,0,0,.3);
        }


        .user-modal-header {

            padding: 25px 27px;

            display: flex;

            align-items: center;

            justify-content: space-between;

            border-bottom:
                1px solid #eeecf2;
        }


        .user-modal-header span {

            color: #7559ff;

            font-size: 10px;

            font-weight: 800;

            letter-spacing: 1.4px;
        }


        .user-modal-header h2 {

            margin-top: 5px;

            font-family:
                "Manrope",
                sans-serif;
        }


        .close-modal {

            width: 36px;

            height: 36px;

            border: none;

            border-radius: 9px;

            background: #f3f2f6;

            cursor: pointer;

            font-size: 18px;
        }


        .user-form {
            padding: 27px;
        }


        .form-group {
            margin-bottom: 18px;
        }


        .form-group label {

            display: block;

            margin-bottom: 7px;

            color: #4e4a59;

            font-size: 11px;

            font-weight: 700;
        }


        .form-group input,
        .form-group select {

            width: 100%;

            height: 49px;

            padding: 0 13px;

            border:
                1px solid #e2e0e8;

            border-radius: 10px;

            background: #fafafd;

            outline: none;

            font-family: inherit;
        }


        .form-group input:focus,
        .form-group select:focus {

            border-color: #9d8cf5;

            background: white;

            box-shadow:
                0 0 0 4px
                rgba(117,89,255,.07);
        }


        .password-note {

            margin-top: 6px;

            color: #9995a4;

            font-size: 10px;

            line-height: 1.5;
        }


        .form-message {

            display: none;

            margin-bottom: 17px;

            padding: 12px 14px;

            border-radius: 9px;

            font-size: 11px;
        }


        .form-message.error {

            display: block;

            color: #ae4141;

            background: #fff0f0;
        }


        .form-message.success {

            display: block;

            color: #187858;

            background: #edf9f4;
        }


        .form-actions {

            display: flex;

            justify-content: flex-end;

            gap: 10px;

            padding-top: 20px;

            border-top:
                1px solid #efedf3;
        }


        .cancel-btn,
        .save-user-btn {

            padding: 12px 18px;

            border: none;

            border-radius: 9px;

            cursor: pointer;

            font-weight: 700;
        }


        .cancel-btn {

            background: #f1f0f5;

            color: #5d5968;
        }


        .save-user-btn {

            color: white;

            background: #7559ff;
        }


        .save-user-btn:disabled {

            opacity: .6;

            cursor: not-allowed;
        }


        /* ======================================
           DELETE MODAL
        ====================================== */

        .delete-modal {

            width: min(420px, 100%);

            padding: 32px;

            text-align: center;

            background: white;

            border-radius: 20px;
        }


        .delete-icon {

            width: 58px;

            height: 58px;

            display: grid;

            place-items: center;

            margin: auto;

            border-radius: 50%;

            color: #b84545;

            background: #fff0f0;

            font-size: 24px;
        }


        .delete-modal h2 {

            margin-top: 17px;

            font-family:
                "Manrope",
                sans-serif;
        }


        .delete-modal p {

            margin-top: 9px;

            color: #807c8d;

            font-size: 12px;

            line-height: 1.6;
        }


        .delete-buttons {

            display: flex;

            gap: 10px;

            margin-top: 24px;
        }


        .delete-buttons button {

            flex: 1;

            padding: 12px;

            border: none;

            border-radius: 9px;

            cursor: pointer;

            font-weight: 700;
        }


        .confirm-delete {

            background: #c34848;

            color: white;
        }


        /* ======================================
           TOAST
        ====================================== */

        .toast {

            position: fixed;

            z-index: 7000;

            right: 25px;

            bottom: 25px;

            min-width: 280px;

            padding: 15px 19px;

            color: white;

            border-radius: 11px;

            opacity: 0;

            transform: translateY(80px);

            pointer-events: none;

            transition: .3s;

            font-size: 12px;

            box-shadow:
                0 18px 45px
                rgba(0,0,0,.2);
        }


        .toast.show {

            opacity: 1;

            transform: translateY(0);
        }


        .toast.success {
            background: #207b5c;
        }


        .toast.error {
            background: #b34343;
        }


        @media (max-width: 900px) {

            .user-stats {

                grid-template-columns:
                    repeat(2, 1fr);
            }


            .user-toolbar {

                flex-direction: column;
            }


            .user-toolbar input,
            .user-toolbar select {

                width: 100%;
            }

        }


        @media (max-width: 600px) {

            .users-hero-content {

                flex-direction: column;

                align-items: flex-start;
            }


            .user-stats {

                grid-template-columns: 1fr;
            }

        }

    </style>

</head>


<body>


<!-- NAVIGATION -->

<header class="navbar">

    <div class="container nav-container">

        <a
            href="index.php"
            class="brand"
        >

            <div class="brand-icon">
                E
            </div>

            <span>
                Event<span class="brand-purple">ify</span>
            </span>

        </a>


        <nav class="nav-links">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="manage-events.php">
                Events
            </a>

            <a href="manage-venues.php">
                Venues
            </a>

            <a href="manage-bookings.php">
                Bookings
            </a>

            <a
                href="manage-users.php"
                class="active"
            >
                Users
            </a>

        </nav>


        <div
            class="nav-actions"
            id="authNavigation"
        >
        </div>

    </div>

</header>



<!-- HERO -->

<section class="users-hero">

    <div
        class="
            container
            users-hero-content
        "
    >

        <div>

            <span class="eyebrow">
                ADMINISTRATION
            </span>

            <h1>
                Manage Users
            </h1>

            <p>
                Manage customer, organiser and
                administrator accounts.
            </p>

        </div>


        <button
            type="button"
            class="add-user-btn"
            id="addUserButton"
        >
            + Create User
        </button>

    </div>

</section>



<!-- CONTENT -->

<main class="users-section">

    <div class="container">


        <!-- STATS -->

        <section class="user-stats">


            <article class="user-stat">

                <span>
                    Total Users
                </span>

                <strong id="totalUsers">
                    0
                </strong>

            </article>


            <article class="user-stat">

                <span>
                    Customers
                </span>

                <strong id="customerCount">
                    0
                </strong>

            </article>


            <article class="user-stat">

                <span>
                    Organisers
                </span>

                <strong id="organiserCount">
                    0
                </strong>

            </article>


            <article class="user-stat">

                <span>
                    Administrators
                </span>

                <strong id="adminCount">
                    0
                </strong>

            </article>


        </section>



        <!-- TOOLBAR -->

        <section class="user-toolbar">


            <input
                type="text"
                id="userSearch"
                placeholder="Search name, email or user ID..."
            >


            <select id="roleFilter">

                <option value="">
                    All Roles
                </option>

                <option value="Administrator">
                    Administrator
                </option>

                <option value="Organiser">
                    Organiser
                </option>

                <option value="Customer">
                    Customer
                </option>

            </select>


        </section>



        <!-- TABLE -->

        <section class="users-table-card">

            <div class="table-scroll">

                <table class="users-table">


                    <thead>

                        <tr>

                            <th>
                                User
                            </th>

                            <th>
                                Role
                            </th>

                            <th>
                                Events
                            </th>

                            <th>
                                Bookings
                            </th>

                            <th>
                                Joined
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>


                    <tbody id="userTableBody">

                        <tr>

                            <td
                                colspan="6"
                                class="empty-users"
                            >
                                Loading users...
                            </td>

                        </tr>

                    </tbody>


                </table>

            </div>

        </section>


    </div>

</main>



<!-- CREATE / EDIT MODAL -->

<div
    class="modal-overlay"
    id="userModal"
>

    <div class="user-modal">


        <div class="user-modal-header">

            <div>

                <span id="modalEyebrow">
                    CREATE USER
                </span>

                <h2 id="modalTitle">
                    New User
                </h2>

            </div>


            <button
                type="button"
                class="close-modal"
                id="closeUserModal"
            >
                ×
            </button>

        </div>



        <form
            class="user-form"
            id="userForm"
        >


            <input
                type="hidden"
                id="userId"
            >


            <div
                class="form-message"
                id="formMessage"
            >
            </div>



            <div class="form-group">

                <label for="userName">
                    Full Name
                </label>

                <input
                    type="text"
                    id="userName"
                    placeholder="Enter full name"
                    required
                >

            </div>



            <div class="form-group">

                <label for="userEmail">
                    Email Address
                </label>

                <input
                    type="email"
                    id="userEmail"
                    placeholder="example@email.com"
                    required
                >

            </div>



            <div class="form-group">

                <label for="userRole">
                    Role
                </label>

                <select
                    id="userRole"
                    required
                >

                    <option value="Customer">
                        Customer
                    </option>

                    <option value="Organiser">
                        Organiser
                    </option>

                    <option value="Administrator">
                        Administrator
                    </option>

                </select>

            </div>



            <div class="form-group">

                <label for="userPassword">
                    Password
                </label>

                <input
                    type="password"
                    id="userPassword"
                    placeholder="Enter password"
                >

                <p
                    class="password-note"
                    id="passwordNote"
                >
                    Minimum 6 characters.
                </p>

            </div>



            <div class="form-actions">


                <button
                    type="button"
                    class="cancel-btn"
                    id="cancelUserButton"
                >
                    Cancel
                </button>


                <button
                    type="submit"
                    class="save-user-btn"
                    id="saveUserButton"
                >
                    Create User
                </button>


            </div>


        </form>


    </div>

</div>



<!-- DELETE MODAL -->

<div
    class="modal-overlay"
    id="deleteModal"
>

    <div class="delete-modal">


        <div class="delete-icon">
            !
        </div>


        <h2>
            Delete User?
        </h2>


        <p id="deleteText">

            This account will be permanently deleted.
        </p>


        <div class="delete-buttons">


            <button
                type="button"
                class="cancel-btn"
                id="keepUserButton"
            >
                Keep User
            </button>


            <button
                type="button"
                class="confirm-delete"
                id="confirmDeleteButton"
            >
                Delete User
            </button>


        </div>


    </div>

</div>



<div
    class="toast"
    id="toast"
>
</div>



<script>

/* ======================================
   VARIABLES
====================================== */

const token =
    localStorage.getItem(
        "eventify_token"
    );


let currentUser =
    null;


let users =
    [];


let formMode =
    "create";


let selectedDeleteId =
    null;



const userTableBody =
    document.getElementById(
        "userTableBody"
    );


const userModal =
    document.getElementById(
        "userModal"
    );


const deleteModal =
    document.getElementById(
        "deleteModal"
    );


const userForm =
    document.getElementById(
        "userForm"
    );


const formMessage =
    document.getElementById(
        "formMessage"
    );


const saveUserButton =
    document.getElementById(
        "saveUserButton"
    );


const toast =
    document.getElementById(
        "toast"
    );



/* ======================================
   INITIALISE
====================================== */

async function initialise() {


    if (!token) {

        window.location.href =
            "login.php";

        return;
    }


    try {


        const response =
            await fetch(
                "auth/me.php",
                {
                    headers: {

                        Authorization:
                            "Bearer "
                            + token

                    }
                }
            );


        const result =
            await response.json();


        if (
            !response.ok ||
            result.status !== "success"
        ) {

            logout();

            return;
        }


        currentUser =
            result.user;



        /* ADMIN ONLY */

        if (
            currentUser.role !==
            "Administrator"
        ) {

            alert(
                "Administrator access is required."
            );


            window.location.href =
                currentUser.role ===
                "Organiser"

                ?

                "dashboard.php"

                :

                "events.php";


            return;
        }


        updateNavbar();


        await loadUsers();


    } catch (error) {


        showToast(
            "Unable to load user management.",
            "error"
        );

    }

}



/* ======================================
   LOAD USERS
====================================== */

async function loadUsers() {


    const response =
        await fetch(
            "api/users.php",
            {
                headers: {

                    Authorization:
                        "Bearer "
                        + token

                }
            }
        );


    const result =
        await response.json();


    if (
        response.status === 401
    ) {

        logout();

        return;
    }


    if (
        !response.ok ||
        result.status !== "success"
    ) {

        throw new Error(
            result.message ||
            "Unable to load users"
        );
    }


    users =
        result.data;


    displayUsers(
        users
    );


    updateStatistics();

}



/* ======================================
   DISPLAY USERS
====================================== */

function displayUsers(
    userList
) {


    userTableBody.innerHTML =
        "";


    if (
        userList.length === 0
    ) {


        userTableBody.innerHTML = `

            <tr>

                <td
                    colspan="6"
                    class="empty-users"
                >

                    No users found.

                </td>

            </tr>

        `;


        return;
    }



    userList.forEach(
        user => {


            const initial =
                String(
                    user.name
                )
                .charAt(0)
                .toUpperCase();


            const joined =
                new Date(
                    String(
                        user.created_at
                    ).replace(
                        " ",
                        "T"
                    )
                );


            const joinedText =
                isNaN(
                    joined.getTime()
                )

                ?

                user.created_at

                :

                joined.toLocaleDateString(
                    "en-MY",
                    {
                        day: "numeric",
                        month: "short",
                        year: "numeric"
                    }
                );


            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>

                    <div class="user-cell">

                        <div class="table-avatar">

                            ${initial}

                        </div>


                        <div>

                            <strong>

                                ${escapeHTML(
                                    user.name
                                )}

                            </strong>

                            <span>

                                #${user.user_id}
                                •
                                ${escapeHTML(
                                    user.email
                                )}

                            </span>

                        </div>

                    </div>

                </td>


                <td>

                    <span
                        class="
                            role-badge
                            ${getRoleClass(
                                user.role
                            )}
                        "
                    >

                        ${escapeHTML(
                            user.role
                        )}

                    </span>

                </td>


                <td>

                    ${Number(
                        user.event_count
                    )}

                </td>


                <td>

                    ${Number(
                        user.booking_count
                    )}

                </td>


                <td>

                    ${joinedText}

                </td>


                <td>

                    <div class="user-actions">


                        <button
                            type="button"
                            class="edit-user-btn"
                            onclick="
                                editUser(
                                    ${user.user_id}
                                )
                            "
                        >

                            Edit

                        </button>


                        ${
                            Number(
                                user.user_id
                            )
                            !==
                            Number(
                                currentUser.user_id
                            )

                            ?

                            `

                            <button
                                type="button"
                                class="delete-user-btn"

                                onclick="
                                    askDelete(
                                        ${user.user_id}
                                    )
                                "
                            >

                                Delete

                            </button>

                            `

                            :

                            ""

                        }


                    </div>

                </td>

            `;


            userTableBody
                .appendChild(
                    row
                );

        }
    );

}



/* ======================================
   STATISTICS
====================================== */

function updateStatistics() {


    const customers =
        users.filter(
            user =>
                user.role ===
                "Customer"
        ).length;


    const organisers =
        users.filter(
            user =>
                user.role ===
                "Organiser"
        ).length;


    const administrators =
        users.filter(
            user =>
                user.role ===
                "Administrator"
        ).length;


    document
        .getElementById(
            "totalUsers"
        )
        .textContent =
            users.length;


    document
        .getElementById(
            "customerCount"
        )
        .textContent =
            customers;


    document
        .getElementById(
            "organiserCount"
        )
        .textContent =
            organisers;


    document
        .getElementById(
            "adminCount"
        )
        .textContent =
            administrators;

}



/* ======================================
   SEARCH
====================================== */

document
    .getElementById(
        "userSearch"
    )
    .addEventListener(
        "input",
        filterUsers
    );


document
    .getElementById(
        "roleFilter"
    )
    .addEventListener(
        "change",
        filterUsers
    );


function filterUsers() {


    const search =
        document
            .getElementById(
                "userSearch"
            )
            .value
            .toLowerCase();


    const role =
        document
            .getElementById(
                "roleFilter"
            )
            .value;


    const filtered =
        users.filter(
            user => {


                const text =
                    (
                        user.user_id
                        + " "
                        + user.name
                        + " "
                        + user.email
                    )
                    .toLowerCase();


                const searchMatch =
                    text.includes(
                        search
                    );


                const roleMatch =
                    role === ""
                    ||
                    user.role === role;


                return (
                    searchMatch &&
                    roleMatch
                );

            }
        );


    displayUsers(
        filtered
    );

}



/* ======================================
   CREATE USER
====================================== */

document
    .getElementById(
        "addUserButton"
    )
    .addEventListener(
        "click",
        openCreateUser
    );


function openCreateUser() {


    formMode =
        "create";


    userForm.reset();


    document
        .getElementById(
            "userId"
        )
        .value =
            "";


    document
        .getElementById(
            "modalEyebrow"
        )
        .textContent =
            "CREATE USER";


    document
        .getElementById(
            "modalTitle"
        )
        .textContent =
            "New User";


    document
        .getElementById(
            "passwordNote"
        )
        .textContent =
            "Password is required. Minimum 6 characters.";


    document
        .getElementById(
            "userPassword"
        )
        .required =
            true;


    saveUserButton.textContent =
        "Create User";


    clearMessage();


    userModal.classList.add(
        "show"
    );

}



/* ======================================
   EDIT USER
====================================== */

function editUser(
    userId
) {


    const user =
        users.find(
            item =>
                Number(
                    item.user_id
                )
                ===
                Number(userId)
        );


    if (!user) {

        return;
    }


    formMode =
        "edit";


    document
        .getElementById(
            "userId"
        )
        .value =
            user.user_id;


    document
        .getElementById(
            "userName"
        )
        .value =
            user.name;


    document
        .getElementById(
            "userEmail"
        )
        .value =
            user.email;


    document
        .getElementById(
            "userRole"
        )
        .value =
            user.role;


    document
        .getElementById(
            "userPassword"
        )
        .value =
            "";


    document
        .getElementById(
            "userPassword"
        )
        .required =
            false;


    document
        .getElementById(
            "passwordNote"
        )
        .textContent =
            "Leave blank to keep the existing password. Enter at least 6 characters to reset it.";


    document
        .getElementById(
            "modalEyebrow"
        )
        .textContent =
            "EDIT USER";


    document
        .getElementById(
            "modalTitle"
        )
        .textContent =
            "Update User";


    saveUserButton.textContent =
        "Save Changes";


    clearMessage();


    userModal.classList.add(
        "show"
    );

}



/* ======================================
   SAVE USER
====================================== */

userForm.addEventListener(
    "submit",
    async function (
        event
    ) {


        event.preventDefault();


        const password =
            document
                .getElementById(
                    "userPassword"
                )
                .value;


        const payload = {

            name:
                document
                    .getElementById(
                        "userName"
                    )
                    .value
                    .trim(),

            email:
                document
                    .getElementById(
                        "userEmail"
                    )
                    .value
                    .trim(),

            role:
                document
                    .getElementById(
                        "userRole"
                    )
                    .value,

            password:
                password

        };


        if (
            formMode === "edit"
        ) {

            payload.user_id =
                Number(
                    document
                        .getElementById(
                            "userId"
                        )
                        .value
                );

        }


        if (
            formMode === "create"
            &&
            password.length < 6
        ) {

            showMessage(
                "Password must contain at least 6 characters.",
                "error"
            );

            return;
        }


        if (
            formMode === "edit"
            &&
            password !== ""
            &&
            password.length < 6
        ) {

            showMessage(
                "New password must contain at least 6 characters.",
                "error"
            );

            return;
        }


        saveUserButton.disabled =
            true;


        saveUserButton.textContent =
            formMode === "create"
            ?
            "Creating..."
            :
            "Saving...";


        try {


            const response =
                await fetch(
                    "api/users.php",
                    {

                        method:
                            formMode ===
                            "create"
                            ?
                            "POST"
                            :
                            "PUT",

                        headers: {

                            "Content-Type":
                                "application/json",

                            Authorization:
                                "Bearer "
                                + token

                        },

                        body:
                            JSON.stringify(
                                payload
                            )

                    }
                );


            const result =
                await response.json();


            if (
                response.status === 401
            ) {

                logout();

                return;
            }


            if (
                !response.ok ||
                result.status !==
                "success"
            ) {

                throw new Error(
                    result.message ||
                    "Unable to save user"
                );

            }


            showMessage(
                result.message,
                "success"
            );


            await loadUsers();


            setTimeout(
                function () {


                    userModal.classList.remove(
                        "show"
                    );


                    showToast(
                        result.message,
                        "success"
                    );


                },
                600
            );


        } catch (error) {


            showMessage(
                error.message,
                "error"
            );


        } finally {


            saveUserButton.disabled =
                false;


            saveUserButton.textContent =
                formMode === "create"
                ?
                "Create User"
                :
                "Save Changes";

        }

    }
);



/* ======================================
   DELETE
====================================== */

function askDelete(
    userId
) {


    selectedDeleteId =
        userId;


    const user =
        users.find(
            item =>
                Number(
                    item.user_id
                )
                ===
                Number(userId)
        );


    document
        .getElementById(
            "deleteText"
        )
        .textContent =

            user

            ?

            'Delete "'
            +
            user.name
            +
            '"? Accounts linked to events or bookings cannot be deleted.'

            :

            "Delete this user?";


    deleteModal.classList.add(
        "show"
    );

}



document
    .getElementById(
        "confirmDeleteButton"
    )
    .addEventListener(
        "click",
        async function () {


            if (
                !selectedDeleteId
            ) {

                return;
            }


            this.disabled =
                true;


            this.textContent =
                "Deleting...";


            try {


                const response =
                    await fetch(
                        "api/users.php",
                        {

                            method:
                                "DELETE",

                            headers: {

                                "Content-Type":
                                    "application/json",

                                Authorization:
                                    "Bearer "
                                    + token

                            },

                            body:
                                JSON.stringify({

                                    user_id:
                                        selectedDeleteId

                                })

                        }
                    );


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    "success"
                ) {

                    throw new Error(
                        result.message ||
                        "Unable to delete user"
                    );

                }


                deleteModal.classList.remove(
                    "show"
                );


                selectedDeleteId =
                    null;


                await loadUsers();


                showToast(
                    result.message,
                    "success"
                );


            } catch (error) {


                deleteModal.classList.remove(
                    "show"
                );


                showToast(
                    error.message,
                    "error"
                );


            } finally {


                this.disabled =
                    false;


                this.textContent =
                    "Delete User";

            }

        }
    );



/* ======================================
   MODALS
====================================== */

function closeUserModal() {


    userModal.classList.remove(
        "show"
    );

}



document
    .getElementById(
        "closeUserModal"
    )
    .addEventListener(
        "click",
        closeUserModal
    );


document
    .getElementById(
        "cancelUserButton"
    )
    .addEventListener(
        "click",
        closeUserModal
    );


document
    .getElementById(
        "keepUserButton"
    )
    .addEventListener(
        "click",
        function () {


            selectedDeleteId =
                null;


            deleteModal.classList.remove(
                "show"
            );

        }
    );



/* ======================================
   MESSAGES
====================================== */

function clearMessage() {


    formMessage.className =
        "form-message";


    formMessage.textContent =
        "";

}



function showMessage(
    message,
    type
) {


    formMessage.textContent =
        message;


    formMessage.className =
        "form-message "
        + type;

}



/* ======================================
   ROLE CLASS
====================================== */

function getRoleClass(
    role
) {


    if (
        role === "Administrator"
    ) {

        return "role-admin";
    }


    if (
        role === "Organiser"
    ) {

        return "role-organiser";
    }


    return "role-customer";

}



/* ======================================
   NAVBAR
====================================== */

function updateNavbar() {


    document
        .getElementById(
            "authNavigation"
        )
        .innerHTML = `

            <span
                style="
                    color:#555263;
                    font-size:13px;
                    font-weight:700;
                "
            >

                ${escapeHTML(
                    currentUser.name
                )}

                <small
                    style="
                        color:#9995a4;
                    "
                >

                    (Administrator)

                </small>

            </span>


            <button
                type="button"
                onclick="logout()"

                style="
                    border:none;
                    padding:11px 17px;
                    border-radius:9px;
                    background:#11101d;
                    color:white;
                    cursor:pointer;
                    font-weight:700;
                "
            >

                Logout

            </button>

        `;

}



/* ======================================
   LOGOUT
====================================== */

function logout() {


    localStorage.removeItem(
        "eventify_token"
    );


    localStorage.removeItem(
        "eventify_user"
    );


    window.location.href =
        "login.php";

}



/* ======================================
   TOAST
====================================== */

function showToast(
    message,
    type
) {


    toast.textContent =
        message;


    toast.className =
        "toast "
        + type
        + " show";


    setTimeout(
        function () {


            toast.classList.remove(
                "show"
            );


        },
        3500
    );

}



/* ======================================
   ESCAPE
====================================== */

function escapeHTML(
    value
) {


    return String(
        value ?? ""
    )

        .replaceAll("&", "&amp;")

        .replaceAll("<", "&lt;")

        .replaceAll(">", "&gt;")

        .replaceAll('"', "&quot;")

        .replaceAll("'", "&#039;");

}



/* ======================================
   START
====================================== */

initialise();

</script>


</body>

</html>