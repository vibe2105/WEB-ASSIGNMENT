# Automated checks completed on packaged code

- PHP syntax checks: 32 PHP files; all passed `php -l`.
- Standalone JS and frontend embedded JS: all passed `node --check`.
- JWT smoke tests: create, verify, reject tampered token; passed with temporary test-only environment secrets.
- Query-validation helper tests: accepted valid text/int, rejected array and negative integer; passed.
- Postman v2.1 JSON: parsed and request URLs checked; 37+ requests available.
- Package excludes real SQL data, local passwords and actual JWT/Ticket signing keys.

**Not tested**: end-to-end MySQL behaviour, live browser login/book/cancel, remote QR provider response or live API status codes. Your team must run XAMPP and Postman to verify all of these.
