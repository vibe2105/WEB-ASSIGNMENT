# Eventify — Updated Team Handoff (14 October 2026)

## Changed and added

- `config/settings.php`, `config/local.example.php`, `config/database.php`, `config/jwt.php`: secret-key configuration and safe DB errors. Old JWT key removed from source. **Three separate keys required** (JWT, ticket, internal metrics).
- `config/.htaccess`, `.gitignore`: protect and avoid committing local configuration.
- `middleware/auth.php`: re-check current MySQL user and role for every verified JWT.
- `middleware/api.php`, `middleware/validation.php`, `middleware/apikey.php`: shared exception handler, request logging, query/body validators, internal key protection.
- `api/events.php`: optional search/category/status filtering, sort, pagination (backwards compatible); checks venue capacity, availability, schedule overlap, organiser ownership, malformed event fields.
- `api/users.php`, `api/venues.php`: malformed field handling tightened.
- `api/status.php`: now returns valid JSON health response.
- `api/ticket-qr.php`: JWT-protected access to genuine remote goQR.me PNG API for confirmed bookings.
- `api/verify-ticket.php`: staff-side signature, owner, and booking-status verification (not an attendance/check-in feature).
- `api/system-metrics.php`: Administrator JWT + `X-API-Key` required for internal counts.
- `bookings.php`: View QR Ticket action for Confirmed bookings.
- Removed duplicate, unused root `/auth.js`; public pages use `/js/auth.js`.
- `database/schema.sql`, `database/sample_data.sql`, `database/ERD.mmd`: **synthetic reference** schema, sample data and Mermaid ERD. NOT exported real XAMPP DB.
- `tools/create_admin.php`, `README.md`, `docs/*`, `postman/Eventify.postman_collection.json`: setup, documentation, tests, team checklist.

## Completed static checks

- PHP syntax: all PHP source files passed `php -l`.
- Embedded and standalone JavaScript syntax passed Node `--check`.
- JWT signing/verification and tamper rejection smoke test passed with temporary test keys.
- Validation helper checks passed on valid and invalid input.
- Postman collection parsed as JSON and its URL structures were checked.

## Must be done by your team

1. **Back up** existing files and database BEFORE replacing.
2. Copy `config/local.example.php` to `config/local.php`, generate **three different** strong keys and configure database credentials. Do not put local.php in your GitHub repo.
3. Import or export **the real existing XAMPP MySQL database**. Reference schema/sample SQL should be used **only on a clean separate DB**.
4. Log out/login again (JWT secret change invalidates existing tokens).
5. Perform full live role/CRUD/venue overlap/booking + stock tests in XAMPP.
6. Confirm PHP cURL, CA certificate and network access, then test actual remote QR PNG and its verification.
7. Fill in real Postman screenshots/results and your group's ERD, contribution report and demonstration video.
8. Separate test data from the final database; clean up any Postman test-created records on the test DB.

**No live database or external API tests were performed here.** This is an improved **development handoff build**, not a verified production release or completed university submission.
