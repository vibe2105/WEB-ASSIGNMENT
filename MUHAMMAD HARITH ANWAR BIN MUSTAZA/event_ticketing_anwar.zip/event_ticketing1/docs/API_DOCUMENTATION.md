# Eventify REST API Documentation (team handoff)

Base URL in local XAMPP: `http://localhost/event_ticketing1`. All standard APIs return JSON with `status: "success"` or `status: "error"`. Set `Content-Type: application/json` for JSON requests. Protected requests: `Authorization: Bearer <JWT>`.

| Endpoint | HTTP | Access | Request | Success | Typical errors |
|---|---|---|---|---|---|
| `auth/register.php` | POST | Guest | `name,email,password,confirm_password` | 201, Customer info | 400,409,500 |
| `auth/login.php` | POST | Guest | `email,password` | 200, JWT `token`, user | 400,401,500 |
| `auth/me.php` | GET | Any signed-in | JWT | 200, current user and role | 401,503 |
| `api/status.php` | GET | Public | none | 200, API running | 405 |
| `api/system-metrics.php` | GET | Administrator JWT **and** `X-API-Key: <internal key>` | none | 200, counts of users/events/venues/bookings | 401,403,405,503 |
| `api/users.php` | GET | Administrator | optional `?user_id=N` | 200, user(s), counts | 401,403,404 |
| `api/users.php` | POST | Administrator | `name,email,password,role` | 201, user created | 400,401,403,409 |
| `api/users.php` | PUT | Administrator | `user_id,name,email,role,password` (password optional) | 200 | 400,401,403,404,409 |
| `api/users.php` | DELETE | Administrator | `user_id` | 200 | 401,403,404,409 |
| `api/venues.php` | GET | Public | optional `?venue_id=N` | 200, venue(s) | 404 |
| `api/venues.php` | POST | Administrator | `venue_name,location,capacity,status` | 201, `venue_id` | 400,401,403,409 |
| `api/venues.php` | PUT | Administrator | `venue_id,venue_name,location,capacity,status` | 200 | 400,401,403,404,409 |
| `api/venues.php` | DELETE | Administrator | `venue_id` | 200 | 401,403,404,409 |
| `api/events.php` | GET | Public | `?event_id=N` OR list `?search=&category=&status=&page=&limit=&sort=&order=` | 200, event(s), optional pagination | 400,404 |
| `api/events.php` | POST | Administrator or Organiser | fields below | 201, `event_id` | 400,401,403 |
| `api/events.php` | PUT | Administrator or event-owning Organiser | `event_id` + fields below | 200 | 400,401,403,404 |
| `api/events.php` | DELETE | Administrator or event-owning Organiser | `event_id` | 200 | 401,403,404,409 |
| `api/bookings.php` | GET | Signed-in | optional `?booking_id=N` | 200, bookings authorized for role | 401,403,404 |
| `api/bookings.php` | POST | Customer | `event_id,quantity` | 201, booking details | 400,401,403,404,409 |
| `api/bookings.php` | PUT | Administrator / event-owning Organiser | `booking_id,booking_status` | 200 | 400,401,403,404,409 |
| `api/bookings.php` | DELETE | Customer own or permitted staff | `booking_id` | 200 (soft cancel) | 400,401,403,404,409 |
| `api/ticket-qr.php` | GET | Booking-owning Customer, owning Organiser or Administrator | `?booking_id=N`, JWT | 200, binary `image/png` from external API | 400,401,403,404,409,502,503 |
| `api/verify-ticket.php` | POST | Administrator / owning Organiser | `ticket_code` string | 200, `valid:true/false` + summary | 400,401,403,404 |

**Events request fields:** `event_name`, `category`, `venue_id`, `description` (optional), `event_date` (`YYYY-MM-DD`), `start_time` (`HH:MM:SS`), `end_time` (`HH:MM:SS`), `ticket_price` (>=0), `total_tickets` (>0), `status` (`Upcoming|Ongoing|Completed|Cancelled`). `organiser_id` is derived from JWT for creation; it must **not** be chosen by the client. Venue must be available for new assignments, within capacity, and not time-overlapping.

**Event list:** `search` searches event name, description and venue name; `category` and `status` filter exact values; `sort=event_date|event_name|ticket_price`, `order=asc|desc`; `page` and/or `limit` enables pagination (`limit` 1–100). Without page/limit, full list is returned to retain frontend compatibility. `total` is the filtered total and paged calls have `{pagination:{page,limit,total_pages}}`.

### Example create event
```http
POST /event_ticketing1/api/events.php
Authorization: Bearer <organiser-token>
Content-Type: application/json
```
```json
{"event_name":"Team API Demo","category":"Workshop","venue_id":1,"description":"Sample","event_date":"2027-03-25","start_time":"09:00:00","end_time":"12:00:00","ticket_price":20,"total_tickets":30,"status":"Upcoming"}
```
201 example: `{"status":"success","message":"Event created successfully","event_id":"13"}` (ID varies).
400 example: `{"status":"error","message":"Selected venue is unavailable. Choose an available venue"}`.
403 example: `{"status":"error","message":"You do not have permission to access this resource"}`.

### Example filtered events
`GET /event_ticketing1/api/events.php?search=concert&category=Music&page=1&limit=5`
```json
{"status":"success","total":1,"data":[{"event_id":1,"event_name":"Example Concert"}],"pagination":{"page":1,"limit":5,"total_pages":1}}
```
The example is illustrative, not a captured live response. The real API returns full event record fields.

### QR Code external API details

- Eventify calls goQR.me QR Code API server-side: `GET https://api.qrserver.com/v1/create-qr-code/?data=<URL-encoded signed ticket code>&size=240x240&format=png&qzone=4`.
- It returns **PNG image bytes**, not JSON. Eventify proxies these as `image/png` after checking JWT, ownership, confirmed status and PNG response.
- The code format is `EVF1|booking_id|24-hex-HMAC` signed with `EVENTIFY_TICKET_SECRET`. No name, email, password or bearer token is sent to the provider.
- Staff can decode the QR with a camera/scanner and submit its text to `POST /api/verify-ticket.php` using `{"ticket_code":"EVF1|...|..."}`. The server checks signature, current booking status and Organiser ownership. A confirmed ticket returns `valid:true`, cancelled returns `valid:false`.
- **No live third-party response has been captured by ChatGPT.** Your team must test it on a machine with internet access and include actual request/image screenshots in the report.
- Third-party provider documentation: https://goqr.me/api/doc/create-qr-code/

### Error conventions

400 invalid input; 401 no/expired JWT; 403 wrong role/owner; 404 missing record; 405 method not supported; 409 business-rule conflict; 500 internal server error; 502 remote QR provider failure; 503 service/config unavailable.

**Documentation note:** Verify exact success response examples and any role-specific business rules with your team's exported Postman tests before final submission. No test results are invented here.

### API key protection

For internal metrics only: `GET /api/system-metrics.php` requires both `Authorization: Bearer <admin-JWT>` and `X-API-Key: <EVENTIFY_INTERNAL_API_KEY>`. Use a third generated secret distinct from JWT/ticket signing keys; store it only in private settings. Never publish keys, even in screenshots.
