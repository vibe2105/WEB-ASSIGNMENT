<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Discover Events | Eventify</title>

    <link rel="stylesheet" href="css/style.css">
</head>


<body>


<!-- ================================
     NAVIGATION
================================ -->

<header class="navbar">

    <div class="container nav-container">

        <a href="index.php" class="brand">

            <div class="brand-icon">
                E
            </div>

            <span>
                Event<span class="brand-purple">ify</span>
            </span>

        </a>


        <nav class="nav-links">

            <a href="index.php">
                Home
            </a>

            <a href="events.php" class="active">
                Events
            </a>

            <a href="bookings.php">
                My Bookings
            </a>

        </nav>


        <div class="nav-actions" id="authNavigation">

            <a href="login.php" class="sign-in">
                Sign In
            </a>

            <a href="register.php" class="nav-button">
                Create Account
            </a>

        </div>

    </div>

</header>



<!-- ================================
     HERO
================================ -->

<section class="events-hero">

    <div class="hero-glow glow-one"></div>

    <div class="hero-glow glow-two"></div>


    <div class="container events-hero-content">

        <div class="hero-badge">

            ✦ CURATED EXPERIENCES

        </div>


        <h1>

            Find something

            <span>
                worth remembering.
            </span>

        </h1>


        <p>

            Concerts, workshops, technology showcases
            and unforgettable experiences — all in one place.

        </p>


        <div class="hero-stats">

            <div>

                <strong>
                    50+
                </strong>

                <span>
                    Events
                </span>

            </div>


            <div class="stat-line"></div>


            <div>

                <strong>
                    20+
                </strong>

                <span>
                    Venues
                </span>

            </div>


            <div class="stat-line"></div>


            <div>

                <strong>
                    1K+
                </strong>

                <span>
                    Bookings
                </span>

            </div>

        </div>

    </div>

</section>



<!-- ================================
     EVENTS
================================ -->

<main class="events-main">

    <div class="container">


        <!-- SEARCH PANEL -->

        <div class="search-panel">


            <div class="search-input-wrapper">

                <span class="search-icon">
                    ⌕
                </span>


                <input
                    type="text"
                    id="searchInput"
                    placeholder="Search events, venues or experiences..."
                >

            </div>



            <select id="categoryFilter">

                <option value="">
                    All Categories
                </option>

                <option value="Technology">
                    Technology
                </option>

                <option value="Workshop">
                    Workshop
                </option>

                <option value="Music">
                    Music
                </option>

                <option value="Seminar">
                    Seminar
                </option>

                <option value="Food">
                    Food
                </option>

            </select>



            <button
                type="button"
                class="search-button"
                id="searchButton"
            >

                Search Events

            </button>


        </div>



        <!-- EVENTS HEADING -->

        <div class="events-heading">


            <div>

                <span class="eyebrow">
                    UPCOMING
                </span>


                <h2>
                    Events made for you
                </h2>


                <p>
                    Discover what's happening and secure your spot.
                </p>

            </div>



            <div class="event-count">

                <span id="eventCount">
                    0
                </span>

                Events Available

            </div>


        </div>



        <!-- EVENTS LOADED FROM API -->

        <div
            class="event-grid"
            id="eventGrid"
        >

            <div class="loading-events">

                Loading amazing events...

            </div>

        </div>


    </div>

</main>



<!-- ================================
     CALL TO ACTION
================================ -->

<section class="events-cta">

    <div class="container">

        <div class="cta-box">


            <div>

                <span class="eyebrow">
                    CREATE MEMORIES
                </span>


                <h2>
                    Your next experience starts here.
                </h2>


                <p>
                    Create your account and start booking today.
                </p>

            </div>


            <a
                href="register.php"
                class="cta-button"
            >

                Get Started →

            </a>


        </div>

    </div>

</section>



<!-- ================================
     FOOTER
================================ -->

<footer class="footer">

    <div class="container footer-content">


        <a
            href="index.php"
            class="brand footer-brand"
        >

            <div class="brand-icon">
                E
            </div>


            <span>

                Event<span class="brand-purple">ify</span>

            </span>

        </a>



        <p>
            Event Ticketing & Venue Booking System
        </p>


        <p class="copyright">
            © 2026 Eventify
        </p>


    </div>

</footer>



<script src="js/app.js"></script>
<script src="js/auth.js"></script>


</body>

</html>