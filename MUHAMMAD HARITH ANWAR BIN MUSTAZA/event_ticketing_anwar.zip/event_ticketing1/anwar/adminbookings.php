<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Manage Bookings - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }


        .bookings-shell {
            width: min(1180px, 92%);
            margin: 0 auto;
            flex: 1;
        }


        /*
        ========================================
        PAGE HEADER
        ========================================
        */

        .bookings-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 18px;
            flex-wrap: wrap;

            margin-bottom: 14px;
        }


        .bookings-page-header-text h2 {
            margin: 0 0 4px 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 17px;
            font-weight: 800;

            color: #ffffff;
        }


        .bookings-page-header-text p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.5;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        /*
        ========================================
        BOOKING COUNT
        ========================================
        */

        .bookings-count-card {
            display: flex;
            align-items: center;

            gap: 10px;

            min-width: 120px;

            padding: 10px 13px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.22
                );

            border-radius: 8px;

            background:
                linear-gradient(
                    135deg,
                    rgba(
                        91,
                        42,
                        134,
                        0.23
                    ),
                    rgba(
                        176,
                        68,
                        158,
                        0.10
                    )
                );
        }


        .bookings-count-icon {
            width: 30px;
            height: 30px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 7px;

            background:
                rgba(
                    224,
                    107,
                    174,
                    0.10
                );

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .bookings-count-icon svg {
            width: 16px;
            height: 16px;
        }


        .bookings-count-content {
            display: flex;
            flex-direction: column;
        }


        .bookings-count-number {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 15px;
            font-weight: 800;

            color: #ffffff;
        }


        .bookings-count-label {
            margin-top: 1px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 700;

            letter-spacing: 0.5px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        #bookingMessage:empty {
            display: none;
        }


        #bookingMessage {
            width: 100%;

            box-sizing: border-box;

            margin:
                0
                0
                14px
                0;
        }


        .bookings-notification {
            width: 100%;

            display: flex;
            align-items: center;

            gap: 11px;

            box-sizing: border-box;

            padding: 10px 13px;

            border-radius: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .bookings-notification-success {
            border:
                1px solid
                rgba(
                    95,
                    180,
                    160,
                    0.28
                );

            background:
                rgba(
                    95,
                    180,
                    160,
                    0.09
                );
        }


        .bookings-notification-error {
            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.28
                );

            background:
                rgba(
                    230,
                    95,
                    120,
                    0.09
                );
        }


        .notification-icon {
            width: 27px;
            height: 27px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 6px;

            font-size: 13px;
            font-weight: 800;
        }


        .bookings-notification-success
        .notification-icon {
            background:
                rgba(
                    95,
                    180,
                    160,
                    0.13
                );

            color: #8FD8C6;
        }


        .bookings-notification-error
        .notification-icon {
            background:
                rgba(
                    230,
                    95,
                    120,
                    0.13
                );

            color: #EF8295;
        }


        .notification-content {
            min-width: 0;
        }


        .notification-title {
            margin-bottom: 2px;

            font-size: 10px;
            font-weight: 800;

            color: #ffffff;
        }


        .notification-text {
            font-size: 10px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.58
                );
        }


        /*
        ========================================
        TOOLBAR
        ========================================
        */

        .bookings-toolbar {
            display: grid;

            grid-template-columns:
                minmax(
                    280px,
                    1fr
                )
                180px;

            gap: 12px;

            margin-bottom: 14px;
        }


        /*
        SEARCH
        */

        .search-wrapper {
            position: relative;
        }


        .search-icon {
            position: absolute;

            left: 15px;
            top: 50%;

            width: 17px;
            height: 17px;

            transform:
                translateY(
                    -50%
                );

            pointer-events: none;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        .search-wrapper input {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                15px
                0
                43px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.22
                );

            border-radius: 8px;

            outline: none;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.085
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 12px;

            transition:
                border-color
                0.18s ease,
                background
                0.18s ease,
                box-shadow
                0.18s ease;
        }


        .search-wrapper input::placeholder {
            color:
                rgba(
                    255,
                    255,
                    255,
                    0.47
                );
        }


        .search-wrapper input:hover {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.105
                );
        }


        .search-wrapper input:focus {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.11
                );

            border-color:
                rgba(
                    224,
                    107,
                    174,
                    0.55
                );

            box-shadow:
                0
                0
                0
                3px
                rgba(
                    224,
                    107,
                    174,
                    0.07
                );
        }


        /*
        FILTER
        */

        .bookings-filter select {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                13px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.12
                );

            border-radius: 8px;

            outline: none;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.06
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            font-weight: 600;

            cursor: pointer;
        }


        .bookings-filter option {
            background: #1B1745;
            color: #ffffff;
        }


        /*
        ========================================
        TABLE
        ========================================
        */

        .bookings-table-wrapper {
            width: 100%;
            overflow-x: auto;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 9px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.02
                );
        }


        .bookings-table {
            width: 100%;
            min-width: 1000px;

            border-collapse: collapse;
            table-layout: fixed;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .bookings-table thead {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.045
                );
        }


        .bookings-table th {
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                12px;

            text-align: left;

            border-bottom:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.65px;

            color:
                rgba(
                    246,
                    197,
                    142,
                    0.88
                );
        }


        .bookings-table td {
            height: 51px;

            box-sizing: border-box;

            padding:
                7px
                12px;

            vertical-align: middle;

            border-bottom:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.065
                );

            font-size: 10px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.83
                );
        }


        .bookings-table tbody tr:hover {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.028
                );
        }


        .bookings-table tbody tr:last-child td {
            border-bottom: none;
        }


        /*
        COLUMN WIDTH
        */

        .col-id {
            width: 70px;
        }


        .col-customer {
            width: 190px;
        }


        .col-event {
            width: 210px;
        }


        .col-qty {
            width: 70px;
            text-align: center !important;
        }


        .col-total {
            width: 105px;
        }


        .col-date {
            width: 120px;
        }


        .col-status {
            width: 110px;
            text-align: center !important;
        }


        .col-action {
            width: 120px;
            text-align: center !important;
        }


        /*
        BOOKING INFO
        */

        .booking-id {
            font-weight: 800;

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .customer-name,
        .event-name {
            margin-bottom: 2px;

            font-size: 10px;
            font-weight: 750;

            color: #ffffff;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        .customer-email,
        .event-subtext {
            font-size: 9px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.45
                );

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        /*
        MINI COUNT
        */

        .mini-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 32px;
            height: 25px;

            padding:
                0
                7px;

            box-sizing: border-box;

            border-radius: 5px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.055
                );

            font-size: 10px;
            font-weight: 750;

            color: #ffffff;
        }


        /*
        STATUS
        */

        .status-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 80px;

            padding:
                5px
                8px;

            box-sizing: border-box;

            border-radius: 5px;

            font-size: 8px;
            font-weight: 800;
            letter-spacing: 0.25px;
        }


        .status-confirmed {
            background:
                rgba(
                    95,
                    180,
                    160,
                    0.10
                );

            border:
                1px solid
                rgba(
                    95,
                    180,
                    160,
                    0.24
                );

            color: #8FD8C6;
        }


        .status-cancelled {
            background:
                rgba(
                    230,
                    95,
                    120,
                    0.10
                );

            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.25
                );

            color: #EF8295;
        }


        /*
        ========================================
        ACTION BUTTON
        ========================================
        */

        .booking-actions {
            display: flex;
            align-items: center;
            justify-content: center;
        }


        .manage-booking-btn {
            height: 30px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            padding:
                0
                13px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.25
                );

            border-radius: 5px;

            background:
                linear-gradient(
                    135deg,
                    var(
                        --purple,
                        #5B2A86
                    ),
                    var(
                        --magenta,
                        #B0449E
                    )
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.3px;

            cursor: pointer;
        }


        .manage-booking-btn:hover {
            opacity: 0.88;
        }


        /*
        ========================================
        EMPTY
        ========================================
        */

        .bookings-empty {
            padding:
                30px
                20px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        .pagination-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 14px;
            flex-wrap: wrap;

            margin-top: 13px;
        }


        .pagination-info {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        .pagination-controls {
            display: flex;
            align-items: center;
            gap: 8px;
        }


        .pagination-btn {
            min-width: 82px;
            height: 32px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            padding:
                0
                12px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 5px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.045
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 750;

            cursor: pointer;
        }


        .pagination-btn:hover:not(:disabled) {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.09
                );
        }


        .pagination-btn:disabled {
            opacity: 0.28;
            cursor: not-allowed;
        }


        .pagination-page {
            min-width: 78px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 700;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        /*
        ========================================
        MODAL
        ========================================
        */

        .bookings-modal-overlay {
            position: fixed;
            inset: 0;

            display: none;
            align-items: center;
            justify-content: center;

            padding: 20px;

            box-sizing: border-box;

            background:
                rgba(
                    0,
                    0,
                    0,
                    0.74
                );

            z-index: 9999;
        }


        .bookings-modal-overlay.active {
            display: flex;
        }


        .bookings-modal {
            width: 100%;
            max-width: 560px;

            max-height: 90vh;
            overflow-y: auto;

            box-sizing: border-box;

            padding: 23px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.14
                );

            border-radius: 10px;

            background:
                var(
                    --panel-soft,
                    #241C56
                );
        }


        .bookings-modal-header {
            margin-bottom: 20px;
        }


        .bookings-modal-header h2 {
            margin:
                0
                0
                5px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 18px;
            font-weight: 800;

            color: #ffffff;
        }


        .bookings-modal-header p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        .booking-summary-card {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;

            margin-bottom: 18px;

            padding: 14px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.08
                );

            border-radius: 8px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.025
                );
        }


        .booking-summary-item {
            min-width: 0;
        }


        .booking-summary-label {
            display: block;

            margin-bottom: 4px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;
            letter-spacing: 0.55px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.44
                );
        }


        .booking-summary-value {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 700;

            color: #ffffff;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        .bookings-modal .form-group {
            margin-bottom: 14px;
        }


        .bookings-modal .form-group label {
            display: block;

            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.6px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        .bookings-modal select {
            width: 100%;
            height: 40px;

            box-sizing: border-box;

            padding:
                0
                12px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.12
                );

            border-radius: 6px;

            outline: none;

            background:
                var(
                    --panel,
                    #1B1745
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
        }


        .bookings-modal select option {
            background: #1B1745;
            color: #ffffff;
        }


        .bookings-modal-actions {
            display: grid;

            grid-template-columns:
                1fr
                1fr;

            gap: 10px;

            margin-top: 20px;
        }


        .bookings-modal-actions button {
            height: 38px;
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                10px !important;

            padding-top:
                11px !important;

            padding-bottom:
                11px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 720px) {

            .bookings-toolbar {
                grid-template-columns: 1fr;
            }


            .bookings-page-header {
                align-items: stretch;
            }


            .bookings-count-card {
                width: 100%;
            }


            .booking-summary-card {
                grid-template-columns: 1fr;
            }


            .pagination-bar {
                justify-content: center;
            }


            .pagination-info {
                width: 100%;
                text-align: center;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <h1>MANAGE BOOKINGS</h1>


    <div class="bookings-shell">


        <!-- PAGE HEADER -->

        <div class="bookings-page-header">


            <div class="bookings-page-header-text">

                <h2>
                    Booking Management
                </h2>

                <p>
                    Review customer bookings and manage booking status.
                </p>

            </div>


            <div class="bookings-count-card">


                <div class="bookings-count-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                    >

                        <path
                            d="M4 5h16v14H4z"
                        ></path>

                        <path
                            d="M8 9h8"
                        ></path>

                        <path
                            d="M8 13h5"
                        ></path>

                    </svg>

                </div>


                <div class="bookings-count-content">

                    <span
                        class="bookings-count-number"
                        id="bookingsCount"
                    >
                        0
                    </span>

                    <span class="bookings-count-label">
                        BOOKINGS
                    </span>

                </div>


            </div>


        </div>


        <!-- NOTIFICATION -->

        <div id="bookingMessage"></div>


        <!-- TOOLBAR -->

        <div class="bookings-toolbar">


            <div class="search-wrapper">


                <svg
                    class="search-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20l-3.5-3.5"
                    ></path>

                </svg>


                <input
                    type="text"
                    id="bookingSearch"
                    placeholder="Search booking, customer, email or event..."
                >


            </div>


            <div class="bookings-filter">

                <select id="statusFilter">

                    <option value="All">
                        All Status
                    </option>

                    <option value="Confirmed">
                        Confirmed
                    </option>

                    <option value="Cancelled">
                        Cancelled
                    </option>

                </select>

            </div>


        </div>


        <!-- TABLE -->

        <div class="bookings-table-wrapper">


            <table class="bookings-table">


                <thead>

                    <tr>

                        <th class="col-id">
                            ID
                        </th>

                        <th class="col-customer">
                            CUSTOMER
                        </th>

                        <th class="col-event">
                            EVENT
                        </th>

                        <th class="col-qty">
                            QTY
                        </th>

                        <th class="col-total">
                            TOTAL
                        </th>

                        <th class="col-date">
                            BOOKED ON
                        </th>

                        <th class="col-status">
                            STATUS
                        </th>

                        <th class="col-action">
                            ACTION
                        </th>

                    </tr>

                </thead>


                <tbody id="bookingsTableBody">

                    <tr>

                        <td colspan="8">

                            <div class="bookings-empty">
                                Loading bookings...
                            </div>

                        </td>

                    </tr>

                </tbody>


            </table>


        </div>


        <!-- PAGINATION -->

        <div class="pagination-bar">


            <div
                class="pagination-info"
                id="paginationInfo"
            >
                Showing 0 bookings
            </div>


            <div class="pagination-controls">


                <button
                    type="button"
                    class="pagination-btn"
                    id="previousPageButton"
                    onclick="previousPage()"
                >
                    PREVIOUS
                </button>


                <div
                    class="pagination-page"
                    id="paginationPage"
                >
                    Page 1 of 1
                </div>


                <button
                    type="button"
                    class="pagination-btn"
                    id="nextPageButton"
                    onclick="nextPage()"
                >
                    NEXT
                </button>


            </div>


        </div>


    </div>


    <!-- MANAGE BOOKING MODAL -->

    <div
        class="bookings-modal-overlay"
        id="manageBookingModal"
    >


        <div class="bookings-modal">


            <div class="bookings-modal-header">

                <h2>
                    Manage Booking
                </h2>

                <p>
                    Review booking details and update the booking status.
                </p>

            </div>


            <div class="booking-summary-card">


                <div class="booking-summary-item">

                    <span class="booking-summary-label">
                        BOOKING ID
                    </span>

                    <span
                        class="booking-summary-value"
                        id="modalBookingId"
                    >
                        -
                    </span>

                </div>


                <div class="booking-summary-item">

                    <span class="booking-summary-label">
                        CUSTOMER
                    </span>

                    <span
                        class="booking-summary-value"
                        id="modalCustomer"
                    >
                        -
                    </span>

                </div>


                <div class="booking-summary-item">

                    <span class="booking-summary-label">
                        EVENT
                    </span>

                    <span
                        class="booking-summary-value"
                        id="modalEvent"
                    >
                        -
                    </span>

                </div>


                <div class="booking-summary-item">

                    <span class="booking-summary-label">
                        TICKETS
                    </span>

                    <span
                        class="booking-summary-value"
                        id="modalTickets"
                    >
                        -
                    </span>

                </div>


            </div>


            <div class="form-group">

                <label for="manageBookingStatus">
                    BOOKING STATUS
                </label>

                <select id="manageBookingStatus">

                    <option value="Confirmed">
                        Confirmed
                    </option>

                    <option value="Cancelled">
                        Cancelled
                    </option>

                </select>

            </div>


            <div class="bookings-modal-actions">


                <button
                    type="button"
                    class="btn"
                    id="updateBookingButton"
                    onclick="updateSelectedBooking()"
                >
                    UPDATE BOOKING
                </button>


                <button
                    type="button"
                    class="btn btn-secondary"
                    onclick="closeManageBookingModal()"
                >
                    CANCEL
                </button>


            </div>


        </div>


    </div>


    <div class="footer">

        EVENTIFY ADMIN PORTAL

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        SESSION
        ========================================
        */

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser =
            null;


        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const bookingsTableBody =
            document.getElementById(
                'bookingsTableBody'
            );


        const bookingSearch =
            document.getElementById(
                'bookingSearch'
            );


        const statusFilter =
            document.getElementById(
                'statusFilter'
            );


        const bookingsCount =
            document.getElementById(
                'bookingsCount'
            );


        const paginationInfo =
            document.getElementById(
                'paginationInfo'
            );


        const paginationPage =
            document.getElementById(
                'paginationPage'
            );


        const previousPageButton =
            document.getElementById(
                'previousPageButton'
            );


        const nextPageButton =
            document.getElementById(
                'nextPageButton'
            );


        const bookingMessage =
            document.getElementById(
                'bookingMessage'
            );


        const manageBookingModal =
            document.getElementById(
                'manageBookingModal'
            );


        /*
        ========================================
        DATA
        ========================================
        */

        let allBookings =
            [];


        let filteredBookings =
            [];


        let selectedBookingId =
            null;


        const bookingsPerPage =
            5;


        let currentPage =
            1;


        /*
        ========================================
        AUTH
        ========================================
        */

        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }


            if (
                currentUser &&
                currentUser.role !==
                'Administrator'
            ) {

                alert(
                    'Administrator access only.'
                );


                window.location.href =
                    'login.php';

            }

            else if (currentUser) {

                loadBookings();

            }

        }


        /*
        ========================================
        SEARCH / FILTER
        ========================================
        */

        bookingSearch.addEventListener(
            'input',
            function() {

                currentPage =
                    1;


                filterBookings();

            }
        );


        statusFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterBookings();

            }
        );


        /*
        ========================================
        MODAL
        ========================================
        */

        manageBookingModal.addEventListener(
            'click',
            function(event) {

                if (
                    event.target ===
                    manageBookingModal
                ) {

                    closeManageBookingModal();

                }

            }
        );


        document.addEventListener(
            'keydown',
            function(event) {

                if (
                    event.key ===
                    'Escape'
                ) {

                    closeManageBookingModal();

                }

            }
        );


        /*
        ========================================
        LOAD BOOKINGS
        ========================================
        */

        async function loadBookings() {

            bookingsTableBody.innerHTML = `

                <tr>

                    <td colspan="8">

                        <div class="bookings-empty">
                            Loading bookings...
                        </div>

                    </td>

                </tr>

            `;


            try {

                const response =
                    await fetch(
                        '../api/bookings.php',
                        {

                            headers: {

                                'Authorization':
                                    `Bearer ${token}`

                            }

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    allBookings =
                        result.data ||
                        [];


                    filterBookings();

                }

                else {

                    showNotification(
                        'error',
                        'Unable to load bookings',
                        result.message ||
                        'The booking list could not be retrieved.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Bookings API error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Bookings API.'
                );

            }

        }


        /*
        ========================================
        FILTER
        ========================================
        */

        function filterBookings() {

            const searchValue =
                bookingSearch
                    .value
                    .trim()
                    .toLowerCase();


            const selectedStatus =
                statusFilter.value;


            filteredBookings =
                allBookings.filter(
                    function(booking) {


                        const id =
                            String(
                                booking.booking_id ||
                                ''
                            )
                            .toLowerCase();


                        const customer =
                            String(
                                booking.customer_name ||
                                booking.name ||
                                ''
                            )
                            .toLowerCase();


                        const email =
                            String(
                                booking.customer_email ||
                                booking.email ||
                                ''
                            )
                            .toLowerCase();


                        const event =
                            String(
                                booking.event_name ||
                                ''
                            )
                            .toLowerCase();


                        const matchesSearch =

                            !searchValue

                            ||

                            id.includes(
                                searchValue
                            )

                            ||

                            customer.includes(
                                searchValue
                            )

                            ||

                            email.includes(
                                searchValue
                            )

                            ||

                            event.includes(
                                searchValue
                            );


                        const matchesStatus =

                            selectedStatus ===
                            'All'

                            ||

                            booking.booking_status ===
                            selectedStatus;


                        return (
                            matchesSearch &&
                            matchesStatus
                        );

                    }
                );


            const totalPages =
                getTotalPages();


            if (
                currentPage >
                totalPages
            ) {

                currentPage =
                    totalPages;

            }


            if (
                currentPage <
                1
            ) {

                currentPage =
                    1;

            }


            displayBookings();

        }


        /*
        ========================================
        DISPLAY
        ========================================
        */

        function displayBookings() {

            bookingsCount.textContent =
                filteredBookings.length;


            if (
                filteredBookings.length ===
                0
            ) {

                bookingsTableBody.innerHTML = `

                    <tr>

                        <td colspan="8">

                            <div class="bookings-empty">
                                No bookings found.
                            </div>

                        </td>

                    </tr>

                `;


                updatePagination();

                return;

            }


            const startIndex =
                (
                    currentPage -
                    1
                )
                *
                bookingsPerPage;


            const endIndex =
                startIndex +
                bookingsPerPage;


            const pageBookings =
                filteredBookings.slice(
                    startIndex,
                    endIndex
                );


            bookingsTableBody.innerHTML =
                '';


            pageBookings.forEach(
                function(booking) {


                    const customerName =
                        booking.customer_name ||
                        booking.name ||
                        '-';


                    const customerEmail =
                        booking.customer_email ||
                        booking.email ||
                        '';


                    const quantity =
                        Number(
                            booking.quantity ||
                            booking.ticket_quantity ||
                            0
                        );


                    const totalAmount =
                        Number(
                            booking.total_amount ||
                            booking.total_price ||
                            0
                        );


                    bookingsTableBody.innerHTML += `

                        <tr>


                            <td>

                                <span class="booking-id">

                                    #${booking.booking_id}

                                </span>

                            </td>


                            <td>

                                <div class="customer-name">

                                    ${escapeHtml(
                                        customerName
                                    )}

                                </div>


                                <div class="customer-email">

                                    ${escapeHtml(
                                        customerEmail
                                    )}

                                </div>

                            </td>


                            <td>

                                <div class="event-name">

                                    ${escapeHtml(
                                        booking.event_name ||
                                        '-'
                                    )}

                                </div>


                                <div class="event-subtext">

                                    ${escapeHtml(
                                        booking.venue_name ||
                                        ''
                                    )}

                                </div>

                            </td>


                            <td
                                style="
                                    text-align:center;
                                "
                            >

                                <span class="mini-count">

                                    ${quantity}

                                </span>

                            </td>


                            <td>

                                RM ${totalAmount.toFixed(
                                    2
                                )}

                            </td>


                            <td>

                                ${formatDate(
                                    booking.booking_date ||
                                    booking.created_at
                                )}

                            </td>


                            <td
                                style="
                                    text-align:center;
                                "
                            >

                                <span
                                    class="
                                        status-badge
                                        ${getStatusClass(
                                            booking.booking_status
                                        )}
                                    "
                                >

                                    ${escapeHtml(
                                        booking.booking_status
                                    )}

                                </span>

                            </td>


                            <td>


                                <div class="booking-actions">


                                    <button
                                        type="button"
                                        class="manage-booking-btn"
                                        onclick="openManageBookingModal(
                                            ${booking.booking_id}
                                        )"
                                    >
                                        MANAGE
                                    </button>


                                </div>


                            </td>


                        </tr>

                    `;

                }
            );


            updatePagination();

        }


        /*
        ========================================
        STATUS
        ========================================
        */

        function getStatusClass(
            status
        ) {

            if (
                status ===
                'Cancelled'
            ) {

                return 'status-cancelled';

            }


            return 'status-confirmed';

        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        function getTotalPages() {

            return Math.max(

                1,

                Math.ceil(
                    filteredBookings.length /
                    bookingsPerPage
                )

            );

        }


        function updatePagination() {

            const totalPages =
                getTotalPages();


            const start =

                filteredBookings.length ===
                0

                ? 0

                : (
                    (
                        currentPage -
                        1
                    )
                    *
                    bookingsPerPage
                )
                +
                1;


            const end =
                Math.min(

                    currentPage *
                    bookingsPerPage,

                    filteredBookings.length

                );


            paginationInfo.textContent =

                filteredBookings.length ===
                0

                ? 'Showing 0 bookings'

                : `Showing ${start}-${end} of ${filteredBookings.length} bookings`;


            paginationPage.textContent =

                `Page ${currentPage} of ${totalPages}`;


            previousPageButton.disabled =
                currentPage <=
                1;


            nextPageButton.disabled =
                currentPage >=
                totalPages;

        }


        function previousPage() {

            if (
                currentPage <=
                1
            ) {

                return;

            }


            currentPage--;


            displayBookings();

        }


        function nextPage() {

            const totalPages =
                getTotalPages();


            if (
                currentPage >=
                totalPages
            ) {

                return;

            }


            currentPage++;


            displayBookings();

        }


        /*
        ========================================
        MANAGE BOOKING
        ========================================
        */

        function openManageBookingModal(
            bookingId
        ) {

            const booking =
                allBookings.find(
                    function(item) {

                        return (
                            Number(
                                item.booking_id
                            )
                            ===
                            Number(
                                bookingId
                            )
                        );

                    }
                );


            if (!booking) {

                return;

            }


            selectedBookingId =
                Number(
                    bookingId
                );


            const customerName =
                booking.customer_name ||
                booking.name ||
                '-';


            const quantity =
                Number(
                    booking.quantity ||
                    booking.ticket_quantity ||
                    0
                );


            document
                .getElementById(
                    'modalBookingId'
                )
                .textContent =
                    `#${booking.booking_id}`;


            document
                .getElementById(
                    'modalCustomer'
                )
                .textContent =
                    customerName;


            document
                .getElementById(
                    'modalEvent'
                )
                .textContent =
                    booking.event_name ||
                    '-';


            document
                .getElementById(
                    'modalTickets'
                )
                .textContent =
                    quantity;


            document
                .getElementById(
                    'manageBookingStatus'
                )
                .value =
                    booking.booking_status;


            manageBookingModal
                .classList
                .add(
                    'active'
                );


            document.body.style.overflow =
                'hidden';

        }


        function closeManageBookingModal() {

            manageBookingModal
                .classList
                .remove(
                    'active'
                );


            selectedBookingId =
                null;


            document.body.style.overflow =
                '';

        }


        /*
        ========================================
        UPDATE BOOKING
        ========================================
        */

        async function updateSelectedBooking() {

            if (
                selectedBookingId ===
                null
            ) {

                return;

            }


            const booking =
                allBookings.find(
                    function(item) {

                        return (
                            Number(
                                item.booking_id
                            )
                            ===
                            Number(
                                selectedBookingId
                            )
                        );

                    }
                );


            if (!booking) {

                return;

            }


            const newStatus =
                document
                    .getElementById(
                        'manageBookingStatus'
                    )
                    .value;


            if (
                newStatus ===
                booking.booking_status
            ) {

                closeManageBookingModal();

                return;

            }


            let confirmationText =
                'Update this booking status?';


            if (
                booking.booking_status ===
                'Confirmed'
                &&
                newStatus ===
                'Cancelled'
            ) {

                confirmationText =
                    'Cancel this booking?\n\n' +
                    'The booked tickets will be returned to the event availability.';

            }


            if (
                booking.booking_status ===
                'Cancelled'
                &&
                newStatus ===
                'Confirmed'
            ) {

                confirmationText =
                    'Confirm this cancelled booking again?\n\n' +
                    'Tickets will be deducted from the event availability if sufficient tickets are available.';

            }


            const confirmed =
                confirm(
                    confirmationText
                );


            if (!confirmed) {

                document
                    .getElementById(
                        'manageBookingStatus'
                    )
                    .value =
                        booking.booking_status;


                return;

            }


            const button =
                document.getElementById(
                    'updateBookingButton'
                );


            button.disabled =
                true;


            button.textContent =
                'UPDATING...';


            try {

                const response =
                    await fetch(
                        '../api/bookings.php',
                        {

                            method:
                                'PUT',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    booking_id:
                                        Number(
                                            selectedBookingId
                                        ),

                                    booking_status:
                                        newStatus

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    closeManageBookingModal();


                    showNotification(
                        'success',
                        'Booking updated',
                        `Booking #${selectedBookingId} is now ${newStatus}.`
                    );


                    await loadBookings();

                }

                else {

                    showNotification(
                        'error',
                        'Update failed',
                        result.message ||
                        'Unable to update this booking.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Update booking error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Bookings API.'
                );

            }

            finally {

                button.disabled =
                    false;


                button.textContent =
                    'UPDATE BOOKING';

            }

        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        function showNotification(
            type,
            title,
            text
        ) {

            const isSuccess =
                type ===
                'success';


            bookingMessage.innerHTML = `

                <div
                    class="
                        bookings-notification
                        ${
                            isSuccess

                            ? 'bookings-notification-success'

                            : 'bookings-notification-error'
                        }
                    "
                >

                    <div class="notification-icon">

                        ${
                            isSuccess
                            ? '✓'
                            : '!'
                        }

                    </div>


                    <div class="notification-content">

                        <div class="notification-title">

                            ${escapeHtml(
                                title
                            )}

                        </div>


                        <div class="notification-text">

                            ${escapeHtml(
                                text
                            )}

                        </div>

                    </div>

                </div>

            `;


            window.setTimeout(
                function() {

                    bookingMessage.innerHTML =
                        '';

                },
                4000
            );

        }


        /*
        ========================================
        HELPERS
        ========================================
        */

        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const datePart =
                String(
                    value
                )
                .substring(
                    0,
                    10
                );


            const parts =
                datePart.split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return datePart;

            }


            return (
                parts[2]
                +
                '/'
                +
                parts[1]
                +
                '/'
                +
                parts[0]
            );

        }


        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }


        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );


            localStorage.removeItem(
                'eventify_user'
            );


            window.location.href =
                'login.php';

        }

    </script>


</body>

</html>