<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Manage Users - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }


        .users-shell {
            width: min(1180px, 92%);
            margin: 0 auto;
            flex: 1;
        }


        /*
        ========================================
        PAGE HEADER
        ========================================
        */

        .users-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 18px;
            flex-wrap: wrap;

            margin-bottom: 14px;
        }


        .users-page-header-text h2 {
            margin: 0 0 4px 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 17px;
            font-weight: 800;

            color: #ffffff;
        }


        .users-page-header-text p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.5;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        /*
        ========================================
        USER COUNT
        ========================================
        */

        .users-count-card {
            display: flex;
            align-items: center;

            gap: 10px;

            min-width: 105px;

            padding: 10px 13px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.22
                );

            border-radius: 8px;

            background:
                linear-gradient(
                    135deg,
                    rgba(
                        91,
                        42,
                        134,
                        0.23
                    ),
                    rgba(
                        176,
                        68,
                        158,
                        0.10
                    )
                );
        }


        .users-count-icon {
            width: 30px;
            height: 30px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 7px;

            background:
                rgba(
                    224,
                    107,
                    174,
                    0.10
                );

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .users-count-icon svg {
            width: 16px;
            height: 16px;
        }


        .users-count-content {
            display: flex;
            flex-direction: column;
        }


        .users-count-number {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 15px;
            font-weight: 800;

            color: #ffffff;
        }


        .users-count-label {
            margin-top: 1px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 700;
            letter-spacing: 0.5px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        #userMessage:empty {
            display: none;
        }


        #userMessage {
            width: 100%;

            box-sizing: border-box;

            margin:
                0
                0
                14px
                0;
        }


        .users-notification {
            width: 100%;

            display: flex;
            align-items: center;

            gap: 11px;

            box-sizing: border-box;

            padding: 10px 13px;

            border-radius: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .users-notification-success {
            border:
                1px solid
                rgba(
                    95,
                    180,
                    160,
                    0.28
                );

            background:
                rgba(
                    95,
                    180,
                    160,
                    0.09
                );
        }


        .users-notification-error {
            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.28
                );

            background:
                rgba(
                    230,
                    95,
                    120,
                    0.09
                );
        }


        .notification-icon {
            width: 27px;
            height: 27px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 6px;

            font-size: 13px;
            font-weight: 800;
        }


        .users-notification-success
        .notification-icon {
            background:
                rgba(
                    95,
                    180,
                    160,
                    0.13
                );

            color: #8FD8C6;
        }


        .users-notification-error
        .notification-icon {
            background:
                rgba(
                    230,
                    95,
                    120,
                    0.13
                );

            color: #EF8295;
        }


        .notification-content {
            min-width: 0;
        }


        .notification-title {
            margin-bottom: 2px;

            font-size: 10px;
            font-weight: 800;

            color: #ffffff;
        }


        .notification-text {
            font-size: 10px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.58
                );
        }


        /*
        ========================================
        TOOLBAR
        ========================================
        */

        .users-toolbar {
            display: grid;

            grid-template-columns:
                minmax(
                    280px,
                    1fr
                )
                190px;

            gap: 12px;

            margin-bottom: 14px;
        }


        /*
        SEARCH
        */

        .search-wrapper {
            position: relative;
        }


        .search-icon {
            position: absolute;

            left: 15px;
            top: 50%;

            width: 17px;
            height: 17px;

            transform:
                translateY(
                    -50%
                );

            pointer-events: none;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        .search-wrapper input {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                15px
                0
                43px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.22
                );

            border-radius: 8px;

            outline: none;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.085
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 12px;

            transition:
                border-color
                0.18s ease,
                background
                0.18s ease,
                box-shadow
                0.18s ease;
        }


        .search-wrapper input::placeholder {
            color:
                rgba(
                    255,
                    255,
                    255,
                    0.47
                );
        }


        .search-wrapper input:hover {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.105
                );
        }


        .search-wrapper input:focus {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.11
                );

            border-color:
                rgba(
                    224,
                    107,
                    174,
                    0.55
                );

            box-shadow:
                0
                0
                0
                3px
                rgba(
                    224,
                    107,
                    174,
                    0.07
                );
        }


        /*
        FILTER
        */

        .users-filter select {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                13px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.12
                );

            border-radius: 8px;

            outline: none;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.06
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            font-weight: 600;

            cursor: pointer;
        }


        .users-filter option {
            background: #1B1745;
            color: #ffffff;
        }


        /*
        ========================================
        TABLE
        ========================================
        */

        .users-table-wrapper {
            width: 100%;
            overflow-x: auto;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 9px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.02
                );
        }


        .users-table {
            width: 100%;
            min-width: 900px;

            border-collapse: collapse;
            table-layout: fixed;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .users-table thead {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.045
                );
        }


        .users-table th {
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                13px;

            text-align: left;

            border-bottom:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.65px;

            color:
                rgba(
                    246,
                    197,
                    142,
                    0.88
                );
        }


        .users-table td {
            height: 51px;

            box-sizing: border-box;

            padding:
                7px
                13px;

            vertical-align: middle;

            border-bottom:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.065
                );

            font-size: 11px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.83
                );
        }


        .users-table tbody tr:hover {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.028
                );
        }


        .users-table tbody tr:last-child td {
            border-bottom: none;
        }


        /*
        COLUMN WIDTH
        */

        .col-id {
            width: 65px;
        }


        .col-user {
            width: 245px;
        }


        .col-role {
            width: 130px;
        }


        .col-events {
            width: 85px;
            text-align: center !important;
        }


        .col-bookings {
            width: 95px;
            text-align: center !important;
        }


        .col-created {
            width: 125px;
        }


        .col-action {
            width: 165px;
            text-align: center !important;
        }


        /*
        USER INFO
        */

        .user-id {
            font-weight: 800;

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .user-info {
            min-width: 0;
        }


        .user-name {
            margin-bottom: 2px;

            font-size: 11px;
            font-weight: 750;

            color: #ffffff;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        .user-email {
            font-size: 9px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        /*
        ROLE BADGES
        */

        .role-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 82px;

            padding:
                5px
                8px;

            box-sizing: border-box;

            border-radius: 5px;

            font-size: 8px;
            font-weight: 800;
            letter-spacing: 0.35px;
        }


        .role-administrator {
            background:
                rgba(
                    224,
                    107,
                    174,
                    0.12
                );

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.28
                );

            color: #F4A7D0;
        }


        .role-organiser {
            background:
                rgba(
                    246,
                    197,
                    142,
                    0.10
                );

            border:
                1px solid
                rgba(
                    246,
                    197,
                    142,
                    0.25
                );

            color: #F6C58E;
        }


        .role-customer {
            background:
                rgba(
                    95,
                    180,
                    160,
                    0.10
                );

            border:
                1px solid
                rgba(
                    95,
                    180,
                    160,
                    0.24
                );

            color: #8FD8C6;
        }


        /*
        COUNTS
        */

        .mini-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 30px;
            height: 25px;

            padding:
                0
                7px;

            box-sizing: border-box;

            border-radius: 5px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.055
                );

            font-size: 10px;
            font-weight: 750;

            color: #ffffff;
        }


        /*
        ========================================
        ACTION BUTTONS
        ========================================
        */

        .user-actions {
            display: flex;
            align-items: center;
            justify-content: center;

            gap: 9px;
        }


        .manage-user-btn {
            height: 30px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            padding:
                0
                13px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.25
                );

            border-radius: 5px;

            background:
                linear-gradient(
                    135deg,
                    var(
                        --purple,
                        #5B2A86
                    ),
                    var(
                        --magenta,
                        #B0449E
                    )
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.3px;

            cursor: pointer;
        }


        .manage-user-btn:hover {
            opacity: 0.88;
        }


        .delete-user-btn {
            width: 32px;
            height: 30px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            padding: 0;

            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.25
                );

            border-radius: 5px;

            background:
                rgba(
                    180,
                    55,
                    80,
                    0.13
                );

            color: #EF8295;

            cursor: pointer;

            transition:
                background
                0.15s ease,
                transform
                0.15s ease;
        }


        .delete-user-btn:hover {
            background:
                rgba(
                    180,
                    55,
                    80,
                    0.26
                );

            transform:
                translateY(
                    -1px
                );
        }


        .delete-user-btn svg {
            width: 14px;
            height: 14px;
        }


        .delete-user-btn:disabled {
            opacity: 0.25;
            cursor: not-allowed;
            transform: none;
        }


        /*
        ========================================
        EMPTY
        ========================================
        */

        .users-empty {
            padding:
                30px
                20px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        .pagination-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 14px;
            flex-wrap: wrap;

            margin-top: 13px;
        }


        .pagination-info {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        .pagination-controls {
            display: flex;
            align-items: center;
            gap: 8px;
        }


        .pagination-btn {
            min-width: 82px;
            height: 32px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            padding:
                0
                12px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 5px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.045
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 750;

            cursor: pointer;
        }


        .pagination-btn:hover:not(:disabled) {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.09
                );
        }


        .pagination-btn:disabled {
            opacity: 0.28;
            cursor: not-allowed;
        }


        .pagination-page {
            min-width: 78px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 700;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        /*
        ========================================
        MODAL
        ========================================
        */

        .users-modal-overlay {
            position: fixed;
            inset: 0;

            display: none;
            align-items: center;
            justify-content: center;

            padding: 20px;

            box-sizing: border-box;

            background:
                rgba(
                    0,
                    0,
                    0,
                    0.74
                );

            z-index: 9999;
        }


        .users-modal-overlay.active {
            display: flex;
        }


        .users-modal {
            width: 100%;
            max-width: 520px;

            max-height: 90vh;
            overflow-y: auto;

            box-sizing: border-box;

            padding: 23px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.14
                );

            border-radius: 10px;

            background:
                var(
                    --panel-soft,
                    #241C56
                );
        }


        .users-modal-header {
            margin-bottom: 20px;
        }


        .users-modal-header h2 {
            margin:
                0
                0
                5px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 18px;
            font-weight: 800;

            color: #ffffff;
        }


        .users-modal-header p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        .users-modal .form-group {
            margin-bottom: 15px;
        }


        .users-modal .form-group label {
            display: block;

            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.6px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        .users-modal input,
        .users-modal select {
            width: 100%;
            height: 40px;

            box-sizing: border-box;

            padding:
                0
                12px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.12
                );

            border-radius: 6px;

            outline: none;

            background:
                var(
                    --panel,
                    #1B1745
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
        }


        .users-modal select option {
            background: #1B1745;
        }


        .users-modal-actions {
            display: grid;

            grid-template-columns:
                1fr
                1fr;

            gap: 10px;

            margin-top: 20px;
        }


        .users-modal-actions button {
            height: 38px;
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                10px !important;

            padding-top:
                11px !important;

            padding-bottom:
                11px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 720px) {

            .users-toolbar {
                grid-template-columns:
                    1fr;
            }


            .users-page-header {
                align-items: stretch;
            }


            .users-count-card {
                width: 100%;
            }


            .pagination-bar {
                justify-content: center;
            }


            .pagination-info {
                width: 100%;
                text-align: center;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <!--
        GLOBAL PAGE TITLE

        Kekal di luar .users-shell
        supaya alignment sama dengan page lain.
    -->

    <h1>MANAGE USERS</h1>


    <div class="users-shell">


        <!-- PAGE HEADER -->

        <div class="users-page-header">


            <div class="users-page-header-text">

                <h2>
                    User Management
                </h2>

                <p>
                    Manage registered Eventify users and their system roles.
                </p>

            </div>


            <div class="users-count-card">


                <div class="users-count-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <path
                            d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"
                        ></path>

                        <circle
                            cx="9"
                            cy="7"
                            r="4"
                        ></circle>

                        <path
                            d="M22 21v-2a4 4 0 0 0-3-3.87"
                        ></path>

                        <path
                            d="M16 3.13a4 4 0 0 1 0 7.75"
                        ></path>

                    </svg>

                </div>


                <div class="users-count-content">

                    <span
                        class="users-count-number"
                        id="usersCount"
                    >
                        0
                    </span>

                    <span class="users-count-label">
                        USERS
                    </span>

                </div>


            </div>


        </div>


        <!--
            NOTIFICATION

            Kekal antara:
            User Management
            dan
            Search bar
        -->

        <div id="userMessage"></div>


        <!-- TOOLBAR -->

        <div class="users-toolbar">


            <div class="search-wrapper">


                <svg
                    class="search-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20l-3.5-3.5"
                    ></path>

                </svg>


                <input
                    type="text"
                    id="userSearch"
                    placeholder="Search user name, email or user ID..."
                >


            </div>


            <div class="users-filter">

                <select id="roleFilter">

                    <option value="All">
                        All Roles
                    </option>

                    <option value="Administrator">
                        Administrator
                    </option>

                    <option value="Organiser">
                        Organiser
                    </option>

                    <option value="Customer">
                        Customer
                    </option>

                </select>

            </div>


        </div>


        <!-- TABLE -->

        <div class="users-table-wrapper">


            <table class="users-table">


                <thead>

                    <tr>

                        <th class="col-id">
                            ID
                        </th>

                        <th class="col-user">
                            USER
                        </th>

                        <th class="col-role">
                            ROLE
                        </th>

                        <th class="col-events">
                            EVENTS
                        </th>

                        <th class="col-bookings">
                            BOOKINGS
                        </th>

                        <th class="col-created">
                            CREATED
                        </th>

                        <th class="col-action">
                            ACTION
                        </th>

                    </tr>

                </thead>


                <tbody id="usersTableBody">

                    <tr>

                        <td colspan="7">

                            <div class="users-empty">
                                Loading users...
                            </div>

                        </td>

                    </tr>

                </tbody>


            </table>


        </div>


        <!-- PAGINATION -->

        <div class="pagination-bar">


            <div
                class="pagination-info"
                id="paginationInfo"
            >
                Showing 0 users
            </div>


            <div class="pagination-controls">


                <button
                    type="button"
                    class="pagination-btn"
                    id="previousPageButton"
                    onclick="previousPage()"
                >
                    PREVIOUS
                </button>


                <div
                    class="pagination-page"
                    id="paginationPage"
                >
                    Page 1 of 1
                </div>


                <button
                    type="button"
                    class="pagination-btn"
                    id="nextPageButton"
                    onclick="nextPage()"
                >
                    NEXT
                </button>


            </div>


        </div>


    </div>


    <!-- MANAGE USER MODAL -->

    <div
        class="users-modal-overlay"
        id="manageUserModal"
    >


        <div class="users-modal">


            <div class="users-modal-header">

                <h2>
                    Manage User
                </h2>

                <p>
                    Update user account information and role.
                </p>

            </div>


            <div class="form-group">

                <label>
                    USER ID
                </label>

                <input
                    type="text"
                    id="manageUserId"
                    readonly
                >

            </div>


            <div class="form-group">

                <label for="manageUserName">
                    NAME
                </label>

                <input
                    type="text"
                    id="manageUserName"
                >

            </div>


            <div class="form-group">

                <label for="manageUserEmail">
                    EMAIL
                </label>

                <input
                    type="email"
                    id="manageUserEmail"
                >

            </div>


            <div class="form-group">

                <label for="manageUserRole">
                    ROLE
                </label>

                <select id="manageUserRole">

                    <option value="Administrator">
                        Administrator
                    </option>

                    <option value="Organiser">
                        Organiser
                    </option>

                    <option value="Customer">
                        Customer
                    </option>

                </select>

            </div>


            <div class="users-modal-actions">


                <button
                    type="button"
                    class="btn"
                    id="updateUserButton"
                    onclick="updateSelectedUser()"
                >
                    UPDATE USER
                </button>


                <button
                    type="button"
                    class="btn btn-secondary"
                    onclick="closeManageUserModal()"
                >
                    CANCEL
                </button>


            </div>


        </div>


    </div>


    <div class="footer">

        EVENTIFY ADMIN PORTAL

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser = null;


        const usersTableBody =
            document.getElementById(
                'usersTableBody'
            );


        const userSearch =
            document.getElementById(
                'userSearch'
            );


        const roleFilter =
            document.getElementById(
                'roleFilter'
            );


        const usersCount =
            document.getElementById(
                'usersCount'
            );


        const paginationInfo =
            document.getElementById(
                'paginationInfo'
            );


        const paginationPage =
            document.getElementById(
                'paginationPage'
            );


        const previousPageButton =
            document.getElementById(
                'previousPageButton'
            );


        const nextPageButton =
            document.getElementById(
                'nextPageButton'
            );


        const manageUserModal =
            document.getElementById(
                'manageUserModal'
            );


        const userMessage =
            document.getElementById(
                'userMessage'
            );


        let allUsers = [];

        let filteredUsers = [];

        let selectedUserId = null;


        const usersPerPage =
            5;


        let currentPage =
            1;


        /*
        ========================================
        AUTH
        ========================================
        */

        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }


            if (
                currentUser &&
                currentUser.role !==
                'Administrator'
            ) {

                alert(
                    'Administrator access only.'
                );


                window.location.href =
                    'login.php';

            }

            else if (currentUser) {

                loadUsers();

            }

        }


        /*
        ========================================
        SEARCH + FILTER
        ========================================
        */

        userSearch.addEventListener(
            'input',
            function() {

                currentPage =
                    1;


                filterUsers();

            }
        );


        roleFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterUsers();

            }
        );


        /*
        ========================================
        MODAL
        ========================================
        */

        manageUserModal.addEventListener(
            'click',
            function(event) {

                if (
                    event.target ===
                    manageUserModal
                ) {

                    closeManageUserModal();

                }

            }
        );


        document.addEventListener(
            'keydown',
            function(event) {

                if (
                    event.key ===
                    'Escape'
                ) {

                    closeManageUserModal();

                }

            }
        );


        /*
        ========================================
        LOAD USERS
        ========================================
        */

        async function loadUsers() {

            usersTableBody.innerHTML = `

                <tr>

                    <td colspan="7">

                        <div class="users-empty">
                            Loading users...
                        </div>

                    </td>

                </tr>

            `;


            try {

                const response =
                    await fetch(
                        '../api/users.php',
                        {

                            headers: {

                                'Authorization':
                                    `Bearer ${token}`

                            }

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    allUsers =
                        result.data ||
                        [];


                    filterUsers();

                }

                else {

                    showNotification(
                        'error',
                        'Unable to load users',
                        result.message ||
                        'The user list could not be retrieved.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Users API error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Users API.'
                );

            }

        }


        /*
        ========================================
        FILTER
        ========================================
        */

        function filterUsers() {

            const searchValue =
                userSearch
                    .value
                    .trim()
                    .toLowerCase();


            const roleValue =
                roleFilter.value;


            filteredUsers =
                allUsers.filter(
                    function(user) {


                        const id =
                            String(
                                user.user_id ||
                                ''
                            )
                            .toLowerCase();


                        const name =
                            String(
                                user.name ||
                                ''
                            )
                            .toLowerCase();


                        const email =
                            String(
                                user.email ||
                                ''
                            )
                            .toLowerCase();


                        const matchesSearch =

                            !searchValue

                            ||

                            id.includes(
                                searchValue
                            )

                            ||

                            name.includes(
                                searchValue
                            )

                            ||

                            email.includes(
                                searchValue
                            );


                        const matchesRole =

                            roleValue ===
                            'All'

                            ||

                            user.role ===
                            roleValue;


                        return (
                            matchesSearch &&
                            matchesRole
                        );

                    }
                );


            const totalPages =
                getTotalPages();


            if (
                currentPage >
                totalPages
            ) {

                currentPage =
                    totalPages;

            }


            if (
                currentPage <
                1
            ) {

                currentPage =
                    1;

            }


            displayUsers();

        }


        /*
        ========================================
        DISPLAY USERS
        ========================================
        */

        function displayUsers() {

            usersCount.textContent =
                filteredUsers.length;


            if (
                filteredUsers.length ===
                0
            ) {

                usersTableBody.innerHTML = `

                    <tr>

                        <td colspan="7">

                            <div class="users-empty">
                                No users found.
                            </div>

                        </td>

                    </tr>

                `;


                updatePagination();

                return;

            }


            const startIndex =
                (
                    currentPage -
                    1
                )
                *
                usersPerPage;


            const endIndex =
                startIndex +
                usersPerPage;


            const pageUsers =
                filteredUsers.slice(
                    startIndex,
                    endIndex
                );


            usersTableBody.innerHTML =
                '';


            pageUsers.forEach(
                function(user) {


                    const isCurrentUser =

                        Number(
                            user.user_id
                        )

                        ===

                        Number(
                            currentUser.user_id
                        );


                    const eventCount =
                        Number(

                            user.event_count

                            ??

                            user.events_count

                            ??

                            user.total_events

                            ??

                            0

                        );


                    const bookingCount =
                        Number(

                            user.booking_count

                            ??

                            user.bookings_count

                            ??

                            user.total_bookings

                            ??

                            0

                        );


                    usersTableBody.innerHTML += `

                        <tr>


                            <td>

                                <span class="user-id">

                                    #${user.user_id}

                                </span>

                            </td>


                            <td>

                                <div class="user-info">


                                    <div class="user-name">

                                        ${escapeHtml(
                                            user.name
                                        )}

                                        ${
                                            isCurrentUser

                                            ? ' (You)'

                                            : ''
                                        }

                                    </div>


                                    <div class="user-email">

                                        ${escapeHtml(
                                            user.email
                                        )}

                                    </div>


                                </div>

                            </td>


                            <td>

                                <span
                                    class="
                                        role-badge
                                        ${getRoleClass(
                                            user.role
                                        )}
                                    "
                                >

                                    ${escapeHtml(
                                        user.role
                                    )}

                                </span>

                            </td>


                            <td
                                style="
                                    text-align:center;
                                "
                            >

                                <span class="mini-count">

                                    ${eventCount}

                                </span>

                            </td>


                            <td
                                style="
                                    text-align:center;
                                "
                            >

                                <span class="mini-count">

                                    ${bookingCount}

                                </span>

                            </td>


                            <td>

                                ${formatDate(
                                    user.created_at
                                )}

                            </td>


                            <td>


                                <div class="user-actions">


                                    <button
                                        type="button"
                                        class="manage-user-btn"
                                        onclick="openManageUserModal(
                                            ${user.user_id}
                                        )"
                                    >
                                        MANAGE
                                    </button>


                                    <button
                                        type="button"
                                        class="delete-user-btn"
                                        onclick="deleteUser(
                                            ${user.user_id}
                                        )"
                                        ${
                                            isCurrentUser
                                            ? 'disabled'
                                            : ''
                                        }
                                        title="${
                                            isCurrentUser
                                            ? 'You cannot delete your own account'
                                            : 'Delete user'
                                        }"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.9"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >

                                            <polyline
                                                points="3 6 5 6 21 6"
                                            ></polyline>

                                            <path
                                                d="M19 6l-1 14H6L5 6"
                                            ></path>

                                            <path
                                                d="M10 11v5"
                                            ></path>

                                            <path
                                                d="M14 11v5"
                                            ></path>

                                            <path
                                                d="M9 6V4h6v2"
                                            ></path>

                                        </svg>

                                    </button>


                                </div>


                            </td>


                        </tr>

                    `;

                }
            );


            updatePagination();

        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        function getTotalPages() {

            return Math.max(

                1,

                Math.ceil(
                    filteredUsers.length /
                    usersPerPage
                )

            );

        }


        function updatePagination() {

            const totalPages =
                getTotalPages();


            const start =

                filteredUsers.length ===
                0

                ? 0

                : (
                    (
                        currentPage -
                        1
                    )
                    *
                    usersPerPage
                )
                +
                1;


            const end =
                Math.min(

                    currentPage *
                    usersPerPage,

                    filteredUsers.length

                );


            paginationInfo.textContent =

                filteredUsers.length ===
                0

                ? 'Showing 0 users'

                : `Showing ${start}-${end} of ${filteredUsers.length} users`;


            paginationPage.textContent =

                `Page ${currentPage} of ${totalPages}`;


            previousPageButton.disabled =
                currentPage <=
                1;


            nextPageButton.disabled =
                currentPage >=
                totalPages;

        }


        function previousPage() {

            if (
                currentPage <=
                1
            ) {

                return;

            }


            currentPage--;


            displayUsers();

        }


        function nextPage() {

            const totalPages =
                getTotalPages();


            if (
                currentPage >=
                totalPages
            ) {

                return;

            }


            currentPage++;


            displayUsers();

        }


        /*
        ========================================
        MANAGE USER
        ========================================
        */

        function openManageUserModal(
            userId
        ) {

            const user =
                allUsers.find(
                    function(item) {

                        return (
                            Number(
                                item.user_id
                            )
                            ===
                            Number(
                                userId
                            )
                        );

                    }
                );


            if (!user) {

                return;

            }


            selectedUserId =
                Number(
                    userId
                );


            document
                .getElementById(
                    'manageUserId'
                )
                .value =
                    user.user_id;


            document
                .getElementById(
                    'manageUserName'
                )
                .value =
                    user.name ||
                    '';


            document
                .getElementById(
                    'manageUserEmail'
                )
                .value =
                    user.email ||
                    '';


            document
                .getElementById(
                    'manageUserRole'
                )
                .value =
                    user.role;


            const roleSelect =
                document
                    .getElementById(
                        'manageUserRole'
                    );


            const isCurrentUser =

                Number(
                    user.user_id
                )

                ===

                Number(
                    currentUser.user_id
                );


            roleSelect.disabled =
                isCurrentUser;


            manageUserModal
                .classList
                .add(
                    'active'
                );


            document.body.style.overflow =
                'hidden';

        }


        function closeManageUserModal() {

            manageUserModal
                .classList
                .remove(
                    'active'
                );


            document
                .getElementById(
                    'manageUserRole'
                )
                .disabled =
                    false;


            selectedUserId =
                null;


            document.body.style.overflow =
                '';

        }


        /*
        ========================================
        UPDATE USER
        ========================================
        */

        async function updateSelectedUser() {

            if (
                selectedUserId ===
                null
            ) {

                return;

            }


            const name =
                document
                    .getElementById(
                        'manageUserName'
                    )
                    .value
                    .trim();


            const email =
                document
                    .getElementById(
                        'manageUserEmail'
                    )
                    .value
                    .trim();


            const role =
                document
                    .getElementById(
                        'manageUserRole'
                    )
                    .value;


            if (
                !name ||
                !email
            ) {

                showNotification(
                    'error',
                    'Missing information',
                    'Name and email are required.'
                );

                return;

            }


            const button =
                document
                    .getElementById(
                        'updateUserButton'
                    );


            button.disabled =
                true;


            button.textContent =
                'UPDATING...';


            try {

                const response =
                    await fetch(
                        '../api/users.php',
                        {

                            method:
                                'PUT',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    user_id:
                                        Number(
                                            selectedUserId
                                        ),

                                    name:
                                        name,

                                    email:
                                        email,

                                    role:
                                        role

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    closeManageUserModal();


                    showNotification(
                        'success',
                        'User updated',
                        `${name} has been updated successfully.`
                    );


                    await loadUsers();

                }

                else {

                    showNotification(
                        'error',
                        'Update failed',
                        result.message ||
                        'Unable to update this user.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Update user error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Users API.'
                );

            }

            finally {

                button.disabled =
                    false;


                button.textContent =
                    'UPDATE USER';

            }

        }


        /*
        ========================================
        DELETE USER
        ========================================
        */

        async function deleteUser(
            userId
        ) {

            const user =
                allUsers.find(
                    function(item) {

                        return (
                            Number(
                                item.user_id
                            )
                            ===
                            Number(
                                userId
                            )
                        );

                    }
                );


            if (!user) {

                return;

            }


            if (
                Number(
                    user.user_id
                )
                ===
                Number(
                    currentUser.user_id
                )
            ) {

                showNotification(
                    'error',
                    'Action unavailable',
                    'You cannot delete your own administrator account.'
                );

                return;

            }


            const confirmed =
                confirm(

                    `Delete user "${user.name}"?\n\n` +

                    `Email: ${user.email}\n` +

                    `Role: ${user.role}\n\n` +

                    `This action cannot be undone.`

                );


            if (!confirmed) {

                return;

            }


            try {

                const response =
                    await fetch(
                        '../api/users.php',
                        {

                            method:
                                'DELETE',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    user_id:
                                        Number(
                                            userId
                                        )

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    showNotification(
                        'success',
                        'User deleted',
                        `${user.name} has been removed successfully.`
                    );


                    await loadUsers();

                }

                else {

                    showNotification(
                        'error',
                        'Delete failed',
                        result.message ||
                        'Unable to delete this user.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Delete user error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Users API.'
                );

            }

        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        function showNotification(
            type,
            title,
            text
        ) {

            const isSuccess =
                type ===
                'success';


            userMessage.innerHTML = `

                <div
                    class="
                        users-notification
                        ${
                            isSuccess

                            ? 'users-notification-success'

                            : 'users-notification-error'
                        }
                    "
                >

                    <div class="notification-icon">

                        ${
                            isSuccess
                            ? '✓'
                            : '!'
                        }

                    </div>


                    <div class="notification-content">

                        <div class="notification-title">

                            ${escapeHtml(
                                title
                            )}

                        </div>


                        <div class="notification-text">

                            ${escapeHtml(
                                text
                            )}

                        </div>

                    </div>

                </div>

            `;


            window.setTimeout(
                function() {

                    userMessage.innerHTML =
                        '';

                },
                4000
            );

        }


        /*
        ========================================
        HELPERS
        ========================================
        */

        function getRoleClass(
            role
        ) {

            if (
                role ===
                'Administrator'
            ) {

                return 'role-administrator';

            }


            if (
                role ===
                'Organiser'
            ) {

                return 'role-organiser';

            }


            return 'role-customer';

        }


        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const rawDate =
                String(
                    value
                )
                .substring(
                    0,
                    10
                );


            const parts =
                rawDate.split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return rawDate;

            }


            return (
                parts[2]
                +
                '/'
                +
                parts[1]
                +
                '/'
                +
                parts[0]
            );

        }


        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }


        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );


            localStorage.removeItem(
                'eventify_user'
            );


            window.location.href =
                'login.php';

        }

    </script>


</body>

</html>