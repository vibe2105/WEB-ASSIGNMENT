<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Event Bookings - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        /*
        ========================================
        PAGE
        ========================================
        */

        body {
            min-height: 100vh;

            display: flex;
            flex-direction: column;
        }


        .bookings-shell {
            width: min(1180px, 92%);

            margin:
                0
                auto;

            flex: 1;
        }


        /*
        ========================================
        HEADER
        ========================================
        */

        .page-panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 24px;

            margin-bottom: 14px;

            padding:
                18px
                20px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 10px;

            background:
                linear-gradient(
                    135deg,
                    rgba(91, 42, 134, 0.22),
                    rgba(21, 17, 58, 0.82)
                );
        }


        .page-panel-header h2 {
            margin:
                0
                0
                6px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 22px;
            font-weight: 850;

            color: #ffffff;
        }


        .page-panel-header p {
            margin: 0;

            max-width: 720px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.55;

            color:
                rgba(255, 255, 255, 0.52);
        }


        /*
        ========================================
        COUNT CARD
        ========================================
        */

        .count-card {
            min-width: 165px;
            height: 62px;

            display: flex;
            align-items: center;

            gap: 11px;

            padding:
                10px
                13px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(224, 107, 174, 0.20);

            border-radius: 8px;

            background:
                rgba(255, 255, 255, 0.03);
        }


        .count-icon {
            width: 36px;
            height: 36px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 7px;

            background:
                rgba(224, 107, 174, 0.09);

            color: #E06BAE;
        }


        .count-icon svg {
            width: 17px;
            height: 17px;
        }


        .count-number {
            display: block;

            margin-bottom: 3px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 12px;

            color: #F6C58E;
        }


        .count-label {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;

            letter-spacing: 0.45px;

            color:
                rgba(255, 255, 255, 0.42);
        }


        /*
        ========================================
        MESSAGE
        ========================================
        */

        #bookingMessage:empty {
            display: none;
        }


        #bookingMessage {
            margin-bottom: 11px;
        }


        .notification {
            display: flex;
            align-items: center;

            gap: 10px;

            padding:
                10px
                12px;

            box-sizing: border-box;

            border-radius: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .notification.success {
            border:
                1px solid
                rgba(95, 180, 160, 0.26);

            background:
                rgba(95, 180, 160, 0.07);
        }


        .notification.error {
            border:
                1px solid
                rgba(230, 95, 120, 0.26);

            background:
                rgba(230, 95, 120, 0.07);
        }


        .notification-icon {
            width: 28px;
            height: 28px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 6px;

            font-size: 12px;
            font-weight: 850;
        }


        .notification.success
        .notification-icon {
            background:
                rgba(95, 180, 160, 0.12);

            color: #8FD8C6;
        }


        .notification.error
        .notification-icon {
            background:
                rgba(230, 95, 120, 0.12);

            color: #EF8295;
        }


        .notification-title {
            margin-bottom: 2px;

            font-size: 10px;
            font-weight: 850;

            color: #ffffff;
        }


        .notification-text {
            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.52);
        }


        /*
        ========================================
        TOOLBAR
        ========================================
        */

        .bookings-toolbar {
            display: grid;

            grid-template-columns:
                minmax(360px, 1fr)
                180px;

            gap: 10px;

            margin-bottom: 11px;
        }


        /*
        SEARCH
        */

        .search-wrapper {
            position: relative;
        }


        .search-icon {
            position: absolute;

            left: 14px;
            top: 50%;

            width: 17px;
            height: 17px;

            transform:
                translateY(-50%);

            pointer-events: none;

            color:
                rgba(255, 255, 255, 0.62);
        }


        .search-wrapper input {
            width: 100%;
            height: 46px;

            box-sizing: border-box;

            padding:
                0
                14px
                0
                43px;

            border:
                1px solid
                rgba(224, 107, 174, 0.22);

            border-radius: 7px;

            outline: none;

            background:
                rgba(255, 255, 255, 0.075);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
        }


        .search-wrapper input::placeholder {
            color:
                rgba(255, 255, 255, 0.40);
        }


        .search-wrapper input:focus {
            border-color:
                rgba(224, 107, 174, 0.48);

            box-shadow:
                0
                0
                0
                3px
                rgba(224, 107, 174, 0.05);
        }


        /*
        FILTER
        */

        .filter-select {
            width: 100%;
            height: 46px;

            padding:
                0
                12px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 7px;

            outline: none;

            background:
                rgba(255, 255, 255, 0.055);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 700;
        }


        .filter-select option {
            background: #1B1745;
        }


        /*
        ========================================
        TABLE WRAPPER
        ========================================
        */

        .table-wrapper {
            overflow-x: auto;

            border:
                1px solid
                rgba(255, 255, 255, 0.08);

            border-radius: 9px;

            background:
                rgba(255, 255, 255, 0.012);
        }


        /*
        ========================================
        TABLE
        ========================================
        */

        .bookings-table {
            width: 100%;
            min-width: 1110px;

            table-layout: fixed;

            border-collapse: collapse;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .bookings-table th {
            padding:
                12px
                10px;

            text-align: left;

            border-bottom:
                1px solid
                rgba(255, 255, 255, 0.08);

            background:
                rgba(255, 255, 255, 0.03);

            font-size: 9px;
            font-weight: 850;

            letter-spacing: 0.55px;

            color:
                rgba(255, 255, 255, 0.48);
        }


        .bookings-table td {
            height: 65px;

            box-sizing: border-box;

            padding:
                10px;

            border-bottom:
                1px solid
                rgba(255, 255, 255, 0.055);

            vertical-align: middle;

            font-size: 10px;
            line-height: 1.35;

            color:
                rgba(255, 255, 255, 0.68);
        }


        .bookings-table tbody tr {
            transition:
                background
                0.15s ease;
        }


        .bookings-table tbody tr:hover {
            background:
                rgba(255, 255, 255, 0.022);
        }


        .bookings-table tr:last-child td {
            border-bottom: none;
        }


        /*
        COLUMN WIDTH
        */

        .bookings-table th:nth-child(1),
        .bookings-table td:nth-child(1) {
            width: 60px;
        }


        .bookings-table th:nth-child(2),
        .bookings-table td:nth-child(2) {
            width: 170px;
        }


        .bookings-table th:nth-child(3),
        .bookings-table td:nth-child(3) {
            width: 230px;
        }


        .bookings-table th:nth-child(4),
        .bookings-table td:nth-child(4) {
            width: 155px;
        }


        .bookings-table th:nth-child(5),
        .bookings-table td:nth-child(5) {
            width: 80px;
        }


        .bookings-table th:nth-child(6),
        .bookings-table td:nth-child(6) {
            width: 100px;
        }


        .bookings-table th:nth-child(7),
        .bookings-table td:nth-child(7) {
            width: 120px;
        }


        .bookings-table th:nth-child(8),
        .bookings-table td:nth-child(8) {
            width: 120px;
        }


        /*
        ========================================
        BOOKING ID
        ========================================
        */

        .booking-id {
            font-size: 9px;
            font-weight: 850;

            color: #F6C58E;
        }


        /*
        ========================================
        CUSTOMER CELL
        ========================================
        */

        .customer-cell {
            min-width: 0;
        }


        .customer-name {
            display: block;

            margin-bottom: 3px;

            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;

            font-size: 10px;
            font-weight: 850;

            color: #ffffff;
        }


        .customer-email {
            display: block;

            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;

            font-size: 8px;

            color:
                rgba(255, 255, 255, 0.38);
        }


        /*
        ========================================
        EVENT CELL
        ========================================
        */

        .event-cell {
            display: flex;
            align-items: center;

            gap: 10px;

            min-width: 0;
        }


        .event-thumbnail {
            width: 52px;
            height: 39px;

            flex-shrink: 0;

            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.07);

            border-radius: 6px;

            background:
                linear-gradient(
                    135deg,
                    #241C56,
                    #5B2A86
                );
        }


        .event-thumbnail img {
            width: 100%;
            height: 100%;

            object-fit: cover;
        }


        .event-mini {
            min-width: 0;
        }


        .event-name {
            display: block;

            margin-bottom: 3px;

            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;

            font-size: 10px;
            font-weight: 850;

            color: #ffffff;
        }


        .event-date {
            display: block;

            font-size: 8px;

            color:
                rgba(255, 255, 255, 0.38);
        }


        /*
        ========================================
        VENUE
        ========================================
        */

        .venue-name {
            display: block;

            margin-bottom: 3px;

            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;

            font-size: 9px;
            font-weight: 700;

            color:
                rgba(255, 255, 255, 0.72);
        }


        .venue-location {
            display: block;

            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;

            font-size: 8px;

            color:
                rgba(255, 255, 255, 0.35);
        }


        /*
        ========================================
        QTY
        ========================================
        */

        .qty-badge {
            min-width: 34px;
            height: 28px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            padding:
                0
                7px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(224, 107, 174, 0.15);

            border-radius: 5px;

            background:
                rgba(224, 107, 174, 0.05);

            font-size: 9px;
            font-weight: 850;

            color: #ffffff;
        }


        /*
        ========================================
        TOTAL
        ========================================
        */

        .total-text {
            font-size: 10px;
            font-weight: 850;

            color: #F6C58E;
        }


        /*
        ========================================
        STATUS
        ========================================
        */

        .status-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 82px;
            height: 27px;

            box-sizing: border-box;

            padding:
                0
                8px;

            border-radius: 5px;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.2px;
        }


        .status-confirmed {
            border:
                1px solid
                rgba(143, 216, 198, 0.18);

            background:
                rgba(143, 216, 198, 0.07);

            color: #8FD8C6;
        }


        .status-cancelled {
            border:
                1px solid
                rgba(239, 130, 149, 0.18);

            background:
                rgba(239, 130, 149, 0.07);

            color: #EF8295;
        }


        /*
        ========================================
        ACTION
        ========================================
        */

        .manage-btn {
            min-width: 82px;
            height: 32px;

            border:
                1px solid
                rgba(224, 107, 174, 0.22);

            border-radius: 5px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            cursor: pointer;
        }


        .manage-btn:hover {
            opacity: 0.90;
        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        .pagination-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 12px;

            margin-top: 11px;
        }


        .pagination-info {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.44);
        }


        .pagination-controls {
            display: flex;
            align-items: center;

            gap: 7px;
        }


        .pagination-btn {
            min-width: 82px;
            height: 32px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 5px;

            background:
                rgba(255, 255, 255, 0.035);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;

            cursor: pointer;
        }


        .pagination-btn:hover:not(:disabled) {
            background:
                rgba(255, 255, 255, 0.07);
        }


        .pagination-btn:disabled {
            opacity: 0.25;

            cursor: not-allowed;
        }


        .pagination-page {
            min-width: 82px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 650;

            color:
                rgba(255, 255, 255, 0.50);
        }


        /*
        ========================================
        MODAL
        ========================================
        */

        .modal-overlay {
            position: fixed;

            inset: 0;

            z-index: 1000;

            display: none;
            align-items: center;
            justify-content: center;

            padding: 20px;

            box-sizing: border-box;

            background:
                rgba(4, 4, 20, 0.80);

            backdrop-filter:
                blur(8px);
        }


        .modal-overlay.active {
            display: flex;
        }


        .booking-modal {
            width: min(650px, 96vw);

            box-sizing: border-box;

            padding:
                22px;

            border:
                1px solid
                rgba(255, 255, 255, 0.12);

            border-radius: 11px;

            background:
                linear-gradient(
                    180deg,
                    #241C56,
                    #15113A
                );

            box-shadow:
                0
                30px
                80px
                rgba(0, 0, 0, 0.38);
        }


        /*
        ========================================
        MODAL HEADER
        ========================================
        */

        .modal-header {
            display: flex;
            align-items: start;
            justify-content: space-between;

            gap: 15px;

            margin-bottom: 18px;
        }


        .modal-header h3 {
            margin:
                0
                0
                5px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 20px;
            font-weight: 850;

            color: #ffffff;
        }


        .modal-header p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            line-height: 1.45;

            color:
                rgba(255, 255, 255, 0.43);
        }


        .modal-close {
            width: 33px;
            height: 33px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 6px;

            background:
                rgba(255, 255, 255, 0.035);

            color: #ffffff;

            font-size: 18px;

            cursor: pointer;
        }


        /*
        ========================================
        BOOKING SUMMARY
        ========================================
        */

        .booking-summary {
            display: grid;

            grid-template-columns:
                repeat(
                    2,
                    minmax(0, 1fr)
                );

            gap: 10px;

            margin-bottom: 16px;
        }


        .summary-item {
            min-width: 0;

            padding:
                11px
                12px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.07);

            border-radius: 7px;

            background:
                rgba(255, 255, 255, 0.022);
        }


        .summary-item.full {
            grid-column:
                1 / -1;
        }


        .summary-label {
            display: block;

            margin-bottom: 4px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 850;

            letter-spacing: 0.45px;

            color:
                rgba(255, 255, 255, 0.35);
        }


        .summary-value {
            display: block;

            overflow-wrap: anywhere;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 750;
            line-height: 1.4;

            color: #ffffff;
        }


        .summary-value.highlight {
            color: #F6C58E;
        }


        /*
        ========================================
        STATUS CONTROL
        ========================================
        */

        .status-control {
            margin-top: 4px;
        }


        .status-control label {
            display: block;

            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.5px;

            color:
                rgba(255, 255, 255, 0.58);
        }


        .status-control select {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                11px;

            border:
                1px solid
                rgba(255, 255, 255, 0.11);

            border-radius: 6px;

            outline: none;

            background:
                rgba(11, 11, 46, 0.52);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
        }


        .status-control select:focus {
            border-color:
                rgba(224, 107, 174, 0.50);

            box-shadow:
                0
                0
                0
                3px
                rgba(224, 107, 174, 0.05);
        }


        .status-control select option {
            background: #1B1745;
        }


        /*
        ========================================
        WARNING
        ========================================
        */

        .booking-warning {
            margin-top: 10px;

            padding:
                9px
                10px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(246, 197, 142, 0.16);

            border-radius: 6px;

            background:
                rgba(246, 197, 142, 0.045);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            line-height: 1.5;

            color:
                rgba(246, 197, 142, 0.82);
        }


        /*
        ========================================
        MODAL ACTIONS
        ========================================
        */

        .modal-actions {
            display: flex;
            justify-content: flex-end;

            gap: 8px;

            margin-top: 18px;
        }


        .modal-btn {
            min-width: 110px;
            height: 38px;

            border-radius: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            cursor: pointer;
        }


        .modal-btn.secondary {
            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            background:
                rgba(255, 255, 255, 0.035);

            color: #ffffff;
        }


        .modal-btn.primary {
            border:
                1px solid
                rgba(224, 107, 174, 0.25);

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            color: #ffffff;
        }


        .modal-btn:disabled {
            opacity: 0.45;

            cursor: wait;
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                10px !important;

            padding-top:
                10px !important;

            padding-bottom:
                10px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 850px) {

            .bookings-toolbar {
                grid-template-columns: 1fr;
            }


            .booking-summary {
                grid-template-columns: 1fr;
            }


            .summary-item.full {
                grid-column: auto;
            }

        }


        @media (max-width: 600px) {

            .page-panel-header {
                flex-direction: column;
                align-items: stretch;
            }


            .count-card {
                width: 100%;
            }

        }

    </style>

</head>


<body>


    <?php include 'navbar.php'; ?>


    <h1>EVENT BOOKINGS</h1>


    <div class="bookings-shell">


        <!--
        ========================================
        HEADER
        ========================================
        -->

        <section class="page-panel-header">


            <div>


                <h2>
                    Booking Management
                </h2>


                <p>

                    Review customer reservations for your events
                    and manage booking confirmation or cancellation status.

                </p>


            </div>


            <div class="count-card">


                <div class="count-icon">


                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <path
                            d="M4 5h16v14H4z"
                        ></path>

                        <path
                            d="M8 9h8"
                        ></path>

                        <path
                            d="M8 13h5"
                        ></path>

                    </svg>


                </div>


                <div>


                    <span
                        class="count-number"
                        id="bookingCount"
                    >
                        0
                    </span>


                    <span class="count-label">
                        BOOKINGS
                    </span>


                </div>


            </div>


        </section>


        <!--
        ========================================
        MESSAGE
        ========================================
        -->

        <div id="bookingMessage"></div>


        <!--
        ========================================
        TOOLBAR
        ========================================
        -->

        <div class="bookings-toolbar">


            <!-- SEARCH -->

            <div class="search-wrapper">


                <svg
                    class="search-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20l-3.5-3.5"
                    ></path>

                </svg>


                <input
                    type="text"
                    id="bookingSearch"
                    placeholder="Search customer, event, venue or Booking ID..."
                >


            </div>


            <!-- STATUS -->

            <select
                id="statusFilter"
                class="filter-select"
            >

                <option value="All">
                    All Status
                </option>

                <option value="Confirmed">
                    Confirmed
                </option>

                <option value="Cancelled">
                    Cancelled
                </option>

            </select>


        </div>


        <!--
        ========================================
        TABLE
        ========================================
        -->

        <div class="table-wrapper">


            <table class="bookings-table">


                <thead>


                    <tr>

                        <th>ID</th>

                        <th>CUSTOMER</th>

                        <th>EVENT</th>

                        <th>VENUE</th>

                        <th>QTY</th>

                        <th>TOTAL</th>

                        <th>STATUS</th>

                        <th>ACTION</th>

                    </tr>


                </thead>


                <tbody id="bookingsTableBody">


                    <tr>

                        <td colspan="8">
                            Loading bookings...
                        </td>

                    </tr>


                </tbody>


            </table>


        </div>


        <!--
        ========================================
        PAGINATION
        ========================================
        -->

        <div class="pagination-bar">


            <div
                class="pagination-info"
                id="paginationInfo"
            >
                Showing 0 bookings
            </div>


            <div class="pagination-controls">


                <button
                    type="button"
                    class="pagination-btn"
                    id="previousPageButton"
                    onclick="previousPage()"
                >
                    PREVIOUS
                </button>


                <div
                    class="pagination-page"
                    id="paginationPage"
                >
                    Page 1 of 1
                </div>


                <button
                    type="button"
                    class="pagination-btn"
                    id="nextPageButton"
                    onclick="nextPage()"
                >
                    NEXT
                </button>


            </div>


        </div>


    </div>


    <!--
    ========================================
    MANAGE MODAL
    ========================================
    -->

    <div
        class="modal-overlay"
        id="manageModal"
    >


        <div class="booking-modal">


            <!-- HEADER -->

            <div class="modal-header">


                <div>


                    <h3>
                        Manage Booking
                    </h3>


                    <p>

                        Review booking information and update the
                        reservation status for your event.

                    </p>


                </div>


                <button
                    type="button"
                    class="modal-close"
                    onclick="closeManageModal()"
                >
                    ×
                </button>


            </div>


            <!-- SUMMARY -->

            <div class="booking-summary">


                <!-- ID -->

                <div class="summary-item">


                    <span class="summary-label">
                        BOOKING ID
                    </span>


                    <span
                        class="summary-value highlight"
                        id="modalBookingId"
                    >
                        -
                    </span>


                </div>


                <!-- CUSTOMER -->

                <div class="summary-item">


                    <span class="summary-label">
                        CUSTOMER
                    </span>


                    <span
                        class="summary-value"
                        id="modalCustomer"
                    >
                        -
                    </span>


                </div>


                <!-- EVENT -->

                <div class="summary-item full">


                    <span class="summary-label">
                        EVENT
                    </span>


                    <span
                        class="summary-value"
                        id="modalEvent"
                    >
                        -
                    </span>


                </div>


                <!-- VENUE -->

                <div class="summary-item full">


                    <span class="summary-label">
                        VENUE
                    </span>


                    <span
                        class="summary-value"
                        id="modalVenue"
                    >
                        -
                    </span>


                </div>


                <!-- TICKETS -->

                <div class="summary-item">


                    <span class="summary-label">
                        TICKETS
                    </span>


                    <span
                        class="summary-value"
                        id="modalQuantity"
                    >
                        -
                    </span>


                </div>


                <!-- TOTAL -->

                <div class="summary-item">


                    <span class="summary-label">
                        TOTAL AMOUNT
                    </span>


                    <span
                        class="summary-value highlight"
                        id="modalTotal"
                    >
                        -
                    </span>


                </div>


                <!-- DATE -->

                <div class="summary-item full">


                    <span class="summary-label">
                        BOOKED ON
                    </span>


                    <span
                        class="summary-value"
                        id="modalBookingDate"
                    >
                        -
                    </span>


                </div>


            </div>


            <!-- STATUS -->

            <div class="status-control">


                <label for="manageStatus">
                    BOOKING STATUS
                </label>


                <select id="manageStatus">


                    <option value="Confirmed">
                        Confirmed
                    </option>


                    <option value="Cancelled">
                        Cancelled
                    </option>


                </select>


            </div>


            <!-- WARNING -->

            <div
                class="booking-warning"
                id="bookingWarning"
            >
                Booking status changes may automatically update
                the event's available ticket quantity.
            </div>


            <!-- ACTION -->

            <div class="modal-actions">


                <button
                    type="button"
                    class="modal-btn secondary"
                    onclick="closeManageModal()"
                >
                    CANCEL
                </button>


                <button
                    type="button"
                    class="modal-btn primary"
                    id="saveBookingButton"
                    onclick="updateBooking()"
                >
                    SAVE CHANGES
                </button>


            </div>


        </div>


    </div>


    <!--
    ========================================
    FOOTER
    ========================================
    -->

    <div class="footer">

        EVENTIFY ORGANISER PORTAL

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        SESSION
        ========================================
        */

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser =
            null;


        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }


            if (
                currentUser &&
                currentUser.role !==
                'Organiser'
            ) {

                window.location.href =
                    'login.php';

            }

        }


        /*
        ========================================
        DATA
        ========================================
        */

        let allBookings =
            [];


        let filteredBookings =
            [];


        let selectedBooking =
            null;


        const bookingsPerPage =
            5;


        let currentPage =
            1;


        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const bookingsTableBody =
            document.getElementById(
                'bookingsTableBody'
            );


        const bookingSearch =
            document.getElementById(
                'bookingSearch'
            );


        const statusFilter =
            document.getElementById(
                'statusFilter'
            );


        /*
        ========================================
        INIT
        ========================================
        */

        loadBookings();


        bookingSearch.addEventListener(
            'input',
            function() {

                currentPage =
                    1;


                filterBookings();

            }
        );


        statusFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterBookings();

            }
        );


        /*
        ========================================
        LOAD BOOKINGS
        ========================================
        */

        async function loadBookings() {

            try {

                const response =
                    await fetch(
                        '../api/bookings.php',
                        {

                            headers: {

                                'Authorization':
                                    `Bearer ${token}`

                            }

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    'success'
                ) {

                    throw new Error(
                        result.message ||
                        'Unable to load bookings.'
                    );

                }


                /*
                Backend organiser GET should
                already return bookings for
                own events only.
                */

                allBookings =
                    result.data ||
                    [];


                document
                    .getElementById(
                        'bookingCount'
                    )
                    .textContent =
                        allBookings.length;


                filterBookings();

            }

            catch (error) {

                console.error(
                    'Bookings error:',
                    error
                );


                bookingsTableBody.innerHTML = `

                    <tr>

                        <td
                            colspan="8"
                            style="
                                text-align:center;
                                padding:32px;
                                font-size:11px;
                            "
                        >
                            Unable to load bookings.
                        </td>

                    </tr>

                `;


                showNotification(
                    'error',
                    'Unable to load bookings',
                    error.message ||
                    'Booking data could not be retrieved.'
                );

            }

        }


        /*
        ========================================
        FILTER
        ========================================
        */

        function filterBookings() {

            const search =
                bookingSearch
                    .value
                    .trim()
                    .toLowerCase();


            const status =
                statusFilter.value;


            filteredBookings =
                allBookings.filter(
                    function(booking) {


                        const bookingId =
                            String(
                                booking.booking_id ||
                                ''
                            )
                            .toLowerCase();


                        const customerName =
                            String(
                                booking.customer_name
                                ??
                                booking.user_name
                                ??
                                booking.name
                                ??
                                ''
                            )
                            .toLowerCase();


                        const customerEmail =
                            String(
                                booking.customer_email
                                ??
                                booking.email
                                ??
                                ''
                            )
                            .toLowerCase();


                        const eventName =
                            String(
                                booking.event_name ||
                                ''
                            )
                            .toLowerCase();


                        const venueName =
                            String(
                                booking.venue_name ||
                                ''
                            )
                            .toLowerCase();


                        const location =
                            String(
                                booking.location ||
                                ''
                            )
                            .toLowerCase();


                        const matchesSearch =

                            !search

                            ||

                            bookingId.includes(
                                search
                            )

                            ||

                            customerName.includes(
                                search
                            )

                            ||

                            customerEmail.includes(
                                search
                            )

                            ||

                            eventName.includes(
                                search
                            )

                            ||

                            venueName.includes(
                                search
                            )

                            ||

                            location.includes(
                                search
                            );


                        const matchesStatus =

                            status ===
                            'All'

                            ||

                            booking.booking_status ===
                            status;


                        return (
                            matchesSearch &&
                            matchesStatus
                        );

                    }
                );


            const totalPages =
                getTotalPages();


            if (
                currentPage >
                totalPages
            ) {

                currentPage =
                    totalPages;

            }


            if (
                currentPage <
                1
            ) {

                currentPage =
                    1;

            }


            displayBookings();

        }


        /*
        ========================================
        DISPLAY BOOKINGS
        ========================================
        */

        function displayBookings() {

            if (
                filteredBookings.length ===
                0
            ) {

                bookingsTableBody.innerHTML = `

                    <tr>

                        <td
                            colspan="8"
                            style="
                                text-align:center;
                                padding:32px;
                                font-size:11px;
                            "
                        >
                            No bookings found.
                        </td>

                    </tr>

                `;


                updatePagination();

                return;

            }


            const start =
                (
                    currentPage -
                    1
                )
                *
                bookingsPerPage;


            const pageBookings =
                filteredBookings.slice(

                    start,

                    start +
                    bookingsPerPage

                );


            bookingsTableBody.innerHTML =
                '';


            pageBookings.forEach(
                function(booking) {


                    const quantity =
                        Number(
                            booking.quantity
                            ??
                            booking.ticket_quantity
                            ??
                            0
                        );


                    const total =
                        Number(
                            booking.total_amount
                            ??
                            booking.total_price
                            ??
                            0
                        );


                    const customerName =

                        booking.customer_name
                        ??
                        booking.user_name
                        ??
                        booking.name
                        ??
                        'Customer';


                    const customerEmail =

                        booking.customer_email
                        ??
                        booking.email
                        ??
                        '';


                    bookingsTableBody.innerHTML += `

                        <tr>


                            <!-- ID -->

                            <td>

                                <span class="booking-id">

                                    #${booking.booking_id}

                                </span>

                            </td>


                            <!-- CUSTOMER -->

                            <td>


                                <div class="customer-cell">


                                    <span class="customer-name">

                                        ${escapeHtml(
                                            customerName
                                        )}

                                    </span>


                                    <span class="customer-email">

                                        ${escapeHtml(
                                            customerEmail ||
                                            'Eventify Customer'
                                        )}

                                    </span>


                                </div>


                            </td>


                            <!-- EVENT -->

                            <td>


                                <div class="event-cell">


                                    <div class="event-thumbnail">


                                        <img
                                            src="assets/events/event-${booking.event_id}.jpg?v=${Date.now()}"
                                            alt=""
                                            onerror="
                                                this.style.display='none'
                                            "
                                        >


                                    </div>


                                    <div class="event-mini">


                                        <span class="event-name">

                                            ${escapeHtml(
                                                booking.event_name ||
                                                'Untitled Event'
                                            )}

                                        </span>


                                        <span class="event-date">

                                            ${formatDate(
                                                booking.event_date
                                            )}

                                        </span>


                                    </div>


                                </div>


                            </td>


                            <!-- VENUE -->

                            <td>


                                <span class="venue-name">

                                    ${escapeHtml(
                                        booking.venue_name ||
                                        'Venue TBA'
                                    )}

                                </span>


                                <span class="venue-location">

                                    ${escapeHtml(
                                        booking.location ||
                                        '-'
                                    )}

                                </span>


                            </td>


                            <!-- QTY -->

                            <td>

                                <span class="qty-badge">

                                    ${quantity}

                                </span>

                            </td>


                            <!-- TOTAL -->

                            <td>

                                <span class="total-text">

                                    RM ${total.toFixed(
                                        2
                                    )}

                                </span>

                            </td>


                            <!-- STATUS -->

                            <td>

                                <span
                                    class="
                                        status-badge
                                        ${
                                            booking.booking_status ===
                                            'Cancelled'

                                            ?
                                            'status-cancelled'

                                            :
                                            'status-confirmed'
                                        }
                                    "
                                >

                                    ${escapeHtml(
                                        booking.booking_status ||
                                        '-'
                                    )}

                                </span>

                            </td>


                            <!-- ACTION -->

                            <td>


                                <button
                                    type="button"
                                    class="manage-btn"
                                    onclick="openManageModal(
                                        ${booking.booking_id}
                                    )"
                                >
                                    MANAGE
                                </button>


                            </td>


                        </tr>

                    `;

                }
            );


            updatePagination();

        }


        /*
        ========================================
        OPEN MANAGE MODAL
        ========================================
        */

        function openManageModal(
            bookingId
        ) {

            selectedBooking =
                allBookings.find(
                    function(booking) {

                        return (
                            Number(
                                booking.booking_id
                            )
                            ===
                            Number(
                                bookingId
                            )
                        );

                    }
                );


            if (!selectedBooking) {

                return;

            }


            const customerName =

                selectedBooking.customer_name
                ??
                selectedBooking.user_name
                ??
                selectedBooking.name
                ??
                'Customer';


            const customerEmail =

                selectedBooking.customer_email
                ??
                selectedBooking.email
                ??
                '';


            const quantity =
                Number(
                    selectedBooking.quantity
                    ??
                    selectedBooking.ticket_quantity
                    ??
                    0
                );


            const total =
                Number(
                    selectedBooking.total_amount
                    ??
                    selectedBooking.total_price
                    ??
                    0
                );


            document
                .getElementById(
                    'modalBookingId'
                )
                .textContent =
                    `#${selectedBooking.booking_id}`;


            document
                .getElementById(
                    'modalCustomer'
                )
                .textContent =
                    customerEmail
                    ?
                    `${customerName} • ${customerEmail}`
                    :
                    customerName;


            document
                .getElementById(
                    'modalEvent'
                )
                .textContent =
                    selectedBooking.event_name ||
                    '-';


            document
                .getElementById(
                    'modalVenue'
                )
                .textContent =
                    selectedBooking.location

                    ?
                    `${selectedBooking.venue_name || 'Venue TBA'} • ${selectedBooking.location}`

                    :
                    (
                        selectedBooking.venue_name ||
                        'Venue TBA'
                    );


            document
                .getElementById(
                    'modalQuantity'
                )
                .textContent =
                    `${quantity} ticket(s)`;


            document
                .getElementById(
                    'modalTotal'
                )
                .textContent =
                    `RM ${total.toFixed(2)}`;


            document
                .getElementById(
                    'modalBookingDate'
                )
                .textContent =
                    formatDateTime(

                        selectedBooking.booking_date
                        ??
                        selectedBooking.created_at
                        ??
                        ''

                    );


            document
                .getElementById(
                    'manageStatus'
                )
                .value =
                    selectedBooking.booking_status ||
                    'Confirmed';


            updateWarning();


            document
                .getElementById(
                    'manageModal'
                )
                .classList.add(
                    'active'
                );

        }


        /*
        ========================================
        CLOSE MODAL
        ========================================
        */

        function closeManageModal() {

            document
                .getElementById(
                    'manageModal'
                )
                .classList.remove(
                    'active'
                );


            selectedBooking =
                null;

        }


        /*
        ========================================
        STATUS CHANGE WARNING
        ========================================
        */

        document
            .getElementById(
                'manageStatus'
            )
            .addEventListener(
                'change',
                updateWarning
            );


        function updateWarning() {

            if (!selectedBooking) {

                return;

            }


            const originalStatus =
                selectedBooking.booking_status;


            const newStatus =
                document
                    .getElementById(
                        'manageStatus'
                    )
                    .value;


            const warning =
                document.getElementById(
                    'bookingWarning'
                );


            if (
                originalStatus ===
                newStatus
            ) {

                warning.textContent =
                    'No status change selected. Booking details will remain unchanged.';


                return;

            }


            if (
                originalStatus ===
                'Confirmed'
                &&
                newStatus ===
                'Cancelled'
            ) {

                warning.textContent =
                    'Confirmed → Cancelled: the booked ticket quantity will be returned to the event availability.';


                return;

            }


            if (
                originalStatus ===
                'Cancelled'
                &&
                newStatus ===
                'Confirmed'
            ) {

                warning.textContent =
                    'Cancelled → Confirmed: Eventify will check ticket availability before confirming and deduct the required tickets.';


                return;

            }


            warning.textContent =
                'Booking status changes may automatically update the event available ticket quantity.';

        }


        /*
        ========================================
        UPDATE BOOKING
        ========================================
        */

        async function updateBooking() {

            if (!selectedBooking) {

                return;

            }


            const newStatus =
                document
                    .getElementById(
                        'manageStatus'
                    )
                    .value;


            const originalStatus =
                selectedBooking.booking_status;


            /*
            No change
            */

            if (
                originalStatus ===
                newStatus
            ) {

                closeManageModal();


                showNotification(
                    'success',
                    'No changes required',
                    'The booking status is already up to date.'
                );


                return;

            }


            let confirmationText =
                `Change booking #${selectedBooking.booking_id} from ${originalStatus} to ${newStatus}?`;


            if (
                originalStatus ===
                'Confirmed'
                &&
                newStatus ===
                'Cancelled'
            ) {

                confirmationText +=

                    '\n\nThe booked tickets will be returned to the event availability.';

            }


            if (
                originalStatus ===
                'Cancelled'
                &&
                newStatus ===
                'Confirmed'
            ) {

                confirmationText +=

                    '\n\nEventify will check availability and deduct the required tickets if enough tickets remain.';

            }


            const confirmed =
                confirm(
                    confirmationText
                );


            if (!confirmed) {

                return;

            }


            const button =
                document.getElementById(
                    'saveBookingButton'
                );


            button.disabled =
                true;


            button.textContent =
                'SAVING...';


            try {

                const response =
                    await fetch(
                        '../api/bookings.php',
                        {

                            method:
                                'PUT',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    booking_id:
                                        Number(
                                            selectedBooking.booking_id
                                        ),

                                    booking_status:
                                        newStatus

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    'success'
                ) {

                    throw new Error(
                        result.message ||
                        'Unable to update booking.'
                    );

                }


                closeManageModal();


                showNotification(
                    'success',
                    'Booking updated',
                    `Booking #${selectedBooking?.booking_id ?? ''} status was updated successfully.`
                );


                await loadBookings();

            }

            catch (error) {

                console.error(
                    'Update booking error:',
                    error
                );


                showNotification(
                    'error',
                    'Update failed',
                    error.message ||
                    'Unable to update booking status.'
                );

            }

            finally {

                button.disabled =
                    false;


                button.textContent =
                    'SAVE CHANGES';

            }

        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        function getTotalPages() {

            return Math.max(

                1,

                Math.ceil(
                    filteredBookings.length /
                    bookingsPerPage
                )

            );

        }


        function updatePagination() {

            const totalPages =
                getTotalPages();


            const start =

                filteredBookings.length ===
                0

                ? 0

                : (
                    (
                        currentPage -
                        1
                    )
                    *
                    bookingsPerPage
                )
                +
                1;


            const end =
                Math.min(

                    currentPage *
                    bookingsPerPage,

                    filteredBookings.length

                );


            document
                .getElementById(
                    'paginationInfo'
                )
                .textContent =

                    filteredBookings.length ===
                    0

                    ?
                    'Showing 0 bookings'

                    :
                    `Showing ${start}-${end} of ${filteredBookings.length} bookings`;


            document
                .getElementById(
                    'paginationPage'
                )
                .textContent =
                    `Page ${currentPage} of ${totalPages}`;


            document
                .getElementById(
                    'previousPageButton'
                )
                .disabled =
                    currentPage <=
                    1;


            document
                .getElementById(
                    'nextPageButton'
                )
                .disabled =
                    currentPage >=
                    totalPages;

        }


        function previousPage() {

            if (
                currentPage <=
                1
            ) {

                return;

            }


            currentPage--;


            displayBookings();

        }


        function nextPage() {

            if (
                currentPage >=
                getTotalPages()
            ) {

                return;

            }


            currentPage++;


            displayBookings();

        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        function showNotification(
            type,
            title,
            text
        ) {

            const container =
                document.getElementById(
                    'bookingMessage'
                );


            container.innerHTML = `

                <div
                    class="
                        notification
                        ${type}
                    "
                >


                    <div class="notification-icon">

                        ${
                            type ===
                            'success'

                            ?
                            '✓'

                            :
                            '!'
                        }

                    </div>


                    <div>


                        <div class="notification-title">

                            ${escapeHtml(
                                title
                            )}

                        </div>


                        <div class="notification-text">

                            ${escapeHtml(
                                text
                            )}

                        </div>


                    </div>


                </div>

            `;


            setTimeout(
                function() {

                    container.innerHTML =
                        '';

                },
                4000
            );

        }


        /*
        ========================================
        DATE
        ========================================
        */

        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const parts =
                String(
                    value
                )
                .substring(
                    0,
                    10
                )
                .split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return value;

            }


            return (
                parts[2]
                +
                '/'
                +
                parts[1]
                +
                '/'
                +
                parts[0]
            );

        }


        /*
        ========================================
        DATE TIME
        ========================================
        */

        function formatDateTime(
            value
        ) {

            if (!value) {

                return '-';

            }


            const text =
                String(
                    value
                );


            const date =
                formatDate(
                    text
                );


            let time =
                '';


            if (
                text.length >=
                16
            ) {

                time =
                    text.substring(
                        11,
                        16
                    );

            }


            return (
                time
                ?
                `${date} • ${time}`
                :
                date
            );

        }


        /*
        ========================================
        SESSION
        ========================================
        */

        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );


            localStorage.removeItem(
                'eventify_user'
            );


            window.location.href =
                'login.php';

        }


        /*
        ========================================
        ESCAPE
        ========================================
        */

        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    </script>


</body>

</html>