<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Events - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        /*
        ========================================
        PAGE
        ========================================
        */

        body {
            min-height: 100vh;

            display: flex;
            flex-direction: column;
        }


        .events-shell {
            width: min(1180px, 92%);

            margin:
                0
                auto;

            flex: 1;
        }


        /*
        ========================================
        HEADER
        ========================================
        */

        .page-panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 24px;

            margin-bottom: 14px;

            padding:
                18px
                20px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 10px;

            background:
                linear-gradient(
                    135deg,
                    rgba(91, 42, 134, 0.22),
                    rgba(21, 17, 58, 0.82)
                );
        }


        .page-panel-header h2 {
            margin:
                0
                0
                6px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 22px;
            font-weight: 850;

            color: #ffffff;
        }


        .page-panel-header p {
            margin: 0;

            max-width: 700px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.55;

            color:
                rgba(255, 255, 255, 0.52);
        }


        /*
        ========================================
        COUNT CARD
        ========================================
        */

        .count-card {
            min-width: 150px;
            height: 62px;

            display: flex;
            align-items: center;

            gap: 11px;

            padding:
                10px
                13px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(224, 107, 174, 0.20);

            border-radius: 8px;

            background:
                rgba(255, 255, 255, 0.03);
        }


        .count-icon {
            width: 36px;
            height: 36px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 7px;

            background:
                rgba(224, 107, 174, 0.09);

            color: #E06BAE;
        }


        .count-icon svg {
            width: 17px;
            height: 17px;
        }


        .count-number {
            display: block;

            margin-bottom: 3px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 12px;

            color: #F6C58E;
        }


        .count-label {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;

            letter-spacing: 0.45px;

            color:
                rgba(255, 255, 255, 0.42);
        }


        /*
        ========================================
        MESSAGE
        ========================================
        */

        #eventMessage:empty {
            display: none;
        }


        #eventMessage {
            margin-bottom: 11px;
        }


        .notification {
            display: flex;
            align-items: center;

            gap: 10px;

            padding:
                10px
                12px;

            box-sizing: border-box;

            border-radius: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .notification.success {
            border:
                1px solid
                rgba(95, 180, 160, 0.26);

            background:
                rgba(95, 180, 160, 0.07);
        }


        .notification.error {
            border:
                1px solid
                rgba(230, 95, 120, 0.26);

            background:
                rgba(230, 95, 120, 0.07);
        }


        .notification-icon {
            width: 28px;
            height: 28px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 6px;

            font-size: 12px;
            font-weight: 850;
        }


        .notification.success
        .notification-icon {
            background:
                rgba(95, 180, 160, 0.12);

            color: #8FD8C6;
        }


        .notification.error
        .notification-icon {
            background:
                rgba(230, 95, 120, 0.12);

            color: #EF8295;
        }


        .notification-title {
            margin-bottom: 2px;

            font-size: 10px;
            font-weight: 850;

            color: #ffffff;
        }


        .notification-text {
            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.52);
        }


        /*
        ========================================
        TOOLBAR
        ========================================
        */

        .events-toolbar {
            display: grid;

            grid-template-columns:
                minmax(360px, 1fr)
                180px
                160px;

            gap: 10px;

            margin-bottom: 11px;
        }


        /*
        SEARCH
        */

        .search-wrapper {
            position: relative;
        }


        .search-icon {
            position: absolute;

            left: 14px;
            top: 50%;

            width: 17px;
            height: 17px;

            transform:
                translateY(-50%);

            pointer-events: none;

            color:
                rgba(255, 255, 255, 0.62);
        }


        .search-wrapper input {
            width: 100%;
            height: 46px;

            box-sizing: border-box;

            padding:
                0
                14px
                0
                43px;

            border:
                1px solid
                rgba(224, 107, 174, 0.22);

            border-radius: 7px;

            outline: none;

            background:
                rgba(255, 255, 255, 0.075);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
        }


        .search-wrapper input::placeholder {
            color:
                rgba(255, 255, 255, 0.40);
        }


        .search-wrapper input:focus {
            border-color:
                rgba(224, 107, 174, 0.48);

            box-shadow:
                0
                0
                0
                3px
                rgba(224, 107, 174, 0.05);
        }


        /*
        FILTER
        */

        .filter-select {
            width: 100%;
            height: 46px;

            padding:
                0
                12px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 7px;

            outline: none;

            background:
                rgba(255, 255, 255, 0.055);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 700;
        }


        .filter-select option {
            background: #1B1745;
        }


        /*
        CREATE BUTTON
        */

        .create-event-btn {
            height: 46px;

            display: flex;
            align-items: center;
            justify-content: center;

            gap: 7px;

            border:
                1px solid
                rgba(224, 107, 174, 0.26);

            border-radius: 7px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            letter-spacing: 0.3px;

            cursor: pointer;
        }


        .create-event-btn:hover {
            opacity: 0.92;

            transform:
                translateY(-1px);
        }


        /*
        ========================================
        TABLE WRAPPER
        ========================================
        */

        .table-wrapper {
            overflow-x: auto;

            border:
                1px solid
                rgba(255, 255, 255, 0.08);

            border-radius: 9px;

            background:
                rgba(255, 255, 255, 0.012);
        }


        /*
        ========================================
        TABLE
        ========================================
        */

        .events-table {
            width: 100%;
            min-width: 1100px;

            table-layout: fixed;

            border-collapse: collapse;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        /*
        HEADER
        */

        .events-table th {
            padding:
                12px
                10px;

            text-align: left;

            border-bottom:
                1px solid
                rgba(255, 255, 255, 0.08);

            background:
                rgba(255, 255, 255, 0.03);

            font-size: 9px;
            font-weight: 850;

            letter-spacing: 0.55px;

            color:
                rgba(255, 255, 255, 0.48);
        }


        /*
        CELL
        */

        .events-table td {
            height: 65px;

            box-sizing: border-box;

            padding:
                10px;

            border-bottom:
                1px solid
                rgba(255, 255, 255, 0.055);

            vertical-align: middle;

            font-size: 10px;
            line-height: 1.35;

            color:
                rgba(255, 255, 255, 0.68);
        }


        .events-table tbody tr {
            transition:
                background
                0.15s ease;
        }


        .events-table tbody tr:hover {
            background:
                rgba(255, 255, 255, 0.022);
        }


        .events-table tr:last-child td {
            border-bottom: none;
        }


        /*
        COLUMN WIDTH
        */

        .events-table th:nth-child(1),
        .events-table td:nth-child(1) {
            width: 55px;
        }


        .events-table th:nth-child(2),
        .events-table td:nth-child(2) {
            width: 250px;
        }


        .events-table th:nth-child(3),
        .events-table td:nth-child(3) {
            width: 165px;
        }


        .events-table th:nth-child(4),
        .events-table td:nth-child(4) {
            width: 110px;
        }


        .events-table th:nth-child(5),
        .events-table td:nth-child(5) {
            width: 95px;
        }


        .events-table th:nth-child(6),
        .events-table td:nth-child(6) {
            width: 105px;
        }


        .events-table th:nth-child(7),
        .events-table td:nth-child(7) {
            width: 115px;
        }


        .events-table th:nth-child(8),
        .events-table td:nth-child(8) {
            width: 120px;
        }


        /*
        ========================================
        EVENT CELL
        ========================================
        */

        .event-cell {
            display: flex;
            align-items: center;

            gap: 11px;

            min-width: 0;
        }


        .event-thumbnail {
            width: 58px;
            height: 43px;

            flex-shrink: 0;

            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.07);

            border-radius: 6px;

            background:
                linear-gradient(
                    135deg,
                    #241C56,
                    #5B2A86
                );
        }


        .event-thumbnail img {
            width: 100%;
            height: 100%;

            object-fit: cover;
        }


        .event-details-mini {
            min-width: 0;
        }


        .event-name {
            display: block;

            margin-bottom: 4px;

            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;

            font-size: 11px;
            font-weight: 850;

            color: #ffffff;
        }


        .event-category {
            display: block;

            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;

            font-size: 8px;
            font-weight: 650;

            color:
                rgba(255, 255, 255, 0.38);
        }


        /*
        ========================================
        ID
        ========================================
        */

        .event-id {
            font-size: 9px;
            font-weight: 800;

            color: #F6C58E;
        }


        /*
        ========================================
        VENUE
        ========================================
        */

        .venue-text {
            display: block;

            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;

            font-size: 9px;
            font-weight: 650;

            color:
                rgba(255, 255, 255, 0.70);
        }


        /*
        ========================================
        PRICE
        ========================================
        */

        .price-text {
            font-size: 10px;
            font-weight: 850;

            color: #F6C58E;
        }


        /*
        ========================================
        TICKETS
        ========================================
        */

        .ticket-count {
            font-size: 10px;
            font-weight: 800;

            color: #ffffff;
        }


        .ticket-count span {
            color:
                rgba(255, 255, 255, 0.38);
        }


        /*
        ========================================
        STATUS
        ========================================
        */

        .status-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 78px;
            height: 26px;

            box-sizing: border-box;

            padding:
                0
                8px;

            border-radius: 5px;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.2px;
        }


        .status-upcoming {
            border:
                1px solid
                rgba(143, 216, 198, 0.16);

            background:
                rgba(143, 216, 198, 0.07);

            color: #8FD8C6;
        }


        .status-ongoing {
            border:
                1px solid
                rgba(246, 197, 142, 0.17);

            background:
                rgba(246, 197, 142, 0.07);

            color: #F6C58E;
        }


        .status-completed {
            border:
                1px solid
                rgba(169, 185, 236, 0.17);

            background:
                rgba(169, 185, 236, 0.07);

            color: #A9B9EC;
        }


        .status-cancelled {
            border:
                1px solid
                rgba(239, 130, 149, 0.18);

            background:
                rgba(239, 130, 149, 0.07);

            color: #EF8295;
        }


        /*
        ========================================
        ACTION
        ========================================
        */

        .action-group {
            display: flex;
            align-items: center;

            gap: 6px;
        }


        .manage-btn {
            min-width: 76px;
            height: 32px;

            border:
                1px solid
                rgba(224, 107, 174, 0.22);

            border-radius: 5px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            cursor: pointer;
        }


        .manage-btn:hover {
            opacity: 0.90;
        }


        .delete-btn {
            width: 34px;
            height: 32px;

            display: flex;
            align-items: center;
            justify-content: center;

            padding: 0;

            border:
                1px solid
                rgba(239, 130, 149, 0.20);

            border-radius: 5px;

            background:
                rgba(239, 130, 149, 0.06);

            color: #EF8295;

            cursor: pointer;
        }


        .delete-btn:hover {
            background:
                rgba(239, 130, 149, 0.12);
        }


        .delete-btn svg {
            width: 14px;
            height: 14px;
        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        .pagination-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 12px;

            margin-top: 11px;
        }


        .pagination-info {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.44);
        }


        .pagination-controls {
            display: flex;
            align-items: center;

            gap: 7px;
        }


        .pagination-btn {
            min-width: 82px;
            height: 32px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 5px;

            background:
                rgba(255, 255, 255, 0.035);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;

            cursor: pointer;
        }


        .pagination-btn:hover:not(:disabled) {
            background:
                rgba(255, 255, 255, 0.07);
        }


        .pagination-btn:disabled {
            opacity: 0.25;

            cursor: not-allowed;
        }


        .pagination-page {
            min-width: 82px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 650;

            color:
                rgba(255, 255, 255, 0.50);
        }


        /*
        ========================================
        MODAL
        ========================================
        */

        .modal-overlay {
            position: fixed;

            inset: 0;

            z-index: 1000;

            display: none;
            align-items: center;
            justify-content: center;

            padding: 20px;

            box-sizing: border-box;

            background:
                rgba(4, 4, 20, 0.80);

            backdrop-filter:
                blur(8px);
        }


        .modal-overlay.active {
            display: flex;
        }


        .event-modal {
            width: min(780px, 96vw);
            max-height: 92vh;

            overflow-y: auto;

            box-sizing: border-box;

            padding:
                22px;

            border:
                1px solid
                rgba(255, 255, 255, 0.12);

            border-radius: 11px;

            background:
                linear-gradient(
                    180deg,
                    #241C56,
                    #15113A
                );

            box-shadow:
                0
                30px
                80px
                rgba(0, 0, 0, 0.38);
        }


        /*
        MODAL HEADER
        */

        .modal-header {
            display: flex;
            align-items: start;
            justify-content: space-between;

            gap: 15px;

            margin-bottom: 18px;
        }


        .modal-header h3 {
            margin:
                0
                0
                5px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 20px;
            font-weight: 850;

            color: #ffffff;
        }


        .modal-header p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            line-height: 1.45;

            color:
                rgba(255, 255, 255, 0.43);
        }


        .modal-close {
            width: 33px;
            height: 33px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 6px;

            background:
                rgba(255, 255, 255, 0.035);

            color: #ffffff;

            font-size: 18px;

            cursor: pointer;
        }


        /*
        ========================================
        FORM GRID
        ========================================
        */

        .form-grid {
            display: grid;

            grid-template-columns:
                repeat(
                    2,
                    minmax(0, 1fr)
                );

            gap:
                14px
                14px;
        }


        .form-group {
            min-width: 0;
        }


        .form-group.full {
            grid-column:
                1 / -1;
        }


        .form-group label {
            display: block;

            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.5px;

            color:
                rgba(255, 255, 255, 0.58);
        }


        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.11);

            border-radius: 6px;

            outline: none;

            background:
                rgba(11, 11, 46, 0.52);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
        }


        .form-group input,
        .form-group select {
            height: 42px;

            padding:
                0
                11px;
        }


        .form-group textarea {
            min-height: 82px;

            padding:
                10px
                11px;

            resize: vertical;

            line-height: 1.5;
        }


        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color:
                rgba(224, 107, 174, 0.50);

            box-shadow:
                0
                0
                0
                3px
                rgba(224, 107, 174, 0.05);
        }


        .form-group select option {
            background: #1B1745;
        }


        /*
        ========================================
        IMAGE UPLOAD
        ========================================
        */

        .image-upload-area {
            display: grid;

            grid-template-columns:
                190px
                minmax(0, 1fr);

            gap: 14px;

            align-items: stretch;

            padding:
                11px;

            border:
                1px solid
                rgba(224, 107, 174, 0.16);

            border-radius: 8px;

            background:
                rgba(224, 107, 174, 0.026);
        }


        .image-preview {
            position: relative;

            width: 100%;
            height: 118px;

            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.06);

            border-radius: 7px;

            background:
                linear-gradient(
                    135deg,
                    #1B1745,
                    #5B2A86
                );
        }


        .image-preview img {
            width: 100%;
            height: 100%;

            display: none;

            object-fit: cover;
        }


        .image-preview img.active {
            display: block;
        }


        .image-preview-placeholder {
            position: absolute;

            inset: 0;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-direction: column;

            gap: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 700;

            color:
                rgba(255, 255, 255, 0.38);
        }


        .image-preview-placeholder svg {
            width: 27px;
            height: 27px;

            color: #E06BAE;
        }


        .image-upload-content {
            display: flex;
            justify-content: center;

            flex-direction: column;
        }


        .image-upload-title {
            margin-bottom: 5px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            font-weight: 850;

            color: #ffffff;
        }


        .image-upload-description {
            margin-bottom: 10px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.42);
        }


        .image-file-input {
            height: auto !important;

            padding:
                8px !important;

            cursor: pointer;
        }


        /*
        ========================================
        HOLIDAY CHECK
        ========================================
        */

        .holiday-check {
            margin-top: 7px;

            min-height: 30px;

            display: flex;
            align-items: center;

            box-sizing: border-box;

            padding:
                7px
                9px;

            border:
                1px solid
                rgba(255, 255, 255, 0.055);

            border-radius: 5px;

            background:
                rgba(255, 255, 255, 0.018);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            line-height: 1.4;

            color:
                rgba(255, 255, 255, 0.42);
        }


        .holiday-check.loading {
            color: #F6C58E;
        }


        .holiday-check.clear {
            border-color:
                rgba(143, 216, 198, 0.16);

            color: #8FD8C6;
        }


        .holiday-check.holiday {
            border-color:
                rgba(246, 197, 142, 0.19);

            background:
                rgba(246, 197, 142, 0.04);

            color: #F6C58E;
        }


        .holiday-check.error {
            border-color:
                rgba(239, 130, 149, 0.15);

            color: #EF8295;
        }


        /*
        ========================================
        MODAL ACTION
        ========================================
        */

        .modal-actions {
            display: flex;
            justify-content: flex-end;

            gap: 8px;

            margin-top: 18px;
        }


        .modal-btn {
            min-width: 110px;
            height: 38px;

            border-radius: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            cursor: pointer;
        }


        .modal-btn.secondary {
            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            background:
                rgba(255, 255, 255, 0.035);

            color: #ffffff;
        }


        .modal-btn.primary {
            border:
                1px solid
                rgba(224, 107, 174, 0.25);

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            color: #ffffff;
        }


        .modal-btn:disabled {
            opacity: 0.45;

            cursor: wait;
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                10px !important;

            padding-top:
                10px !important;

            padding-bottom:
                10px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 850px) {

            .events-toolbar {
                grid-template-columns: 1fr;
            }


            .form-grid {
                grid-template-columns: 1fr;
            }


            .form-group.full {
                grid-column: auto;
            }


            .image-upload-area {
                grid-template-columns: 1fr;
            }

        }


        @media (max-width: 600px) {

            .page-panel-header {
                flex-direction: column;
                align-items: stretch;
            }


            .count-card {
                width: 100%;
            }

        }

    </style>

</head>


<body>


    <?php include 'navbar.php'; ?>


    <h1>MY EVENTS</h1>


    <div class="events-shell">


        <!--
        ========================================
        HEADER
        ========================================
        -->

        <section class="page-panel-header">


            <div>

                <h2>
                    Event Management
                </h2>

                <p>
                    Create, update and manage your Eventify events,
                    ticket availability and event images.
                </p>

            </div>


            <div class="count-card">


                <div class="count-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <rect
                            x="3"
                            y="5"
                            width="18"
                            height="16"
                            rx="2"
                        ></rect>

                        <path d="M8 3v4"></path>

                        <path d="M16 3v4"></path>

                        <path d="M3 10h18"></path>

                    </svg>

                </div>


                <div>

                    <span
                        class="count-number"
                        id="eventCount"
                    >
                        0
                    </span>

                    <span class="count-label">
                        MY EVENTS
                    </span>

                </div>


            </div>


        </section>


        <!--
        ========================================
        MESSAGE
        ========================================
        -->

        <div id="eventMessage"></div>


        <!--
        ========================================
        TOOLBAR
        ========================================
        -->

        <div class="events-toolbar">


            <!-- SEARCH -->

            <div class="search-wrapper">


                <svg
                    class="search-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20l-3.5-3.5"
                    ></path>

                </svg>


                <input
                    type="text"
                    id="eventSearch"
                    placeholder="Search event, venue, category or Event ID..."
                >


            </div>


            <!-- STATUS -->

            <select
                id="statusFilter"
                class="filter-select"
            >

                <option value="All">
                    All Status
                </option>

                <option value="Upcoming">
                    Upcoming
                </option>

                <option value="Ongoing">
                    Ongoing
                </option>

                <option value="Completed">
                    Completed
                </option>

                <option value="Cancelled">
                    Cancelled
                </option>

            </select>


            <!-- CREATE -->

            <button
                type="button"
                class="create-event-btn"
                onclick="openCreateModal()"
            >
                + CREATE EVENT
            </button>


        </div>


        <!--
        ========================================
        TABLE
        ========================================
        -->

        <div class="table-wrapper">


            <table class="events-table">


                <thead>

                    <tr>

                        <th>ID</th>

                        <th>EVENT</th>

                        <th>VENUE</th>

                        <th>DATE</th>

                        <th>PRICE</th>

                        <th>TICKETS</th>

                        <th>STATUS</th>

                        <th>ACTION</th>

                    </tr>

                </thead>


                <tbody id="eventsTableBody">


                    <tr>

                        <td colspan="8">
                            Loading events...
                        </td>

                    </tr>


                </tbody>


            </table>


        </div>


        <!--
        ========================================
        PAGINATION
        ========================================
        -->

        <div class="pagination-bar">


            <div
                class="pagination-info"
                id="paginationInfo"
            >
                Showing 0 events
            </div>


            <div class="pagination-controls">


                <button
                    type="button"
                    class="pagination-btn"
                    id="previousPageButton"
                    onclick="previousPage()"
                >
                    PREVIOUS
                </button>


                <div
                    class="pagination-page"
                    id="paginationPage"
                >
                    Page 1 of 1
                </div>


                <button
                    type="button"
                    class="pagination-btn"
                    id="nextPageButton"
                    onclick="nextPage()"
                >
                    NEXT
                </button>


            </div>


        </div>


    </div>


    <!--
    ========================================
    CREATE MODAL
    ========================================
    -->

    <div
        class="modal-overlay"
        id="createModal"
    >


        <div class="event-modal">


            <!-- HEADER -->

            <div class="modal-header">


                <div>

                    <h3>
                        Create Event
                    </h3>

                    <p>
                        Add a new event and optionally upload its Eventify cover image.
                    </p>

                </div>


                <button
                    type="button"
                    class="modal-close"
                    onclick="closeCreateModal()"
                >
                    ×
                </button>


            </div>


            <!-- FORM -->

            <form
                id="createEventForm"
                class="form-grid"
            >


                <!-- IMAGE -->

                <div class="form-group full">


                    <label>
                        EVENT IMAGE (OPTIONAL)
                    </label>


                    <div class="image-upload-area">


                        <div class="image-preview">


                            <img
                                id="createImagePreview"
                                alt="Event preview"
                            >


                            <div
                                class="image-preview-placeholder"
                                id="createImagePlaceholder"
                            >

                                <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="1.8"
                                >

                                    <rect
                                        x="3"
                                        y="5"
                                        width="18"
                                        height="15"
                                        rx="2"
                                    ></rect>

                                    <circle
                                        cx="8"
                                        cy="10"
                                        r="2"
                                    ></circle>

                                    <path
                                        d="M3 17l5-5 4 4 3-3 6 6"
                                    ></path>

                                </svg>

                                EVENT COVER

                            </div>


                        </div>


                        <div class="image-upload-content">


                            <div class="image-upload-title">
                                Upload event cover image
                            </div>


                            <div class="image-upload-description">

                                Optional. JPG or JPEG only, maximum 5 MB.
                                Recommended landscape size: 1200 × 700 px.

                            </div>


                            <input
                                type="file"
                                id="createEventImage"
                                class="image-file-input"
                                accept=".jpg,.jpeg,image/jpeg"
                            >


                        </div>


                    </div>


                </div>


                <!-- NAME -->

                <div class="form-group full">

                    <label>
                        EVENT NAME
                    </label>

                    <input
                        type="text"
                        id="createEventName"
                        required
                    >

                </div>


                <!-- CATEGORY -->

                <div class="form-group">

                    <label>
                        CATEGORY
                    </label>

                    <input
                        type="text"
                        id="createCategory"
                        required
                    >

                </div>


                <!-- VENUE -->

                <div class="form-group">

                    <label>
                        VENUE
                    </label>

                    <select
                        id="createVenue"
                        required
                    >
                    </select>

                </div>


                <!-- DATE -->

                <div class="form-group">

                    <label>
                        EVENT DATE
                    </label>

                    <input
                        type="date"
                        id="createEventDate"
                        required
                    >

                    <div
                        class="holiday-check"
                        id="createHolidayCheck"
                    >
                        Select a date to check Malaysia public holidays.
                    </div>

                </div>


                <!-- STATUS -->

                <div class="form-group">

                    <label>
                        STATUS
                    </label>

                    <select
                        id="createStatus"
                        required
                    >

                        <option value="Upcoming">
                            Upcoming
                        </option>

                        <option value="Ongoing">
                            Ongoing
                        </option>

                        <option value="Completed">
                            Completed
                        </option>

                        <option value="Cancelled">
                            Cancelled
                        </option>

                    </select>

                </div>


                <!-- START -->

                <div class="form-group">

                    <label>
                        START TIME
                    </label>

                    <input
                        type="time"
                        id="createStartTime"
                        required
                    >

                </div>


                <!-- END -->

                <div class="form-group">

                    <label>
                        END TIME
                    </label>

                    <input
                        type="time"
                        id="createEndTime"
                        required
                    >

                </div>


                <!-- PRICE -->

                <div class="form-group">

                    <label>
                        TICKET PRICE (RM)
                    </label>

                    <input
                        type="number"
                        id="createTicketPrice"
                        min="0"
                        step="0.01"
                        required
                    >

                </div>


                <!-- TOTAL TICKETS -->

                <div class="form-group">

                    <label>
                        TOTAL TICKETS
                    </label>

                    <input
                        type="number"
                        id="createTotalTickets"
                        min="1"
                        required
                    >

                </div>


                <!-- DESCRIPTION -->

                <div class="form-group full">

                    <label>
                        DESCRIPTION
                    </label>

                    <textarea
                        id="createDescription"
                        required
                    ></textarea>

                </div>


            </form>


            <!-- ACTION -->

            <div class="modal-actions">


                <button
                    type="button"
                    class="modal-btn secondary"
                    onclick="closeCreateModal()"
                >
                    CANCEL
                </button>


                <button
                    type="button"
                    class="modal-btn primary"
                    id="createEventButton"
                    onclick="createEvent()"
                >
                    CREATE EVENT
                </button>


            </div>


        </div>


    </div>


    <!--
    ========================================
    MANAGE MODAL
    ========================================
    -->

    <div
        class="modal-overlay"
        id="manageModal"
    >


        <div class="event-modal">


            <!-- HEADER -->

            <div class="modal-header">


                <div>

                    <h3>
                        Manage Event
                    </h3>

                    <p>
                        Update event details or replace the event cover image.
                    </p>

                </div>


                <button
                    type="button"
                    class="modal-close"
                    onclick="closeManageModal()"
                >
                    ×
                </button>


            </div>


            <!-- FORM -->

            <form
                id="manageEventForm"
                class="form-grid"
            >


                <input
                    type="hidden"
                    id="manageEventId"
                >


                <!-- IMAGE -->

                <div class="form-group full">


                    <label>
                        EVENT IMAGE
                    </label>


                    <div class="image-upload-area">


                        <div class="image-preview">


                            <img
                                id="manageImagePreview"
                                alt="Event preview"
                            >


                            <div
                                class="image-preview-placeholder"
                                id="manageImagePlaceholder"
                            >

                                <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="1.8"
                                >

                                    <rect
                                        x="3"
                                        y="5"
                                        width="18"
                                        height="15"
                                        rx="2"
                                    ></rect>

                                    <circle
                                        cx="8"
                                        cy="10"
                                        r="2"
                                    ></circle>

                                    <path
                                        d="M3 17l5-5 4 4 3-3 6 6"
                                    ></path>

                                </svg>

                                EVENT COVER

                            </div>


                        </div>


                        <div class="image-upload-content">


                            <div class="image-upload-title">
                                Replace event cover image
                            </div>


                            <div class="image-upload-description">

                                Leave empty to keep the current image.
                                JPG or JPEG only, maximum 5 MB.

                            </div>


                            <input
                                type="file"
                                id="manageEventImage"
                                class="image-file-input"
                                accept=".jpg,.jpeg,image/jpeg"
                            >


                        </div>


                    </div>


                </div>


                <!-- EVENT NAME -->

                <div class="form-group full">

                    <label>
                        EVENT NAME
                    </label>

                    <input
                        type="text"
                        id="manageEventName"
                        required
                    >

                </div>


                <!-- CATEGORY -->

                <div class="form-group">

                    <label>
                        CATEGORY
                    </label>

                    <input
                        type="text"
                        id="manageCategory"
                        required
                    >

                </div>


                <!-- VENUE -->

                <div class="form-group">

                    <label>
                        VENUE
                    </label>

                    <select
                        id="manageVenue"
                        required
                    >
                    </select>

                </div>


                <!-- DATE -->

                <div class="form-group">

                    <label>
                        EVENT DATE
                    </label>

                    <input
                        type="date"
                        id="manageEventDate"
                        required
                    >

                    <div
                        class="holiday-check"
                        id="manageHolidayCheck"
                    >
                        Select a date to check Malaysia public holidays.
                    </div>

                </div>


                <!-- STATUS -->

                <div class="form-group">

                    <label>
                        STATUS
                    </label>

                    <select
                        id="manageStatus"
                        required
                    >

                        <option value="Upcoming">
                            Upcoming
                        </option>

                        <option value="Ongoing">
                            Ongoing
                        </option>

                        <option value="Completed">
                            Completed
                        </option>

                        <option value="Cancelled">
                            Cancelled
                        </option>

                    </select>

                </div>


                <!-- START -->

                <div class="form-group">

                    <label>
                        START TIME
                    </label>

                    <input
                        type="time"
                        id="manageStartTime"
                        required
                    >

                </div>


                <!-- END -->

                <div class="form-group">

                    <label>
                        END TIME
                    </label>

                    <input
                        type="time"
                        id="manageEndTime"
                        required
                    >

                </div>


                <!-- PRICE -->

                <div class="form-group">

                    <label>
                        TICKET PRICE (RM)
                    </label>

                    <input
                        type="number"
                        id="manageTicketPrice"
                        min="0"
                        step="0.01"
                        required
                    >

                </div>


                <!-- TOTAL -->

                <div class="form-group">

                    <label>
                        TOTAL TICKETS
                    </label>

                    <input
                        type="number"
                        id="manageTotalTickets"
                        min="1"
                        required
                    >

                </div>


                <!-- DESCRIPTION -->

                <div class="form-group full">

                    <label>
                        DESCRIPTION
                    </label>

                    <textarea
                        id="manageDescription"
                        required
                    ></textarea>

                </div>


            </form>


            <!-- ACTION -->

            <div class="modal-actions">


                <button
                    type="button"
                    class="modal-btn secondary"
                    onclick="closeManageModal()"
                >
                    CANCEL
                </button>


                <button
                    type="button"
                    class="modal-btn primary"
                    id="updateEventButton"
                    onclick="updateEvent()"
                >
                    SAVE CHANGES
                </button>


            </div>


        </div>


    </div>


    <!--
    ========================================
    FOOTER
    ========================================
    -->

    <div class="footer">

        EVENTIFY ORGANISER PORTAL

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        SESSION
        ========================================
        */

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser =
            null;


        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }


            if (
                currentUser &&
                currentUser.role !==
                'Organiser'
            ) {

                window.location.href =
                    'login.php';

            }

        }


        /*
        ========================================
        DATA
        ========================================
        */

        let allEvents =
            [];


        let filteredEvents =
            [];


        let allVenues =
            [];


        const eventsPerPage =
            5;


        let currentPage =
            1;


        /*
        HOLIDAY CACHE
        */

        const holidayCache =
            {};


        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const eventsTableBody =
            document.getElementById(
                'eventsTableBody'
            );


        const eventSearch =
            document.getElementById(
                'eventSearch'
            );


        const statusFilter =
            document.getElementById(
                'statusFilter'
            );


        /*
        ========================================
        INIT
        ========================================
        */

        loadPageData();


        eventSearch.addEventListener(
            'input',
            function() {

                currentPage =
                    1;


                filterEvents();

            }
        );


        statusFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterEvents();

            }
        );


        /*
        ========================================
        IMAGE PREVIEW
        ========================================
        */

        document
            .getElementById(
                'createEventImage'
            )
            .addEventListener(
                'change',
                function() {

                    previewSelectedImage(
                        this,
                        'createImagePreview',
                        'createImagePlaceholder'
                    );

                }
            );


        document
            .getElementById(
                'manageEventImage'
            )
            .addEventListener(
                'change',
                function() {

                    previewSelectedImage(
                        this,
                        'manageImagePreview',
                        'manageImagePlaceholder'
                    );

                }
            );


        function previewSelectedImage(
            input,
            previewId,
            placeholderId
        ) {

            const preview =
                document.getElementById(
                    previewId
                );


            const placeholder =
                document.getElementById(
                    placeholderId
                );


            if (
                !input.files ||
                !input.files[0]
            ) {

                return;

            }


            const file =
                input.files[0];


            const allowedTypes =
                [
                    'image/jpeg',
                    'image/jpg'
                ];


            if (
                !allowedTypes.includes(
                    file.type
                )
            ) {

                showNotification(
                    'error',
                    'Invalid image',
                    'Only JPG or JPEG images are allowed.'
                );


                input.value =
                    '';


                return;

            }


            if (
                file.size >
                5 * 1024 * 1024
            ) {

                showNotification(
                    'error',
                    'Image too large',
                    'Event image must be smaller than 5 MB.'
                );


                input.value =
                    '';


                return;

            }


            const reader =
                new FileReader();


            reader.onload =
                function(event) {

                    preview.src =
                        event.target.result;


                    preview.classList.add(
                        'active'
                    );


                    placeholder.style.display =
                        'none';

                };


            reader.readAsDataURL(
                file
            );

        }


        /*
        ========================================
        LOAD PAGE
        ========================================
        */

        async function loadPageData() {

            try {

                const [
                    eventsResponse,
                    venuesResponse
                ] =
                    await Promise.all([

                        fetch(
                            '../api/events.php'
                        ),

                        fetch(
                            '../api/venues.php'
                        )

                    ]);


                const eventsResult =
                    await eventsResponse.json();


                const venuesResult =
                    await venuesResponse.json();


                if (
                    eventsResult.status !==
                    'success'
                ) {

                    throw new Error(
                        eventsResult.message ||
                        'Unable to load events'
                    );

                }


                if (
                    venuesResult.status !==
                    'success'
                ) {

                    throw new Error(
                        venuesResult.message ||
                        'Unable to load venues'
                    );

                }


                allEvents =
                    (
                        eventsResult.data ||
                        []
                    )
                    .filter(
                        function(event) {

                            return (
                                Number(
                                    event.organiser_id
                                )
                                ===
                                Number(
                                    currentUser.user_id
                                )
                            );

                        }
                    );


                allVenues =
                    venuesResult.data ||
                    [];


                populateVenueOptions();


                filterEvents();

            }

            catch (error) {

                console.error(
                    error
                );


                showNotification(
                    'error',
                    'Unable to load events',
                    error.message
                );

            }

        }


        /*
        ========================================
        VENUES
        ========================================
        */

        function populateVenueOptions() {

            const createVenue =
                document.getElementById(
                    'createVenue'
                );


            const manageVenue =
                document.getElementById(
                    'manageVenue'
                );


            createVenue.innerHTML =
                '<option value="">Select Venue</option>';


            manageVenue.innerHTML =
                '<option value="">Select Venue</option>';


            allVenues.forEach(
                function(venue) {


                    if (
                        venue.status ===
                        'Available'
                    ) {

                        createVenue.innerHTML += `

                            <option value="${venue.venue_id}">

                                ${escapeHtml(
                                    venue.venue_name
                                )}

                            </option>

                        `;

                    }


                    manageVenue.innerHTML += `

                        <option value="${venue.venue_id}">

                            ${escapeHtml(
                                venue.venue_name
                            )}

                        </option>

                    `;

                }
            );

        }


        /*
        ========================================
        FILTER
        ========================================
        */

        function filterEvents() {

            const search =
                eventSearch
                    .value
                    .trim()
                    .toLowerCase();


            const status =
                statusFilter.value;


            filteredEvents =
                allEvents.filter(
                    function(event) {


                        const matchSearch =

                            !search

                            ||

                            String(
                                event.event_id ||
                                ''
                            )
                            .includes(
                                search
                            )

                            ||

                            String(
                                event.event_name ||
                                ''
                            )
                            .toLowerCase()
                            .includes(
                                search
                            )

                            ||

                            String(
                                event.category ||
                                ''
                            )
                            .toLowerCase()
                            .includes(
                                search
                            )

                            ||

                            String(
                                event.venue_name ||
                                ''
                            )
                            .toLowerCase()
                            .includes(
                                search
                            );


                        const matchStatus =

                            status ===
                            'All'

                            ||

                            event.status ===
                            status;


                        return (
                            matchSearch &&
                            matchStatus
                        );

                    }
                );


            displayEvents();

        }


        /*
        ========================================
        DISPLAY
        ========================================
        */

        function displayEvents() {

            document
                .getElementById(
                    'eventCount'
                )
                .textContent =
                    allEvents.length;


            const totalPages =
                getTotalPages();


            if (
                currentPage >
                totalPages
            ) {

                currentPage =
                    totalPages;

            }


            if (
                filteredEvents.length ===
                0
            ) {

                eventsTableBody.innerHTML = `

                    <tr>

                        <td
                            colspan="8"
                            style="
                                text-align:center;
                                padding:32px;
                                font-size:11px;
                            "
                        >
                            No events found.
                        </td>

                    </tr>

                `;


                updatePagination();

                return;

            }


            const start =
                (
                    currentPage -
                    1
                )
                *
                eventsPerPage;


            const pageEvents =
                filteredEvents.slice(

                    start,

                    start +
                    eventsPerPage

                );


            eventsTableBody.innerHTML =
                '';


            pageEvents.forEach(
                function(event) {


                    eventsTableBody.innerHTML += `

                        <tr>


                            <td>

                                <span class="event-id">

                                    #${event.event_id}

                                </span>

                            </td>


                            <td>


                                <div class="event-cell">


                                    <div class="event-thumbnail">

                                        <img
                                            src="assets/events/event-${event.event_id}.jpg?v=${Date.now()}"
                                            alt=""
                                            onerror="
                                                this.style.display='none'
                                            "
                                        >

                                    </div>


                                    <div class="event-details-mini">


                                        <span class="event-name">

                                            ${escapeHtml(
                                                event.event_name
                                            )}

                                        </span>


                                        <span class="event-category">

                                            ${escapeHtml(
                                                event.category
                                            )}

                                        </span>


                                    </div>


                                </div>


                            </td>


                            <td>

                                <span class="venue-text">

                                    ${escapeHtml(
                                        event.venue_name ||
                                        '-'
                                    )}

                                </span>

                            </td>


                            <td>

                                ${formatDate(
                                    event.event_date
                                )}

                            </td>


                            <td>

                                <span class="price-text">

                                    RM ${Number(
                                        event.ticket_price ||
                                        0
                                    ).toFixed(
                                        2
                                    )}

                                </span>

                            </td>


                            <td>

                                <span class="ticket-count">

                                    ${event.available_tickets}

                                    <span>
                                        /
                                        ${event.total_tickets}
                                    </span>

                                </span>

                            </td>


                            <td>

                                <span
                                    class="
                                        status-badge
                                        ${getStatusClass(
                                            event.status
                                        )}
                                    "
                                >

                                    ${escapeHtml(
                                        event.status
                                    )}

                                </span>

                            </td>


                            <td>


                                <div class="action-group">


                                    <button
                                        type="button"
                                        class="manage-btn"
                                        onclick="openManageModal(
                                            ${event.event_id}
                                        )"
                                    >
                                        MANAGE
                                    </button>


                                    <button
                                        type="button"
                                        class="delete-btn"
                                        onclick="deleteEvent(
                                            ${event.event_id}
                                        )"
                                        title="Delete Event"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2"
                                        >

                                            <path
                                                d="M3 6h18"
                                            ></path>

                                            <path
                                                d="M8 6V4h8v2"
                                            ></path>

                                            <path
                                                d="M19 6l-1 14H6L5 6"
                                            ></path>

                                        </svg>

                                    </button>


                                </div>


                            </td>


                        </tr>

                    `;

                }
            );


            updatePagination();

        }


        /*
        ========================================
        CREATE MODAL
        ========================================
        */

        function openCreateModal() {

            document
                .getElementById(
                    'createEventForm'
                )
                .reset();


            resetCreateImage();


            const holidayCheck =
                document.getElementById(
                    'createHolidayCheck'
                );


            holidayCheck.className =
                'holiday-check';


            holidayCheck.textContent =
                'Select a date to check Malaysia public holidays.';


            document
                .getElementById(
                    'createModal'
                )
                .classList.add(
                    'active'
                );

        }


        function closeCreateModal() {

            document
                .getElementById(
                    'createModal'
                )
                .classList.remove(
                    'active'
                );

        }


        function resetCreateImage() {

            const preview =
                document.getElementById(
                    'createImagePreview'
                );


            preview.src =
                '';


            preview.classList.remove(
                'active'
            );


            document
                .getElementById(
                    'createImagePlaceholder'
                )
                .style
                .display =
                    'flex';

        }


        /*
        ========================================
        CREATE EVENT
        ========================================
        */

        async function createEvent() {

            const form =
                document.getElementById(
                    'createEventForm'
                );


            if (
                !form.checkValidity()
            ) {

                form.reportValidity();

                return;

            }


            const button =
                document.getElementById(
                    'createEventButton'
                );


            button.disabled =
                true;


            button.textContent =
                'CREATING...';


            const payload = {

                organiser_id:
                    Number(
                        currentUser.user_id
                    ),

                venue_id:
                    Number(
                        document
                            .getElementById(
                                'createVenue'
                            )
                            .value
                    ),

                event_name:
                    document
                        .getElementById(
                            'createEventName'
                        )
                        .value
                        .trim(),

                category:
                    document
                        .getElementById(
                            'createCategory'
                        )
                        .value
                        .trim(),

                description:
                    document
                        .getElementById(
                            'createDescription'
                        )
                        .value
                        .trim(),

                event_date:
                    document
                        .getElementById(
                            'createEventDate'
                        )
                        .value,

                start_time:
                    document
                        .getElementById(
                            'createStartTime'
                        )
                        .value,

                end_time:
                    document
                        .getElementById(
                            'createEndTime'
                        )
                        .value,

                ticket_price:
                    Number(
                        document
                            .getElementById(
                                'createTicketPrice'
                            )
                            .value
                    ),

                total_tickets:
                    Number(
                        document
                            .getElementById(
                                'createTotalTickets'
                            )
                            .value
                    ),

                status:
                    document
                        .getElementById(
                            'createStatus'
                        )
                        .value

            };


            try {

                const response =
                    await fetch(
                        '../api/events.php',
                        {

                            method:
                                'POST',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify(
                                    payload
                                )

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    'success'
                ) {

                    throw new Error(
                        result.message ||
                        'Unable to create event'
                    );

                }


                /*
                ========================================
                NEW EVENT ID
                ========================================
                */

                let newEventId =

                    result.event_id

                    ??

                    result.data?.event_id

                    ??

                    result.data?.id

                    ??

                    null;


                /*
                Fallback if backend does not return ID
                */

                if (!newEventId) {

                    const refreshedResponse =
                        await fetch(
                            '../api/events.php'
                        );


                    const refreshedResult =
                        await refreshedResponse.json();


                    if (
                        refreshedResult.status ===
                        'success'
                    ) {

                        const matching =
                            (
                                refreshedResult.data ||
                                []
                            )
                            .filter(
                                function(event) {

                                    return (

                                        Number(
                                            event.organiser_id
                                        )
                                        ===
                                        Number(
                                            currentUser.user_id
                                        )

                                        &&

                                        event.event_name ===
                                        payload.event_name

                                    );

                                }
                            )
                            .sort(
                                function(a, b) {

                                    return (
                                        Number(
                                            b.event_id
                                        )
                                        -
                                        Number(
                                            a.event_id
                                        )
                                    );

                                }
                            );


                        if (
                            matching.length >
                            0
                        ) {

                            newEventId =
                                matching[0].event_id;

                        }

                    }

                }


                /*
                ========================================
                OPTIONAL IMAGE
                ========================================
                */

                const imageInput =
                    document.getElementById(
                        'createEventImage'
                    );


                if (
                    imageInput.files.length >
                    0
                    &&
                    newEventId
                ) {

                    await uploadEventImage(
                        newEventId,
                        imageInput.files[0]
                    );

                }


                closeCreateModal();


                showNotification(

                    'success',

                    'Event created',

                    imageInput.files.length > 0
                    ?
                    'Event and cover image were created successfully.'
                    :
                    'Event was created successfully.'

                );


                await loadPageData();

            }

            catch (error) {

                console.error(
                    error
                );


                showNotification(
                    'error',
                    'Create failed',
                    error.message
                );

            }

            finally {

                button.disabled =
                    false;


                button.textContent =
                    'CREATE EVENT';

            }

        }


        /*
        ========================================
        MANAGE MODAL
        ========================================
        */

        function openManageModal(
            eventId
        ) {

            const event =
                allEvents.find(
                    function(item) {

                        return (
                            Number(
                                item.event_id
                            )
                            ===
                            Number(
                                eventId
                            )
                        );

                    }
                );


            if (!event) {

                return;

            }


            document
                .getElementById(
                    'manageEventId'
                )
                .value =
                    event.event_id;


            document
                .getElementById(
                    'manageEventName'
                )
                .value =
                    event.event_name ||
                    '';


            document
                .getElementById(
                    'manageCategory'
                )
                .value =
                    event.category ||
                    '';


            document
                .getElementById(
                    'manageVenue'
                )
                .value =
                    event.venue_id ||
                    '';


            document
                .getElementById(
                    'manageEventDate'
                )
                .value =
                    String(
                        event.event_date ||
                        ''
                    )
                    .substring(
                        0,
                        10
                    );


            document
                .getElementById(
                    'manageStartTime'
                )
                .value =
                    String(
                        event.start_time ||
                        ''
                    )
                    .substring(
                        0,
                        5
                    );


            document
                .getElementById(
                    'manageEndTime'
                )
                .value =
                    String(
                        event.end_time ||
                        ''
                    )
                    .substring(
                        0,
                        5
                    );


            document
                .getElementById(
                    'manageTicketPrice'
                )
                .value =
                    event.ticket_price ||
                    0;


            document
                .getElementById(
                    'manageTotalTickets'
                )
                .value =
                    event.total_tickets ||
                    0;


            document
                .getElementById(
                    'manageStatus'
                )
                .value =
                    event.status ||
                    'Upcoming';


            document
                .getElementById(
                    'manageDescription'
                )
                .value =
                    event.description ||
                    '';


            /*
            CURRENT IMAGE
            */

            const preview =
                document.getElementById(
                    'manageImagePreview'
                );


            const placeholder =
                document.getElementById(
                    'manageImagePlaceholder'
                );


            preview.src =
                `assets/events/event-${event.event_id}.jpg?v=${Date.now()}`;


            preview.classList.add(
                'active'
            );


            placeholder.style.display =
                'none';


            preview.onerror =
                function() {

                    preview.classList.remove(
                        'active'
                    );


                    placeholder.style.display =
                        'flex';

                };


            document
                .getElementById(
                    'manageEventImage'
                )
                .value =
                    '';


            /*
            HOLIDAY
            */

            checkMalaysiaPublicHoliday(

                document
                    .getElementById(
                        'manageEventDate'
                    )
                    .value,

                'manageHolidayCheck'

            );


            document
                .getElementById(
                    'manageModal'
                )
                .classList.add(
                    'active'
                );

        }


        function closeManageModal() {

            document
                .getElementById(
                    'manageModal'
                )
                .classList.remove(
                    'active'
                );

        }


        /*
        ========================================
        UPDATE EVENT
        ========================================
        */

        async function updateEvent() {

            const form =
                document.getElementById(
                    'manageEventForm'
                );


            if (
                !form.checkValidity()
            ) {

                form.reportValidity();

                return;

            }


            const eventId =
                Number(
                    document
                        .getElementById(
                            'manageEventId'
                        )
                        .value
                );


            const original =
                allEvents.find(
                    function(event) {

                        return (
                            Number(
                                event.event_id
                            )
                            ===
                            eventId
                        );

                    }
                );


            if (!original) {

                return;

            }


            const newTotalTickets =
                Number(
                    document
                        .getElementById(
                            'manageTotalTickets'
                        )
                        .value
                );


            const soldTickets =
                Number(
                    original.total_tickets ||
                    0
                )
                -
                Number(
                    original.available_tickets ||
                    0
                );


            const newAvailableTickets =
                Math.max(
                    0,
                    newTotalTickets -
                    soldTickets
                );


            const payload = {

                event_id:
                    eventId,

                organiser_id:
                    Number(
                        currentUser.user_id
                    ),

                venue_id:
                    Number(
                        document
                            .getElementById(
                                'manageVenue'
                            )
                            .value
                    ),

                event_name:
                    document
                        .getElementById(
                            'manageEventName'
                        )
                        .value
                        .trim(),

                category:
                    document
                        .getElementById(
                            'manageCategory'
                        )
                        .value
                        .trim(),

                description:
                    document
                        .getElementById(
                            'manageDescription'
                        )
                        .value
                        .trim(),

                event_date:
                    document
                        .getElementById(
                            'manageEventDate'
                        )
                        .value,

                start_time:
                    document
                        .getElementById(
                            'manageStartTime'
                        )
                        .value,

                end_time:
                    document
                        .getElementById(
                            'manageEndTime'
                        )
                        .value,

                ticket_price:
                    Number(
                        document
                            .getElementById(
                                'manageTicketPrice'
                            )
                            .value
                    ),

                total_tickets:
                    newTotalTickets,

                available_tickets:
                    newAvailableTickets,

                status:
                    document
                        .getElementById(
                            'manageStatus'
                        )
                        .value

            };


            const button =
                document.getElementById(
                    'updateEventButton'
                );


            button.disabled =
                true;


            button.textContent =
                'SAVING...';


            try {

                const response =
                    await fetch(
                        '../api/events.php',
                        {

                            method:
                                'PUT',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify(
                                    payload
                                )

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    'success'
                ) {

                    throw new Error(
                        result.message ||
                        'Unable to update event'
                    );

                }


                /*
                OPTIONAL IMAGE REPLACE
                */

                const imageInput =
                    document.getElementById(
                        'manageEventImage'
                    );


                if (
                    imageInput.files.length >
                    0
                ) {

                    await uploadEventImage(
                        eventId,
                        imageInput.files[0]
                    );

                }


                closeManageModal();


                showNotification(

                    'success',

                    'Event updated',

                    imageInput.files.length > 0
                    ?
                    'Event details and cover image were updated successfully.'
                    :
                    'Event details were updated successfully.'

                );


                await loadPageData();

            }

            catch (error) {

                console.error(
                    error
                );


                showNotification(
                    'error',
                    'Update failed',
                    error.message
                );

            }

            finally {

                button.disabled =
                    false;


                button.textContent =
                    'SAVE CHANGES';

            }

        }


        /*
        ========================================
        UPLOAD IMAGE
        ========================================
        */

        async function uploadEventImage(
            eventId,
            file
        ) {

            const formData =
                new FormData();


            formData.append(
                'event_id',
                eventId
            );


            formData.append(
                'event_image',
                file
            );


            const response =
                await fetch(
                    'eventimage.php',
                    {

                        method:
                            'POST',

                        body:
                            formData

                    }
                );


            const result =
                await response.json();


            if (
                !response.ok ||
                result.status !==
                'success'
            ) {

                throw new Error(
                    result.message ||
                    'Unable to upload event image'
                );

            }


            return result;

        }


        /*
        ========================================
        DELETE EVENT
        ========================================
        */

        async function deleteEvent(
            eventId
        ) {

            const event =
                allEvents.find(
                    function(item) {

                        return (
                            Number(
                                item.event_id
                            )
                            ===
                            Number(
                                eventId
                            )
                        );

                    }
                );


            if (!event) {

                return;

            }


            const confirmed =
                confirm(

                    `Delete event #${eventId}?\n\n` +

                    `${event.event_name}\n\n` +

                    `This action cannot be undone.`

                );


            if (!confirmed) {

                return;

            }


            try {

                const response =
                    await fetch(
                        '../api/events.php',
                        {

                            method:
                                'DELETE',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    event_id:
                                        Number(
                                            eventId
                                        )

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    showNotification(
                        'success',
                        'Event deleted',
                        `Event #${eventId} was deleted successfully.`
                    );


                    await loadPageData();

                }

                else {

                    showNotification(
                        'error',
                        'Delete failed',
                        result.message ||
                        'Unable to delete event.'
                    );

                }

            }

            catch (error) {

                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Event API.'
                );

            }

        }


        /*
        ========================================
        HOLIDAY CHECK EVENTS
        ========================================
        */

        document
            .getElementById(
                'createEventDate'
            )
            .addEventListener(
                'change',
                function() {

                    checkMalaysiaPublicHoliday(

                        this.value,

                        'createHolidayCheck'

                    );

                }
            );


        document
            .getElementById(
                'manageEventDate'
            )
            .addEventListener(
                'change',
                function() {

                    checkMalaysiaPublicHoliday(

                        this.value,

                        'manageHolidayCheck'

                    );

                }
            );


        /*
        ========================================
        HOLIDAY API
        ========================================
        */

        async function checkMalaysiaPublicHoliday(
            dateValue,
            targetElementId
        ) {

            const target =
                document.getElementById(
                    targetElementId
                );


            if (!dateValue) {

                target.className =
                    'holiday-check';


                target.textContent =
                    'Select a date to check Malaysia public holidays.';


                return;

            }


            /*
            CACHE
            */

            if (
                holidayCache[
                    dateValue
                ]
            ) {

                renderHolidayResult(

                    holidayCache[
                        dateValue
                    ],

                    target

                );


                return;

            }


            target.className =
                'holiday-check loading';


            target.textContent =
                'CHECKING MALAYSIA PUBLIC HOLIDAY...';


            try {

                const response =
                    await fetch(

                        `holidayproxy.php?date=${encodeURIComponent(
                            dateValue
                        )}`

                    );


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    'success'
                ) {

                    throw new Error(
                        result.message ||
                        'Calendar check unavailable'
                    );

                }


                holidayCache[
                    dateValue
                ] =
                    result;


                renderHolidayResult(
                    result,
                    target
                );

            }

            catch (error) {

                target.className =
                    'holiday-check error';


                target.textContent =
                    'CALENDAR CHECK UNAVAILABLE • Event creation can still continue.';

            }

        }


        /*
        ========================================
        RENDER HOLIDAY
        ========================================
        */

        function renderHolidayResult(
            apiResult,
            target
        ) {

            const data =
                apiResult.data ||
                {};


            if (
                !data.is_holiday
            ) {

                target.className =
                    'holiday-check clear';


                target.textContent =
                    '✓ NO PUBLIC HOLIDAY DETECTED • Malaysia Holiday API';


                return;

            }


            const holidayNames =
                (
                    data.holidays ||
                    []
                )
                .map(
                    function(item) {

                        return (
                            item.name
                            ||
                            item.holiday_name
                            ||
                            'Public Holiday'
                        );

                    }
                )
                .join(
                    ', '
                );


            target.className =
                'holiday-check holiday';


            target.textContent =
                `⚠ PUBLIC HOLIDAY DETECTED • ${holidayNames || 'Malaysia Public Holiday'}`;

        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        function getTotalPages() {

            return Math.max(

                1,

                Math.ceil(
                    filteredEvents.length /
                    eventsPerPage
                )

            );

        }


        function updatePagination() {

            const totalPages =
                getTotalPages();


            const start =

                filteredEvents.length ===
                0

                ? 0

                : (
                    (
                        currentPage -
                        1
                    )
                    *
                    eventsPerPage
                )
                +
                1;


            const end =
                Math.min(

                    currentPage *
                    eventsPerPage,

                    filteredEvents.length

                );


            document
                .getElementById(
                    'paginationInfo'
                )
                .textContent =

                    filteredEvents.length ===
                    0

                    ?
                    'Showing 0 events'

                    :
                    `Showing ${start}-${end} of ${filteredEvents.length} events`;


            document
                .getElementById(
                    'paginationPage'
                )
                .textContent =
                    `Page ${currentPage} of ${totalPages}`;


            document
                .getElementById(
                    'previousPageButton'
                )
                .disabled =
                    currentPage <=
                    1;


            document
                .getElementById(
                    'nextPageButton'
                )
                .disabled =
                    currentPage >=
                    totalPages;

        }


        function previousPage() {

            if (
                currentPage <=
                1
            ) {

                return;

            }


            currentPage--;


            displayEvents();

        }


        function nextPage() {

            if (
                currentPage >=
                getTotalPages()
            ) {

                return;

            }


            currentPage++;


            displayEvents();

        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        function showNotification(
            type,
            title,
            text
        ) {

            const container =
                document.getElementById(
                    'eventMessage'
                );


            container.innerHTML = `

                <div
                    class="
                        notification
                        ${type}
                    "
                >

                    <div class="notification-icon">

                        ${
                            type ===
                            'success'
                            ?
                            '✓'
                            :
                            '!'
                        }

                    </div>


                    <div>


                        <div class="notification-title">

                            ${escapeHtml(
                                title
                            )}

                        </div>


                        <div class="notification-text">

                            ${escapeHtml(
                                text
                            )}

                        </div>


                    </div>


                </div>

            `;


            setTimeout(
                function() {

                    container.innerHTML =
                        '';

                },
                4000
            );

        }


        /*
        ========================================
        STATUS CLASS
        ========================================
        */

        function getStatusClass(
            status
        ) {

            if (
                status ===
                'Ongoing'
            ) {

                return 'status-ongoing';

            }


            if (
                status ===
                'Completed'
            ) {

                return 'status-completed';

            }


            if (
                status ===
                'Cancelled'
            ) {

                return 'status-cancelled';

            }


            return 'status-upcoming';

        }


        /*
        ========================================
        DATE
        ========================================
        */

        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const parts =
                String(
                    value
                )
                .substring(
                    0,
                    10
                )
                .split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return value;

            }


            return (
                parts[2]
                +
                '/'
                +
                parts[1]
                +
                '/'
                +
                parts[0]
            );

        }


        /*
        ========================================
        SESSION
        ========================================
        */

        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );


            localStorage.removeItem(
                'eventify_user'
            );


            window.location.href =
                'login.php';

        }


        /*
        ========================================
        ESCAPE
        ========================================
        */

        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    </script>


</body>

</html>