<?php

/*
========================================
EVENTIFY NAVBAR
========================================
*/

?>

<style>

    /*
    ========================================
    NAVBAR
    ========================================
    */

    .eventify-navbar {
        width: 100%;
        min-height: 64px;

        display: flex;
        align-items: center;

        box-sizing: border-box;

        padding:
            0
            max(
                4%,
                calc((100% - 1180px) / 2)
            );

        border-bottom:
            1px solid
            rgba(224, 107, 174, 0.18);

        background:
            rgba(11, 11, 46, 0.94);

        backdrop-filter:
            blur(14px);

        position: relative;
        z-index: 100;
    }


    /*
    TOP ACCENT
    */

    .eventify-navbar::after {
        content: "";

        position: absolute;

        left: 0;
        right: 0;
        bottom: -1px;

        height: 1px;

        background:
            linear-gradient(
                90deg,
                transparent,
                rgba(176, 68, 158, 0.60),
                rgba(224, 107, 174, 0.70),
                transparent
            );

        pointer-events: none;
    }


    /*
    ========================================
    INNER
    ========================================
    */

    .eventify-navbar-inner {
        width: 100%;

        display: flex;
        align-items: center;
        justify-content: space-between;

        gap: 25px;
    }


    /*
    ========================================
    LOGO
    ========================================
    */

    .eventify-navbar-logo {
        display: inline-flex;
        align-items: center;

        gap: 10px;

        flex-shrink: 0;

        text-decoration: none;
    }


    .eventify-navbar-logo-mark {
        width: 31px;
        height: 31px;

        display: flex;
        align-items: center;
        justify-content: center;

        box-sizing: border-box;

        border:
            1px solid
            rgba(224, 107, 174, 0.28);

        border-radius: 7px;

        background:
            linear-gradient(
                135deg,
                #5B2A86,
                #B0449E
            );

        box-shadow:
            0
            0
            18px
            rgba(176, 68, 158, 0.15);

        font-family:
            "Press Start 2P",
            monospace;

        font-size: 10px;

        color: #ffffff;
    }


    .eventify-navbar-logo-text {
        font-family:
            "Press Start 2P",
            monospace;

        font-size: 14px;

        letter-spacing: 0.5px;

        background:
            linear-gradient(
                90deg,
                #F6C58E,
                #F4A7A0
            );

        background-clip: text;
        -webkit-background-clip: text;

        color: transparent;
        -webkit-text-fill-color: transparent;
    }


    /*
    ========================================
    NAVIGATION
    ========================================
    */

    .eventify-nav-links {
        display: flex;
        align-items: center;

        gap: 7px;
    }


    .eventify-nav-link {
        min-height: 34px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        gap: 6px;

        box-sizing: border-box;

        padding:
            0
            12px;

        border:
            1px solid
            transparent;

        border-radius: 6px;

        background:
            transparent;

        text-decoration: none;

        font-family:
            Inter,
            Arial,
            sans-serif;

        font-size: 9px;
        font-weight: 800;

        letter-spacing: 0.35px;

        color:
            rgba(255, 255, 255, 0.62);

        transition:
            background
            0.15s ease,
            border-color
            0.15s ease,
            color
            0.15s ease,
            transform
            0.15s ease;
    }


    .eventify-nav-link svg {
        width: 13px;
        height: 13px;

        flex-shrink: 0;
    }


    /*
    HOVER
    */

    .eventify-nav-link:hover {
        border-color:
            rgba(255, 255, 255, 0.08);

        background:
            rgba(255, 255, 255, 0.045);

        color: #ffffff;

        transform:
            translateY(-1px);
    }


    /*
    ACTIVE
    */

    .eventify-nav-link.active {
        border-color:
            rgba(224, 107, 174, 0.24);

        background:
            linear-gradient(
                135deg,
                rgba(91, 42, 134, 0.75),
                rgba(176, 68, 158, 0.72)
            );

        box-shadow:
            0
            7px
            18px
            rgba(91, 42, 134, 0.16);

        color: #ffffff;
    }


    /*
    ========================================
    LOGOUT
    ========================================
    */

    .eventify-nav-logout {
        min-height: 34px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        gap: 6px;

        box-sizing: border-box;

        margin-left: 3px;

        padding:
            0
            12px;

        border:
            1px solid
            rgba(239, 130, 149, 0.16);

        border-radius: 6px;

        background:
            rgba(239, 130, 149, 0.045);

        color:
            rgba(239, 130, 149, 0.82);

        font-family:
            Inter,
            Arial,
            sans-serif;

        font-size: 9px;
        font-weight: 800;

        letter-spacing: 0.35px;

        cursor: pointer;

        transition:
            background
            0.15s ease,
            border-color
            0.15s ease,
            color
            0.15s ease;
    }


    .eventify-nav-logout svg {
        width: 13px;
        height: 13px;
    }


    .eventify-nav-logout:hover {
        border-color:
            rgba(239, 130, 149, 0.28);

        background:
            rgba(239, 130, 149, 0.085);

        color: #EF8295;
    }


    /*
    ========================================
    USER CHIP
    ========================================
    */

    .eventify-user-chip {
        display: none;

        align-items: center;

        gap: 7px;

        margin-left: 4px;

        padding:
            5px
            8px;

        box-sizing: border-box;

        border:
            1px solid
            rgba(255, 255, 255, 0.07);

        border-radius: 6px;

        background:
            rgba(255, 255, 255, 0.025);
    }


    .eventify-user-avatar {
        width: 24px;
        height: 24px;

        display: flex;
        align-items: center;
        justify-content: center;

        flex-shrink: 0;

        border-radius: 5px;

        background:
            rgba(224, 107, 174, 0.08);

        font-family:
            Inter,
            Arial,
            sans-serif;

        font-size: 9px;
        font-weight: 850;

        color: #F6C58E;
    }


    .eventify-user-info {
        min-width: 0;
    }


    .eventify-user-name {
        display: block;

        max-width: 110px;

        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;

        margin-bottom: 1px;

        font-family:
            Inter,
            Arial,
            sans-serif;

        font-size: 7px;
        font-weight: 800;

        color: #ffffff;
    }


    .eventify-user-role {
        display: block;

        font-family:
            Inter,
            Arial,
            sans-serif;

        font-size: 6px;
        font-weight: 700;

        letter-spacing: 0.35px;

        color:
            rgba(255, 255, 255, 0.32);
    }


    /*
    ========================================
    MOBILE MENU BUTTON
    ========================================
    */

    .eventify-menu-button {
        width: 36px;
        height: 34px;

        display: none;
        align-items: center;
        justify-content: center;

        padding: 0;

        border:
            1px solid
            rgba(255, 255, 255, 0.09);

        border-radius: 6px;

        background:
            rgba(255, 255, 255, 0.035);

        color: #ffffff;

        cursor: pointer;
    }


    .eventify-menu-button svg {
        width: 17px;
        height: 17px;
    }


    /*
    ========================================
    RESPONSIVE
    ========================================
    */

    @media (max-width: 900px) {

        .eventify-navbar {
            min-height: 60px;
        }


        .eventify-menu-button {
            display: flex;
        }


        .eventify-nav-links {
            position: absolute;

            top: calc(100% + 8px);
            left: 4%;
            right: 4%;

            display: none;
            flex-direction: column;

            align-items: stretch;

            box-sizing: border-box;

            padding: 9px;

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 8px;

            background:
                rgba(21, 17, 58, 0.98);

            box-shadow:
                0
                18px
                45px
                rgba(0, 0, 0, 0.25);
        }


        .eventify-nav-links.open {
            display: flex;
        }


        .eventify-nav-link,
        .eventify-nav-logout {
            width: 100%;

            min-height: 38px;

            justify-content: flex-start;

            margin: 0;

            padding:
                0
                12px;
        }


        .eventify-user-chip {
            width: 100%;

            margin: 3px 0;

            box-sizing: border-box;
        }

    }


    @media (max-width: 500px) {

        .eventify-navbar-logo-text {
            font-size: 11px;
        }


        .eventify-navbar-logo-mark {
            width: 28px;
            height: 28px;
        }

    }

</style>


<nav class="eventify-navbar">


    <div class="eventify-navbar-inner">


        <!--
        ========================================
        LOGO
        ========================================
        -->

        <a
            href="home.php"
            class="eventify-navbar-logo"
            id="eventifyLogo"
        >

            <span class="eventify-navbar-logo-mark">
                E
            </span>


            <span class="eventify-navbar-logo-text">
                EVENTIFY
            </span>

        </a>


        <!--
        ========================================
        MOBILE
        ========================================
        -->

        <button
            type="button"
            class="eventify-menu-button"
            id="eventifyMenuButton"
            aria-label="Open navigation menu"
        >

            <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
            >

                <path d="M4 7h16"></path>

                <path d="M4 12h16"></path>

                <path d="M4 17h16"></path>

            </svg>

        </button>


        <!--
        ========================================
        LINKS
        ========================================
        -->

        <div
            class="eventify-nav-links"
            id="eventifyNavLinks"
        >
        </div>


    </div>


</nav>


<script>

    /*
    ========================================
    EVENTIFY NAVBAR
    ========================================
    */

    (function() {

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let user =
            null;


        if (storedUser) {

            try {

                user =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                user =
                    null;

            }

        }


        const currentPage =
            window.location.pathname
                .split('/')
                .pop()
                .split('?')[0]
                ||
                'home.php';


        const navLinks =
            document.getElementById(
                'eventifyNavLinks'
            );


        const logo =
            document.getElementById(
                'eventifyLogo'
            );


        /*
        ========================================
        ICONS
        ========================================
        */

        const icons = {

            home: `
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                >
                    <path
                        d="M3 11l9-8 9 8"
                    ></path>

                    <path
                        d="M5 10v10h14V10"
                    ></path>
                </svg>
            `,

            events: `
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                >
                    <rect
                        x="3"
                        y="5"
                        width="18"
                        height="16"
                        rx="2"
                    ></rect>

                    <path d="M8 3v4"></path>

                    <path d="M16 3v4"></path>

                    <path d="M3 10h18"></path>
                </svg>
            `,

            bookings: `
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                >
                    <path
                        d="M4 5h16v14H4z"
                    ></path>

                    <path
                        d="M8 9h8"
                    ></path>

                    <path
                        d="M8 13h5"
                    ></path>
                </svg>
            `,

            users: `
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                >
                    <circle
                        cx="9"
                        cy="8"
                        r="4"
                    ></circle>

                    <path
                        d="M3 21v-2a6 6 0 0 1 12 0v2"
                    ></path>

                    <path
                        d="M16 7h5"
                    ></path>

                    <path
                        d="M18.5 4.5v5"
                    ></path>
                </svg>
            `,

            venues: `
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                >
                    <path
                        d="M4 20h16"
                    ></path>

                    <path
                        d="M6 20V8l6-4 6 4v12"
                    ></path>

                    <path
                        d="M9 12h6"
                    ></path>
                </svg>
            `,

            dashboard: `
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                >
                    <rect
                        x="3"
                        y="3"
                        width="7"
                        height="7"
                    ></rect>

                    <rect
                        x="14"
                        y="3"
                        width="7"
                        height="7"
                    ></rect>

                    <rect
                        x="3"
                        y="14"
                        width="7"
                        height="7"
                    ></rect>

                    <rect
                        x="14"
                        y="14"
                        width="7"
                        height="7"
                    ></rect>
                </svg>
            `,

            login: `
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                >
                    <path
                        d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"
                    ></path>

                    <path
                        d="M10 17l5-5-5-5"
                    ></path>

                    <path
                        d="M15 12H3"
                    ></path>
                </svg>
            `,

            logout: `
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                >
                    <path
                        d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"
                    ></path>

                    <path
                        d="M16 17l5-5-5-5"
                    ></path>

                    <path
                        d="M21 12H9"
                    ></path>
                </svg>
            `

        };


        /*
        ========================================
        ACTIVE PAGE
        ========================================
        */

        function isActive(
            pages
        ) {

            return pages.includes(
                currentPage
            );

        }


        /*
        ========================================
        NAV ITEM
        ========================================
        */

        function navItem(
            href,
            label,
            icon,
            pages
        ) {

            const active =
                isActive(
                    pages
                )
                ?
                ' active'
                :
                '';


            return `

                <a
                    href="${href}"
                    class="eventify-nav-link${active}"
                >

                    ${icon}

                    <span>
                        ${label}
                    </span>

                </a>

            `;

        }


        /*
        ========================================
        GUEST
        ========================================
        */

        if (
            !token ||
            !user
        ) {

            logo.href =
                'home.php';


            navLinks.innerHTML =

                navItem(
                    'home.php',
                    'HOME',
                    icons.home,
                    [
                        'home.php',
                        'index.php'
                    ]
                )

                +

                navItem(
                    'events.php',
                    'EVENTS',
                    icons.events,
                    [
                        'events.php',
                        'eventdetails.php'
                    ]
                )

                +

                navItem(
                    'login.php',
                    'LOGIN',
                    icons.login,
                    [
                        'login.php',
                        'register.php'
                    ]
                );

        }


        /*
        ========================================
        CUSTOMER
        ========================================
        */

        else if (
            user.role ===
            'Customer'
        ) {

            logo.href =
                'home.php';


            navLinks.innerHTML =

                navItem(
                    'home.php',
                    'HOME',
                    icons.home,
                    [
                        'home.php'
                    ]
                )

                +

                navItem(
                    'events.php',
                    'EVENTS',
                    icons.events,
                    [
                        'events.php',
                        'eventdetails.php',
                        'booking.php'
                    ]
                )

                +

                navItem(
                    'mybookings.php',
                    'MY BOOKINGS',
                    icons.bookings,
                    [
                        'mybookings.php'
                    ]
                )

                +

                createUserChip(
                    user
                )

                +

                logoutButton();

        }


        /*
        ========================================
        ORGANISER
        ========================================
        */

        else if (
            user.role ===
            'Organiser'
        ) {

            logo.href =
                'organiserdashboard.php';


            navLinks.innerHTML =

                navItem(
                    'organiserdashboard.php',
                    'DASHBOARD',
                    icons.dashboard,
                    [
                        'organiserdashboard.php'
                    ]
                )

                +

                navItem(
                    'organiserevents.php',
                    'MY EVENTS',
                    icons.events,
                    [
                        'organiserevents.php'
                    ]
                )

                +

                navItem(
                    'organiserbookings.php',
                    'BOOKINGS',
                    icons.bookings,
                    [
                        'organiserbookings.php'
                    ]
                )

                +

                createUserChip(
                    user
                )

                +

                logoutButton();

        }


        /*
        ========================================
        ADMINISTRATOR
        ========================================
        */

        else if (
            user.role ===
            'Administrator'
        ) {

            logo.href =
                'admindashboard.php';


            navLinks.innerHTML =

                navItem(
                    'admindashboard.php',
                    'DASHBOARD',
                    icons.dashboard,
                    [
                        'admindashboard.php'
                    ]
                )

                +

                navItem(
                    'adminusers.php',
                    'USERS',
                    icons.users,
                    [
                        'adminusers.php'
                    ]
                )

                +

                navItem(
                    'adminevents.php',
                    'EVENTS',
                    icons.events,
                    [
                        'adminevents.php'
                    ]
                )

                +

                navItem(
                    'adminvenues.php',
                    'VENUES',
                    icons.venues,
                    [
                        'adminvenues.php'
                    ]
                )

                +

                navItem(
                    'adminbookings.php',
                    'BOOKINGS',
                    icons.bookings,
                    [
                        'adminbookings.php'
                    ]
                )

                +

                createUserChip(
                    user
                )

                +

                logoutButton();

        }


        /*
        ========================================
        USER CHIP
        ========================================
        */

        function createUserChip(
            currentUser
        ) {

            const name =
                currentUser.name
                ||
                currentUser.username
                ||
                'User';


            const firstLetter =
                String(
                    name
                )
                .charAt(0)
                .toUpperCase();


            return `

                <div class="eventify-user-chip">


                    <div class="eventify-user-avatar">

                        ${escapeNavbarHtml(
                            firstLetter
                        )}

                    </div>


                    <div class="eventify-user-info">


                        <span class="eventify-user-name">

                            ${escapeNavbarHtml(
                                name
                            )}

                        </span>


                        <span class="eventify-user-role">

                            ${escapeNavbarHtml(
                                currentUser.role ||
                                ''
                            )}

                        </span>


                    </div>


                </div>

            `;

        }


        /*
        ========================================
        LOGOUT BUTTON
        ========================================
        */

        function logoutButton() {

            return `

                <button
                    type="button"
                    class="eventify-nav-logout"
                    onclick="eventifyLogout()"
                >

                    ${icons.logout}

                    <span>
                        LOGOUT
                    </span>

                </button>

            `;

        }


        /*
        ========================================
        MOBILE
        ========================================
        */

        const menuButton =
            document.getElementById(
                'eventifyMenuButton'
            );


        menuButton.addEventListener(
            'click',
            function() {

                navLinks.classList.toggle(
                    'open'
                );

            }
        );


        /*
        CLOSE MENU AFTER CLICK
        */

        navLinks.addEventListener(
            'click',
            function(event) {

                if (
                    event.target.closest(
                        'a'
                    )
                ) {

                    navLinks.classList.remove(
                        'open'
                    );

                }

            }
        );


        /*
        ========================================
        ESCAPE
        ========================================
        */

        function escapeNavbarHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    })();


    /*
    ========================================
    LOGOUT
    ========================================
    */

    function eventifyLogout() {

        const confirmed =
            confirm(
                'Logout from Eventify?'
            );


        if (!confirmed) {

            return;

        }


        localStorage.removeItem(
            'eventify_token'
        );


        localStorage.removeItem(
            'eventify_user'
        );


        window.location.href =
            'login.php';

    }

</script>