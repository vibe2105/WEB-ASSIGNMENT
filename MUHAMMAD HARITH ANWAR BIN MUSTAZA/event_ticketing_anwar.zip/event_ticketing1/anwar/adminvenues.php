<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Manage Venues - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }


        .venues-shell {
            width: min(1180px, 92%);
            margin: 0 auto;
            flex: 1;
        }


        /*
        ========================================
        PAGE HEADER
        ========================================
        */

        .venues-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 18px;
            flex-wrap: wrap;

            margin-bottom: 14px;
        }


        .venues-page-header-text h2 {
            margin: 0 0 4px 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 17px;
            font-weight: 800;

            color: #ffffff;
        }


        .venues-page-header-text p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.5;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        /*
        ========================================
        VENUE COUNT
        ========================================
        */

        .venues-count-card {
            display: flex;
            align-items: center;

            gap: 10px;

            min-width: 110px;

            padding: 10px 13px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.22
                );

            border-radius: 8px;

            background:
                linear-gradient(
                    135deg,
                    rgba(
                        91,
                        42,
                        134,
                        0.23
                    ),
                    rgba(
                        176,
                        68,
                        158,
                        0.10
                    )
                );
        }


        .venues-count-icon {
            width: 30px;
            height: 30px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 7px;

            background:
                rgba(
                    224,
                    107,
                    174,
                    0.10
                );

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .venues-count-icon svg {
            width: 16px;
            height: 16px;
        }


        .venues-count-content {
            display: flex;
            flex-direction: column;
        }


        .venues-count-number {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 15px;
            font-weight: 800;

            color: #ffffff;
        }


        .venues-count-label {
            margin-top: 1px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 700;

            letter-spacing: 0.5px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        #venueMessage:empty {
            display: none;
        }


        #venueMessage {
            width: 100%;

            box-sizing: border-box;

            margin:
                0
                0
                14px
                0;
        }


        .venues-notification {
            width: 100%;

            display: flex;
            align-items: center;

            gap: 11px;

            box-sizing: border-box;

            padding: 10px 13px;

            border-radius: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .venues-notification-success {
            border:
                1px solid
                rgba(
                    95,
                    180,
                    160,
                    0.28
                );

            background:
                rgba(
                    95,
                    180,
                    160,
                    0.09
                );
        }


        .venues-notification-error {
            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.28
                );

            background:
                rgba(
                    230,
                    95,
                    120,
                    0.09
                );
        }


        .notification-icon {
            width: 27px;
            height: 27px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 6px;

            font-size: 13px;
            font-weight: 800;
        }


        .venues-notification-success
        .notification-icon {
            background:
                rgba(
                    95,
                    180,
                    160,
                    0.13
                );

            color: #8FD8C6;
        }


        .venues-notification-error
        .notification-icon {
            background:
                rgba(
                    230,
                    95,
                    120,
                    0.13
                );

            color: #EF8295;
        }


        .notification-content {
            min-width: 0;
        }


        .notification-title {
            margin-bottom: 2px;

            font-size: 10px;
            font-weight: 800;

            color: #ffffff;
        }


        .notification-text {
            font-size: 10px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.58
                );
        }


        /*
        ========================================
        TOOLBAR
        ========================================
        */

        .venues-toolbar {
            display: grid;

            grid-template-columns:
                minmax(
                    280px,
                    1fr
                )
                180px
                145px;

            gap: 12px;

            margin-bottom: 14px;
        }


        /*
        SEARCH
        */

        .search-wrapper {
            position: relative;
        }


        .search-icon {
            position: absolute;

            left: 15px;
            top: 50%;

            width: 17px;
            height: 17px;

            transform:
                translateY(
                    -50%
                );

            pointer-events: none;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        .search-wrapper input {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                15px
                0
                43px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.22
                );

            border-radius: 8px;

            outline: none;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.085
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 12px;

            transition:
                border-color
                0.18s ease,
                background
                0.18s ease,
                box-shadow
                0.18s ease;
        }


        .search-wrapper input::placeholder {
            color:
                rgba(
                    255,
                    255,
                    255,
                    0.47
                );
        }


        .search-wrapper input:hover {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.105
                );
        }


        .search-wrapper input:focus {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.11
                );

            border-color:
                rgba(
                    224,
                    107,
                    174,
                    0.55
                );

            box-shadow:
                0
                0
                0
                3px
                rgba(
                    224,
                    107,
                    174,
                    0.07
                );
        }


        /*
        FILTER
        */

        .venues-filter select {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                13px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.12
                );

            border-radius: 8px;

            outline: none;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.06
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            font-weight: 600;

            cursor: pointer;
        }


        .venues-filter option {
            background: #1B1745;
            color: #ffffff;
        }


        /*
        ADD BUTTON
        */

        .add-venue-btn {
            width: 100%;
            height: 42px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            gap: 7px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.28
                );

            border-radius: 8px;

            background:
                linear-gradient(
                    135deg,
                    var(
                        --purple,
                        #5B2A86
                    ),
                    var(
                        --magenta,
                        #B0449E
                    )
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.35px;

            cursor: pointer;
        }


        .add-venue-btn:hover {
            opacity: 0.9;
        }


        .add-venue-btn svg {
            width: 14px;
            height: 14px;
        }


        /*
        ========================================
        TABLE
        ========================================
        */

        .venues-table-wrapper {
            width: 100%;
            overflow-x: auto;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 9px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.02
                );
        }


        .venues-table {
            width: 100%;
            min-width: 900px;

            border-collapse: collapse;
            table-layout: fixed;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .venues-table thead {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.045
                );
        }


        .venues-table th {
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                13px;

            text-align: left;

            border-bottom:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.65px;

            color:
                rgba(
                    246,
                    197,
                    142,
                    0.88
                );
        }


        .venues-table td {
            height: 51px;

            box-sizing: border-box;

            padding:
                7px
                13px;

            vertical-align: middle;

            border-bottom:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.065
                );

            font-size: 11px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.83
                );
        }


        .venues-table tbody tr:hover {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.028
                );
        }


        .venues-table tbody tr:last-child td {
            border-bottom: none;
        }


        /*
        COLUMN WIDTHS
        */

        .col-id {
            width: 70px;
        }


        .col-venue {
            width: 220px;
        }


        .col-location {
            width: 260px;
        }


        .col-capacity {
            width: 110px;
            text-align: center !important;
        }


        .col-events {
            width: 95px;
            text-align: center !important;
        }


        .col-status {
            width: 120px;
            text-align: center !important;
        }


        .col-action {
            width: 165px;
            text-align: center !important;
        }


        /*
        VENUE INFO
        */

        .venue-id {
            font-weight: 800;

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .venue-name {
            font-size: 11px;
            font-weight: 750;

            color: #ffffff;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        .venue-location {
            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.70
                );

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        /*
        MINI COUNT
        */

        .mini-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 36px;
            height: 25px;

            padding:
                0
                7px;

            box-sizing: border-box;

            border-radius: 5px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.055
                );

            font-size: 10px;
            font-weight: 750;

            color: #ffffff;
        }


        /*
        STATUS
        */

        .status-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 78px;

            padding:
                5px
                8px;

            box-sizing: border-box;

            border-radius: 5px;

            font-size: 8px;
            font-weight: 800;
            letter-spacing: 0.25px;
        }


        .status-available {
            background:
                rgba(
                    95,
                    180,
                    160,
                    0.10
                );

            border:
                1px solid
                rgba(
                    95,
                    180,
                    160,
                    0.24
                );

            color: #8FD8C6;
        }


        .status-unavailable {
            background:
                rgba(
                    230,
                    95,
                    120,
                    0.10
                );

            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.25
                );

            color: #EF8295;
        }


        /*
        ========================================
        ACTIONS
        ========================================
        */

        .venue-actions {
            display: flex;
            align-items: center;
            justify-content: center;

            gap: 9px;
        }


        .manage-venue-btn {
            height: 30px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            padding:
                0
                13px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.25
                );

            border-radius: 5px;

            background:
                linear-gradient(
                    135deg,
                    var(
                        --purple,
                        #5B2A86
                    ),
                    var(
                        --magenta,
                        #B0449E
                    )
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.3px;

            cursor: pointer;
        }


        .manage-venue-btn:hover {
            opacity: 0.88;
        }


        .delete-venue-btn {
            width: 32px;
            height: 30px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            padding: 0;

            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.25
                );

            border-radius: 5px;

            background:
                rgba(
                    180,
                    55,
                    80,
                    0.13
                );

            color: #EF8295;

            cursor: pointer;

            transition:
                background
                0.15s ease,
                transform
                0.15s ease;
        }


        .delete-venue-btn:hover {
            background:
                rgba(
                    180,
                    55,
                    80,
                    0.26
                );

            transform:
                translateY(
                    -1px
                );
        }


        .delete-venue-btn svg {
            width: 14px;
            height: 14px;
        }


        /*
        ========================================
        EMPTY
        ========================================
        */

        .venues-empty {
            padding:
                30px
                20px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        .pagination-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 14px;
            flex-wrap: wrap;

            margin-top: 13px;
        }


        .pagination-info {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        .pagination-controls {
            display: flex;
            align-items: center;

            gap: 8px;
        }


        .pagination-btn {
            min-width: 82px;
            height: 32px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            padding:
                0
                12px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 5px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.045
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 750;

            cursor: pointer;
        }


        .pagination-btn:hover:not(:disabled) {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.09
                );
        }


        .pagination-btn:disabled {
            opacity: 0.28;
            cursor: not-allowed;
        }


        .pagination-page {
            min-width: 78px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 700;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        /*
        ========================================
        MODAL
        ========================================
        */

        .venues-modal-overlay {
            position: fixed;
            inset: 0;

            display: none;
            align-items: center;
            justify-content: center;

            padding: 20px;

            box-sizing: border-box;

            background:
                rgba(
                    0,
                    0,
                    0,
                    0.74
                );

            z-index: 9999;
        }


        .venues-modal-overlay.active {
            display: flex;
        }


        .venues-modal {
            width: 100%;
            max-width: 560px;

            max-height: 90vh;
            overflow-y: auto;

            box-sizing: border-box;

            padding: 23px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.14
                );

            border-radius: 10px;

            background:
                var(
                    --panel-soft,
                    #241C56
                );
        }


        .venues-modal-header {
            margin-bottom: 20px;
        }


        .venues-modal-header h2 {
            margin:
                0
                0
                5px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 18px;
            font-weight: 800;

            color: #ffffff;
        }


        .venues-modal-header p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        .venues-modal .form-group {
            margin-bottom: 14px;
        }


        .venues-modal .form-group label {
            display: block;

            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.6px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        .venues-modal input,
        .venues-modal select {
            width: 100%;
            height: 40px;

            box-sizing: border-box;

            padding:
                0
                12px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.12
                );

            border-radius: 6px;

            outline: none;

            background:
                var(
                    --panel,
                    #1B1745
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
        }


        .venues-modal select option {
            background: #1B1745;
            color: #ffffff;
        }


        .venues-modal input:focus,
        .venues-modal select:focus {
            border-color:
                rgba(
                    224,
                    107,
                    174,
                    0.45
                );
        }


        .venues-modal-actions {
            display: grid;

            grid-template-columns:
                1fr
                1fr;

            gap: 10px;

            margin-top: 20px;
        }


        .venues-modal-actions button {
            height: 38px;
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                10px !important;

            padding-top:
                11px !important;

            padding-bottom:
                11px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 850px) {

            .venues-toolbar {
                grid-template-columns:
                    1fr;
            }

        }


        @media (max-width: 720px) {

            .venues-page-header {
                align-items: stretch;
            }


            .venues-count-card {
                width: 100%;
            }


            .pagination-bar {
                justify-content: center;
            }


            .pagination-info {
                width: 100%;
                text-align: center;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <h1>MANAGE VENUES</h1>


    <div class="venues-shell">


        <!-- PAGE HEADER -->

        <div class="venues-page-header">


            <div class="venues-page-header-text">

                <h2>
                    Venue Management
                </h2>

                <p>
                    Manage venue information, capacity and availability.
                </p>

            </div>


            <div class="venues-count-card">


                <div class="venues-count-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                    >

                        <path
                            d="M3 21h18"
                        ></path>

                        <path
                            d="M5 21V8l7-5 7 5v13"
                        ></path>

                        <path
                            d="M9 21v-6h6v6"
                        ></path>

                        <path
                            d="M8 10h.01"
                        ></path>

                        <path
                            d="M12 10h.01"
                        ></path>

                        <path
                            d="M16 10h.01"
                        ></path>

                    </svg>

                </div>


                <div class="venues-count-content">

                    <span
                        class="venues-count-number"
                        id="venuesCount"
                    >
                        0
                    </span>

                    <span class="venues-count-label">
                        VENUES
                    </span>

                </div>


            </div>


        </div>


        <!-- NOTIFICATION -->

        <div id="venueMessage"></div>


        <!-- TOOLBAR -->

        <div class="venues-toolbar">


            <div class="search-wrapper">


                <svg
                    class="search-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20l-3.5-3.5"
                    ></path>

                </svg>


                <input
                    type="text"
                    id="venueSearch"
                    placeholder="Search venue name, location or venue ID..."
                >


            </div>


            <div class="venues-filter">

                <select id="statusFilter">

                    <option value="All">
                        All Status
                    </option>

                    <option value="Available">
                        Available
                    </option>

                    <option value="Unavailable">
                        Unavailable
                    </option>

                </select>

            </div>


            <button
                type="button"
                class="add-venue-btn"
                onclick="openAddVenueModal()"
            >

                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <path
                        d="M12 5v14"
                    ></path>

                    <path
                        d="M5 12h14"
                    ></path>

                </svg>

                ADD VENUE

            </button>


        </div>


        <!-- TABLE -->

        <div class="venues-table-wrapper">


            <table class="venues-table">


                <thead>

                    <tr>

                        <th class="col-id">
                            ID
                        </th>

                        <th class="col-venue">
                            VENUE
                        </th>

                        <th class="col-location">
                            LOCATION
                        </th>

                        <th class="col-capacity">
                            CAPACITY
                        </th>

                        <th class="col-events">
                            EVENTS
                        </th>

                        <th class="col-status">
                            STATUS
                        </th>

                        <th class="col-action">
                            ACTION
                        </th>

                    </tr>

                </thead>


                <tbody id="venuesTableBody">

                    <tr>

                        <td colspan="7">

                            <div class="venues-empty">
                                Loading venues...
                            </div>

                        </td>

                    </tr>

                </tbody>


            </table>


        </div>


        <!-- PAGINATION -->

        <div class="pagination-bar">


            <div
                class="pagination-info"
                id="paginationInfo"
            >
                Showing 0 venues
            </div>


            <div class="pagination-controls">


                <button
                    type="button"
                    class="pagination-btn"
                    id="previousPageButton"
                    onclick="previousPage()"
                >
                    PREVIOUS
                </button>


                <div
                    class="pagination-page"
                    id="paginationPage"
                >
                    Page 1 of 1
                </div>


                <button
                    type="button"
                    class="pagination-btn"
                    id="nextPageButton"
                    onclick="nextPage()"
                >
                    NEXT
                </button>


            </div>


        </div>


    </div>


    <!-- ADD VENUE MODAL -->

    <div
        class="venues-modal-overlay"
        id="addVenueModal"
    >


        <div class="venues-modal">


            <div class="venues-modal-header">

                <h2>
                    Add Venue
                </h2>

                <p>
                    Create a new venue for Eventify events.
                </p>

            </div>


            <div class="form-group">

                <label for="addVenueName">
                    VENUE NAME
                </label>

                <input
                    type="text"
                    id="addVenueName"
                    placeholder="Enter venue name"
                >

            </div>


            <div class="form-group">

                <label for="addVenueLocation">
                    LOCATION
                </label>

                <input
                    type="text"
                    id="addVenueLocation"
                    placeholder="Enter venue location"
                >

            </div>


            <div class="form-group">

                <label for="addVenueCapacity">
                    CAPACITY
                </label>

                <input
                    type="number"
                    id="addVenueCapacity"
                    min="1"
                    placeholder="Enter venue capacity"
                >

            </div>


            <div class="form-group">

                <label for="addVenueStatus">
                    STATUS
                </label>

                <select id="addVenueStatus">

                    <option value="Available">
                        Available
                    </option>

                    <option value="Unavailable">
                        Unavailable
                    </option>

                </select>

            </div>


            <div class="venues-modal-actions">


                <button
                    type="button"
                    class="btn"
                    id="createVenueButton"
                    onclick="createVenue()"
                >
                    CREATE VENUE
                </button>


                <button
                    type="button"
                    class="btn btn-secondary"
                    onclick="closeAddVenueModal()"
                >
                    CANCEL
                </button>


            </div>


        </div>


    </div>


    <!-- MANAGE VENUE MODAL -->

    <div
        class="venues-modal-overlay"
        id="manageVenueModal"
    >


        <div class="venues-modal">


            <div class="venues-modal-header">

                <h2>
                    Manage Venue
                </h2>

                <p>
                    Update venue information and availability.
                </p>

            </div>


            <div class="form-group">

                <label>
                    VENUE ID
                </label>

                <input
                    type="text"
                    id="manageVenueId"
                    readonly
                >

            </div>


            <div class="form-group">

                <label for="manageVenueName">
                    VENUE NAME
                </label>

                <input
                    type="text"
                    id="manageVenueName"
                >

            </div>


            <div class="form-group">

                <label for="manageVenueLocation">
                    LOCATION
                </label>

                <input
                    type="text"
                    id="manageVenueLocation"
                >

            </div>


            <div class="form-group">

                <label for="manageVenueCapacity">
                    CAPACITY
                </label>

                <input
                    type="number"
                    id="manageVenueCapacity"
                    min="1"
                >

            </div>


            <div class="form-group">

                <label for="manageVenueStatus">
                    STATUS
                </label>

                <select id="manageVenueStatus">

                    <option value="Available">
                        Available
                    </option>

                    <option value="Unavailable">
                        Unavailable
                    </option>

                </select>

            </div>


            <div class="venues-modal-actions">


                <button
                    type="button"
                    class="btn"
                    id="updateVenueButton"
                    onclick="updateSelectedVenue()"
                >
                    UPDATE VENUE
                </button>


                <button
                    type="button"
                    class="btn btn-secondary"
                    onclick="closeManageVenueModal()"
                >
                    CANCEL
                </button>


            </div>


        </div>


    </div>


    <div class="footer">

        EVENTIFY ADMIN PORTAL

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        SESSION
        ========================================
        */

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser =
            null;


        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const venuesTableBody =
            document.getElementById(
                'venuesTableBody'
            );


        const venueSearch =
            document.getElementById(
                'venueSearch'
            );


        const statusFilter =
            document.getElementById(
                'statusFilter'
            );


        const venuesCount =
            document.getElementById(
                'venuesCount'
            );


        const paginationInfo =
            document.getElementById(
                'paginationInfo'
            );


        const paginationPage =
            document.getElementById(
                'paginationPage'
            );


        const previousPageButton =
            document.getElementById(
                'previousPageButton'
            );


        const nextPageButton =
            document.getElementById(
                'nextPageButton'
            );


        const venueMessage =
            document.getElementById(
                'venueMessage'
            );


        const addVenueModal =
            document.getElementById(
                'addVenueModal'
            );


        const manageVenueModal =
            document.getElementById(
                'manageVenueModal'
            );


        /*
        ========================================
        DATA
        ========================================
        */

        let allVenues =
            [];


        let filteredVenues =
            [];


        let selectedVenueId =
            null;


        const venuesPerPage =
            5;


        let currentPage =
            1;


        /*
        ========================================
        AUTH
        ========================================
        */

        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }


            if (
                currentUser &&
                currentUser.role !==
                'Administrator'
            ) {

                alert(
                    'Administrator access only.'
                );


                window.location.href =
                    'login.php';

            }

            else if (currentUser) {

                loadVenues();

            }

        }


        /*
        ========================================
        SEARCH / FILTER
        ========================================
        */

        venueSearch.addEventListener(
            'input',
            function() {

                currentPage =
                    1;


                filterVenues();

            }
        );


        statusFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterVenues();

            }
        );


        /*
        ========================================
        MODAL BACKDROP
        ========================================
        */

        addVenueModal.addEventListener(
            'click',
            function(event) {

                if (
                    event.target ===
                    addVenueModal
                ) {

                    closeAddVenueModal();

                }

            }
        );


        manageVenueModal.addEventListener(
            'click',
            function(event) {

                if (
                    event.target ===
                    manageVenueModal
                ) {

                    closeManageVenueModal();

                }

            }
        );


        document.addEventListener(
            'keydown',
            function(event) {

                if (
                    event.key ===
                    'Escape'
                ) {

                    closeAddVenueModal();

                    closeManageVenueModal();

                }

            }
        );


        /*
        ========================================
        LOAD VENUES
        ========================================
        */

        async function loadVenues() {

            venuesTableBody.innerHTML = `

                <tr>

                    <td colspan="7">

                        <div class="venues-empty">
                            Loading venues...
                        </div>

                    </td>

                </tr>

            `;


            try {

                const response =
                    await fetch(
                        '../api/venues.php'
                    );


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    allVenues =
                        result.data ||
                        [];


                    filterVenues();

                }

                else {

                    showNotification(
                        'error',
                        'Unable to load venues',
                        result.message ||
                        'The venue list could not be retrieved.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Venue API error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Venues API.'
                );

            }

        }


        /*
        ========================================
        FILTER
        ========================================
        */

        function filterVenues() {

            const searchValue =
                venueSearch
                    .value
                    .trim()
                    .toLowerCase();


            const selectedStatus =
                statusFilter.value;


            filteredVenues =
                allVenues.filter(
                    function(venue) {


                        const id =
                            String(
                                venue.venue_id ||
                                ''
                            )
                            .toLowerCase();


                        const name =
                            String(
                                venue.venue_name ||
                                ''
                            )
                            .toLowerCase();


                        const location =
                            String(
                                venue.location ||
                                ''
                            )
                            .toLowerCase();


                        const matchesSearch =

                            !searchValue

                            ||

                            id.includes(
                                searchValue
                            )

                            ||

                            name.includes(
                                searchValue
                            )

                            ||

                            location.includes(
                                searchValue
                            );


                        const matchesStatus =

                            selectedStatus ===
                            'All'

                            ||

                            venue.status ===
                            selectedStatus;


                        return (
                            matchesSearch &&
                            matchesStatus
                        );

                    }
                );


            const totalPages =
                getTotalPages();


            if (
                currentPage >
                totalPages
            ) {

                currentPage =
                    totalPages;

            }


            if (
                currentPage <
                1
            ) {

                currentPage =
                    1;

            }


            displayVenues();

        }


        /*
        ========================================
        DISPLAY
        ========================================
        */

        function displayVenues() {

            venuesCount.textContent =
                filteredVenues.length;


            if (
                filteredVenues.length ===
                0
            ) {

                venuesTableBody.innerHTML = `

                    <tr>

                        <td colspan="7">

                            <div class="venues-empty">
                                No venues found.
                            </div>

                        </td>

                    </tr>

                `;


                updatePagination();

                return;

            }


            const startIndex =
                (
                    currentPage -
                    1
                )
                *
                venuesPerPage;


            const endIndex =
                startIndex +
                venuesPerPage;


            const pageVenues =
                filteredVenues.slice(
                    startIndex,
                    endIndex
                );


            venuesTableBody.innerHTML =
                '';


            pageVenues.forEach(
                function(venue) {


                    const eventCount =
                        Number(

                            venue.event_count

                            ??

                            venue.events_count

                            ??

                            venue.total_events

                            ??

                            0

                        );


                    venuesTableBody.innerHTML += `

                        <tr>


                            <td>

                                <span class="venue-id">

                                    #${venue.venue_id}

                                </span>

                            </td>


                            <td>

                                <div class="venue-name">

                                    ${escapeHtml(
                                        venue.venue_name
                                    )}

                                </div>

                            </td>


                            <td>

                                <div class="venue-location">

                                    ${escapeHtml(
                                        venue.location
                                    )}

                                </div>

                            </td>


                            <td
                                style="
                                    text-align:center;
                                "
                            >

                                <span class="mini-count">

                                    ${Number(
                                        venue.capacity ||
                                        0
                                    )}

                                </span>

                            </td>


                            <td
                                style="
                                    text-align:center;
                                "
                            >

                                <span class="mini-count">

                                    ${eventCount}

                                </span>

                            </td>


                            <td
                                style="
                                    text-align:center;
                                "
                            >

                                <span
                                    class="
                                        status-badge
                                        ${getStatusClass(
                                            venue.status
                                        )}
                                    "
                                >

                                    ${escapeHtml(
                                        venue.status
                                    )}

                                </span>

                            </td>


                            <td>


                                <div class="venue-actions">


                                    <button
                                        type="button"
                                        class="manage-venue-btn"
                                        onclick="openManageVenueModal(
                                            ${venue.venue_id}
                                        )"
                                    >
                                        MANAGE
                                    </button>


                                    <button
                                        type="button"
                                        class="delete-venue-btn"
                                        onclick="deleteVenue(
                                            ${venue.venue_id}
                                        )"
                                        title="Delete venue"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.9"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >

                                            <polyline
                                                points="3 6 5 6 21 6"
                                            ></polyline>

                                            <path
                                                d="M19 6l-1 14H6L5 6"
                                            ></path>

                                            <path
                                                d="M10 11v5"
                                            ></path>

                                            <path
                                                d="M14 11v5"
                                            ></path>

                                            <path
                                                d="M9 6V4h6v2"
                                            ></path>

                                        </svg>

                                    </button>


                                </div>


                            </td>


                        </tr>

                    `;

                }
            );


            updatePagination();

        }


        /*
        ========================================
        STATUS
        ========================================
        */

        function getStatusClass(
            status
        ) {

            if (
                status ===
                'Available'
            ) {

                return 'status-available';

            }


            return 'status-unavailable';

        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        function getTotalPages() {

            return Math.max(

                1,

                Math.ceil(
                    filteredVenues.length /
                    venuesPerPage
                )

            );

        }


        function updatePagination() {

            const totalPages =
                getTotalPages();


            const start =

                filteredVenues.length ===
                0

                ? 0

                : (
                    (
                        currentPage -
                        1
                    )
                    *
                    venuesPerPage
                )
                +
                1;


            const end =
                Math.min(

                    currentPage *
                    venuesPerPage,

                    filteredVenues.length

                );


            paginationInfo.textContent =

                filteredVenues.length ===
                0

                ? 'Showing 0 venues'

                : `Showing ${start}-${end} of ${filteredVenues.length} venues`;


            paginationPage.textContent =

                `Page ${currentPage} of ${totalPages}`;


            previousPageButton.disabled =
                currentPage <=
                1;


            nextPageButton.disabled =
                currentPage >=
                totalPages;

        }


        function previousPage() {

            if (
                currentPage <=
                1
            ) {

                return;

            }


            currentPage--;


            displayVenues();

        }


        function nextPage() {

            const totalPages =
                getTotalPages();


            if (
                currentPage >=
                totalPages
            ) {

                return;

            }


            currentPage++;


            displayVenues();

        }


        /*
        ========================================
        ADD VENUE MODAL
        ========================================
        */

        function openAddVenueModal() {

            document
                .getElementById(
                    'addVenueName'
                )
                .value =
                    '';


            document
                .getElementById(
                    'addVenueLocation'
                )
                .value =
                    '';


            document
                .getElementById(
                    'addVenueCapacity'
                )
                .value =
                    '';


            document
                .getElementById(
                    'addVenueStatus'
                )
                .value =
                    'Available';


            addVenueModal
                .classList
                .add(
                    'active'
                );


            document.body.style.overflow =
                'hidden';

        }


        function closeAddVenueModal() {

            addVenueModal
                .classList
                .remove(
                    'active'
                );


            document.body.style.overflow =
                '';

        }


        /*
        ========================================
        CREATE VENUE
        ========================================
        */

        async function createVenue() {

            const venueName =
                document
                    .getElementById(
                        'addVenueName'
                    )
                    .value
                    .trim();


            const location =
                document
                    .getElementById(
                        'addVenueLocation'
                    )
                    .value
                    .trim();


            const capacity =
                Number(
                    document
                        .getElementById(
                            'addVenueCapacity'
                        )
                        .value
                );


            const status =
                document
                    .getElementById(
                        'addVenueStatus'
                    )
                    .value;


            if (
                !venueName ||
                !location
            ) {

                showNotification(
                    'error',
                    'Missing information',
                    'Venue name and location are required.'
                );

                return;

            }


            if (
                capacity <
                1
            ) {

                showNotification(
                    'error',
                    'Invalid capacity',
                    'Venue capacity must be at least 1.'
                );

                return;

            }


            const button =
                document.getElementById(
                    'createVenueButton'
                );


            button.disabled =
                true;


            button.textContent =
                'CREATING...';


            try {

                const response =
                    await fetch(
                        '../api/venues.php',
                        {

                            method:
                                'POST',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    venue_name:
                                        venueName,

                                    location:
                                        location,

                                    capacity:
                                        capacity,

                                    status:
                                        status

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    closeAddVenueModal();


                    showNotification(
                        'success',
                        'Venue created',
                        `${venueName} has been added successfully.`
                    );


                    await loadVenues();

                }

                else {

                    showNotification(
                        'error',
                        'Create failed',
                        result.message ||
                        'Unable to create this venue.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Create venue error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Venues API.'
                );

            }

            finally {

                button.disabled =
                    false;


                button.textContent =
                    'CREATE VENUE';

            }

        }


        /*
        ========================================
        MANAGE VENUE MODAL
        ========================================
        */

        function openManageVenueModal(
            venueId
        ) {

            const venue =
                allVenues.find(
                    function(item) {

                        return (
                            Number(
                                item.venue_id
                            )
                            ===
                            Number(
                                venueId
                            )
                        );

                    }
                );


            if (!venue) {

                return;

            }


            selectedVenueId =
                Number(
                    venueId
                );


            document
                .getElementById(
                    'manageVenueId'
                )
                .value =
                    venue.venue_id;


            document
                .getElementById(
                    'manageVenueName'
                )
                .value =
                    venue.venue_name ||
                    '';


            document
                .getElementById(
                    'manageVenueLocation'
                )
                .value =
                    venue.location ||
                    '';


            document
                .getElementById(
                    'manageVenueCapacity'
                )
                .value =
                    venue.capacity ||
                    '';


            document
                .getElementById(
                    'manageVenueStatus'
                )
                .value =
                    venue.status;


            manageVenueModal
                .classList
                .add(
                    'active'
                );


            document.body.style.overflow =
                'hidden';

        }


        function closeManageVenueModal() {

            manageVenueModal
                .classList
                .remove(
                    'active'
                );


            selectedVenueId =
                null;


            document.body.style.overflow =
                '';

        }


        /*
        ========================================
        UPDATE VENUE
        ========================================
        */

        async function updateSelectedVenue() {

            if (
                selectedVenueId ===
                null
            ) {

                return;

            }


            const venueName =
                document
                    .getElementById(
                        'manageVenueName'
                    )
                    .value
                    .trim();


            const location =
                document
                    .getElementById(
                        'manageVenueLocation'
                    )
                    .value
                    .trim();


            const capacity =
                Number(
                    document
                        .getElementById(
                            'manageVenueCapacity'
                        )
                        .value
                );


            const status =
                document
                    .getElementById(
                        'manageVenueStatus'
                    )
                    .value;


            if (
                !venueName ||
                !location
            ) {

                showNotification(
                    'error',
                    'Missing information',
                    'Venue name and location are required.'
                );

                return;

            }


            if (
                capacity <
                1
            ) {

                showNotification(
                    'error',
                    'Invalid capacity',
                    'Venue capacity must be at least 1.'
                );

                return;

            }


            const button =
                document.getElementById(
                    'updateVenueButton'
                );


            button.disabled =
                true;


            button.textContent =
                'UPDATING...';


            try {

                const response =
                    await fetch(
                        '../api/venues.php',
                        {

                            method:
                                'PUT',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    venue_id:
                                        Number(
                                            selectedVenueId
                                        ),

                                    venue_name:
                                        venueName,

                                    location:
                                        location,

                                    capacity:
                                        capacity,

                                    status:
                                        status

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    closeManageVenueModal();


                    showNotification(
                        'success',
                        'Venue updated',
                        `${venueName} has been updated successfully.`
                    );


                    await loadVenues();

                }

                else {

                    showNotification(
                        'error',
                        'Update failed',
                        result.message ||
                        'Unable to update this venue.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Update venue error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Venues API.'
                );

            }

            finally {

                button.disabled =
                    false;


                button.textContent =
                    'UPDATE VENUE';

            }

        }


        /*
        ========================================
        DELETE VENUE
        ========================================
        */

        async function deleteVenue(
            venueId
        ) {

            const venue =
                allVenues.find(
                    function(item) {

                        return (
                            Number(
                                item.venue_id
                            )
                            ===
                            Number(
                                venueId
                            )
                        );

                    }
                );


            if (!venue) {

                return;

            }


            const confirmed =
                confirm(

                    `Delete venue "${venue.venue_name}"?\n\n` +

                    `Location: ${venue.location}\n` +

                    `Capacity: ${venue.capacity}\n\n` +

                    `Venues linked to existing events may not be deleted.`

                );


            if (!confirmed) {

                return;

            }


            try {

                const response =
                    await fetch(
                        '../api/venues.php',
                        {

                            method:
                                'DELETE',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    venue_id:
                                        Number(
                                            venueId
                                        )

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    showNotification(
                        'success',
                        'Venue deleted',
                        `${venue.venue_name} has been removed successfully.`
                    );


                    await loadVenues();

                }

                else {

                    showNotification(
                        'error',
                        'Delete failed',
                        result.message ||
                        'Unable to delete this venue.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Delete venue error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Venues API.'
                );

            }

        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        function showNotification(
            type,
            title,
            text
        ) {

            const isSuccess =
                type ===
                'success';


            venueMessage.innerHTML = `

                <div
                    class="
                        venues-notification
                        ${
                            isSuccess

                            ? 'venues-notification-success'

                            : 'venues-notification-error'
                        }
                    "
                >

                    <div class="notification-icon">

                        ${
                            isSuccess
                            ? '✓'
                            : '!'
                        }

                    </div>


                    <div class="notification-content">

                        <div class="notification-title">

                            ${escapeHtml(
                                title
                            )}

                        </div>


                        <div class="notification-text">

                            ${escapeHtml(
                                text
                            )}

                        </div>

                    </div>

                </div>

            `;


            window.setTimeout(
                function() {

                    venueMessage.innerHTML =
                        '';

                },
                4000
            );

        }


        /*
        ========================================
        HELPERS
        ========================================
        */

        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }


        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );


            localStorage.removeItem(
                'eventify_user'
            );


            window.location.href =
                'login.php';

        }

    </script>


</body>

</html>