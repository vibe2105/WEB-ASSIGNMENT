<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Organiser Dashboard - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }


        .dashboard-shell {
            width: min(1180px, 92%);
            margin: 0 auto;
            flex: 1;
        }


        /*
        ========================================
        HERO
        ========================================
        */

        .dashboard-hero {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 18px;
            flex-wrap: wrap;

            margin-bottom: 20px;

            padding: 18px 22px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 10px;

            background:
                linear-gradient(
                    135deg,
                    rgba(
                        91,
                        42,
                        134,
                        0.22
                    ),
                    rgba(
                        27,
                        23,
                        69,
                        0.75
                    )
                );
        }


        .dashboard-hero-text {
            flex: 1;

            min-width: 250px;
        }


        .dashboard-hero-text h2 {
            margin:
                0
                0
                6px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 21px;
            font-weight: 800;
            line-height: 1.25;

            color: #ffffff;
        }


        .dashboard-hero-text p {
            margin: 0;

            max-width: 650px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 13px;
            line-height: 1.5;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.65
                );
        }


        .dashboard-role-badge {
            padding:
                9px
                13px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.35
                );

            border-radius: 6px;

            background:
                rgba(
                    224,
                    107,
                    174,
                    0.08
                );

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 800;

            letter-spacing: 1px;

            color:
                var(
                    --pink,
                    #E06BAE
                );

            white-space: nowrap;
        }


        /*
        ========================================
        SECTION
        ========================================
        */

        .dashboard-section {
            margin-bottom: 22px;
        }


        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: end;

            gap: 12px;
            flex-wrap: wrap;

            margin-bottom: 11px;
        }


        .section-heading {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 16px;
            font-weight: 800;

            color: #ffffff;
        }


        .section-description {
            margin-top: 3px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        /*
        ========================================
        STAT CARDS
        ========================================
        */

        .dashboard-stats {
            display: grid;

            grid-template-columns:
                repeat(
                    4,
                    1fr
                );

            gap: 14px;
        }


        .stat-card {
            position: relative;

            display: flex;
            flex-direction: column;

            min-height: 150px;

            box-sizing: border-box;

            padding: 16px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 10px;

            background:
                linear-gradient(
                    180deg,
                    rgba(
                        255,
                        255,
                        255,
                        0.045
                    ),
                    rgba(
                        255,
                        255,
                        255,
                        0.015
                    )
                );

            overflow: hidden;

            transition:
                transform
                0.18s ease,
                border-color
                0.18s ease;
        }


        .stat-card:hover {
            transform:
                translateY(
                    -2px
                );

            border-color:
                rgba(
                    224,
                    107,
                    174,
                    0.32
                );
        }


        .stat-card::after {
            content: "";

            position: absolute;

            top: -45px;
            right: -45px;

            width: 105px;
            height: 105px;

            border-radius: 50%;

            background:
                rgba(
                    176,
                    68,
                    158,
                    0.07
                );

            pointer-events: none;
        }


        .stat-label {
            position: relative;

            z-index: 2;

            margin-bottom: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 800;

            letter-spacing: 0.8px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.58
                );
        }


        .stat-value {
            position: relative;

            z-index: 2;

            margin-bottom: 5px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 21px;
            line-height: 1.35;

            color:
                var(
                    --sun,
                    #F6C58E
                );
        }


        .stat-description {
            position: relative;

            z-index: 2;

            margin-bottom: 12px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            line-height: 1.35;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.46
                );
        }


        .dashboard-action-btn {
            position: relative;

            z-index: 2;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            width: 100%;
            min-height: 34px;

            box-sizing: border-box;

            margin-top: auto;

            padding:
                8px
                10px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.28
                );

            border-radius: 6px;

            background:
                linear-gradient(
                    135deg,
                    var(
                        --purple,
                        #5B2A86
                    ),
                    var(
                        --magenta,
                        #B0449E
                    )
                );

            color: #ffffff;

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 800;

            letter-spacing: 0.4px;

            cursor: pointer;

            transition:
                opacity
                0.16s ease,
                transform
                0.16s ease;
        }


        .dashboard-action-btn:hover {
            opacity: 0.9;

            transform:
                translateY(
                    -1px
                );
        }


        /*
        ========================================
        EVENT STATUS
        ========================================
        */

        .summary-panel {
            padding: 14px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 10px;

            background:
                linear-gradient(
                    180deg,
                    rgba(
                        255,
                        255,
                        255,
                        0.035
                    ),
                    rgba(
                        255,
                        255,
                        255,
                        0.015
                    )
                );
        }


        .summary-grid {
            display: grid;

            grid-template-columns:
                repeat(
                    3,
                    1fr
                );

            gap: 12px;
        }


        .summary-item {
            min-height: 74px;

            box-sizing: border-box;

            padding:
                13px
                15px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.07
                );

            border-radius: 8px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.025
                );
        }


        .summary-label {
            display: block;

            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 800;

            letter-spacing: 0.6px;

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .summary-value {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 14px;
            font-weight: 700;

            line-height: 1.35;

            color: #ffffff;
        }


        /*
        ========================================
        ERROR
        ========================================
        */

        #dashboardMessage:empty {
            display: none;
        }


        #dashboardMessage {
            margin-bottom: 14px;
        }


        .dashboard-error {
            padding:
                10px
                13px;

            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.28
                );

            border-radius: 7px;

            background:
                rgba(
                    230,
                    95,
                    120,
                    0.09
                );

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color: #EF8295;
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                10px !important;

            padding-top:
                12px !important;

            padding-bottom:
                12px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 950px) {

            .dashboard-stats {
                grid-template-columns:
                    repeat(
                        2,
                        1fr
                    );
            }


            .summary-grid {
                grid-template-columns:
                    1fr;
            }

        }


        @media (max-width: 600px) {

            .dashboard-stats {
                grid-template-columns:
                    1fr;
            }


            .dashboard-role-badge {
                width: 100%;

                box-sizing: border-box;

                text-align: center;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <h1>ORGANISER DASHBOARD</h1>


    <div class="dashboard-shell">


        <div id="dashboardMessage"></div>


        <!-- HERO -->

        <div class="dashboard-hero">


            <div class="dashboard-hero-text">


                <h2 id="organiserWelcome">
                    Welcome back
                </h2>


                <p>
                    Track your events, customer bookings and
                    ticket activity from your Eventify organiser dashboard.
                </p>


            </div>


            <div class="dashboard-role-badge">
                ORGANISER
            </div>


        </div>


        <!-- EVENT OVERVIEW -->

        <div class="dashboard-section">


            <div class="section-header">


                <div>


                    <h2 class="section-heading">
                        Event Overview
                    </h2>


                    <div class="section-description">
                        Current activity from events managed by your account.
                    </div>


                </div>


            </div>


            <div class="dashboard-stats">


                <!-- MY EVENTS -->

                <div class="stat-card">


                    <div class="stat-label">
                        MY EVENTS
                    </div>


                    <div
                        class="stat-value"
                        id="totalEvents"
                    >
                        -
                    </div>


                    <div class="stat-description">
                        Total events currently managed by you.
                    </div>


                    <a
                        href="organiserevents.php"
                        class="dashboard-action-btn"
                    >
                        VIEW EVENTS
                    </a>


                </div>


                <!-- UPCOMING -->

                <div class="stat-card">


                    <div class="stat-label">
                        UPCOMING EVENTS
                    </div>


                    <div
                        class="stat-value"
                        id="upcomingEvents"
                    >
                        -
                    </div>


                    <div class="stat-description">
                        Events currently scheduled as upcoming.
                    </div>


                    <a
                        href="organiserevents.php"
                        class="dashboard-action-btn"
                    >
                        MANAGE EVENTS
                    </a>


                </div>


                <!-- TOTAL BOOKINGS -->

                <div class="stat-card">


                    <div class="stat-label">
                        TOTAL BOOKINGS
                    </div>


                    <div
                        class="stat-value"
                        id="totalBookings"
                    >
                        -
                    </div>


                    <div class="stat-description">
                        Customer bookings across your events.
                    </div>


                    <a
                        href="organiserbookings.php"
                        class="dashboard-action-btn"
                    >
                        VIEW BOOKINGS
                    </a>


                </div>


                <!-- CONFIRMED BOOKINGS -->

                <div class="stat-card">


                    <div class="stat-label">
                        CONFIRMED BOOKINGS
                    </div>


                    <div
                        class="stat-value"
                        id="confirmedBookings"
                    >
                        -
                    </div>


                    <div class="stat-description">
                        Booking records currently confirmed.
                    </div>


                    <a
                        href="organiserbookings.php"
                        class="dashboard-action-btn"
                    >
                        MANAGE BOOKINGS
                    </a>


                </div>


            </div>


        </div>


        <!-- EVENT STATUS -->

        <div class="dashboard-section">


            <div class="section-header">


                <div>


                    <h2 class="section-heading">
                        Event Status
                    </h2>


                    <div class="section-description">
                        Quick summary of the current status of your events.
                    </div>


                </div>


            </div>


            <div class="summary-panel">


                <div class="summary-grid">


                    <!-- ONGOING -->

                    <div class="summary-item">


                        <span class="summary-label">
                            ONGOING EVENTS
                        </span>


                        <span
                            class="summary-value"
                            id="ongoingEvents"
                        >
                            Loading...
                        </span>


                    </div>


                    <!-- COMPLETED -->

                    <div class="summary-item">


                        <span class="summary-label">
                            COMPLETED EVENTS
                        </span>


                        <span
                            class="summary-value"
                            id="completedEvents"
                        >
                            Loading...
                        </span>


                    </div>


                    <!-- CANCELLED -->

                    <div class="summary-item">


                        <span class="summary-label">
                            CANCELLED EVENTS
                        </span>


                        <span
                            class="summary-value"
                            id="cancelledEvents"
                        >
                            Loading...
                        </span>


                    </div>


                </div>


            </div>


        </div>


    </div>


    <div class="footer">

        EVENTIFY ORGANISER PORTAL

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        SESSION
        ========================================
        */

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser =
            null;


        /*
        ========================================
        AUTH
        ========================================
        */

        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }


            if (
                currentUser &&
                currentUser.role !==
                'Organiser'
            ) {

                alert(
                    'Organiser access only.'
                );


                window.location.href =
                    'login.php';

            }

            else if (currentUser) {


                const displayName =

                    currentUser.name

                    ||

                    currentUser.username

                    ||

                    'Organiser';


                document
                    .getElementById(
                        'organiserWelcome'
                    )
                    .textContent =
                        `Welcome, ${displayName}`;


                loadDashboard();

            }

        }


        /*
        ========================================
        LOAD DASHBOARD
        ========================================
        */

        async function loadDashboard() {

            try {

                const [
                    eventsResponse,
                    bookingsResponse
                ] =
                    await Promise.all([


                        fetch(
                            '../api/events.php'
                        ),


                        fetch(
                            '../api/bookings.php',
                            {

                                headers: {

                                    'Authorization':
                                        `Bearer ${token}`

                                }

                            }
                        )


                    ]);


                /*
                    SESSION EXPIRED
                */

                if (
                    bookingsResponse.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const [
                    eventsResult,
                    bookingsResult
                ] =
                    await Promise.all([


                        eventsResponse.json(),


                        bookingsResponse.json()


                    ]);


                /*
                ========================================
                EVENTS
                ========================================
                */

                const allEvents =

                    eventsResult.status ===
                    'success'

                    ? (
                        eventsResult.data ||
                        []
                    )

                    : [];


                /*
                    Filter only events created
                    by current organiser.
                */

                const myEvents =
                    allEvents.filter(
                        function(event) {

                            return (

                                Number(
                                    event.organiser_id
                                )

                                ===

                                Number(
                                    currentUser.user_id
                                )

                            );

                        }
                    );


                /*
                ========================================
                BOOKINGS
                ========================================
                */

                const bookings =

                    bookingsResult.status ===
                    'success'

                    ? (
                        bookingsResult.data ||
                        []
                    )

                    : [];


                /*
                ========================================
                TOTAL EVENTS
                ========================================
                */

                document
                    .getElementById(
                        'totalEvents'
                    )
                    .textContent =
                        myEvents.length;


                /*
                ========================================
                UPCOMING EVENTS
                ========================================
                */

                const upcomingCount =
                    myEvents.filter(
                        function(event) {

                            return (
                                event.status ===
                                'Upcoming'
                            );

                        }
                    ).length;


                document
                    .getElementById(
                        'upcomingEvents'
                    )
                    .textContent =
                        upcomingCount;


                /*
                ========================================
                BOOKINGS
                ========================================
                */

                document
                    .getElementById(
                        'totalBookings'
                    )
                    .textContent =
                        bookings.length;


                const confirmedCount =
                    bookings.filter(
                        function(booking) {

                            return (
                                booking.booking_status ===
                                'Confirmed'
                            );

                        }
                    ).length;


                document
                    .getElementById(
                        'confirmedBookings'
                    )
                    .textContent =
                        confirmedCount;


                /*
                ========================================
                EVENT STATUS
                ========================================
                */

                const ongoingCount =
                    myEvents.filter(
                        function(event) {

                            return (
                                event.status ===
                                'Ongoing'
                            );

                        }
                    ).length;


                const completedCount =
                    myEvents.filter(
                        function(event) {

                            return (
                                event.status ===
                                'Completed'
                            );

                        }
                    ).length;


                const cancelledCount =
                    myEvents.filter(
                        function(event) {

                            return (
                                event.status ===
                                'Cancelled'
                            );

                        }
                    ).length;


                document
                    .getElementById(
                        'ongoingEvents'
                    )
                    .textContent =

                        ongoingCount

                        +

                        (
                            ongoingCount ===
                            1

                            ? ' ongoing event'

                            : ' ongoing events'
                        );


                document
                    .getElementById(
                        'completedEvents'
                    )
                    .textContent =

                        completedCount

                        +

                        (
                            completedCount ===
                            1

                            ? ' completed event'

                            : ' completed events'
                        );


                document
                    .getElementById(
                        'cancelledEvents'
                    )
                    .textContent =

                        cancelledCount

                        +

                        (
                            cancelledCount ===
                            1

                            ? ' cancelled event'

                            : ' cancelled events'
                        );


            }

            catch (error) {

                console.error(
                    'Organiser dashboard error:',
                    error
                );


                document
                    .getElementById(
                        'dashboardMessage'
                    )
                    .innerHTML = `

                        <div class="dashboard-error">

                            Unable to load organiser dashboard data.

                        </div>

                    `;

            }

        }


        /*
        ========================================
        SESSION
        ========================================
        */

        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );


            localStorage.removeItem(
                'eventify_user'
            );


            window.location.href =
                'login.php';

        }

    </script>


</body>

</html>