<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Create Account - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >

    <style>

        /*
        ========================================
        PAGE
        ========================================
        */

        body {
            min-height: 100vh;
            margin: 0;

            display: flex;
            flex-direction: column;

            overflow-x: hidden;

            background:
                radial-gradient(
                    circle at 14% 82%,
                    rgba(91, 42, 134, 0.15),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 92% 16%,
                    rgba(224, 107, 174, 0.10),
                    transparent 28%
                ),
                #0B0B2E;
        }


        /*
        ========================================
        MAIN
        ========================================
        */

        .register-main {
            width: min(1180px, 92%);

            flex: 1;

            margin:
                0
                auto;

            display: grid;

            grid-template-columns:
                minmax(0, 1fr)
                1px
                minmax(420px, 490px);

            align-items: center;

            gap: 46px;

            box-sizing: border-box;

            padding:
                34px
                0
                26px
                0;
        }


        /*
        ========================================
        LEFT
        ========================================
        */

        .register-intro {
            width: 100%;
            max-width: 650px;
        }


        .intro-eyebrow {
            width: fit-content;

            display: inline-flex;
            align-items: center;

            gap: 8px;

            margin-bottom: 18px;

            padding:
                8px
                11px;

            border:
                1px solid
                rgba(224, 107, 174, 0.24);

            border-radius: 6px;

            background:
                rgba(224, 107, 174, 0.06);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            letter-spacing: 0.8px;

            color: #E06BAE;
        }


        .intro-dot {
            width: 6px;
            height: 6px;

            border-radius: 50%;

            background: #E06BAE;

            box-shadow:
                0
                0
                9px
                rgba(224, 107, 174, 0.65);
        }


        .register-intro h1 {
            margin:
                0
                0
                17px
                0;

            font-family:
                "Press Start 2P",
                monospace;

            font-size:
                clamp(
                    28px,
                    3.3vw,
                    46px
                );

            line-height: 1.38;

            color: #ffffff;
        }


        .register-intro h1 span {
            background:
                linear-gradient(
                    90deg,
                    #F6C58E,
                    #F4A7A0,
                    #E06BAE
                );

            background-clip: text;
            -webkit-background-clip: text;

            color: transparent;
            -webkit-text-fill-color: transparent;
        }


        .intro-description {
            margin:
                0
                0
                22px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 12px;
            line-height: 1.65;

            color:
                rgba(255, 255, 255, 0.60);
        }


        /*
        ========================================
        PROFILE CARD
        ========================================
        */

        .profile-card {
            display: flex;
            align-items: center;

            gap: 17px;

            padding:
                20px;

            margin-bottom: 12px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 9px;

            background:
                linear-gradient(
                    135deg,
                    rgba(36, 28, 86, 0.78),
                    rgba(21, 17, 58, 0.88)
                );
        }


        .profile-icon {
            width: 63px;
            height: 63px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border:
                1px solid
                rgba(224, 107, 174, 0.24);

            border-radius: 10px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            color: #ffffff;
        }


        .profile-icon svg {
            width: 30px;
            height: 30px;
        }


        .profile-content {
            flex: 1;
        }


        .profile-small {
            margin-bottom: 4px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.6px;

            color: #F6C58E;
        }


        .profile-title {
            margin-bottom: 5px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 17px;
            font-weight: 850;

            color: #ffffff;
        }


        .profile-text {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.43);
        }


        .profile-role {
            min-width: 70px;

            padding:
                9px
                8px;

            text-align: center;

            border:
                1px solid
                rgba(143, 216, 198, 0.14);

            border-radius: 6px;

            background:
                rgba(143, 216, 198, 0.04);
        }


        .profile-role strong {
            display: block;

            margin-bottom: 5px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;

            color: #8FD8C6;
        }


        .profile-role span {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;

            color:
                rgba(255, 255, 255, 0.26);
        }


        /*
        ========================================
        FEATURES
        ========================================
        */

        .feature-grid {
            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 9px;

            margin-bottom: 10px;
        }


        .feature-card {
            min-height: 83px;

            padding:
                12px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.07);

            border-radius: 7px;

            background:
                rgba(255, 255, 255, 0.022);
        }


        .feature-title {
            margin-bottom: 8px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            color: #ffffff;
        }


        .feature-text {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.38);
        }


        /*
        ========================================
        STEPS
        ========================================
        */

        .steps {
            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.07);

            border-radius: 7px;
        }


        .step {
            padding:
                9px;

            text-align: center;

            border-right:
                1px solid
                rgba(255, 255, 255, 0.06);
        }


        .step:last-child {
            border-right: none;
        }


        .step-number {
            display: block;

            margin-bottom: 3px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 8px;

            color: #F6C58E;
        }


        .step-label {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;
            font-weight: 750;

            color:
                rgba(255, 255, 255, 0.33);
        }


        /*
        ========================================
        DIVIDER
        ========================================
        */

        .register-divider {
            width: 1px;
            height: 88%;

            background:
                linear-gradient(
                    transparent,
                    rgba(255, 255, 255, 0.07),
                    rgba(224, 107, 174, 0.30),
                    rgba(255, 255, 255, 0.07),
                    transparent
                );

            position: relative;
        }


        .register-divider::after {
            content: "";

            position: absolute;

            left: 50%;
            top: 50%;

            width: 7px;
            height: 7px;

            transform:
                translate(-50%, -50%);

            border-radius: 50%;

            background: #E06BAE;

            box-shadow:
                0
                0
                12px
                rgba(224, 107, 174, 0.55);
        }


        /*
        ========================================
        REGISTER CARD
        ========================================
        */

        .register-card {
            width: 100%;

            box-sizing: border-box;

            padding:
                25px
                27px;

            border:
                1px solid
                rgba(255, 255, 255, 0.11);

            border-radius: 12px;

            background:
                linear-gradient(
                    180deg,
                    rgba(36, 28, 86, 0.94),
                    rgba(21, 17, 58, 0.97)
                );

            box-shadow:
                0
                25px
                70px
                rgba(0, 0, 0, 0.26);
        }


        /*
        ========================================
        TOP
        ========================================
        */

        .register-top {
            display: flex;
            align-items: center;
            justify-content: space-between;

            margin-bottom: 17px;
        }


        .new-player {
            display: flex;
            align-items: center;

            gap: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            color: #F6C58E;
        }


        .new-player-dot {
            width: 6px;
            height: 6px;

            border-radius: 50%;

            background: #8FD8C6;

            box-shadow:
                0
                0
                8px
                rgba(143, 216, 198, 0.55);
        }


        .customer-account {
            padding:
                5px
                7px;

            border:
                1px solid
                rgba(143, 216, 198, 0.14);

            border-radius: 5px;

            background:
                rgba(143, 216, 198, 0.04);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;
            font-weight: 800;

            color: #8FD8C6;
        }


        /*
        ========================================
        CARD HEADER
        ========================================
        */

        .register-header {
            margin-bottom: 18px;
        }


        .register-header h2 {
            margin:
                0
                0
                6px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 23px;
            font-weight: 850;

            color: #ffffff;
        }


        .register-header p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.44);
        }


        /*
        ========================================
        FORM
        ========================================
        */

        .form-group {
            margin-bottom: 12px;
        }


        .label-row {
            display: flex;
            align-items: center;
            justify-content: space-between;

            margin-bottom: 5px;
        }


        .label-row label {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 850;

            letter-spacing: 0.55px;

            color:
                rgba(255, 255, 255, 0.58);
        }


        .field-hint {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;

            color:
                rgba(255, 255, 255, 0.26);
        }


        .input-wrapper {
            position: relative;
        }


        .input-icon {
            position: absolute;

            left: 13px;
            top: 50%;

            width: 15px;
            height: 15px;

            transform:
                translateY(-50%);

            color:
                rgba(244, 167, 160, 0.72);

            pointer-events: none;
        }


        .input-wrapper input {
            width: 100%;
            height: 43px;

            box-sizing: border-box;

            padding:
                0
                100px
                0
                42px;

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 7px;

            outline: none;

            background:
                rgba(11, 11, 46, 0.48);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
        }


        #name,
        #email {
            padding-right: 13px;
        }


        .input-wrapper input:focus {
            border-color:
                rgba(224, 107, 174, 0.50);

            box-shadow:
                0
                0
                0
                3px
                rgba(224, 107, 174, 0.05);
        }


        /*
        ========================================
        PASSWORD TOGGLE
        ========================================
        */

        .password-toggle {
            position: absolute;

            right: 6px;
            top: 50%;

            min-width: 76px;
            height: 31px;

            transform:
                translateY(-50%);

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 5px;

            background:
                rgba(255, 255, 255, 0.035);

            color:
                rgba(255, 255, 255, 0.68);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 800;

            cursor: pointer;
        }


        /*
        ========================================
        PASSWORD STRENGTH
        ========================================
        */

        .password-strength {
            display: grid;

            grid-template-columns:
                repeat(4, 1fr);

            gap: 4px;

            margin-top: 6px;
        }


        .strength-bar {
            height: 3px;

            border-radius: 10px;

            background:
                rgba(255, 255, 255, 0.08);
        }


        .strength-bar.active {
            background: #8FD8C6;
        }


        .strength-text {
            margin-top: 4px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;

            color:
                rgba(255, 255, 255, 0.34);
        }


        .password-match {
            margin-top: 5px;

            min-height: 10px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;
        }


        .password-match.good {
            color: #8FD8C6;
        }


        .password-match.bad {
            color: #EF8295;
        }


        /*
        ========================================
        BUTTON
        ========================================
        */

        .register-submit {
            width: 100%;
            height: 44px;

            margin-top: 4px;

            border:
                1px solid
                rgba(224, 107, 174, 0.28);

            border-radius: 7px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E,
                    #E06BAE
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            letter-spacing: 0.35px;

            cursor: pointer;
        }


        .register-submit:disabled {
            opacity: 0.50;

            cursor: wait;
        }


        /*
        ========================================
        MESSAGE
        ========================================
        */

        .register-message {
            margin-top: 10px;
        }


        .register-message:empty {
            display: none;
        }


        .status-box {
            display: flex;
            align-items: center;

            gap: 10px;

            padding:
                9px
                10px;

            border-radius: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .status-box.error {
            border:
                1px solid
                rgba(239, 130, 149, 0.24);

            background:
                rgba(239, 130, 149, 0.06);
        }


        .status-box.success {
            border:
                1px solid
                rgba(143, 216, 198, 0.22);

            background:
                rgba(143, 216, 198, 0.055);
        }


        .status-icon {
            width: 27px;
            height: 27px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 5px;

            font-size: 11px;
            font-weight: 850;
        }


        .error .status-icon {
            background:
                rgba(239, 130, 149, 0.12);

            color: #EF8295;
        }


        .success .status-icon {
            background:
                rgba(143, 216, 198, 0.12);

            color: #8FD8C6;
        }


        .status-title {
            margin-bottom: 2px;

            font-size: 8px;
            font-weight: 850;

            color: #ffffff;
        }


        .status-text {
            font-size: 7px;

            color:
                rgba(255, 255, 255, 0.48);
        }


        /*
        ========================================
        BOTTOM
        ========================================
        */

        .account-divider {
            display: flex;
            align-items: center;

            gap: 9px;

            margin:
                13px
                0
                10px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;
            font-weight: 750;

            color:
                rgba(255, 255, 255, 0.27);
        }


        .account-divider::before,
        .account-divider::after {
            content: "";

            flex: 1;

            height: 1px;

            background:
                rgba(255, 255, 255, 0.07);
        }


        .login-link {
            width: 100%;
            height: 37px;

            display: flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            border:
                1px solid
                rgba(246, 197, 142, 0.18);

            border-radius: 6px;

            background:
                rgba(246, 197, 142, 0.03);

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            color: #F6C58E;
        }


        .guest-link {
            display: block;

            margin-top: 10px;

            text-align: center;

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;
            font-weight: 750;

            color:
                rgba(255, 255, 255, 0.37);
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .register-footer {
            padding:
                10px
                20px;

            border-top:
                1px solid
                rgba(255, 255, 255, 0.05);

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.28);
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 950px) {

            .register-main {
                grid-template-columns: 1fr;

                gap: 24px;
            }


            .register-divider {
                display: none;
            }


            .register-intro {
                margin:
                    0
                    auto;
            }


            .register-card {
                max-width: 520px;

                margin:
                    0
                    auto;
            }

        }


        @media (max-width: 600px) {

            .register-intro {
                display: none;
            }


            .register-main {
                width: 90%;
            }


            .register-card {
                padding:
                    21px;
            }

        }

    </style>

</head>


<body>


    <?php include 'navbar.php'; ?>


    <main class="register-main">


        <!--
        ========================================
        LEFT
        ========================================
        -->

        <section class="register-intro">


            <div class="intro-eyebrow">

                <span class="intro-dot"></span>

                JOIN EVENTIFY

            </div>


            <h1>

                CREATE YOUR

                <span>
                    EVENT STORY.
                </span>

            </h1>


            <p class="intro-description">

                Create your customer account and start discovering,
                booking and managing your Eventify experiences.

            </p>


            <div class="profile-card">


                <div class="profile-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <circle
                            cx="12"
                            cy="8"
                            r="4"
                        ></circle>

                        <path
                            d="M4 21v-2a8 8 0 0 1 16 0v2"
                        ></path>

                    </svg>

                </div>


                <div class="profile-content">

                    <div class="profile-small">
                        YOUR EVENTIFY PROFILE
                    </div>

                    <div class="profile-title">
                        One account. Every booking.
                    </div>

                    <div class="profile-text">

                        Your account keeps your event bookings,
                        ticket activity and history together.

                    </div>

                </div>


                <div class="profile-role">

                    <strong>
                        CUSTOMER
                    </strong>

                    <span>
                        DEFAULT ROLE
                    </span>

                </div>


            </div>


            <div class="feature-grid">


                <div class="feature-card">

                    <div class="feature-title">
                        EXPLORE
                    </div>

                    <div class="feature-text">

                        Browse upcoming Eventify events
                        and venues.

                    </div>

                </div>


                <div class="feature-card">

                    <div class="feature-title">
                        BOOK
                    </div>

                    <div class="feature-text">

                        Reserve tickets directly
                        from your account.

                    </div>

                </div>


                <div class="feature-card">

                    <div class="feature-title">
                        TRACK
                    </div>

                    <div class="feature-text">

                        Review confirmed and cancelled
                        bookings anytime.

                    </div>

                </div>


            </div>


            <div class="steps">


                <div class="step">

                    <span class="step-number">
                        01
                    </span>

                    <span class="step-label">
                        CREATE ACCOUNT
                    </span>

                </div>


                <div class="step">

                    <span class="step-number">
                        02
                    </span>

                    <span class="step-label">
                        FIND EVENT
                    </span>

                </div>


                <div class="step">

                    <span class="step-number">
                        03
                    </span>

                    <span class="step-label">
                        BOOK TICKET
                    </span>

                </div>


            </div>


        </section>


        <!-- DIVIDER -->

        <div class="register-divider"></div>


        <!--
        ========================================
        REGISTER CARD
        ========================================
        -->

        <section class="register-card">


            <div class="register-top">


                <div class="new-player">

                    <span class="new-player-dot"></span>

                    NEW PLAYER

                </div>


                <div class="customer-account">
                    CUSTOMER ACCOUNT
                </div>


            </div>


            <div class="register-header">


                <h2>
                    Create account.
                </h2>


                <p>

                    Enter your details below to join Eventify.
                    New public accounts are registered as customers.

                </p>


            </div>


            <form id="registerForm">


                <!--
                ========================================
                NAME
                ========================================
                -->

                <div class="form-group">


                    <div class="label-row">

                        <label for="name">
                            FULL NAME
                        </label>

                        <span class="field-hint">
                            REQUIRED
                        </span>

                    </div>


                    <div class="input-wrapper">


                        <svg
                            class="input-icon"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <circle
                                cx="12"
                                cy="8"
                                r="4"
                            ></circle>

                            <path
                                d="M5 21v-2a7 7 0 0 1 14 0v2"
                            ></path>

                        </svg>


                        <input
                            type="text"
                            id="name"
                            placeholder="Enter your full name"
                            autocomplete="name"
                            minlength="3"
                            required
                        >


                    </div>


                </div>


                <!--
                ========================================
                EMAIL
                ========================================
                -->

                <div class="form-group">


                    <div class="label-row">

                        <label for="email">
                            EMAIL ADDRESS
                        </label>

                        <span class="field-hint">
                            REQUIRED
                        </span>

                    </div>


                    <div class="input-wrapper">


                        <svg
                            class="input-icon"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <rect
                                x="3"
                                y="5"
                                width="18"
                                height="14"
                                rx="2"
                            ></rect>

                            <path
                                d="M3 7l9 6 9-6"
                            ></path>

                        </svg>


                        <input
                            type="email"
                            id="email"
                            placeholder="Enter your email"
                            autocomplete="email"
                            required
                        >


                    </div>


                </div>


                <!--
                ========================================
                PASSWORD
                ========================================
                -->

                <div class="form-group">


                    <div class="label-row">

                        <label for="password">
                            PASSWORD
                        </label>

                        <span class="field-hint">
                            MIN. 6 CHARACTERS
                        </span>

                    </div>


                    <div class="input-wrapper">


                        <svg
                            class="input-icon"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <rect
                                x="5"
                                y="10"
                                width="14"
                                height="10"
                                rx="2"
                            ></rect>

                            <path
                                d="M8 10V7a4 4 0 0 1 8 0v3"
                            ></path>

                        </svg>


                        <input
                            type="password"
                            id="password"
                            placeholder="Create password"
                            autocomplete="new-password"
                            minlength="6"
                            required
                        >


                        <button
                            type="button"
                            class="password-toggle"
                            id="passwordToggle"
                        >
                            SHOW
                        </button>


                    </div>


                    <div class="password-strength">

                        <span
                            class="strength-bar"
                            id="strength1"
                        ></span>

                        <span
                            class="strength-bar"
                            id="strength2"
                        ></span>

                        <span
                            class="strength-bar"
                            id="strength3"
                        ></span>

                        <span
                            class="strength-bar"
                            id="strength4"
                        ></span>

                    </div>


                    <div
                        class="strength-text"
                        id="strengthText"
                    >
                        Enter at least 6 characters
                    </div>


                </div>


                <!--
                ========================================
                CONFIRM PASSWORD
                ========================================
                -->

                <div class="form-group">


                    <div class="label-row">

                        <label for="confirmPassword">
                            CONFIRM PASSWORD
                        </label>

                        <span class="field-hint">
                            REQUIRED
                        </span>

                    </div>


                    <div class="input-wrapper">


                        <svg
                            class="input-icon"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <path
                                d="M12 21s7-4 7-11V5l-7-3-7 3v5c0 7 7 11 7 11z"
                            ></path>

                            <path
                                d="M9 11l2 2 4-4"
                            ></path>

                        </svg>


                        <input
                            type="password"
                            id="confirmPassword"
                            placeholder="Confirm password"
                            autocomplete="new-password"
                            minlength="6"
                            required
                        >


                        <button
                            type="button"
                            class="password-toggle"
                            id="confirmPasswordToggle"
                        >
                            SHOW
                        </button>


                    </div>


                    <div
                        class="password-match"
                        id="passwordMatch"
                    ></div>


                </div>


                <!-- SUBMIT -->

                <button
                    type="submit"
                    class="register-submit"
                    id="registerButton"
                >
                    CREATE CUSTOMER ACCOUNT
                </button>


            </form>


            <!-- MESSAGE -->

            <div
                class="register-message"
                id="registerMessage"
            ></div>


            <!-- BOTTOM -->

            <div class="account-divider">
                ALREADY HAVE AN ACCOUNT?
            </div>


            <a
                href="login.php"
                class="login-link"
            >
                LOGIN TO EVENTIFY
            </a>


            <a
                href="events.php"
                class="guest-link"
            >
                CONTINUE AS GUEST
            </a>


        </section>


    </main>


    <div class="register-footer">

        EVENTIFY • Event Ticketing & Venue Booking System

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const registerForm =
            document.getElementById(
                'registerForm'
            );


        const nameInput =
            document.getElementById(
                'name'
            );


        const emailInput =
            document.getElementById(
                'email'
            );


        const passwordInput =
            document.getElementById(
                'password'
            );


        const confirmPasswordInput =
            document.getElementById(
                'confirmPassword'
            );


        const registerButton =
            document.getElementById(
                'registerButton'
            );


        const registerMessage =
            document.getElementById(
                'registerMessage'
            );


        const passwordMatch =
            document.getElementById(
                'passwordMatch'
            );


        /*
        ========================================
        PASSWORD TOGGLES
        ========================================
        */

        setupPasswordToggle(
            'password',
            'passwordToggle'
        );


        setupPasswordToggle(
            'confirmPassword',
            'confirmPasswordToggle'
        );


        function setupPasswordToggle(
            inputId,
            buttonId
        ) {

            const input =
                document.getElementById(
                    inputId
                );


            const button =
                document.getElementById(
                    buttonId
                );


            button.addEventListener(
                'click',
                function() {

                    const hidden =
                        input.type ===
                        'password';


                    input.type =
                        hidden
                        ?
                        'text'
                        :
                        'password';


                    button.textContent =
                        hidden
                        ?
                        'HIDE'
                        :
                        'SHOW';

                }
            );

        }


        /*
        ========================================
        PASSWORD STRENGTH
        ========================================
        */

        passwordInput.addEventListener(
            'input',
            function() {

                updateStrength();

                checkPasswords();

            }
        );


        confirmPasswordInput.addEventListener(
            'input',
            checkPasswords
        );


        function updateStrength() {

            const password =
                passwordInput.value;


            let score =
                0;


            if (
                password.length >=
                6
            ) {

                score++;

            }


            if (
                password.length >=
                8
            ) {

                score++;

            }


            if (
                /[A-Z]/.test(
                    password
                )
                &&
                /[a-z]/.test(
                    password
                )
            ) {

                score++;

            }


            if (
                /\d/.test(
                    password
                )
                ||
                /[^A-Za-z0-9]/.test(
                    password
                )
            ) {

                score++;

            }


            for (
                let i = 1;
                i <= 4;
                i++
            ) {

                document
                    .getElementById(
                        `strength${i}`
                    )
                    .classList
                    .toggle(
                        'active',
                        i <= score
                    );

            }


            const strengthText =
                document.getElementById(
                    'strengthText'
                );


            if (
                password.length ===
                0
            ) {

                strengthText.textContent =
                    'Enter at least 6 characters';

            }

            else if (
                score <=
                1
            ) {

                strengthText.textContent =
                    'Weak password';

            }

            else if (
                score ===
                2
            ) {

                strengthText.textContent =
                    'Good password';

            }

            else {

                strengthText.textContent =
                    'Strong password';

            }

        }


        /*
        ========================================
        PASSWORD MATCH
        ========================================
        */

        function checkPasswords() {

            const password =
                passwordInput.value;


            const confirmPassword =
                confirmPasswordInput.value;


            if (
                confirmPassword ===
                ''
            ) {

                passwordMatch.textContent =
                    '';


                passwordMatch.className =
                    'password-match';


                return;

            }


            if (
                password ===
                confirmPassword
            ) {

                passwordMatch.textContent =
                    '✓ Passwords match';


                passwordMatch.className =
                    'password-match good';

            }

            else {

                passwordMatch.textContent =
                    '✕ Passwords do not match';


                passwordMatch.className =
                    'password-match bad';

            }

        }


        /*
        ========================================
        REGISTER
        ========================================
        */

        registerForm.addEventListener(
            'submit',
            async function(event) {

                event.preventDefault();


                const name =
                    nameInput
                        .value
                        .trim();


                const email =
                    emailInput
                        .value
                        .trim();


                const password =
                    passwordInput.value;


                const confirmPassword =
                    confirmPasswordInput.value;


                /*
                ========================================
                FRONTEND VALIDATION
                ========================================
                */

                if (
                    !name ||
                    !email ||
                    !password ||
                    !confirmPassword
                ) {

                    showMessage(
                        'error',
                        'Registration failed',
                        'Please complete all required fields.'
                    );


                    return;

                }


                if (
                    name.length <
                    3
                ) {

                    showMessage(
                        'error',
                        'Invalid name',
                        'Name must contain at least 3 characters.'
                    );


                    return;

                }


                if (
                    password.length <
                    6
                ) {

                    showMessage(
                        'error',
                        'Invalid password',
                        'Password must contain at least 6 characters.'
                    );


                    return;

                }


                if (
                    password !==
                    confirmPassword
                ) {

                    showMessage(
                        'error',
                        'Password mismatch',
                        'Both passwords must be the same.'
                    );


                    return;

                }


                /*
                ========================================
                LOADING
                ========================================
                */

                registerButton.disabled =
                    true;


                registerButton.textContent =
                    'CREATING ACCOUNT...';


                registerMessage.innerHTML =
                    '';


                try {

                    /*
                    ========================================
                    IMPORTANT FIX

                    Backend expects EXACTLY:

                    name
                    email
                    password
                    confirm_password
                    ========================================
                    */

                    const payload = {

                        name:
                            name,

                        email:
                            email,

                        password:
                            password,

                        confirm_password:
                            confirmPassword

                    };


                    console.log(
                        'Registration payload:',
                        payload
                    );


                    const response =
                        await fetch(
                            '../auth/register.php',
                            {

                                method:
                                    'POST',

                                headers: {

                                    'Content-Type':
                                        'application/json'

                                },

                                body:
                                    JSON.stringify(
                                        payload
                                    )

                            }
                        );


                    const result =
                        await response.json();


                    /*
                    ========================================
                    SUCCESS
                    ========================================
                    */

                    if (
                        response.ok &&
                        result.status ===
                        'success'
                    ) {

                        showMessage(
                            'success',
                            'Account created',
                            'Your customer account was created successfully. Redirecting to login...'
                        );


                        registerButton.textContent =
                            'ACCOUNT CREATED';


                        registerForm.reset();


                        updateStrength();


                        passwordMatch.textContent =
                            '';


                        setTimeout(
                            function() {

                                window.location.href =
                                    'login.php';

                            },
                            1500
                        );


                        return;

                    }


                    /*
                    ========================================
                    BACKEND ERROR
                    ========================================
                    */

                    showMessage(
                        'error',
                        'Registration failed',
                        result.message ||
                        'Unable to create account.'
                    );


                }

                catch (error) {

                    console.error(
                        'Registration error:',
                        error
                    );


                    showMessage(
                        'error',
                        'Connection error',
                        'Unable to connect to the Eventify registration API.'
                    );

                }

                finally {

                    if (
                        !registerButton.textContent
                            .includes(
                                'ACCOUNT CREATED'
                            )
                    ) {

                        registerButton.disabled =
                            false;


                        registerButton.textContent =
                            'CREATE CUSTOMER ACCOUNT';

                    }

                }

            }
        );


        /*
        ========================================
        MESSAGE
        ========================================
        */

        function showMessage(
            type,
            title,
            text
        ) {

            registerMessage.innerHTML = `

                <div
                    class="
                        status-box
                        ${type}
                    "
                >


                    <div class="status-icon">

                        ${
                            type ===
                            'success'

                            ?
                            '✓'

                            :
                            '!'
                        }

                    </div>


                    <div>


                        <div class="status-title">

                            ${escapeHtml(
                                title
                            )}

                        </div>


                        <div class="status-text">

                            ${escapeHtml(
                                text
                            )}

                        </div>


                    </div>


                </div>

            `;

        }


        /*
        ========================================
        ESCAPE
        ========================================
        */

        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    </script>


</body>

</html>