<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Home - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }


        .home-shell {
            width: min(1180px, 92%);
            margin: 0 auto;
            flex: 1;
        }


        /*
        ========================================
        HERO
        ========================================
        */

        .home-hero {
            position: relative;

            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 24px;
            flex-wrap: wrap;

            margin-bottom: 20px;

            padding: 24px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 12px;

            overflow: hidden;

            background:
                linear-gradient(
                    135deg,
                    rgba(
                        91,
                        42,
                        134,
                        0.28
                    ),
                    rgba(
                        27,
                        23,
                        69,
                        0.86
                    )
                );
        }


        .home-hero::after {
            content: "";

            position: absolute;

            width: 220px;
            height: 220px;

            right: -70px;
            top: -90px;

            border-radius: 50%;

            background:
                radial-gradient(
                    circle,
                    rgba(
                        224,
                        107,
                        174,
                        0.18
                    ),
                    transparent 68%
                );

            pointer-events: none;
        }


        .home-hero-content {
            position: relative;
            z-index: 2;

            flex: 1;

            min-width: 280px;
            max-width: 700px;
        }


        .hero-eyebrow {
            margin-bottom: 9px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;

            letter-spacing: 1px;

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .home-hero h2 {
            margin:
                0
                0
                10px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 25px;
            font-weight: 850;
            line-height: 1.25;

            color: #ffffff;
        }


        .home-hero p {
            margin:
                0
                0
                17px
                0;

            max-width: 620px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 12px;
            line-height: 1.65;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        .hero-actions {
            display: flex;
            align-items: center;

            gap: 10px;
            flex-wrap: wrap;
        }


        .hero-btn {
            min-height: 38px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            padding:
                0
                16px;

            border-radius: 7px;

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;

            letter-spacing: 0.35px;

            transition:
                transform
                0.16s ease,
                opacity
                0.16s ease;
        }


        .hero-btn:hover {
            transform:
                translateY(
                    -1px
                );

            opacity: 0.92;
        }


        .hero-btn-primary {
            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.28
                );

            background:
                linear-gradient(
                    135deg,
                    var(
                        --purple,
                        #5B2A86
                    ),
                    var(
                        --magenta,
                        #B0449E
                    )
                );

            color: #ffffff;
        }


        .hero-btn-secondary {
            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.12
                );

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.045
                );

            color: #ffffff;
        }


        /*
        ========================================
        HERO VISUAL
        ========================================
        */

        .home-hero-visual {
            position: relative;
            z-index: 2;

            width: 230px;
            min-width: 230px;
            height: 135px;

            display: flex;
            align-items: center;
            justify-content: center;
        }


        .ticket-visual {
            width: 205px;
            height: 110px;

            position: relative;

            box-sizing: border-box;

            padding: 16px;

            border:
                1px solid
                rgba(
                    246,
                    197,
                    142,
                    0.25
                );

            border-radius: 10px;

            background:
                linear-gradient(
                    135deg,
                    rgba(
                        246,
                        197,
                        142,
                        0.10
                    ),
                    rgba(
                        224,
                        107,
                        174,
                        0.10
                    )
                );

            transform:
                rotate(
                    -3deg
                );
        }


        .ticket-visual::before,
        .ticket-visual::after {
            content: "";

            position: absolute;

            top: 50%;

            width: 18px;
            height: 18px;

            border-radius: 50%;

            background:
                #15113A;

            transform:
                translateY(
                    -50%
                );
        }


        .ticket-visual::before {
            left: -10px;
        }


        .ticket-visual::after {
            right: -10px;
        }


        .ticket-label {
            margin-bottom: 10px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 8px;

            color:
                #F6C58E;
        }


        .ticket-line {
            width: 100%;
            height: 6px;

            margin-bottom: 8px;

            border-radius: 3px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );
        }


        .ticket-line.short {
            width: 62%;
        }


        /*
        ========================================
        SECTION
        ========================================
        */

        .home-section {
            margin-bottom: 22px;
        }


        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: end;

            gap: 12px;
            flex-wrap: wrap;

            margin-bottom: 11px;
        }


        .section-heading {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 16px;
            font-weight: 800;

            color: #ffffff;
        }


        .section-description {
            margin-top: 3px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        .section-link {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;

            color:
                var(
                    --pink,
                    #E06BAE
                );

            text-decoration: none;
        }


        .section-link:hover {
            text-decoration: underline;
        }


        /*
        ========================================
        CUSTOMER STATS
        ========================================
        */

        .customer-stats {
            display: grid;

            grid-template-columns:
                repeat(
                    3,
                    1fr
                );

            gap: 14px;
        }


        .customer-stat-card {
            min-height: 95px;

            box-sizing: border-box;

            padding: 15px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.09
                );

            border-radius: 9px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.025
                );
        }


        .customer-stat-label {
            margin-bottom: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;

            letter-spacing: 0.6px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        .customer-stat-value {
            margin-bottom: 4px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 18px;
            line-height: 1.4;

            color:
                #F6C58E;
        }


        .customer-stat-description {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.42
                );
        }


        /*
        ========================================
        EVENT PREVIEW
        ========================================
        */

        .event-preview-grid {
            display: grid;

            grid-template-columns:
                repeat(
                    3,
                    1fr
                );

            gap: 14px;
        }


        .event-preview-card {
            display: flex;
            flex-direction: column;

            min-height: 175px;

            box-sizing: border-box;

            padding: 15px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.09
                );

            border-radius: 9px;

            background:
                linear-gradient(
                    180deg,
                    rgba(
                        255,
                        255,
                        255,
                        0.035
                    ),
                    rgba(
                        255,
                        255,
                        255,
                        0.015
                    )
                );
        }


        .event-preview-category {
            margin-bottom: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;

            letter-spacing: 0.55px;

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .event-preview-name {
            margin-bottom: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 13px;
            font-weight: 800;
            line-height: 1.35;

            color: #ffffff;
        }


        .event-preview-meta {
            margin-bottom: 4px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.52
                );
        }


        .event-preview-price {
            margin:
                8px
                0
                10px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            font-weight: 800;

            color:
                #F6C58E;
        }


        .event-preview-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            width: 100%;
            min-height: 34px;

            box-sizing: border-box;

            margin-top: auto;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.24
                );

            border-radius: 6px;

            background:
                linear-gradient(
                    135deg,
                    rgba(
                        91,
                        42,
                        134,
                        0.92
                    ),
                    rgba(
                        176,
                        68,
                        158,
                        0.92
                    )
                );

            color: #ffffff;

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
        }


        .event-preview-btn:hover {
            opacity: 0.9;
        }


        .event-preview-empty {
            grid-column:
                1 / -1;

            padding:
                24px;

            text-align: center;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.08
                );

            border-radius: 9px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.02
                );

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.45
                );
        }


        /*
        ========================================
        GUEST CTA
        ========================================
        */

        .guest-cta {
            display: none;

            margin-bottom: 20px;

            padding: 14px 16px;

            border:
                1px solid
                rgba(
                    246,
                    197,
                    142,
                    0.18
                );

            border-radius: 8px;

            background:
                rgba(
                    246,
                    197,
                    142,
                    0.05
                );

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            line-height: 1.5;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.58
                );
        }


        .guest-cta strong {
            color: #F6C58E;
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                10px !important;

            padding-top:
                11px !important;

            padding-bottom:
                11px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 900px) {

            .customer-stats {
                grid-template-columns:
                    1fr
                    1fr;
            }


            .event-preview-grid {
                grid-template-columns:
                    1fr
                    1fr;
            }

        }


        @media (max-width: 650px) {

            .home-hero-visual {
                display: none;
            }


            .customer-stats,
            .event-preview-grid {
                grid-template-columns:
                    1fr;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <h1>EVENTIFY</h1>


    <div class="home-shell">


        <!-- HERO -->

        <section class="home-hero">


            <div class="home-hero-content">


                <div class="hero-eyebrow">
                    DISCOVER • BOOK • EXPERIENCE
                </div>


                <h2 id="heroTitle">
                    Find your next event.
                </h2>


                <p id="heroDescription">
                    Browse upcoming events, explore venues and secure your tickets
                    through Eventify.
                </p>


                <div class="hero-actions">


                    <a
                        href="events.php"
                        class="
                            hero-btn
                            hero-btn-primary
                        "
                    >
                        BROWSE EVENTS
                    </a>


                    <a
                        href="mybookings.php"
                        class="
                            hero-btn
                            hero-btn-secondary
                        "
                        id="myBookingsButton"
                    >
                        MY BOOKINGS
                    </a>


                    <a
                        href="login.php"
                        class="
                            hero-btn
                            hero-btn-secondary
                        "
                        id="loginButton"
                        style="display:none;"
                    >
                        LOGIN
                    </a>


                </div>


            </div>


            <div class="home-hero-visual">


                <div class="ticket-visual">


                    <div class="ticket-label">
                        EVENTIFY
                    </div>


                    <div class="ticket-line"></div>

                    <div class="ticket-line short"></div>

                    <div class="ticket-line"></div>


                </div>


            </div>


        </section>


        <!-- GUEST MESSAGE -->

        <div
            class="guest-cta"
            id="guestMessage"
        >

            <strong>Browsing as guest.</strong>

            You can explore Eventify events now.
            Login or create an account when you are ready to make a booking.

        </div>


        <!-- CUSTOMER OVERVIEW -->

        <section
            class="home-section"
            id="customerOverview"
        >


            <div class="section-header">


                <div>


                    <h2 class="section-heading">
                        Your Activity
                    </h2>


                    <div class="section-description">
                        Quick overview of your Eventify booking activity.
                    </div>


                </div>


                <a
                    href="mybookings.php"
                    class="section-link"
                >
                    VIEW BOOKINGS
                </a>


            </div>


            <div class="customer-stats">


                <div class="customer-stat-card">


                    <div class="customer-stat-label">
                        TOTAL BOOKINGS
                    </div>


                    <div
                        class="customer-stat-value"
                        id="totalBookings"
                    >
                        -
                    </div>


                    <div class="customer-stat-description">
                        All booking records under your account.
                    </div>


                </div>


                <div class="customer-stat-card">


                    <div class="customer-stat-label">
                        CONFIRMED
                    </div>


                    <div
                        class="customer-stat-value"
                        id="confirmedBookings"
                    >
                        -
                    </div>


                    <div class="customer-stat-description">
                        Bookings currently confirmed.
                    </div>


                </div>


                <div class="customer-stat-card">


                    <div class="customer-stat-label">
                        CANCELLED
                    </div>


                    <div
                        class="customer-stat-value"
                        id="cancelledBookings"
                    >
                        -
                    </div>


                    <div class="customer-stat-description">
                        Booking records that have been cancelled.
                    </div>


                </div>


            </div>


        </section>


        <!-- UPCOMING EVENTS -->

        <section class="home-section">


            <div class="section-header">


                <div>


                    <h2 class="section-heading">
                        Upcoming Events
                    </h2>


                    <div class="section-description">
                        A quick look at events currently available on Eventify.
                    </div>


                </div>


                <a
                    href="events.php"
                    class="section-link"
                >
                    VIEW ALL EVENTS
                </a>


            </div>


            <div
                class="event-preview-grid"
                id="eventPreviewGrid"
            >

                <div class="event-preview-empty">
                    Loading upcoming events...
                </div>

            </div>


        </section>


    </div>


    <div class="footer">

        EVENTIFY

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        SESSION
        ========================================
        */

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser =
            null;


        if (storedUser) {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                currentUser =
                    null;

            }

        }


        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const heroTitle =
            document.getElementById(
                'heroTitle'
            );


        const heroDescription =
            document.getElementById(
                'heroDescription'
            );


        const myBookingsButton =
            document.getElementById(
                'myBookingsButton'
            );


        const loginButton =
            document.getElementById(
                'loginButton'
            );


        const guestMessage =
            document.getElementById(
                'guestMessage'
            );


        const customerOverview =
            document.getElementById(
                'customerOverview'
            );


        const totalBookings =
            document.getElementById(
                'totalBookings'
            );


        const confirmedBookings =
            document.getElementById(
                'confirmedBookings'
            );


        const cancelledBookings =
            document.getElementById(
                'cancelledBookings'
            );


        const eventPreviewGrid =
            document.getElementById(
                'eventPreviewGrid'
            );


        /*
        ========================================
        ROLE-AWARE HOME
        ========================================
        */

        configureHome();


        function configureHome() {

            /*
            GUEST
            */

            if (
                !currentUser ||
                !token
            ) {

                heroTitle.textContent =
                    'Find your next event.';


                heroDescription.textContent =
                    'Browse upcoming events, explore venues and discover what is happening on Eventify.';


                myBookingsButton.style.display =
                    'none';


                loginButton.style.display =
                    'inline-flex';


                guestMessage.style.display =
                    'block';


                customerOverview.style.display =
                    'none';


                loadUpcomingEvents();

                return;

            }


            /*
            CUSTOMER
            */

            if (
                currentUser.role ===
                'Customer'
            ) {

                const displayName =
                    currentUser.name
                    ||
                    currentUser.username
                    ||
                    'Customer';


                heroTitle.textContent =
                    `Welcome, ${displayName}`;


                heroDescription.textContent =
                    'Discover upcoming events, secure your tickets and keep track of your bookings in one place.';


                myBookingsButton.style.display =
                    'inline-flex';


                loginButton.style.display =
                    'none';


                guestMessage.style.display =
                    'none';


                customerOverview.style.display =
                    'block';


                loadCustomerHome();

                return;

            }


            /*
            ORGANISER
            */

            if (
                currentUser.role ===
                'Organiser'
            ) {

                window.location.href =
                    'organiserdashboard.php';

                return;

            }


            /*
            ADMIN
            */

            if (
                currentUser.role ===
                'Administrator'
            ) {

                window.location.href =
                    'admindashboard.php';

                return;

            }


            loadUpcomingEvents();

        }


        /*
        ========================================
        CUSTOMER HOME
        ========================================
        */

        async function loadCustomerHome() {

            await Promise.all([

                loadCustomerBookings(),

                loadUpcomingEvents()

            ]);

        }


        /*
        ========================================
        LOAD BOOKINGS
        ========================================
        */

        async function loadCustomerBookings() {

            try {

                const response =
                    await fetch(
                        '../api/bookings.php',
                        {

                            headers: {

                                'Authorization':
                                    `Bearer ${token}`

                            }

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    localStorage.removeItem(
                        'eventify_token'
                    );


                    localStorage.removeItem(
                        'eventify_user'
                    );


                    window.location.href =
                        'login.php';


                    return;

                }


                const result =
                    await response.json();


                const bookings =

                    response.ok &&
                    result.status ===
                    'success'

                    ? (
                        result.data ||
                        []
                    )

                    : [];


                totalBookings.textContent =
                    bookings.length;


                confirmedBookings.textContent =
                    bookings.filter(
                        function(booking) {

                            return (
                                booking.booking_status ===
                                'Confirmed'
                            );

                        }
                    ).length;


                cancelledBookings.textContent =
                    bookings.filter(
                        function(booking) {

                            return (
                                booking.booking_status ===
                                'Cancelled'
                            );

                        }
                    ).length;

            }

            catch (error) {

                console.error(
                    'Customer booking summary error:',
                    error
                );


                totalBookings.textContent =
                    '0';


                confirmedBookings.textContent =
                    '0';


                cancelledBookings.textContent =
                    '0';

            }

        }


        /*
        ========================================
        LOAD UPCOMING EVENTS
        ========================================
        */

        async function loadUpcomingEvents() {

            try {

                const response =
                    await fetch(
                        '../api/events.php'
                    );


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    'success'
                ) {

                    throw new Error(
                        result.message ||
                        'Unable to load events'
                    );

                }


                const events =
                    (
                        result.data ||
                        []
                    )
                    .filter(
                        function(event) {

                            return (
                                event.status ===
                                'Upcoming'
                                &&
                                Number(
                                    event.available_tickets ||
                                    0
                                ) >
                                0
                            );

                        }
                    )
                    .sort(
                        function(a, b) {

                            return String(
                                a.event_date
                            )
                            .localeCompare(
                                String(
                                    b.event_date
                                )
                            );

                        }
                    )
                    .slice(
                        0,
                        3
                    );


                displayUpcomingEvents(
                    events
                );

            }

            catch (error) {

                console.error(
                    'Upcoming events error:',
                    error
                );


                eventPreviewGrid.innerHTML = `

                    <div class="event-preview-empty">

                        Unable to load upcoming events.

                    </div>

                `;

            }

        }


        /*
        ========================================
        DISPLAY EVENTS
        ========================================
        */

        function displayUpcomingEvents(
            events
        ) {

            if (
                events.length ===
                0
            ) {

                eventPreviewGrid.innerHTML = `

                    <div class="event-preview-empty">

                        No upcoming events are available right now.

                    </div>

                `;


                return;

            }


            eventPreviewGrid.innerHTML =
                '';


            events.forEach(
                function(event) {


                    eventPreviewGrid.innerHTML += `

                        <article class="event-preview-card">


                            <div class="event-preview-category">

                                ${escapeHtml(
                                    event.category ||
                                    'EVENT'
                                )}

                            </div>


                            <div class="event-preview-name">

                                ${escapeHtml(
                                    event.event_name ||
                                    'Untitled Event'
                                )}

                            </div>


                            <div class="event-preview-meta">

                                ${formatDate(
                                    event.event_date
                                )}

                                •

                                ${formatTime(
                                    event.start_time
                                )}

                            </div>


                            <div class="event-preview-meta">

                                ${escapeHtml(
                                    event.venue_name ||
                                    'Venue TBA'
                                )}

                            </div>


                            <div class="event-preview-price">

                                RM ${Number(
                                    event.ticket_price ||
                                    0
                                ).toFixed(
                                    2
                                )}

                            </div>


                            <a
                                href="eventdetails.php?event_id=${encodeURIComponent(
                                    event.event_id
                                )}"
                                class="event-preview-btn"
                            >
                                VIEW EVENT
                            </a>


                        </article>

                    `;

                }
            );

        }


        /*
        ========================================
        HELPERS
        ========================================
        */

        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const parts =
                String(
                    value
                )
                .substring(
                    0,
                    10
                )
                .split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return value;

            }


            return (
                parts[2]
                +
                '/'
                +
                parts[1]
                +
                '/'
                +
                parts[0]
            );

        }


        function formatTime(
            value
        ) {

            if (!value) {

                return '-';

            }


            return String(
                value
            )
            .substring(
                0,
                5
            );

        }


        function escapeHtml(
            value
        ) {

            return String(
                value ??
                ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    </script>


</body>

</html>