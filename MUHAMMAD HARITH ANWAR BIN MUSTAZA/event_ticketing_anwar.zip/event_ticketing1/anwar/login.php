<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Login - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        /*
        ========================================
        PAGE
        ========================================
        */

        body {
            min-height: 100vh;
            margin: 0;

            display: flex;
            flex-direction: column;

            overflow-x: hidden;

            background:
                radial-gradient(
                    circle at 12% 82%,
                    rgba(91, 42, 134, 0.16),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 92% 15%,
                    rgba(224, 107, 174, 0.11),
                    transparent 28%
                ),
                #0B0B2E;
        }


        /*
        ========================================
        MAIN
        ========================================
        */

        .login-main {
            width: min(1180px, 92%);

            flex: 1;

            margin:
                0
                auto;

            display: grid;

            grid-template-columns:
                minmax(0, 1fr)
                1px
                minmax(390px, 445px);

            align-items: stretch;

            gap: 42px;

            box-sizing: border-box;

            padding:
                26px
                0
                20px
                0;
        }


        /*
        ========================================
        DIVIDER
        ========================================
        */

        .login-divider-vertical {
            width: 1px;
            height: 88%;

            align-self: center;

            background:
                linear-gradient(
                    180deg,
                    transparent,
                    rgba(255, 255, 255, 0.08),
                    rgba(224, 107, 174, 0.28),
                    rgba(255, 255, 255, 0.08),
                    transparent
                );

            position: relative;
        }


        .login-divider-vertical::before {
            content: "";

            position: absolute;

            left: 50%;
            top: 50%;

            width: 6px;
            height: 6px;

            transform:
                translate(-50%, -50%);

            border-radius: 50%;

            background: #E06BAE;

            box-shadow:
                0
                0
                14px
                rgba(224, 107, 174, 0.52);
        }


        /*
        ========================================
        LEFT
        ========================================
        */

        .login-intro {
            width: 100%;
            max-width: 610px;

            justify-self: start;

            display: flex;
            flex-direction: column;

            box-sizing: border-box;
        }


        .intro-eyebrow {
            width: fit-content;

            display: inline-flex;
            align-items: center;

            gap: 8px;

            margin-bottom: 14px;

            padding:
                7px
                10px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(224, 107, 174, 0.22);

            border-radius: 6px;

            background:
                rgba(224, 107, 174, 0.06);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            letter-spacing: 0.9px;

            color: #E06BAE;
        }


        .intro-dot {
            width: 6px;
            height: 6px;

            border-radius: 50%;

            background: #E06BAE;

            box-shadow:
                0
                0
                10px
                rgba(224, 107, 174, 0.72);
        }


        .login-intro h1 {
            width: 100%;

            margin:
                0
                0
                14px
                0;

            font-family:
                "Press Start 2P",
                monospace;

            font-size:
                clamp(
                    26px,
                    3vw,
                    41px
                );

            line-height: 1.35;

            color: #ffffff;
        }


        .login-intro h1 span {
            background:
                linear-gradient(
                    90deg,
                    #F6C58E,
                    #F4A7A0,
                    #E06BAE
                );

            background-clip: text;
            -webkit-background-clip: text;

            color: transparent;
            -webkit-text-fill-color: transparent;
        }


        .intro-description {
            width: 100%;

            margin:
                0
                0
                17px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 12px;
            line-height: 1.65;

            color:
                rgba(255, 255, 255, 0.60);
        }


        /*
        ========================================
        TICKET SHOWCASE
        ========================================
        */

        .ticket-showcase {
            width: 100%;
            height: 127px;

            display: flex;
            align-items: center;

            box-sizing: border-box;

            margin-bottom: 10px;

            padding:
                15px
                17px;

            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.085);

            border-radius: 9px;

            background:
                linear-gradient(
                    135deg,
                    rgba(36, 28, 86, 0.75),
                    rgba(21, 17, 58, 0.86)
                );

            position: relative;
        }


        .ticket-showcase::before {
            content: "";

            position: absolute;

            width: 185px;
            height: 185px;

            right: -55px;
            top: -85px;

            border-radius: 50%;

            background:
                radial-gradient(
                    circle,
                    rgba(224, 107, 174, 0.16),
                    transparent 68%
                );
        }


        .ticket-card {
            width: 100%;

            position: relative;
            z-index: 2;

            display: grid;

            grid-template-columns:
                minmax(0, 1fr)
                auto
                100px;

            align-items: center;

            gap: 17px;
        }


        .ticket-mini-label {
            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.7px;

            color: #F6C58E;
        }


        .ticket-event-name {
            margin-bottom: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 15px;
            font-weight: 850;

            color: #ffffff;
        }


        .ticket-meta {
            display: flex;
            flex-wrap: wrap;

            gap: 10px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;

            color:
                rgba(255, 255, 255, 0.48);
        }


        .ticket-divider-small {
            width: 1px;
            height: 55px;

            background:
                linear-gradient(
                    transparent,
                    rgba(255, 255, 255, 0.17),
                    transparent
                );
        }


        .ticket-code {
            display: flex;
            flex-direction: column;

            align-items: center;

            gap: 5px;
        }


        .ticket-code-box {
            width: 68px;
            height: 51px;

            display: grid;

            grid-template-columns:
                repeat(5, 1fr);

            gap: 3px;

            box-sizing: border-box;

            padding: 6px;

            border-radius: 6px;

            background:
                rgba(255, 255, 255, 0.93);
        }


        .pixel {
            background: #1B1745;
        }


        .pixel:nth-child(2),
        .pixel:nth-child(5),
        .pixel:nth-child(7),
        .pixel:nth-child(9),
        .pixel:nth-child(12),
        .pixel:nth-child(14),
        .pixel:nth-child(16),
        .pixel:nth-child(19),
        .pixel:nth-child(21),
        .pixel:nth-child(24) {
            opacity: 0.18;
        }


        .ticket-code-text {
            font-family:
                "Press Start 2P",
                monospace;

            font-size: 5px;

            color:
                rgba(255, 255, 255, 0.42);
        }


        /*
        ========================================
        FEATURES
        ========================================
        */

        .intro-features {
            width: 100%;

            display: grid;

            grid-template-columns:
                repeat(3, minmax(0, 1fr));

            gap: 10px;

            margin-bottom: 10px;
        }


        .intro-feature {
            min-height: 80px;

            box-sizing: border-box;

            padding: 11px;

            border:
                1px solid
                rgba(255, 255, 255, 0.075);

            border-radius: 8px;

            background:
                rgba(255, 255, 255, 0.025);
        }


        .intro-feature-top {
            display: flex;
            align-items: center;

            gap: 7px;

            margin-bottom: 7px;
        }


        .intro-feature-icon {
            width: 26px;
            height: 26px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 6px;

            background:
                rgba(224, 107, 174, 0.08);

            color: #E06BAE;
        }


        .intro-feature-icon svg {
            width: 14px;
            height: 14px;
        }


        .intro-feature-title {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            color: #ffffff;
        }


        .intro-feature-text {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            line-height: 1.45;

            color:
                rgba(255, 255, 255, 0.42);
        }


        /*
        ========================================
        STATS
        ========================================
        */

        .intro-stats {
            width: 100%;

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.07);

            border-radius: 8px;

            background:
                rgba(255, 255, 255, 0.018);

            margin-top: auto;
        }


        .intro-stat {
            padding:
                9px
                10px;

            text-align: center;

            border-right:
                1px solid
                rgba(255, 255, 255, 0.06);
        }


        .intro-stat:last-child {
            border-right: none;
        }


        .intro-stat-number {
            display: block;

            margin-bottom: 3px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 9px;

            color: #F6C58E;
        }


        .intro-stat-label {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 750;

            color:
                rgba(255, 255, 255, 0.36);
        }


        /*
        ========================================
        LOGIN CARD
        ========================================
        */

        .login-card {
            width: 100%;
            max-width: 445px;

            height: 100%;

            justify-self: end;

            display: flex;
            flex-direction: column;

            box-sizing: border-box;

            padding:
                25px
                26px
                18px
                26px;

            border:
                1px solid
                rgba(255, 255, 255, 0.12);

            border-radius: 12px;

            background:
                linear-gradient(
                    180deg,
                    rgba(36, 28, 86, 0.92),
                    rgba(21, 17, 58, 0.96)
                );

            box-shadow:
                0
                24px
                70px
                rgba(0, 0, 0, 0.26);

            position: relative;
            z-index: 3;
        }


        .login-card::before {
            content: "";

            position: absolute;

            top: 0;
            left: 18%;
            right: 18%;

            height: 1px;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    rgba(224, 107, 174, 0.68),
                    transparent
                );
        }


        /*
        ========================================
        TOP
        ========================================
        */

        .login-card-top {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 12px;

            margin-bottom: 17px;
        }


        .login-card-badge {
            display: inline-flex;
            align-items: center;

            gap: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.75px;

            color: #F6C58E;
        }


        .login-card-badge-dot {
            width: 6px;
            height: 6px;

            border-radius: 50%;

            background: #8FD8C6;

            box-shadow:
                0
                0
                8px
                rgba(143, 216, 198, 0.55);
        }


        .secure-badge {
            padding:
                5px
                7px;

            border:
                1px solid
                rgba(143, 216, 198, 0.15);

            border-radius: 5px;

            background:
                rgba(143, 216, 198, 0.04);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 800;

            color: #8FD8C6;
        }


        /*
        ========================================
        HEADER
        ========================================
        */

        .login-card-header {
            margin-bottom: 19px;
        }


        .login-card-header h2 {
            margin:
                0
                0
                6px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 23px;
            font-weight: 850;

            color: #ffffff;
        }


        .login-card-header p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            line-height: 1.55;

            color:
                rgba(255, 255, 255, 0.47);
        }


        /*
        ========================================
        FORM
        ========================================
        */

        .login-form-group {
            margin-bottom: 14px;
        }


        .login-form-label-row {
            display: flex;
            align-items: center;
            justify-content: space-between;

            margin-bottom: 6px;
        }


        .login-form-label-row label {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.7px;

            color:
                rgba(255, 255, 255, 0.66);
        }


        .field-hint {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;

            color:
                rgba(255, 255, 255, 0.30);
        }


        .login-input-wrapper {
            position: relative;
        }


        .login-input-icon {
            position: absolute;

            left: 13px;
            top: 50%;

            width: 16px;
            height: 16px;

            transform:
                translateY(-50%);

            color: #F4A7A0;

            pointer-events: none;
        }


        .login-input-wrapper input {
            width: 100%;
            height: 45px;

            box-sizing: border-box;

            padding:
                0
                105px
                0
                41px;

            border:
                1px solid
                rgba(255, 255, 255, 0.12);

            border-radius: 7px;

            outline: none;

            background:
                rgba(11, 11, 46, 0.50);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
        }


        #email {
            padding-right: 14px;
        }


        .login-input-wrapper input::placeholder {
            color:
                rgba(255, 255, 255, 0.35);
        }


        .login-input-wrapper input:focus {
            border-color:
                rgba(224, 107, 174, 0.58);

            background:
                rgba(11, 11, 46, 0.68);

            box-shadow:
                0
                0
                0
                3px
                rgba(224, 107, 174, 0.07);
        }


        /*
        ========================================
        SHOW / HIDE
        ========================================
        */

        .password-toggle {
            position: absolute;

            right: 6px;
            top: 50%;

            min-width: 86px;
            height: 33px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            gap: 6px;

            box-sizing: border-box;

            padding:
                0
                10px;

            transform:
                translateY(-50%);

            border:
                1px solid
                rgba(246, 197, 142, 0.34);

            border-radius: 6px;

            background:
                linear-gradient(
                    135deg,
                    rgba(246, 197, 142, 0.14),
                    rgba(224, 107, 174, 0.10)
                );

            color: #F6C58E;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.35px;

            cursor: pointer;
        }


        .password-toggle:hover {
            border-color:
                rgba(246, 197, 142, 0.55);

            background:
                linear-gradient(
                    135deg,
                    rgba(246, 197, 142, 0.20),
                    rgba(224, 107, 174, 0.16)
                );

            color: #ffffff;
        }


        .password-toggle svg {
            width: 14px;
            height: 14px;

            stroke: currentColor;
        }


        /*
        ========================================
        LOGIN BUTTON
        ========================================
        */

        .login-submit {
            width: 100%;
            height: 43px;

            display: flex;
            align-items: center;
            justify-content: center;

            gap: 8px;

            box-sizing: border-box;

            margin-top: 5px;

            border:
                1px solid
                rgba(224, 107, 174, 0.30);

            border-radius: 7px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 850;

            letter-spacing: 0.55px;

            cursor: pointer;
        }


        .login-submit:hover:not(:disabled) {
            transform:
                translateY(-1px);

            opacity: 0.93;
        }


        .login-submit:disabled {
            opacity: 0.55;

            cursor: wait;
        }


        .login-submit svg {
            width: 15px;
            height: 15px;
        }


        /*
        ========================================
        BOTTOM AREA
        ========================================
        */

        .login-bottom {
            margin-top: auto;
        }


        /*
        DIVIDER
        */

        .account-divider {
            display: flex;
            align-items: center;

            gap: 10px;

            margin:
                12px
                0
                10px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 750;

            letter-spacing: 0.55px;

            color:
                rgba(255, 255, 255, 0.30);
        }


        .account-divider::before,
        .account-divider::after {
            content: "";

            flex: 1;

            height: 1px;

            background:
                rgba(255, 255, 255, 0.08);
        }


        /*
        CREATE ACCOUNT
        */

        .create-account-btn {
            width: 100%;
            height: 39px;

            display: flex;
            align-items: center;
            justify-content: center;

            gap: 7px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(246, 197, 142, 0.20);

            border-radius: 7px;

            background:
                linear-gradient(
                    135deg,
                    rgba(246, 197, 142, 0.07),
                    rgba(224, 107, 174, 0.05)
                );

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            color: #F6C58E;
        }


        .create-account-btn:hover {
            background:
                linear-gradient(
                    135deg,
                    rgba(246, 197, 142, 0.12),
                    rgba(224, 107, 174, 0.09)
                );

            color: #ffffff;
        }


        .create-account-btn svg {
            width: 14px;
            height: 14px;
        }


        /*
        GUEST
        */

        .guest-link {
            width: 100%;
            height: 35px;

            display: flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            margin-top: 8px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 6px;

            background:
                rgba(255, 255, 255, 0.025);

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 750;

            color:
                rgba(255, 255, 255, 0.60);
        }


        .guest-link:hover {
            background:
                rgba(255, 255, 255, 0.05);

            color: #ffffff;
        }


        /*
        ========================================
        RESERVED MESSAGE AREA
        ========================================
        */

        .message-slot {
            width: 100%;
            height: 64px;

            box-sizing: border-box;

            margin-top: 8px;

            display: flex;
            align-items: stretch;
        }


        #message {
            width: 100%;
            height: 100%;
        }


        #message:empty {
            display: block;
        }


        /*
        EMPTY PLACEHOLDER
        */

        .message-placeholder {
            width: 100%;
            height: 100%;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.018);

            border-radius: 7px;

            background:
                rgba(255, 255, 255, 0.005);
        }


        /*
        ========================================
        LOGIN STATUS
        ========================================
        */

        .login-status {
            width: 100%;
            height: 100%;

            display: flex;
            align-items: center;

            gap: 8px;

            box-sizing: border-box;

            padding:
                7px
                9px;

            border-radius: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        /*
        LOADING
        */

        .login-loading {
            border:
                1px solid
                rgba(246, 197, 142, 0.20);

            background:
                rgba(246, 197, 142, 0.05);
        }


        /*
        SUCCESS
        */

        .login-success {
            border:
                1px solid
                rgba(95, 180, 160, 0.24);

            background:
                rgba(95, 180, 160, 0.055);
        }


        /*
        ERROR
        */

        .login-error {
            border:
                1px solid
                rgba(230, 95, 120, 0.24);

            background:
                rgba(230, 95, 120, 0.055);
        }


        /*
        ICON
        */

        .login-status-icon {
            width: 25px;
            height: 25px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 5px;

            font-size: 11px;
            font-weight: 850;
        }


        .login-success
        .login-status-icon {
            background:
                rgba(95, 180, 160, 0.13);

            color: #8FD8C6;
        }


        .login-error
        .login-status-icon {
            background:
                rgba(230, 95, 120, 0.13);

            color: #EF8295;
        }


        /*
        CONTENT
        */

        .login-status-content {
            flex: 1;

            min-width: 0;

            display: flex;
            flex-direction: column;
            justify-content: center;
        }


        .login-status-title {
            margin-bottom: 1px;

            font-size: 8px;
            font-weight: 850;
            line-height: 1.15;

            color: #ffffff;
        }


        .login-status-text {
            font-size: 8px;
            line-height: 1.22;

            color:
                rgba(255, 255, 255, 0.56);
        }


        /*
        ROLE + REDIRECT IN SAME ROW
        */

        .login-status-bottom {
            display: flex;
            align-items: center;

            gap: 6px;

            margin-top: 3px;
        }


        .login-role {
            display: inline-flex;

            width: fit-content;

            padding:
                2px
                5px;

            border-radius: 4px;

            background:
                rgba(246, 197, 142, 0.08);

            font-size: 6px;
            font-weight: 850;

            color: #F6C58E;
        }


        .login-status-small {
            font-size: 6px;
            line-height: 1.15;

            color:
                rgba(255, 255, 255, 0.34);
        }


        /*
        SPINNER
        */

        .login-spinner {
            width: 12px;
            height: 12px;

            flex-shrink: 0;

            border:
                2px solid
                rgba(246, 197, 142, 0.22);

            border-top-color:
                #F6C58E;

            border-radius: 50%;

            animation:
                spin
                0.7s
                linear
                infinite;
        }


        @keyframes spin {

            to {
                transform:
                    rotate(360deg);
            }

        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .login-footer {
            padding:
                9px
                20px;

            text-align: center;

            border-top:
                1px solid
                rgba(255, 255, 255, 0.055);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.28);
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 950px) {

            .login-main {
                grid-template-columns: 1fr;

                align-items: start;

                gap: 24px;

                padding:
                    28px
                    0;
            }


            .login-divider-vertical {
                display: none;
            }


            .login-intro {
                margin:
                    0
                    auto;
            }


            .intro-stats {
                margin-top: 0;
            }


            .login-card {
                justify-self: center;

                max-width: 500px;

                height: auto;
            }

        }


        @media (max-width: 650px) {

            .login-intro h1 {
                font-size: 23px;
            }


            .intro-features {
                grid-template-columns: 1fr;
            }


            .ticket-code,
            .ticket-divider-small {
                display: none;
            }


            .ticket-card {
                grid-template-columns: 1fr;
            }


            .login-card {
                padding: 21px;
            }

        }


        @media (max-width: 470px) {

            .login-main {
                width: 90%;

                display: flex;
                align-items: center;
                justify-content: center;
            }


            .login-intro {
                display: none;
            }


            .login-card {
                width: 100%;
            }

        }

    </style>

</head>


<body>


    <?php include 'navbar.php'; ?>


    <!--
    ========================================
    MAIN
    ========================================
    -->

    <main class="login-main">


        <!--
        ========================================
        LEFT
        ========================================
        -->

        <section class="login-intro">


            <div class="intro-eyebrow">

                <span class="intro-dot"></span>

                EVENT TICKETING PLATFORM

            </div>


            <h1>

                YOUR NEXT

                <span>
                    EXPERIENCE
                </span>

                STARTS HERE.

            </h1>


            <p class="intro-description">

                Discover events, secure your tickets and manage every
                booking through one connected Eventify experience.

            </p>


            <!--
            ========================================
            DIGITAL PASS
            ========================================
            -->

            <div class="ticket-showcase">


                <div class="ticket-card">


                    <div>


                        <div class="ticket-mini-label">
                            EVENTIFY DIGITAL PASS
                        </div>


                        <div class="ticket-event-name">
                            Your next event is waiting.
                        </div>


                        <div class="ticket-meta">

                            <span>
                                ◉ Browse events
                            </span>

                            <span>
                                ◈ Book tickets
                            </span>

                            <span>
                                ✓ Track bookings
                            </span>

                        </div>


                    </div>


                    <div class="ticket-divider-small"></div>


                    <div class="ticket-code">


                        <div class="ticket-code-box">

                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>

                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>

                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>

                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>

                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>
                            <span class="pixel"></span>

                        </div>


                        <div class="ticket-code-text">
                            EVENTIFY
                        </div>


                    </div>


                </div>


            </div>


            <!--
            ========================================
            FEATURES
            ========================================
            -->

            <div class="intro-features">


                <!-- DISCOVER -->

                <div class="intro-feature">


                    <div class="intro-feature-top">


                        <div class="intro-feature-icon">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <rect
                                    x="3"
                                    y="5"
                                    width="18"
                                    height="16"
                                    rx="2"
                                ></rect>

                                <path d="M8 3v4"></path>

                                <path d="M16 3v4"></path>

                                <path d="M3 10h18"></path>

                            </svg>

                        </div>


                        <div class="intro-feature-title">
                            DISCOVER
                        </div>


                    </div>


                    <div class="intro-feature-text">
                        Explore events, dates, venues and ticket availability.
                    </div>


                </div>


                <!-- BOOK -->

                <div class="intro-feature">


                    <div class="intro-feature-top">


                        <div class="intro-feature-icon">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <path
                                    d="M4 5h16v14H4z"
                                ></path>

                                <path
                                    d="M8 9h8"
                                ></path>

                                <path
                                    d="M8 13h5"
                                ></path>

                            </svg>

                        </div>


                        <div class="intro-feature-title">
                            BOOK
                        </div>


                    </div>


                    <div class="intro-feature-text">
                        Secure tickets through a simple booking experience.
                    </div>


                </div>


                <!-- MANAGE -->

                <div class="intro-feature">


                    <div class="intro-feature-top">


                        <div class="intro-feature-icon">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <path
                                    d="M12 21s7-4.35 7-11V5l-7-3-7 3v5c0 6.65 7 11 7 11z"
                                ></path>

                                <path
                                    d="M9 11l2 2 4-4"
                                ></path>

                            </svg>

                        </div>


                        <div class="intro-feature-title">
                            MANAGE
                        </div>


                    </div>


                    <div class="intro-feature-text">
                        Keep all your Eventify bookings in one place.
                    </div>


                </div>


            </div>


            <!--
            ========================================
            STATS
            ========================================
            -->

            <div class="intro-stats">


                <div class="intro-stat">

                    <span class="intro-stat-number">
                        3
                    </span>

                    <span class="intro-stat-label">
                        USER ROLES
                    </span>

                </div>


                <div class="intro-stat">

                    <span class="intro-stat-number">
                        24/7
                    </span>

                    <span class="intro-stat-label">
                        EVENT ACCESS
                    </span>

                </div>


                <div class="intro-stat">

                    <span class="intro-stat-number">
                        REST
                    </span>

                    <span class="intro-stat-label">
                        API POWERED
                    </span>

                </div>


            </div>


        </section>


        <!--
        ========================================
        CENTER DIVIDER
        ========================================
        -->

        <div class="login-divider-vertical"></div>


        <!--
        ========================================
        LOGIN
        ========================================
        -->

        <section class="login-card">


            <!-- TOP -->

            <div class="login-card-top">


                <div class="login-card-badge">

                    <span class="login-card-badge-dot"></span>

                    PLAYER ACCESS

                </div>


                <div class="secure-badge">
                    SECURE LOGIN
                </div>


            </div>


            <!-- HEADER -->

            <div class="login-card-header">


                <h2>
                    Welcome back.
                </h2>


                <p>
                    Enter your Eventify account credentials
                    to continue to your personalised portal.
                </p>


            </div>


            <!--
            ========================================
            FORM
            ========================================
            -->

            <form id="loginForm">


                <!-- EMAIL -->

                <div class="login-form-group">


                    <div class="login-form-label-row">

                        <label for="email">
                            EMAIL ADDRESS
                        </label>

                        <span class="field-hint">
                            REQUIRED
                        </span>

                    </div>


                    <div class="login-input-wrapper">


                        <svg
                            class="login-input-icon"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2"
                        >

                            <rect
                                x="3"
                                y="5"
                                width="18"
                                height="14"
                                rx="2"
                            ></rect>

                            <path
                                d="M3 7l9 6 9-6"
                            ></path>

                        </svg>


                        <input
                            type="email"
                            id="email"
                            placeholder="Enter your email"
                            autocomplete="email"
                            required
                        >


                    </div>


                </div>


                <!-- PASSWORD -->

                <div class="login-form-group">


                    <div class="login-form-label-row">

                        <label for="password">
                            PASSWORD
                        </label>

                        <span class="field-hint">
                            REQUIRED
                        </span>

                    </div>


                    <div class="login-input-wrapper">


                        <svg
                            class="login-input-icon"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2"
                        >

                            <rect
                                x="5"
                                y="10"
                                width="14"
                                height="10"
                                rx="2"
                            ></rect>

                            <path
                                d="M8 10V7a4 4 0 0 1 8 0v3"
                            ></path>

                        </svg>


                        <input
                            type="password"
                            id="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >


                        <button
                            type="button"
                            class="password-toggle"
                            id="passwordToggle"
                            aria-label="Show password"
                        >


                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                            >

                                <path
                                    d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"
                                ></path>

                                <circle
                                    cx="12"
                                    cy="12"
                                    r="2.5"
                                ></circle>

                            </svg>


                            <span id="passwordToggleText">
                                SHOW
                            </span>


                        </button>


                    </div>


                </div>


                <!-- LOGIN BUTTON -->

                <button
                    type="submit"
                    class="login-submit"
                    id="loginButton"
                >


                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path
                            d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"
                        ></path>

                        <path
                            d="M10 17l5-5-5-5"
                        ></path>

                        <path
                            d="M15 12H3"
                        ></path>

                    </svg>


                    <span id="loginButtonText">
                        LOGIN TO EVENTIFY
                    </span>


                </button>


            </form>


            <!--
            ========================================
            BOTTOM FIXED AREA
            ========================================
            -->

            <div class="login-bottom">


                <!-- DIVIDER -->

                <div class="account-divider">
                    NEW TO EVENTIFY?
                </div>


                <!-- CREATE -->

                <a
                    href="register.php"
                    class="create-account-btn"
                >

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <circle
                            cx="9"
                            cy="8"
                            r="4"
                        ></circle>

                        <path
                            d="M3 21v-2a6 6 0 0 1 12 0v2"
                        ></path>

                        <path
                            d="M19 8v6"
                        ></path>

                        <path
                            d="M16 11h6"
                        ></path>

                    </svg>

                    CREATE ACCOUNT

                </a>


                <!-- GUEST -->

                <a
                    href="events.php"
                    class="guest-link"
                >
                    CONTINUE AS GUEST
                </a>


                <!--
                ========================================
                RESERVED NOTIFICATION AREA
                ========================================
                -->

                <div class="message-slot">


                    <div id="message">


                        <div class="message-placeholder"></div>


                    </div>


                </div>


            </div>


        </section>


    </main>


    <!--
    ========================================
    FOOTER
    ========================================
    -->

    <div class="login-footer">

        EVENTIFY • Event Ticketing & Venue Booking System

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const loginForm =
            document.getElementById(
                'loginForm'
            );


        const message =
            document.getElementById(
                'message'
            );


        const loginButton =
            document.getElementById(
                'loginButton'
            );


        const loginButtonText =
            document.getElementById(
                'loginButtonText'
            );


        const passwordInput =
            document.getElementById(
                'password'
            );


        const passwordToggle =
            document.getElementById(
                'passwordToggle'
            );


        const passwordToggleText =
            document.getElementById(
                'passwordToggleText'
            );


        /*
        ========================================
        PASSWORD SHOW / HIDE
        ========================================
        */

        passwordToggle.addEventListener(
            'click',
            function() {

                const hidden =
                    passwordInput.type ===
                    'password';


                passwordInput.type =
                    hidden
                    ? 'text'
                    : 'password';


                passwordToggleText.textContent =
                    hidden
                    ? 'HIDE'
                    : 'SHOW';


                passwordToggle.setAttribute(

                    'aria-label',

                    hidden
                    ? 'Hide password'
                    : 'Show password'

                );


                passwordToggle
                    .querySelector('svg')
                    .innerHTML =

                    hidden

                    ?

                    `

                        <path
                            d="M3 3l18 18"
                        ></path>

                        <path
                            d="M10.6 10.6a2 2 0 0 0 2.8 2.8"
                        ></path>

                        <path
                            d="M9.9 4.25A10.6 10.6 0 0 1 12 4c6.5 0 10 8 10 8a18.7 18.7 0 0 1-2.2 3.2"
                        ></path>

                        <path
                            d="M6.6 6.6C3.7 8.4 2 12 2 12s3.5 8 10 8a9.8 9.8 0 0 0 4.2-.9"
                        ></path>

                    `

                    :

                    `

                        <path
                            d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"
                        ></path>

                        <circle
                            cx="12"
                            cy="12"
                            r="2.5"
                        ></circle>

                    `;

            }
        );


        /*
        ========================================
        EXISTING LOGIN
        ========================================
        */

        const existingToken =
            localStorage.getItem(
                'eventify_token'
            );


        const existingUser =
            localStorage.getItem(
                'eventify_user'
            );


        if (
            existingToken &&
            existingUser
        ) {

            try {

                const user =
                    JSON.parse(
                        existingUser
                    );


                redirectUser(
                    user.role
                );

            }

            catch (error) {

                localStorage.removeItem(
                    'eventify_token'
                );


                localStorage.removeItem(
                    'eventify_user'
                );

            }

        }


        /*
        ========================================
        LOGIN
        ========================================
        */

        loginForm.addEventListener(
            'submit',
            async function(event) {

                event.preventDefault();


                const email =
                    document
                        .getElementById(
                            'email'
                        )
                        .value
                        .trim();


                const password =
                    passwordInput.value;


                loginButton.disabled =
                    true;


                loginButtonText.textContent =
                    'CONNECTING...';


                /*
                ========================================
                LOADING MESSAGE
                ========================================
                */

                message.innerHTML = `

                    <div class="login-status login-loading">


                        <div class="login-spinner"></div>


                        <div class="login-status-content">


                            <div class="login-status-title">
                                CONNECTING TO EVENTIFY
                            </div>


                            <div class="login-status-text">
                                Verifying your account credentials...
                            </div>


                        </div>


                    </div>

                `;


                try {

                    const response =
                        await fetch(
                            '../auth/login.php',
                            {

                                method:
                                    'POST',

                                headers: {

                                    'Content-Type':
                                        'application/json'

                                },

                                body:
                                    JSON.stringify({

                                        email:
                                            email,

                                        password:
                                            password

                                    })

                            }
                        );


                    const result =
                        await response.json();


                    /*
                    ========================================
                    SUCCESS
                    ========================================
                    */

                    if (
                        response.ok &&
                        result.status ===
                        'success'
                    ) {

                        localStorage.setItem(
                            'eventify_token',
                            result.token
                        );


                        localStorage.setItem(
                            'eventify_user',
                            JSON.stringify(
                                result.user
                            )
                        );


                        message.innerHTML = `

                            <div class="login-status login-success">


                                <div class="login-status-icon">
                                    ✓
                                </div>


                                <div class="login-status-content">


                                    <div class="login-status-title">
                                        LOGIN SUCCESSFUL
                                    </div>


                                    <div class="login-status-text">

                                        Welcome back,

                                        <strong>

                                            ${escapeHtml(
                                                result.user.name
                                            )}

                                        </strong>.

                                    </div>


                                    <div class="login-status-bottom">


                                        <div class="login-role">

                                            ${escapeHtml(
                                                result.user.role
                                            )}

                                        </div>


                                        <div class="login-status-small">
                                            Redirecting...
                                        </div>


                                    </div>


                                </div>


                            </div>

                        `;


                        loginButtonText.textContent =
                            'ACCESS GRANTED';


                        setTimeout(
                            function() {

                                redirectUser(
                                    result.user.role
                                );

                            },
                            1100
                        );

                    }


                    /*
                    ========================================
                    FAILED
                    ========================================
                    */

                    else {

                        message.innerHTML = `

                            <div class="login-status login-error">


                                <div class="login-status-icon">
                                    !
                                </div>


                                <div class="login-status-content">


                                    <div class="login-status-title">
                                        LOGIN FAILED
                                    </div>


                                    <div class="login-status-text">

                                        ${escapeHtml(

                                            result.message
                                            ?
                                            result.message
                                            :
                                            'Invalid email or password.'

                                        )}

                                    </div>


                                </div>


                            </div>

                        `;


                        resetLoginButton();

                    }

                }

                catch (error) {

                    console.error(
                        'Login error:',
                        error
                    );


                    message.innerHTML = `

                        <div class="login-status login-error">


                            <div class="login-status-icon">
                                !
                            </div>


                            <div class="login-status-content">


                                <div class="login-status-title">
                                    CONNECTION ERROR
                                </div>


                                <div class="login-status-text">
                                    Unable to connect to Eventify API.
                                </div>


                            </div>


                        </div>

                    `;


                    resetLoginButton();

                }

            }
        );


        /*
        ========================================
        RESET
        ========================================
        */

        function resetLoginButton() {

            loginButton.disabled =
                false;


            loginButtonText.textContent =
                'LOGIN TO EVENTIFY';

        }


        /*
        ========================================
        REDIRECT
        ========================================
        */

        function redirectUser(
            role
        ) {

            if (
                role ===
                'Administrator'
            ) {

                window.location.href =
                    'admindashboard.php';

            }


            else if (
                role ===
                'Organiser'
            ) {

                window.location.href =
                    'organiserdashboard.php';

            }


            else if (
                role ===
                'Customer'
            ) {

                window.location.href =
                    'events.php';

            }


            else {

                localStorage.removeItem(
                    'eventify_token'
                );


                localStorage.removeItem(
                    'eventify_user'
                );


                window.location.href =
                    'login.php';

            }

        }


        /*
        ========================================
        ESCAPE HTML
        ========================================
        */

        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    </script>


</body>

</html>