<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Bookings - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;

            display: flex;
            flex-direction: column;
        }


        .bookings-shell {
            width: min(1180px, 92%);

            margin: 0 auto;

            flex: 1;
        }


        /*
        ========================================
        HERO
        ========================================
        */

        .bookings-hero {
            width: 100%;

            display: grid;

            grid-template-columns:
                minmax(0, 1fr)
                330px;

            align-items: stretch;

            gap: 14px;

            margin-bottom: 12px;
        }


        /*
        HERO LEFT
        */

        .hero-main {
            position: relative;

            min-height: 106px;

            display: flex;
            align-items: center;

            box-sizing: border-box;

            padding:
                17px
                19px;

            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 9px;

            background:
                linear-gradient(
                    135deg,
                    rgba(91, 42, 134, 0.24),
                    rgba(21, 17, 58, 0.78)
                );
        }


        .hero-main::after {
            content: "";

            position: absolute;

            width: 210px;
            height: 210px;

            right: -60px;
            top: -110px;

            border-radius: 50%;

            background:
                radial-gradient(
                    circle,
                    rgba(224, 107, 174, 0.15),
                    transparent 68%
                );
        }


        .hero-content {
            position: relative;

            z-index: 2;
        }


        .hero-eyebrow {
            display: flex;
            align-items: center;

            gap: 7px;

            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            letter-spacing: 0.75px;

            color: #E06BAE;
        }


        .hero-dot {
            width: 6px;
            height: 6px;

            border-radius: 50%;

            background: #E06BAE;

            box-shadow:
                0
                0
                8px
                rgba(224, 107, 174, 0.70);
        }


        .hero-main h2 {
            margin:
                0
                0
                6px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 21px;
            font-weight: 850;

            color: #ffffff;
        }


        .hero-main p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            line-height: 1.55;

            color:
                rgba(255, 255, 255, 0.50);
        }


        /*
        ========================================
        NEXT EVENT CARD
        ========================================
        */

        .next-event-card {
            min-height: 106px;

            display: grid;

            grid-template-columns:
                58px
                minmax(0, 1fr);

            align-items: center;

            gap: 12px;

            box-sizing: border-box;

            padding:
                13px
                14px;

            border:
                1px solid
                rgba(246, 197, 142, 0.13);

            border-radius: 9px;

            background:
                linear-gradient(
                    135deg,
                    rgba(246, 197, 142, 0.055),
                    rgba(224, 107, 174, 0.055)
                );
        }


        .next-date {
            width: 58px;
            height: 65px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-direction: column;

            box-sizing: border-box;

            border:
                1px solid
                rgba(224, 107, 174, 0.17);

            border-radius: 7px;

            background:
                rgba(91, 42, 134, 0.18);
        }


        .next-day {
            margin-bottom: 3px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 15px;

            color: #F6C58E;
        }


        .next-month {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.7px;

            color:
                rgba(255, 255, 255, 0.58);
        }


        .next-content {
            min-width: 0;
        }


        .next-label {
            margin-bottom: 4px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 850;

            letter-spacing: 0.7px;

            color: #E06BAE;
        }


        .next-name {
            margin-bottom: 5px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 12px;
            font-weight: 850;

            color: #ffffff;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        .next-meta {
            margin-bottom: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;

            color:
                rgba(255, 255, 255, 0.40);
        }


        .next-actions {
            display: flex;
            align-items: center;

            gap: 6px;
        }


        .next-view-btn {
            height: 25px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            padding:
                0
                9px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(224, 107, 174, 0.20);

            border-radius: 4px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 850;

            color: #ffffff;
        }


        .next-ticket-count {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 750;

            color:
                rgba(255, 255, 255, 0.42);
        }


        /*
        ========================================
        CONTROL BAR
        ========================================
        */

        .booking-controls {
            display: grid;

            grid-template-columns:
                125px
                125px
                125px
                minmax(300px, 1fr)
                165px
                150px;

            gap: 9px;

            margin-bottom: 11px;
        }


        /*
        STAT
        */

        .mini-stat {
            height: 54px;

            display: flex;
            align-items: center;

            gap: 9px;

            box-sizing: border-box;

            padding:
                0
                11px;

            border:
                1px solid
                rgba(255, 255, 255, 0.075);

            border-radius: 7px;

            background:
                rgba(255, 255, 255, 0.025);
        }


        .mini-stat-icon {
            width: 29px;
            height: 29px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 6px;

            background:
                rgba(224, 107, 174, 0.07);

            color: #E06BAE;
        }


        .mini-stat-icon svg {
            width: 14px;
            height: 14px;
        }


        .mini-stat-number {
            display: block;

            margin-bottom: 2px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 11px;

            color: #F6C58E;
        }


        .mini-stat-label {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 800;

            letter-spacing: 0.35px;

            color:
                rgba(255, 255, 255, 0.40);
        }


        /*
        SEARCH
        */

        .search-wrapper {
            position: relative;
        }


        .search-icon {
            position: absolute;

            left: 14px;
            top: 50%;

            width: 16px;
            height: 16px;

            transform:
                translateY(-50%);

            color:
                rgba(255, 255, 255, 0.56);

            pointer-events: none;
        }


        .search-wrapper input {
            width: 100%;
            height: 54px;

            box-sizing: border-box;

            padding:
                0
                14px
                0
                42px;

            border:
                1px solid
                rgba(224, 107, 174, 0.20);

            border-radius: 7px;

            outline: none;

            background:
                rgba(255, 255, 255, 0.07);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
        }


        .search-wrapper input::placeholder {
            color:
                rgba(255, 255, 255, 0.40);
        }


        .search-wrapper input:focus {
            border-color:
                rgba(224, 107, 174, 0.52);

            box-shadow:
                0
                0
                0
                3px
                rgba(224, 107, 174, 0.055);
        }


        /*
        FILTER
        */

        .filter-wrapper select {
            width: 100%;
            height: 54px;

            box-sizing: border-box;

            padding:
                0
                12px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 7px;

            outline: none;

            background:
                rgba(255, 255, 255, 0.05);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 700;
        }


        .filter-wrapper option {
            background: #1B1745;

            color: #ffffff;
        }


        /*
        BROWSE
        */

        .browse-btn {
            height: 54px;

            display: flex;
            align-items: center;
            justify-content: center;

            gap: 6px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(224, 107, 174, 0.23);

            border-radius: 7px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            color: #ffffff;
        }


        .browse-btn svg {
            width: 13px;
            height: 13px;
        }


        /*
        ========================================
        MESSAGE
        ========================================
        */

        #bookingMessage:empty {
            display: none;
        }


        #bookingMessage {
            margin-bottom: 9px;
        }


        .notification {
            display: flex;
            align-items: center;

            gap: 9px;

            box-sizing: border-box;

            padding:
                8px
                10px;

            border-radius: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .notification.success {
            border:
                1px solid
                rgba(95, 180, 160, 0.25);

            background:
                rgba(95, 180, 160, 0.07);
        }


        .notification.error {
            border:
                1px solid
                rgba(230, 95, 120, 0.25);

            background:
                rgba(230, 95, 120, 0.07);
        }


        .notification-icon {
            width: 25px;
            height: 25px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 5px;

            font-size: 11px;
            font-weight: 850;
        }


        .notification.success
        .notification-icon {
            background:
                rgba(95, 180, 160, 0.12);

            color: #8FD8C6;
        }


        .notification.error
        .notification-icon {
            background:
                rgba(230, 95, 120, 0.12);

            color: #EF8295;
        }


        .notification-title {
            margin-bottom: 1px;

            font-size: 9px;
            font-weight: 850;

            color: #ffffff;
        }


        .notification-text {
            font-size: 8px;

            color:
                rgba(255, 255, 255, 0.50);
        }


        /*
        ========================================
        LIST HEADER
        ========================================
        */

        .list-header {
            display: flex;
            align-items: end;
            justify-content: space-between;

            margin-bottom: 7px;
        }


        .list-title {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 13px;
            font-weight: 850;

            color: #ffffff;
        }


        .list-subtitle {
            margin-top: 2px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;

            color:
                rgba(255, 255, 255, 0.36);
        }


        /*
        ========================================
        BOOKINGS
        ========================================
        */

        .bookings-list {
            display: grid;

            gap: 8px;
        }


        /*
        ========================================
        BOOKING CARD
        ========================================
        */

        .booking-row {
            min-height: 116px;

            display: grid;

            grid-template-columns:
                105px
                minmax(0, 1fr)
                245px;

            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.085);

            border-radius: 8px;

            background:
                linear-gradient(
                    90deg,
                    rgba(36, 28, 86, 0.58),
                    rgba(21, 17, 58, 0.79)
                );

            transition:
                transform
                0.15s ease,
                border-color
                0.15s ease;
        }


        .booking-row:hover {
            transform:
                translateY(-1px);

            border-color:
                rgba(224, 107, 174, 0.21);
        }


        /*
        ========================================
        DATE COLUMN
        ========================================
        */

        .booking-date {
            position: relative;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-direction: column;

            text-align: center;

            border-right:
                1px dashed
                rgba(255, 255, 255, 0.12);

            background:
                linear-gradient(
                    180deg,
                    rgba(91, 42, 134, 0.24),
                    rgba(91, 42, 134, 0.11)
                );
        }


        .booking-date::before,
        .booking-date::after {
            content: "";

            position: absolute;

            right: -7px;

            width: 13px;
            height: 13px;

            border-radius: 50%;

            background: #0B0B2E;
        }


        .booking-date::before {
            top: -7px;
        }


        .booking-date::after {
            bottom: -7px;
        }


        .date-day {
            margin-bottom: 3px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 18px;

            color: #F6C58E;
        }


        .date-month {
            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.75px;

            color:
                rgba(255, 255, 255, 0.65);
        }


        .booking-ref-small {
            padding:
                3px
                6px;

            border-radius: 4px;

            background:
                rgba(255, 255, 255, 0.04);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 750;

            color:
                rgba(255, 255, 255, 0.37);
        }


        /*
        ========================================
        MAIN CONTENT
        ========================================
        */

        .booking-main {
            min-width: 0;

            display: flex;
            justify-content: center;

            flex-direction: column;

            box-sizing: border-box;

            padding:
                11px
                16px;
        }


        .booking-main-top {
            display: flex;
            align-items: center;

            gap: 8px;

            margin-bottom: 5px;
        }


        .booking-status {
            width: fit-content;

            padding:
                4px
                7px;

            border-radius: 4px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 850;
        }


        .booking-status.confirmed {
            border:
                1px solid
                rgba(143, 216, 198, 0.23);

            background:
                rgba(143, 216, 198, 0.07);

            color: #8FD8C6;
        }


        .booking-status.cancelled {
            border:
                1px solid
                rgba(239, 130, 149, 0.24);

            background:
                rgba(239, 130, 149, 0.07);

            color: #EF8295;
        }


        .booking-booked-label {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;

            color:
                rgba(255, 255, 255, 0.32);
        }


        .booking-event-name {
            margin-bottom: 8px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 16px;
            font-weight: 850;
            line-height: 1.25;

            color: #ffffff;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        /*
        INFO GRID
        */

        .booking-info-grid {
            display: grid;

            grid-template-columns:
                repeat(3, minmax(0, 1fr));

            gap:
                7px
                12px;
        }


        .booking-info-item {
            min-width: 0;

            display: flex;
            align-items: center;

            gap: 6px;
        }


        .booking-info-icon {
            width: 23px;
            height: 23px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 5px;

            background:
                rgba(224, 107, 174, 0.055);

            color: #E06BAE;
        }


        .booking-info-icon svg {
            width: 11px;
            height: 11px;
        }


        .booking-info-content {
            min-width: 0;
        }


        .booking-info-label {
            display: block;

            margin-bottom: 1px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;
            font-weight: 800;

            letter-spacing: 0.3px;

            color:
                rgba(255, 255, 255, 0.27);
        }


        .booking-info-value {
            display: block;

            min-width: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 650;

            color:
                rgba(255, 255, 255, 0.65);

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        /*
        ========================================
        RIGHT PANEL
        ========================================
        */

        .booking-side {
            display: flex;
            flex-direction: column;

            justify-content: center;

            box-sizing: border-box;

            padding:
                11px
                12px;

            border-left:
                1px solid
                rgba(255, 255, 255, 0.065);

            background:
                rgba(255, 255, 255, 0.014);
        }


        .booking-side-title {
            margin-bottom: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 850;

            letter-spacing: 0.65px;

            color:
                rgba(255, 255, 255, 0.30);
        }


        .booking-summary-grid {
            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 5px;

            margin-bottom: 9px;
        }


        .summary-box {
            min-width: 0;

            padding:
                7px
                5px;

            box-sizing: border-box;

            text-align: center;

            border:
                1px solid
                rgba(255, 255, 255, 0.055);

            border-radius: 5px;

            background:
                rgba(255, 255, 255, 0.02);
        }


        .summary-label {
            display: block;

            margin-bottom: 3px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 6px;
            font-weight: 800;

            color:
                rgba(255, 255, 255, 0.28);
        }


        .summary-value {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            color: #ffffff;
        }


        .summary-value.price {
            color: #F6C58E;
        }


        /*
        ACTION
        */

        .booking-actions {
            display: grid;

            grid-template-columns:
                1fr
                1fr;

            gap: 6px;
        }


        .booking-action-btn {
            height: 31px;

            display: flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 5px;

            background:
                rgba(255, 255, 255, 0.03);

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 850;

            color: #ffffff;

            cursor: pointer;
        }


        .booking-action-btn.primary {
            border-color:
                rgba(224, 107, 174, 0.21);

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );
        }


        .booking-action-btn.danger {
            border-color:
                rgba(239, 130, 149, 0.18);

            background:
                rgba(239, 130, 149, 0.055);

            color: #EF8295;
        }


        /*
        ========================================
        EMPTY
        ========================================
        */

        .bookings-empty {
            min-height: 180px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-direction: column;

            gap: 7px;

            padding: 20px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.07);

            border-radius: 8px;

            background:
                rgba(255, 255, 255, 0.018);

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.43);
        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        .pagination-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 12px;

            margin-top: 9px;
        }


        .pagination-info {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.40);
        }


        .pagination-controls {
            display: flex;
            align-items: center;

            gap: 7px;
        }


        .pagination-btn {
            min-width: 80px;
            height: 30px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 5px;

            background:
                rgba(255, 255, 255, 0.035);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;

            cursor: pointer;
        }


        .pagination-btn:hover:not(:disabled) {
            background:
                rgba(255, 255, 255, 0.07);
        }


        .pagination-btn:disabled {
            opacity: 0.25;

            cursor: not-allowed;
        }


        .pagination-page {
            min-width: 82px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 650;

            color:
                rgba(255, 255, 255, 0.50);
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                8px !important;

            padding-top:
                9px !important;

            padding-bottom:
                9px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 1100px) {

            .booking-controls {
                grid-template-columns:
                    repeat(3, 1fr);
            }


            .search-wrapper {
                grid-column:
                    1 / 3;
            }


            .bookings-hero {
                grid-template-columns:
                    1fr;
            }


            .booking-row {
                grid-template-columns:
                    95px
                    minmax(0, 1fr);
            }


            .booking-side {
                grid-column:
                    1 / -1;

                border-left: none;

                border-top:
                    1px solid
                    rgba(255, 255, 255, 0.06);
            }

        }


        @media (max-width: 700px) {

            .booking-controls {
                grid-template-columns: 1fr;
            }


            .search-wrapper {
                grid-column: auto;
            }


            .booking-row {
                grid-template-columns: 1fr;
            }


            .booking-date {
                min-height: 78px;

                border-right: none;

                border-bottom:
                    1px dashed
                    rgba(255, 255, 255, 0.12);
            }


            .booking-date::before,
            .booking-date::after {
                display: none;
            }


            .booking-info-grid {
                grid-template-columns: 1fr;
            }


            .booking-side {
                grid-column: auto;
            }


            .pagination-bar {
                flex-direction: column;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <h1>MY BOOKINGS</h1>


    <div class="bookings-shell">


        <!--
        ========================================
        HERO
        ========================================
        -->

        <section class="bookings-hero">


            <!-- LEFT -->

            <div class="hero-main">


                <div class="hero-content">


                    <div class="hero-eyebrow">

                        <span class="hero-dot"></span>

                        EVENTIFY TICKET WALLET

                    </div>


                    <h2 id="welcomeTitle">
                        Your Eventify bookings.
                    </h2>


                    <p>

                        Keep track of upcoming events, ticket quantities,
                        booking totals and reservation status in one place.

                    </p>


                </div>


            </div>


            <!-- NEXT EVENT -->

            <div
                class="next-event-card"
                id="nextEventCard"
            >


                <div class="next-date">


                    <span
                        class="next-day"
                        id="nextEventDay"
                    >
                        --
                    </span>


                    <span
                        class="next-month"
                        id="nextEventMonth"
                    >
                        ---
                    </span>


                </div>


                <div class="next-content">


                    <div class="next-label">
                        NEXT CONFIRMED EVENT
                    </div>


                    <div
                        class="next-name"
                        id="nextEventName"
                    >
                        Checking your bookings...
                    </div>


                    <div
                        class="next-meta"
                        id="nextEventMeta"
                    >
                        -
                    </div>


                    <div class="next-actions">


                        <a
                            href="events.php"
                            class="next-view-btn"
                            id="nextEventButton"
                        >
                            VIEW EVENT
                        </a>


                        <span
                            class="next-ticket-count"
                            id="nextEventTickets"
                        >
                        </span>


                    </div>


                </div>


            </div>


        </section>


        <!--
        ========================================
        CONTROLS
        ========================================
        -->

        <div class="booking-controls">


            <!-- TOTAL -->

            <div class="mini-stat">


                <div class="mini-stat-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <path d="M4 5h16v14H4z"></path>

                        <path d="M8 9h8"></path>

                        <path d="M8 13h5"></path>

                    </svg>

                </div>


                <div>

                    <span
                        class="mini-stat-number"
                        id="totalBookings"
                    >
                        0
                    </span>

                    <span class="mini-stat-label">
                        TOTAL
                    </span>

                </div>


            </div>


            <!-- CONFIRMED -->

            <div class="mini-stat">


                <div class="mini-stat-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        ></circle>

                        <path
                            d="M8 12l3 3 5-6"
                        ></path>

                    </svg>

                </div>


                <div>

                    <span
                        class="mini-stat-number"
                        id="confirmedBookings"
                    >
                        0
                    </span>

                    <span class="mini-stat-label">
                        CONFIRMED
                    </span>

                </div>


            </div>


            <!-- CANCELLED -->

            <div class="mini-stat">


                <div class="mini-stat-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        ></circle>

                        <path d="M9 9l6 6"></path>

                        <path d="M15 9l-6 6"></path>

                    </svg>

                </div>


                <div>

                    <span
                        class="mini-stat-number"
                        id="cancelledBookings"
                    >
                        0
                    </span>

                    <span class="mini-stat-label">
                        CANCELLED
                    </span>

                </div>


            </div>


            <!-- SEARCH -->

            <div class="search-wrapper">


                <svg
                    class="search-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20l-3.5-3.5"
                    ></path>

                </svg>


                <input
                    type="text"
                    id="bookingSearch"
                    placeholder="Search event, venue, location or booking ID..."
                >


            </div>


            <!-- FILTER -->

            <div class="filter-wrapper">


                <select id="statusFilter">

                    <option value="All">
                        All Status
                    </option>

                    <option value="Confirmed">
                        Confirmed
                    </option>

                    <option value="Cancelled">
                        Cancelled
                    </option>

                </select>


            </div>


            <!-- BROWSE -->

            <a
                href="events.php"
                class="browse-btn"
            >

                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20l-3.5-3.5"
                    ></path>

                </svg>

                BROWSE EVENTS

            </a>


        </div>


        <!-- MESSAGE -->

        <div id="bookingMessage"></div>


        <!--
        ========================================
        LIST HEADER
        ========================================
        -->

        <div class="list-header">


            <div>


                <div class="list-title">
                    Your Tickets
                </div>


                <div
                    class="list-subtitle"
                    id="resultsSubtitle"
                >
                    Loading your bookings...
                </div>


            </div>


        </div>


        <!--
        ========================================
        LIST
        ========================================
        -->

        <div
            class="bookings-list"
            id="bookingsList"
        >

            <div class="bookings-empty">
                Loading your Eventify bookings...
            </div>

        </div>


        <!--
        ========================================
        PAGINATION
        ========================================
        -->

        <div class="pagination-bar">


            <div
                class="pagination-info"
                id="paginationInfo"
            >
                Showing 0 bookings
            </div>


            <div class="pagination-controls">


                <button
                    type="button"
                    class="pagination-btn"
                    id="previousPageButton"
                    onclick="previousPage()"
                >
                    PREVIOUS
                </button>


                <div
                    class="pagination-page"
                    id="paginationPage"
                >
                    Page 1 of 1
                </div>


                <button
                    type="button"
                    class="pagination-btn"
                    id="nextPageButton"
                    onclick="nextPage()"
                >
                    NEXT
                </button>


            </div>


        </div>


    </div>


    <div class="footer">

        EVENTIFY CUSTOMER PORTAL

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        SESSION
        ========================================
        */

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser =
            null;


        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const bookingsList =
            document.getElementById(
                'bookingsList'
            );


        const bookingSearch =
            document.getElementById(
                'bookingSearch'
            );


        const statusFilter =
            document.getElementById(
                'statusFilter'
            );


        const bookingMessage =
            document.getElementById(
                'bookingMessage'
            );


        const totalBookings =
            document.getElementById(
                'totalBookings'
            );


        const confirmedBookings =
            document.getElementById(
                'confirmedBookings'
            );


        const cancelledBookings =
            document.getElementById(
                'cancelledBookings'
            );


        const resultsSubtitle =
            document.getElementById(
                'resultsSubtitle'
            );


        const paginationInfo =
            document.getElementById(
                'paginationInfo'
            );


        const paginationPage =
            document.getElementById(
                'paginationPage'
            );


        const previousPageButton =
            document.getElementById(
                'previousPageButton'
            );


        const nextPageButton =
            document.getElementById(
                'nextPageButton'
            );


        /*
        ========================================
        DATA
        ========================================
        */

        let allBookings =
            [];


        let filteredBookings =
            [];


        let hiddenBookingIds =
            [];


        /*
        3 per page keeps everything compact
        at browser 100%.
        */

        const bookingsPerPage =
            3;


        let currentPage =
            1;


        /*
        ========================================
        AUTH
        ========================================
        */

        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }


            if (
                currentUser &&
                currentUser.role !==
                'Customer'
            ) {

                alert(
                    'Customer access only.'
                );


                window.location.href =
                    'login.php';

            }

            else if (currentUser) {

                document
                    .getElementById(
                        'welcomeTitle'
                    )
                    .textContent =
                        `Welcome back, ${currentUser.name || 'Customer'}.`;


                loadHiddenBookings();


                loadBookings();

            }

        }


        /*
        ========================================
        SEARCH
        ========================================
        */

        bookingSearch.addEventListener(
            'input',
            function() {

                currentPage =
                    1;


                filterBookings();

            }
        );


        statusFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterBookings();

            }
        );


        /*
        ========================================
        HIDDEN BOOKINGS
        ========================================
        */

        function getHiddenStorageKey() {

            return (
                'eventify_hidden_bookings_'
                +
                currentUser.user_id
            );

        }


        function loadHiddenBookings() {

            try {

                const stored =
                    localStorage.getItem(
                        getHiddenStorageKey()
                    );


                hiddenBookingIds =
                    stored
                    ?
                    JSON.parse(
                        stored
                    )
                    :
                    [];

            }

            catch (error) {

                hiddenBookingIds =
                    [];

            }

        }


        function saveHiddenBookings() {

            localStorage.setItem(

                getHiddenStorageKey(),

                JSON.stringify(
                    hiddenBookingIds
                )

            );

        }


        /*
        ========================================
        LOAD
        ========================================
        */

        async function loadBookings() {

            try {

                const response =
                    await fetch(
                        '../api/bookings.php',
                        {

                            headers: {

                                'Authorization':
                                    `Bearer ${token}`

                            }

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    allBookings =
                        result.data ||
                        [];


                    updateStats();


                    updateNextEvent();


                    filterBookings();

                }

                else {

                    throw new Error(
                        result.message ||
                        'Unable to load bookings.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Bookings error:',
                    error
                );


                bookingsList.innerHTML = `

                    <div class="bookings-empty">

                        Unable to load your bookings.

                    </div>

                `;


                showNotification(
                    'error',
                    'Unable to load bookings',
                    error.message ||
                    'Booking data could not be retrieved.'
                );

            }

        }


        /*
        ========================================
        STATS
        ========================================
        */

        function getVisibleBookings() {

            return allBookings.filter(
                function(booking) {

                    return (
                        !hiddenBookingIds.includes(
                            Number(
                                booking.booking_id
                            )
                        )
                    );

                }
            );

        }


        function updateStats() {

            const visible =
                getVisibleBookings();


            totalBookings.textContent =
                visible.length;


            confirmedBookings.textContent =
                visible.filter(
                    function(booking) {

                        return (
                            booking.booking_status ===
                            'Confirmed'
                        );

                    }
                ).length;


            cancelledBookings.textContent =
                visible.filter(
                    function(booking) {

                        return (
                            booking.booking_status ===
                            'Cancelled'
                        );

                    }
                ).length;

        }


        /*
        ========================================
        NEXT EVENT
        ========================================
        */

        function updateNextEvent() {

            const confirmed =
                getVisibleBookings()
                    .filter(
                        function(booking) {

                            return (
                                booking.booking_status ===
                                'Confirmed'
                            );

                        }
                    )
                    .sort(
                        function(a, b) {

                            return String(
                                a.event_date ||
                                ''
                            )
                            .localeCompare(
                                String(
                                    b.event_date ||
                                    ''
                                )
                            );

                        }
                    );


            if (
                confirmed.length ===
                0
            ) {

                document
                    .getElementById(
                        'nextEventDay'
                    )
                    .textContent =
                        '--';


                document
                    .getElementById(
                        'nextEventMonth'
                    )
                    .textContent =
                        '---';


                document
                    .getElementById(
                        'nextEventName'
                    )
                    .textContent =
                        'No confirmed event yet';


                document
                    .getElementById(
                        'nextEventMeta'
                    )
                    .textContent =
                        'Browse Eventify to find your next event.';


                document
                    .getElementById(
                        'nextEventButton'
                    )
                    .href =
                        'events.php';


                document
                    .getElementById(
                        'nextEventButton'
                    )
                    .textContent =
                        'BROWSE EVENTS';


                document
                    .getElementById(
                        'nextEventTickets'
                    )
                    .textContent =
                        '';


                return;

            }


            const next =
                confirmed[0];


            const parts =
                getDateParts(
                    next.event_date
                );


            document
                .getElementById(
                    'nextEventDay'
                )
                .textContent =
                    parts.day;


            document
                .getElementById(
                    'nextEventMonth'
                )
                .textContent =
                    parts.month;


            document
                .getElementById(
                    'nextEventName'
                )
                .textContent =
                    next.event_name ||
                    'Upcoming Event';


            document
                .getElementById(
                    'nextEventMeta'
                )
                .textContent =
                    `${formatTime(
                        next.start_time
                    )} • ${next.venue_name || 'Venue TBA'}`;


            document
                .getElementById(
                    'nextEventButton'
                )
                .href =
                    `eventdetails.php?event_id=${encodeURIComponent(
                        next.event_id
                    )}`;


            document
                .getElementById(
                    'nextEventButton'
                )
                .textContent =
                    'VIEW EVENT';


            document
                .getElementById(
                    'nextEventTickets'
                )
                .textContent =
                    `${Number(
                        next.quantity
                        ??
                        next.ticket_quantity
                        ??
                        0
                    )} ticket(s)`;

        }


        /*
        ========================================
        FILTER
        ========================================
        */

        function filterBookings() {

            const search =
                bookingSearch
                    .value
                    .trim()
                    .toLowerCase();


            const selectedStatus =
                statusFilter.value;


            filteredBookings =
                allBookings.filter(
                    function(booking) {


                        if (
                            hiddenBookingIds.includes(
                                Number(
                                    booking.booking_id
                                )
                            )
                        ) {

                            return false;

                        }


                        const id =
                            String(
                                booking.booking_id ||
                                ''
                            )
                            .toLowerCase();


                        const eventName =
                            String(
                                booking.event_name ||
                                ''
                            )
                            .toLowerCase();


                        const venue =
                            String(
                                booking.venue_name ||
                                ''
                            )
                            .toLowerCase();


                        const location =
                            String(
                                booking.location ||
                                ''
                            )
                            .toLowerCase();


                        const matchesSearch =

                            !search

                            ||

                            id.includes(
                                search
                            )

                            ||

                            eventName.includes(
                                search
                            )

                            ||

                            venue.includes(
                                search
                            )

                            ||

                            location.includes(
                                search
                            );


                        const matchesStatus =

                            selectedStatus ===
                            'All'

                            ||

                            booking.booking_status ===
                            selectedStatus;


                        return (
                            matchesSearch &&
                            matchesStatus
                        );

                    }
                );


            const totalPages =
                getTotalPages();


            if (
                currentPage >
                totalPages
            ) {

                currentPage =
                    totalPages;

            }


            if (
                currentPage <
                1
            ) {

                currentPage =
                    1;

            }


            displayBookings();

        }


        /*
        ========================================
        DISPLAY
        ========================================
        */

        function displayBookings() {

            resultsSubtitle.textContent =

                filteredBookings.length ===
                1

                ? '1 booking found.'

                : `${filteredBookings.length} bookings found.`;


            if (
                filteredBookings.length ===
                0
            ) {

                bookingsList.innerHTML = `

                    <div class="bookings-empty">

                        No bookings found.

                        <br>

                        Browse events and reserve your next ticket.

                    </div>

                `;


                updatePagination();

                return;

            }


            const startIndex =
                (
                    currentPage -
                    1
                )
                *
                bookingsPerPage;


            const pageBookings =
                filteredBookings.slice(

                    startIndex,

                    startIndex +
                    bookingsPerPage

                );


            bookingsList.innerHTML =
                '';


            pageBookings.forEach(
                function(booking) {


                    const dateParts =
                        getDateParts(
                            booking.event_date
                        );


                    const quantity =
                        Number(
                            booking.quantity
                            ??
                            booking.ticket_quantity
                            ??
                            0
                        );


                    const total =
                        Number(
                            booking.total_amount
                            ??
                            booking.total_price
                            ??
                            0
                        );


                    const perTicket =

                        quantity >
                        0

                        ? total /
                        quantity

                        : 0;


                    const cancelled =
                        booking.booking_status ===
                        'Cancelled';


                    const bookedOn =
                        formatDate(
                            booking.booking_date
                            ??
                            booking.created_at
                            ??
                            ''
                        );


                    bookingsList.innerHTML += `

                        <article class="booking-row">


                            <!-- DATE -->

                            <div class="booking-date">


                                <div class="date-day">

                                    ${dateParts.day}

                                </div>


                                <div class="date-month">

                                    ${dateParts.month}

                                    ${dateParts.year}

                                </div>


                                <div class="booking-ref-small">

                                    BOOKING #${booking.booking_id}

                                </div>


                            </div>


                            <!-- MAIN -->

                            <div class="booking-main">


                                <div class="booking-main-top">


                                    <span
                                        class="
                                            booking-status
                                            ${
                                                cancelled
                                                ?
                                                'cancelled'
                                                :
                                                'confirmed'
                                            }
                                        "
                                    >

                                        ${escapeHtml(
                                            booking.booking_status ||
                                            '-'
                                        )}

                                    </span>


                                    <span class="booking-booked-label">

                                        Booked ${escapeHtml(
                                            bookedOn
                                        )}

                                    </span>


                                </div>


                                <div class="booking-event-name">

                                    ${escapeHtml(
                                        booking.event_name ||
                                        'Untitled Event'
                                    )}

                                </div>


                                <div class="booking-info-grid">


                                    <!-- TIME -->

                                    <div class="booking-info-item">


                                        <div class="booking-info-icon">

                                            <svg
                                                viewBox="0 0 24 24"
                                                fill="none"
                                                stroke="currentColor"
                                                stroke-width="1.8"
                                            >

                                                <circle
                                                    cx="12"
                                                    cy="12"
                                                    r="9"
                                                ></circle>

                                                <path
                                                    d="M12 7v5l3 2"
                                                ></path>

                                            </svg>

                                        </div>


                                        <div class="booking-info-content">

                                            <span class="booking-info-label">
                                                TIME
                                            </span>

                                            <span class="booking-info-value">

                                                ${formatTime(
                                                    booking.start_time
                                                )}

                                                -

                                                ${formatTime(
                                                    booking.end_time
                                                )}

                                            </span>

                                        </div>


                                    </div>


                                    <!-- VENUE -->

                                    <div class="booking-info-item">


                                        <div class="booking-info-icon">

                                            <svg
                                                viewBox="0 0 24 24"
                                                fill="none"
                                                stroke="currentColor"
                                                stroke-width="1.8"
                                            >

                                                <path
                                                    d="M12 21s7-5.5 7-12a7 7 0 1 0-14 0c0 6.5 7 12 7 12z"
                                                ></path>

                                                <circle
                                                    cx="12"
                                                    cy="9"
                                                    r="2.2"
                                                ></circle>

                                            </svg>

                                        </div>


                                        <div class="booking-info-content">

                                            <span class="booking-info-label">
                                                VENUE
                                            </span>

                                            <span class="booking-info-value">

                                                ${escapeHtml(
                                                    booking.venue_name ||
                                                    'Venue TBA'
                                                )}

                                            </span>

                                        </div>


                                    </div>


                                    <!-- LOCATION -->

                                    <div class="booking-info-item">


                                        <div class="booking-info-icon">

                                            <svg
                                                viewBox="0 0 24 24"
                                                fill="none"
                                                stroke="currentColor"
                                                stroke-width="1.8"
                                            >

                                                <path
                                                    d="M4 20h16"
                                                ></path>

                                                <path
                                                    d="M6 20V8l6-4 6 4v12"
                                                ></path>

                                            </svg>

                                        </div>


                                        <div class="booking-info-content">

                                            <span class="booking-info-label">
                                                LOCATION
                                            </span>

                                            <span class="booking-info-value">

                                                ${escapeHtml(
                                                    booking.location ||
                                                    '-'
                                                )}

                                            </span>

                                        </div>


                                    </div>


                                </div>


                            </div>


                            <!-- RIGHT -->

                            <div class="booking-side">


                                <div class="booking-side-title">
                                    BOOKING SUMMARY
                                </div>


                                <div class="booking-summary-grid">


                                    <div class="summary-box">

                                        <span class="summary-label">
                                            TICKETS
                                        </span>

                                        <span class="summary-value">

                                            ${quantity}

                                        </span>

                                    </div>


                                    <div class="summary-box">

                                        <span class="summary-label">
                                            EACH
                                        </span>

                                        <span class="summary-value">

                                            RM ${perTicket.toFixed(
                                                2
                                            )}

                                        </span>

                                    </div>


                                    <div class="summary-box">

                                        <span class="summary-label">
                                            TOTAL
                                        </span>

                                        <span class="summary-value price">

                                            RM ${total.toFixed(
                                                2
                                            )}

                                        </span>

                                    </div>


                                </div>


                                <div class="booking-actions">


                                    <a
                                        href="eventdetails.php?event_id=${encodeURIComponent(
                                            booking.event_id
                                        )}"
                                        class="
                                            booking-action-btn
                                            primary
                                        "
                                    >
                                        VIEW EVENT
                                    </a>


                                    ${
                                        cancelled

                                        ?

                                        `

                                            <button
                                                type="button"
                                                class="
                                                    booking-action-btn
                                                    danger
                                                "
                                                onclick="removeBooking(
                                                    ${booking.booking_id}
                                                )"
                                            >
                                                REMOVE
                                            </button>

                                        `

                                        :

                                        `

                                            <button
                                                type="button"
                                                class="
                                                    booking-action-btn
                                                    danger
                                                "
                                                onclick="cancelBooking(
                                                    ${booking.booking_id}
                                                )"
                                            >
                                                CANCEL
                                            </button>

                                        `
                                    }


                                </div>


                            </div>


                        </article>

                    `;

                }
            );


            updatePagination();

        }


        /*
        ========================================
        CANCEL
        ========================================
        */

        async function cancelBooking(
            bookingId
        ) {

            const booking =
                allBookings.find(
                    function(item) {

                        return (
                            Number(
                                item.booking_id
                            )
                            ===
                            Number(
                                bookingId
                            )
                        );

                    }
                );


            if (!booking) {

                return;

            }


            const confirmed =
                confirm(

                    `Cancel booking #${bookingId}?\n\n` +

                    `${booking.event_name}\n\n` +

                    `The booked tickets will be returned to the event availability.`

                );


            if (!confirmed) {

                return;

            }


            try {

                const response =
                    await fetch(
                        '../api/bookings.php',
                        {

                            method:
                                'DELETE',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    booking_id:
                                        Number(
                                            bookingId
                                        )

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    showNotification(
                        'success',
                        'Booking cancelled',
                        `Booking #${bookingId} has been cancelled successfully.`
                    );


                    await loadBookings();

                }

                else {

                    showNotification(
                        'error',
                        'Cancellation failed',
                        result.message ||
                        'Unable to cancel this booking.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Cancel booking error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Booking API.'
                );

            }

        }


        /*
        ========================================
        REMOVE
        ========================================
        */

        function removeBooking(
            bookingId
        ) {

            const confirmed =
                confirm(

                    'Remove this cancelled booking from your view?\n\n' +

                    'The original record will remain available to Eventify administrators and organisers.'

                );


            if (!confirmed) {

                return;

            }


            if (
                !hiddenBookingIds.includes(
                    Number(
                        bookingId
                    )
                )
            ) {

                hiddenBookingIds.push(
                    Number(
                        bookingId
                    )
                );

            }


            saveHiddenBookings();


            currentPage =
                1;


            updateStats();


            updateNextEvent();


            filterBookings();


            showNotification(
                'success',
                'Booking removed',
                `Booking #${bookingId} was removed from this view.`
            );

        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        function showNotification(
            type,
            title,
            text
        ) {

            bookingMessage.innerHTML = `

                <div
                    class="
                        notification
                        ${type}
                    "
                >

                    <div class="notification-icon">

                        ${
                            type ===
                            'success'
                            ?
                            '✓'
                            :
                            '!'
                        }

                    </div>


                    <div>

                        <div class="notification-title">

                            ${escapeHtml(
                                title
                            )}

                        </div>


                        <div class="notification-text">

                            ${escapeHtml(
                                text
                            )}

                        </div>

                    </div>


                </div>

            `;


            window.setTimeout(
                function() {

                    bookingMessage.innerHTML =
                        '';

                },
                3500
            );

        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        function getTotalPages() {

            return Math.max(

                1,

                Math.ceil(
                    filteredBookings.length /
                    bookingsPerPage
                )

            );

        }


        function updatePagination() {

            const totalPages =
                getTotalPages();


            const start =

                filteredBookings.length ===
                0

                ? 0

                : (
                    (
                        currentPage -
                        1
                    )
                    *
                    bookingsPerPage
                )
                +
                1;


            const end =
                Math.min(

                    currentPage *
                    bookingsPerPage,

                    filteredBookings.length

                );


            paginationInfo.textContent =

                filteredBookings.length ===
                0

                ? 'Showing 0 bookings'

                : `Showing ${start}-${end} of ${filteredBookings.length} bookings`;


            paginationPage.textContent =
                `Page ${currentPage} of ${totalPages}`;


            previousPageButton.disabled =
                currentPage <=
                1;


            nextPageButton.disabled =
                currentPage >=
                totalPages;

        }


        function previousPage() {

            if (
                currentPage <=
                1
            ) {

                return;

            }


            currentPage--;


            displayBookings();

        }


        function nextPage() {

            if (
                currentPage >=
                getTotalPages()
            ) {

                return;

            }


            currentPage++;


            displayBookings();

        }


        /*
        ========================================
        DATE
        ========================================
        */

        function getDateParts(
            value
        ) {

            if (!value) {

                return {

                    day:
                        '--',

                    month:
                        '---',

                    year:
                        ''

                };

            }


            const parts =
                String(
                    value
                )
                .substring(
                    0,
                    10
                )
                .split(
                    '-'
                );


            const months =
                [
                    'JAN',
                    'FEB',
                    'MAR',
                    'APR',
                    'MAY',
                    'JUN',
                    'JUL',
                    'AUG',
                    'SEP',
                    'OCT',
                    'NOV',
                    'DEC'
                ];


            return {

                day:
                    parts[2] ||
                    '--',

                month:
                    months[
                        Number(
                            parts[1]
                        )
                        -
                        1
                    ]
                    ||
                    '---',

                year:
                    parts[0] ||
                    ''

            };

        }


        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const raw =
                String(
                    value
                )
                .substring(
                    0,
                    10
                );


            const parts =
                raw.split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return raw;

            }


            return (
                parts[2]
                +
                '/'
                +
                parts[1]
                +
                '/'
                +
                parts[0]
            );

        }


        /*
        ========================================
        TIME
        ========================================
        */

        function formatTime(
            value
        ) {

            if (!value) {

                return '-';

            }


            return String(
                value
            ).substring(
                0,
                5
            );

        }


        /*
        ========================================
        SESSION
        ========================================
        */

        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );


            localStorage.removeItem(
                'eventify_user'
            );


            window.location.href =
                'login.php';

        }


        /*
        ========================================
        ESCAPE
        ========================================
        */

        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    </script>


</body>

</html>