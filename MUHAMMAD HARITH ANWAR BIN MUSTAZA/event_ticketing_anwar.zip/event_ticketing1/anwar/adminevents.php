<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Manage Events - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }


        .events-shell {
            width: min(1180px, 92%);
            margin: 0 auto;
            flex: 1;
        }


        /*
        ========================================
        PAGE HEADER
        ========================================
        */

        .events-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 18px;
            flex-wrap: wrap;

            margin-bottom: 14px;
        }


        .events-page-header-text h2 {
            margin: 0 0 4px 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 17px;
            font-weight: 800;

            color: #ffffff;
        }


        .events-page-header-text p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.5;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        /*
        ========================================
        EVENT COUNT
        ========================================
        */

        .events-count-card {
            display: flex;
            align-items: center;

            gap: 10px;

            min-width: 105px;

            padding: 10px 13px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.22
                );

            border-radius: 8px;

            background:
                linear-gradient(
                    135deg,
                    rgba(
                        91,
                        42,
                        134,
                        0.23
                    ),
                    rgba(
                        176,
                        68,
                        158,
                        0.10
                    )
                );
        }


        .events-count-icon {
            width: 30px;
            height: 30px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 7px;

            background:
                rgba(
                    224,
                    107,
                    174,
                    0.10
                );

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .events-count-icon svg {
            width: 16px;
            height: 16px;
        }


        .events-count-content {
            display: flex;
            flex-direction: column;
        }


        .events-count-number {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 15px;
            font-weight: 800;

            color: #ffffff;
        }


        .events-count-label {
            margin-top: 1px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 700;
            letter-spacing: 0.5px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.50
                );
        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        #eventMessage:empty {
            display: none;
        }


        #eventMessage {
            width: 100%;

            box-sizing: border-box;

            margin:
                0
                0
                14px
                0;
        }


        .events-notification {
            width: 100%;

            display: flex;
            align-items: center;

            gap: 11px;

            box-sizing: border-box;

            padding: 10px 13px;

            border-radius: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .events-notification-success {
            border:
                1px solid
                rgba(
                    95,
                    180,
                    160,
                    0.28
                );

            background:
                rgba(
                    95,
                    180,
                    160,
                    0.09
                );
        }


        .events-notification-error {
            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.28
                );

            background:
                rgba(
                    230,
                    95,
                    120,
                    0.09
                );
        }


        .notification-icon {
            width: 27px;
            height: 27px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 6px;

            font-size: 13px;
            font-weight: 800;
        }


        .events-notification-success
        .notification-icon {
            background:
                rgba(
                    95,
                    180,
                    160,
                    0.13
                );

            color: #8FD8C6;
        }


        .events-notification-error
        .notification-icon {
            background:
                rgba(
                    230,
                    95,
                    120,
                    0.13
                );

            color: #EF8295;
        }


        .notification-content {
            min-width: 0;
        }


        .notification-title {
            margin-bottom: 2px;

            font-size: 10px;
            font-weight: 800;

            color: #ffffff;
        }


        .notification-text {
            font-size: 10px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.58
                );
        }


        /*
        ========================================
        TOOLBAR
        ========================================
        */

        .events-toolbar {
            display: grid;

            grid-template-columns:
                minmax(
                    280px,
                    1fr
                )
                170px
                180px;

            gap: 12px;

            margin-bottom: 14px;
        }


        /*
        SEARCH
        */

        .search-wrapper {
            position: relative;
        }


        .search-icon {
            position: absolute;

            left: 15px;
            top: 50%;

            width: 17px;
            height: 17px;

            transform:
                translateY(
                    -50%
                );

            pointer-events: none;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        .search-wrapper input {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                15px
                0
                43px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.22
                );

            border-radius: 8px;

            outline: none;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.085
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 12px;

            transition:
                border-color
                0.18s ease,
                background
                0.18s ease,
                box-shadow
                0.18s ease;
        }


        .search-wrapper input::placeholder {
            color:
                rgba(
                    255,
                    255,
                    255,
                    0.47
                );
        }


        .search-wrapper input:hover {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.105
                );
        }


        .search-wrapper input:focus {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.11
                );

            border-color:
                rgba(
                    224,
                    107,
                    174,
                    0.55
                );

            box-shadow:
                0
                0
                0
                3px
                rgba(
                    224,
                    107,
                    174,
                    0.07
                );
        }


        /*
        FILTERS
        */

        .events-filter select {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                13px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.12
                );

            border-radius: 8px;

            outline: none;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.06
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            font-weight: 600;

            cursor: pointer;
        }


        .events-filter option {
            background: #1B1745;
            color: #ffffff;
        }


        /*
        ========================================
        TABLE
        ========================================
        */

        .events-table-wrapper {
            width: 100%;
            overflow-x: auto;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 9px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.02
                );
        }


        .events-table {
            width: 100%;
            min-width: 1080px;

            border-collapse: collapse;
            table-layout: fixed;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .events-table thead {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.045
                );
        }


        .events-table th {
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                12px;

            text-align: left;

            border-bottom:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.65px;

            color:
                rgba(
                    246,
                    197,
                    142,
                    0.88
                );
        }


        .events-table td {
            height: 51px;

            box-sizing: border-box;

            padding:
                7px
                12px;

            vertical-align: middle;

            border-bottom:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.065
                );

            font-size: 10px;
            line-height: 1.4;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.83
                );
        }


        .events-table tbody tr:hover {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.028
                );
        }


        .events-table tbody tr:last-child td {
            border-bottom: none;
        }


        /*
        COLUMN WIDTH
        */

        .col-id {
            width: 60px;
        }


        .col-event {
            width: 200px;
        }


        .col-organiser {
            width: 145px;
        }


        .col-venue {
            width: 165px;
        }


        .col-date {
            width: 115px;
        }


        .col-price {
            width: 85px;
        }


        .col-tickets {
            width: 90px;
            text-align: center !important;
        }


        .col-status {
            width: 100px;
            text-align: center !important;
        }


        .col-action {
            width: 150px;
            text-align: center !important;
        }


        /*
        EVENT INFO
        */

        .event-id {
            font-weight: 800;

            color:
                var(
                    --pink,
                    #E06BAE
                );
        }


        .event-name {
            margin-bottom: 2px;

            font-size: 10px;
            font-weight: 750;

            color: #ffffff;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        .event-category,
        .event-subtext {
            font-size: 9px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.45
                );

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        /*
        STATUS
        */

        .status-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 72px;

            padding:
                5px
                8px;

            box-sizing: border-box;

            border-radius: 5px;

            font-size: 8px;
            font-weight: 800;
            letter-spacing: 0.25px;
        }


        .status-upcoming {
            background:
                rgba(
                    95,
                    180,
                    160,
                    0.10
                );

            border:
                1px solid
                rgba(
                    95,
                    180,
                    160,
                    0.24
                );

            color: #8FD8C6;
        }


        .status-ongoing {
            background:
                rgba(
                    246,
                    197,
                    142,
                    0.10
                );

            border:
                1px solid
                rgba(
                    246,
                    197,
                    142,
                    0.25
                );

            color: #F6C58E;
        }


        .status-completed {
            background:
                rgba(
                    120,
                    140,
                    190,
                    0.10
                );

            border:
                1px solid
                rgba(
                    120,
                    140,
                    190,
                    0.24
                );

            color: #A9B9EC;
        }


        .status-cancelled {
            background:
                rgba(
                    230,
                    95,
                    120,
                    0.10
                );

            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.25
                );

            color: #EF8295;
        }


        /*
        TICKETS
        */

        .ticket-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            min-width: 44px;
            height: 25px;

            padding:
                0
                7px;

            box-sizing: border-box;

            border-radius: 5px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.055
                );

            font-size: 9px;
            font-weight: 750;

            color: #ffffff;
        }


        /*
        ========================================
        ACTIONS
        ========================================
        */

        .event-actions {
            display: flex;
            align-items: center;
            justify-content: center;

            gap: 9px;
        }


        .manage-event-btn {
            height: 30px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            padding:
                0
                13px;

            border:
                1px solid
                rgba(
                    224,
                    107,
                    174,
                    0.25
                );

            border-radius: 5px;

            background:
                linear-gradient(
                    135deg,
                    var(
                        --purple,
                        #5B2A86
                    ),
                    var(
                        --magenta,
                        #B0449E
                    )
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.3px;

            cursor: pointer;
        }


        .manage-event-btn:hover {
            opacity: 0.88;
        }


        .delete-event-btn {
            width: 32px;
            height: 30px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            padding: 0;

            border:
                1px solid
                rgba(
                    230,
                    95,
                    120,
                    0.25
                );

            border-radius: 5px;

            background:
                rgba(
                    180,
                    55,
                    80,
                    0.13
                );

            color: #EF8295;

            cursor: pointer;

            transition:
                background
                0.15s ease,
                transform
                0.15s ease;
        }


        .delete-event-btn:hover {
            background:
                rgba(
                    180,
                    55,
                    80,
                    0.26
                );

            transform:
                translateY(
                    -1px
                );
        }


        .delete-event-btn svg {
            width: 14px;
            height: 14px;
        }


        /*
        ========================================
        EMPTY
        ========================================
        */

        .events-empty {
            padding:
                30px
                20px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        .pagination-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 14px;
            flex-wrap: wrap;

            margin-top: 13px;
        }


        .pagination-info {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        .pagination-controls {
            display: flex;
            align-items: center;
            gap: 8px;
        }


        .pagination-btn {
            min-width: 82px;
            height: 32px;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            padding:
                0
                12px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.10
                );

            border-radius: 5px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    0.045
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 750;

            cursor: pointer;
        }


        .pagination-btn:hover:not(:disabled) {
            background:
                rgba(
                    255,
                    255,
                    255,
                    0.09
                );
        }


        .pagination-btn:disabled {
            opacity: 0.28;
            cursor: not-allowed;
        }


        .pagination-page {
            min-width: 78px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 700;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        /*
        ========================================
        MODAL
        ========================================
        */

        .events-modal-overlay {
            position: fixed;
            inset: 0;

            display: none;
            align-items: center;
            justify-content: center;

            padding: 20px;

            box-sizing: border-box;

            background:
                rgba(
                    0,
                    0,
                    0,
                    0.74
                );

            z-index: 9999;
        }


        .events-modal-overlay.active {
            display: flex;
        }


        .events-modal {
            width: 100%;
            max-width: 700px;

            max-height: 90vh;
            overflow-y: auto;

            box-sizing: border-box;

            padding: 23px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.14
                );

            border-radius: 10px;

            background:
                var(
                    --panel-soft,
                    #241C56
                );
        }


        .events-modal-header {
            margin-bottom: 20px;
        }


        .events-modal-header h2 {
            margin:
                0
                0
                5px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 18px;
            font-weight: 800;

            color: #ffffff;
        }


        .events-modal-header p {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.48
                );
        }


        .modal-grid {
            display: grid;

            grid-template-columns:
                1fr
                1fr;

            gap: 14px;
        }


        .modal-full {
            grid-column:
                1 / -1;
        }


        .events-modal .form-group {
            margin-bottom: 0;
        }


        .events-modal .form-group label {
            display: block;

            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.6px;

            color:
                rgba(
                    255,
                    255,
                    255,
                    0.62
                );
        }


        .events-modal input,
        .events-modal select,
        .events-modal textarea {
            width: 100%;

            box-sizing: border-box;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    0.12
                );

            border-radius: 6px;

            outline: none;

            background:
                var(
                    --panel,
                    #1B1745
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
        }


        .events-modal input,
        .events-modal select {
            height: 40px;

            padding:
                0
                12px;
        }


        .events-modal textarea {
            min-height: 85px;

            padding:
                10px
                12px;

            resize: vertical;
        }


        .events-modal select option {
            background: #1B1745;
        }


        .events-modal-actions {
            display: grid;

            grid-template-columns:
                1fr
                1fr;

            gap: 10px;

            margin-top: 20px;
        }


        .events-modal-actions button {
            height: 38px;
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                10px !important;

            padding-top:
                11px !important;

            padding-bottom:
                11px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 850px) {

            .events-toolbar {
                grid-template-columns:
                    1fr;
            }

        }


        @media (max-width: 720px) {

            .events-page-header {
                align-items: stretch;
            }


            .events-count-card {
                width: 100%;
            }


            .modal-grid {
                grid-template-columns:
                    1fr;
            }


            .modal-full {
                grid-column: auto;
            }


            .pagination-bar {
                justify-content: center;
            }


            .pagination-info {
                width: 100%;
                text-align: center;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <!-- GLOBAL TITLE -->

    <h1>MANAGE EVENTS</h1>


    <div class="events-shell">


        <!-- PAGE HEADER -->

        <div class="events-page-header">


            <div class="events-page-header-text">

                <h2>
                    Event Management
                </h2>

                <p>
                    Review and manage events registered across Eventify.
                </p>

            </div>


            <div class="events-count-card">


                <div class="events-count-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <rect
                            x="3"
                            y="5"
                            width="18"
                            height="16"
                            rx="2"
                        ></rect>

                        <path
                            d="M16 3v4"
                        ></path>

                        <path
                            d="M8 3v4"
                        ></path>

                        <path
                            d="M3 10h18"
                        ></path>

                    </svg>

                </div>


                <div class="events-count-content">

                    <span
                        class="events-count-number"
                        id="eventsCount"
                    >
                        0
                    </span>

                    <span class="events-count-label">
                        EVENTS
                    </span>

                </div>


            </div>


        </div>


        <!-- NOTIFICATION -->

        <div id="eventMessage"></div>


        <!-- TOOLBAR -->

        <div class="events-toolbar">


            <div class="search-wrapper">


                <svg
                    class="search-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20l-3.5-3.5"
                    ></path>

                </svg>


                <input
                    type="text"
                    id="eventSearch"
                    placeholder="Search event, organiser, venue or location..."
                >


            </div>


            <div class="events-filter">

                <select id="statusFilter">

                    <option value="All">
                        All Status
                    </option>

                    <option value="Upcoming">
                        Upcoming
                    </option>

                    <option value="Ongoing">
                        Ongoing
                    </option>

                    <option value="Completed">
                        Completed
                    </option>

                    <option value="Cancelled">
                        Cancelled
                    </option>

                </select>

            </div>


            <div class="events-filter">

                <select id="categoryFilter">

                    <option value="All">
                        All Categories
                    </option>

                </select>

            </div>


        </div>


        <!-- TABLE -->

        <div class="events-table-wrapper">


            <table class="events-table">


                <thead>

                    <tr>

                        <th class="col-id">
                            ID
                        </th>

                        <th class="col-event">
                            EVENT
                        </th>

                        <th class="col-organiser">
                            ORGANISER
                        </th>

                        <th class="col-venue">
                            VENUE
                        </th>

                        <th class="col-date">
                            DATE
                        </th>

                        <th class="col-price">
                            PRICE
                        </th>

                        <th class="col-tickets">
                            TICKETS
                        </th>

                        <th class="col-status">
                            STATUS
                        </th>

                        <th class="col-action">
                            ACTION
                        </th>

                    </tr>

                </thead>


                <tbody id="eventsTableBody">

                    <tr>

                        <td colspan="9">

                            <div class="events-empty">
                                Loading events...
                            </div>

                        </td>

                    </tr>

                </tbody>


            </table>


        </div>


        <!-- PAGINATION -->

        <div class="pagination-bar">


            <div
                class="pagination-info"
                id="paginationInfo"
            >
                Showing 0 events
            </div>


            <div class="pagination-controls">


                <button
                    type="button"
                    class="pagination-btn"
                    id="previousPageButton"
                    onclick="previousPage()"
                >
                    PREVIOUS
                </button>


                <div
                    class="pagination-page"
                    id="paginationPage"
                >
                    Page 1 of 1
                </div>


                <button
                    type="button"
                    class="pagination-btn"
                    id="nextPageButton"
                    onclick="nextPage()"
                >
                    NEXT
                </button>


            </div>


        </div>


    </div>


    <!-- MANAGE EVENT MODAL -->

    <div
        class="events-modal-overlay"
        id="manageEventModal"
    >


        <div class="events-modal">


            <div class="events-modal-header">

                <h2>
                    Manage Event
                </h2>

                <p>
                    Update event information, schedule, venue and status.
                </p>

            </div>


            <div class="modal-grid">


                <div class="form-group">

                    <label>
                        EVENT ID
                    </label>

                    <input
                        type="text"
                        id="manageEventId"
                        readonly
                    >

                </div>


                <div class="form-group">

                    <label for="manageEventStatus">
                        STATUS
                    </label>

                    <select id="manageEventStatus">

                        <option value="Upcoming">
                            Upcoming
                        </option>

                        <option value="Ongoing">
                            Ongoing
                        </option>

                        <option value="Completed">
                            Completed
                        </option>

                        <option value="Cancelled">
                            Cancelled
                        </option>

                    </select>

                </div>


                <div class="form-group modal-full">

                    <label for="manageEventName">
                        EVENT NAME
                    </label>

                    <input
                        type="text"
                        id="manageEventName"
                    >

                </div>


                <div class="form-group">

                    <label for="manageEventCategory">
                        CATEGORY
                    </label>

                    <input
                        type="text"
                        id="manageEventCategory"
                    >

                </div>


                <div class="form-group">

                    <label for="manageEventVenue">
                        VENUE
                    </label>

                    <select id="manageEventVenue">
                    </select>

                </div>


                <div class="form-group modal-full">

                    <label for="manageEventDescription">
                        DESCRIPTION
                    </label>

                    <textarea
                        id="manageEventDescription"
                    ></textarea>

                </div>


                <div class="form-group">

                    <label for="manageEventDate">
                        EVENT DATE
                    </label>

                    <input
                        type="date"
                        id="manageEventDate"
                    >

                </div>


                <div class="form-group">

                    <label for="manageEventPrice">
                        TICKET PRICE (RM)
                    </label>

                    <input
                        type="number"
                        id="manageEventPrice"
                        min="0"
                        step="0.01"
                    >

                </div>


                <div class="form-group">

                    <label for="manageEventStartTime">
                        START TIME
                    </label>

                    <input
                        type="time"
                        id="manageEventStartTime"
                    >

                </div>


                <div class="form-group">

                    <label for="manageEventEndTime">
                        END TIME
                    </label>

                    <input
                        type="time"
                        id="manageEventEndTime"
                    >

                </div>


                <div class="form-group modal-full">

                    <label for="manageEventTickets">
                        TOTAL TICKETS
                    </label>

                    <input
                        type="number"
                        id="manageEventTickets"
                        min="1"
                    >

                </div>


            </div>


            <div class="events-modal-actions">


                <button
                    type="button"
                    class="btn"
                    id="updateEventButton"
                    onclick="updateSelectedEvent()"
                >
                    UPDATE EVENT
                </button>


                <button
                    type="button"
                    class="btn btn-secondary"
                    onclick="closeManageEventModal()"
                >
                    CANCEL
                </button>


            </div>


        </div>


    </div>


    <div class="footer">

        EVENTIFY ADMIN PORTAL

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser = null;


        const eventsTableBody =
            document.getElementById(
                'eventsTableBody'
            );


        const eventSearch =
            document.getElementById(
                'eventSearch'
            );


        const statusFilter =
            document.getElementById(
                'statusFilter'
            );


        const categoryFilter =
            document.getElementById(
                'categoryFilter'
            );


        const eventsCount =
            document.getElementById(
                'eventsCount'
            );


        const paginationInfo =
            document.getElementById(
                'paginationInfo'
            );


        const paginationPage =
            document.getElementById(
                'paginationPage'
            );


        const previousPageButton =
            document.getElementById(
                'previousPageButton'
            );


        const nextPageButton =
            document.getElementById(
                'nextPageButton'
            );


        const manageEventModal =
            document.getElementById(
                'manageEventModal'
            );


        const eventMessage =
            document.getElementById(
                'eventMessage'
            );


        let allEvents = [];

        let filteredEvents = [];

        let allVenues = [];

        let selectedEventId = null;


        const eventsPerPage =
            5;


        let currentPage =
            1;


        /*
        ========================================
        AUTH
        ========================================
        */

        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }


            if (
                currentUser &&
                currentUser.role !==
                'Administrator'
            ) {

                alert(
                    'Administrator access only.'
                );


                window.location.href =
                    'login.php';

            }

            else if (currentUser) {

                initializePage();

            }

        }


        /*
        ========================================
        INITIALIZE
        ========================================
        */

        async function initializePage() {

            await loadVenues();

            await loadEvents();

        }


        /*
        ========================================
        SEARCH + FILTER
        ========================================
        */

        eventSearch.addEventListener(
            'input',
            function() {

                currentPage =
                    1;


                filterEvents();

            }
        );


        statusFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterEvents();

            }
        );


        categoryFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterEvents();

            }
        );


        /*
        ========================================
        MODAL
        ========================================
        */

        manageEventModal.addEventListener(
            'click',
            function(event) {

                if (
                    event.target ===
                    manageEventModal
                ) {

                    closeManageEventModal();

                }

            }
        );


        document.addEventListener(
            'keydown',
            function(event) {

                if (
                    event.key ===
                    'Escape'
                ) {

                    closeManageEventModal();

                }

            }
        );


        /*
        ========================================
        LOAD VENUES
        ========================================
        */

        async function loadVenues() {

            try {

                const response =
                    await fetch(
                        '../api/venues.php'
                    );


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    allVenues =
                        result.data ||
                        [];

                }

                else {

                    allVenues =
                        [];

                }

            }

            catch (error) {

                console.error(
                    'Venue API error:',
                    error
                );


                allVenues =
                    [];

            }

        }


        /*
        ========================================
        LOAD EVENTS
        ========================================
        */

        async function loadEvents() {

            eventsTableBody.innerHTML = `

                <tr>

                    <td colspan="9">

                        <div class="events-empty">
                            Loading events...
                        </div>

                    </td>

                </tr>

            `;


            try {

                const response =
                    await fetch(
                        '../api/events.php'
                    );


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    allEvents =
                        result.data ||
                        [];


                    buildCategoryFilter();


                    filterEvents();

                }

                else {

                    showNotification(
                        'error',
                        'Unable to load events',
                        result.message ||
                        'The event list could not be retrieved.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Events API error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Events API.'
                );

            }

        }


        /*
        ========================================
        CATEGORY FILTER
        ========================================
        */

        function buildCategoryFilter() {

            const categories =
                [
                    ...new Set(

                        allEvents
                            .map(
                                function(event) {

                                    return (
                                        event.category ||
                                        ''
                                    ).trim();

                                }
                            )
                            .filter(
                                function(category) {

                                    return (
                                        category !==
                                        ''
                                    );

                                }
                            )

                    )
                ]
                .sort();


            categoryFilter.innerHTML = `

                <option value="All">
                    All Categories
                </option>

            `;


            categories.forEach(
                function(category) {

                    const option =
                        document.createElement(
                            'option'
                        );


                    option.value =
                        category;


                    option.textContent =
                        category;


                    categoryFilter.appendChild(
                        option
                    );

                }
            );

        }


        /*
        ========================================
        FILTER
        ========================================
        */

        function filterEvents() {

            const searchValue =
                eventSearch
                    .value
                    .trim()
                    .toLowerCase();


            const selectedStatus =
                statusFilter.value;


            const selectedCategory =
                categoryFilter.value;


            filteredEvents =
                allEvents.filter(
                    function(event) {


                        const id =
                            String(
                                event.event_id ||
                                ''
                            )
                            .toLowerCase();


                        const name =
                            String(
                                event.event_name ||
                                ''
                            )
                            .toLowerCase();


                        const category =
                            String(
                                event.category ||
                                ''
                            )
                            .toLowerCase();


                        const organiser =
                            String(
                                event.organiser_name ||
                                ''
                            )
                            .toLowerCase();


                        const venue =
                            String(
                                event.venue_name ||
                                ''
                            )
                            .toLowerCase();


                        const location =
                            String(
                                event.location ||
                                ''
                            )
                            .toLowerCase();


                        const matchesSearch =

                            !searchValue

                            ||

                            id.includes(
                                searchValue
                            )

                            ||

                            name.includes(
                                searchValue
                            )

                            ||

                            category.includes(
                                searchValue
                            )

                            ||

                            organiser.includes(
                                searchValue
                            )

                            ||

                            venue.includes(
                                searchValue
                            )

                            ||

                            location.includes(
                                searchValue
                            );


                        const matchesStatus =

                            selectedStatus ===
                            'All'

                            ||

                            event.status ===
                            selectedStatus;


                        const matchesCategory =

                            selectedCategory ===
                            'All'

                            ||

                            event.category ===
                            selectedCategory;


                        return (
                            matchesSearch &&
                            matchesStatus &&
                            matchesCategory
                        );

                    }
                );


            const totalPages =
                getTotalPages();


            if (
                currentPage >
                totalPages
            ) {

                currentPage =
                    totalPages;

            }


            if (
                currentPage <
                1
            ) {

                currentPage =
                    1;

            }


            displayEvents();

        }


        /*
        ========================================
        DISPLAY
        ========================================
        */

        function displayEvents() {

            eventsCount.textContent =
                filteredEvents.length;


            if (
                filteredEvents.length ===
                0
            ) {

                eventsTableBody.innerHTML = `

                    <tr>

                        <td colspan="9">

                            <div class="events-empty">
                                No events found.
                            </div>

                        </td>

                    </tr>

                `;


                updatePagination();

                return;

            }


            const startIndex =
                (
                    currentPage -
                    1
                )
                *
                eventsPerPage;


            const endIndex =
                startIndex +
                eventsPerPage;


            const pageEvents =
                filteredEvents.slice(
                    startIndex,
                    endIndex
                );


            eventsTableBody.innerHTML =
                '';


            pageEvents.forEach(
                function(event) {


                    eventsTableBody.innerHTML += `

                        <tr>


                            <td>

                                <span class="event-id">

                                    #${event.event_id}

                                </span>

                            </td>


                            <td>

                                <div class="event-name">

                                    ${escapeHtml(
                                        event.event_name
                                    )}

                                </div>


                                <div class="event-category">

                                    ${escapeHtml(
                                        event.category
                                    )}

                                </div>

                            </td>


                            <td>

                                ${escapeHtml(
                                    event.organiser_name ||
                                    '-'
                                )}

                            </td>


                            <td>

                                <div>

                                    ${escapeHtml(
                                        event.venue_name ||
                                        '-'
                                    )}

                                </div>


                                <div class="event-subtext">

                                    ${escapeHtml(
                                        event.location ||
                                        ''
                                    )}

                                </div>

                            </td>


                            <td>

                                ${formatDate(
                                    event.event_date
                                )}


                                <div class="event-subtext">

                                    ${formatTime(
                                        event.start_time
                                    )}

                                    -

                                    ${formatTime(
                                        event.end_time
                                    )}

                                </div>

                            </td>


                            <td>

                                RM ${Number(
                                    event.ticket_price ||
                                    0
                                ).toFixed(
                                    2
                                )}

                            </td>


                            <td
                                style="
                                    text-align:center;
                                "
                            >

                                <span class="ticket-count">

                                    ${event.available_tickets}

                                    /

                                    ${event.total_tickets}

                                </span>

                            </td>


                            <td
                                style="
                                    text-align:center;
                                "
                            >

                                <span
                                    class="
                                        status-badge
                                        ${getStatusClass(
                                            event.status
                                        )}
                                    "
                                >

                                    ${escapeHtml(
                                        event.status
                                    )}

                                </span>

                            </td>


                            <td>


                                <div class="event-actions">


                                    <button
                                        type="button"
                                        class="manage-event-btn"
                                        onclick="openManageEventModal(
                                            ${event.event_id}
                                        )"
                                    >
                                        MANAGE
                                    </button>


                                    <button
                                        type="button"
                                        class="delete-event-btn"
                                        onclick="deleteEvent(
                                            ${event.event_id}
                                        )"
                                        title="Delete event"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.9"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >

                                            <polyline
                                                points="3 6 5 6 21 6"
                                            ></polyline>

                                            <path
                                                d="M19 6l-1 14H6L5 6"
                                            ></path>

                                            <path
                                                d="M10 11v5"
                                            ></path>

                                            <path
                                                d="M14 11v5"
                                            ></path>

                                            <path
                                                d="M9 6V4h6v2"
                                            ></path>

                                        </svg>

                                    </button>


                                </div>


                            </td>


                        </tr>

                    `;

                }
            );


            updatePagination();

        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        function getTotalPages() {

            return Math.max(

                1,

                Math.ceil(
                    filteredEvents.length /
                    eventsPerPage
                )

            );

        }


        function updatePagination() {

            const totalPages =
                getTotalPages();


            const start =

                filteredEvents.length ===
                0

                ? 0

                : (
                    (
                        currentPage -
                        1
                    )
                    *
                    eventsPerPage
                )
                +
                1;


            const end =
                Math.min(

                    currentPage *
                    eventsPerPage,

                    filteredEvents.length

                );


            paginationInfo.textContent =

                filteredEvents.length ===
                0

                ? 'Showing 0 events'

                : `Showing ${start}-${end} of ${filteredEvents.length} events`;


            paginationPage.textContent =

                `Page ${currentPage} of ${totalPages}`;


            previousPageButton.disabled =
                currentPage <=
                1;


            nextPageButton.disabled =
                currentPage >=
                totalPages;

        }


        function previousPage() {

            if (
                currentPage <=
                1
            ) {

                return;

            }


            currentPage--;


            displayEvents();

        }


        function nextPage() {

            const totalPages =
                getTotalPages();


            if (
                currentPage >=
                totalPages
            ) {

                return;

            }


            currentPage++;


            displayEvents();

        }


        /*
        ========================================
        STATUS
        ========================================
        */

        function getStatusClass(
            status
        ) {

            if (
                status ===
                'Ongoing'
            ) {

                return 'status-ongoing';

            }


            if (
                status ===
                'Completed'
            ) {

                return 'status-completed';

            }


            if (
                status ===
                'Cancelled'
            ) {

                return 'status-cancelled';

            }


            return 'status-upcoming';

        }


        /*
        ========================================
        MANAGE EVENT
        ========================================
        */

        function openManageEventModal(
            eventId
        ) {

            const event =
                allEvents.find(
                    function(item) {

                        return (
                            Number(
                                item.event_id
                            )
                            ===
                            Number(
                                eventId
                            )
                        );

                    }
                );


            if (!event) {

                return;

            }


            selectedEventId =
                Number(
                    eventId
                );


            document
                .getElementById(
                    'manageEventId'
                )
                .value =
                    event.event_id;


            document
                .getElementById(
                    'manageEventName'
                )
                .value =
                    event.event_name ||
                    '';


            document
                .getElementById(
                    'manageEventCategory'
                )
                .value =
                    event.category ||
                    '';


            document
                .getElementById(
                    'manageEventDescription'
                )
                .value =
                    event.description ||
                    '';


            document
                .getElementById(
                    'manageEventDate'
                )
                .value =
                    event.event_date ||
                    '';


            document
                .getElementById(
                    'manageEventStartTime'
                )
                .value =
                    formatTimeInput(
                        event.start_time
                    );


            document
                .getElementById(
                    'manageEventEndTime'
                )
                .value =
                    formatTimeInput(
                        event.end_time
                    );


            document
                .getElementById(
                    'manageEventPrice'
                )
                .value =
                    event.ticket_price;


            document
                .getElementById(
                    'manageEventTickets'
                )
                .value =
                    event.total_tickets;


            document
                .getElementById(
                    'manageEventStatus'
                )
                .value =
                    event.status;


            buildVenueOptions(
                event.venue_id
            );


            manageEventModal
                .classList
                .add(
                    'active'
                );


            document.body.style.overflow =
                'hidden';

        }


        function closeManageEventModal() {

            manageEventModal
                .classList
                .remove(
                    'active'
                );


            selectedEventId =
                null;


            document.body.style.overflow =
                '';

        }


        /*
        ========================================
        VENUES
        ========================================
        */

        function buildVenueOptions(
            selectedVenueId
        ) {

            const select =
                document.getElementById(
                    'manageEventVenue'
                );


            select.innerHTML =
                '';


            allVenues.forEach(
                function(venue) {


                    const option =
                        document.createElement(
                            'option'
                        );


                    option.value =
                        venue.venue_id;


                    option.textContent =
                        `${venue.venue_name} - ${venue.location}`;


                    if (
                        Number(
                            venue.venue_id
                        )
                        ===
                        Number(
                            selectedVenueId
                        )
                    ) {

                        option.selected =
                            true;

                    }


                    select.appendChild(
                        option
                    );

                }
            );

        }


        /*
        ========================================
        UPDATE EVENT
        ========================================
        */

        async function updateSelectedEvent() {

            if (
                selectedEventId ===
                null
            ) {

                return;

            }


            const eventName =
                document
                    .getElementById(
                        'manageEventName'
                    )
                    .value
                    .trim();


            const category =
                document
                    .getElementById(
                        'manageEventCategory'
                    )
                    .value
                    .trim();


            const description =
                document
                    .getElementById(
                        'manageEventDescription'
                    )
                    .value
                    .trim();


            const venueId =
                Number(
                    document
                        .getElementById(
                            'manageEventVenue'
                        )
                        .value
                );


            const eventDate =
                document
                    .getElementById(
                        'manageEventDate'
                    )
                    .value;


            const startTime =
                document
                    .getElementById(
                        'manageEventStartTime'
                    )
                    .value;


            const endTime =
                document
                    .getElementById(
                        'manageEventEndTime'
                    )
                    .value;


            const ticketPrice =
                Number(
                    document
                        .getElementById(
                            'manageEventPrice'
                        )
                        .value
                );


            const totalTickets =
                Number(
                    document
                        .getElementById(
                            'manageEventTickets'
                        )
                        .value
                );


            const status =
                document
                    .getElementById(
                        'manageEventStatus'
                    )
                    .value;


            if (
                !eventName ||
                !category ||
                !venueId ||
                !eventDate ||
                !startTime ||
                !endTime
            ) {

                showNotification(
                    'error',
                    'Missing information',
                    'Please complete all required event fields.'
                );

                return;

            }


            if (
                ticketPrice <
                0
            ) {

                showNotification(
                    'error',
                    'Invalid ticket price',
                    'Ticket price cannot be negative.'
                );

                return;

            }


            if (
                totalTickets <
                1
            ) {

                showNotification(
                    'error',
                    'Invalid ticket quantity',
                    'Total tickets must be at least 1.'
                );

                return;

            }


            if (
                startTime >=
                endTime
            ) {

                showNotification(
                    'error',
                    'Invalid event time',
                    'End time must be later than start time.'
                );

                return;

            }


            const button =
                document.getElementById(
                    'updateEventButton'
                );


            button.disabled =
                true;


            button.textContent =
                'UPDATING...';


            try {

                const response =
                    await fetch(
                        '../api/events.php',
                        {

                            method:
                                'PUT',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    event_id:
                                        Number(
                                            selectedEventId
                                        ),

                                    event_name:
                                        eventName,

                                    category:
                                        category,

                                    description:
                                        description,

                                    venue_id:
                                        venueId,

                                    event_date:
                                        eventDate,

                                    start_time:
                                        startTime,

                                    end_time:
                                        endTime,

                                    ticket_price:
                                        ticketPrice,

                                    total_tickets:
                                        totalTickets,

                                    status:
                                        status

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    closeManageEventModal();


                    showNotification(
                        'success',
                        'Event updated',
                        `${eventName} has been updated successfully.`
                    );


                    await loadEvents();

                }

                else {

                    showNotification(
                        'error',
                        'Update failed',
                        result.message ||
                        'Unable to update this event.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Update event error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Events API.'
                );

            }

            finally {

                button.disabled =
                    false;


                button.textContent =
                    'UPDATE EVENT';

            }

        }


        /*
        ========================================
        DELETE EVENT
        ========================================
        */

        async function deleteEvent(
            eventId
        ) {

            const event =
                allEvents.find(
                    function(item) {

                        return (
                            Number(
                                item.event_id
                            )
                            ===
                            Number(
                                eventId
                            )
                        );

                    }
                );


            if (!event) {

                return;

            }


            const confirmed =
                confirm(

                    `Delete "${event.event_name}"?\n\n` +

                    `Organiser: ${event.organiser_name || '-'}\n` +

                    `Venue: ${event.venue_name || '-'}\n` +

                    `Date: ${formatDate(
                        event.event_date
                    )}\n\n` +

                    `Events with existing bookings may not be deleted.`

                );


            if (!confirmed) {

                return;

            }


            try {

                const response =
                    await fetch(
                        '../api/events.php',
                        {

                            method:
                                'DELETE',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    event_id:
                                        Number(
                                            eventId
                                        )

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    showNotification(
                        'success',
                        'Event deleted',
                        `${event.event_name} has been removed successfully.`
                    );


                    await loadEvents();

                }

                else {

                    showNotification(
                        'error',
                        'Delete failed',
                        result.message ||
                        'Unable to delete this event.'
                    );

                }

            }

            catch (error) {

                console.error(
                    'Delete event error:',
                    error
                );


                showNotification(
                    'error',
                    'Connection error',
                    'Unable to connect to the Events API.'
                );

            }

        }


        /*
        ========================================
        NOTIFICATION
        ========================================
        */

        function showNotification(
            type,
            title,
            text
        ) {

            const isSuccess =
                type ===
                'success';


            eventMessage.innerHTML = `

                <div
                    class="
                        events-notification
                        ${
                            isSuccess

                            ? 'events-notification-success'

                            : 'events-notification-error'
                        }
                    "
                >

                    <div class="notification-icon">

                        ${
                            isSuccess
                            ? '✓'
                            : '!'
                        }

                    </div>


                    <div class="notification-content">

                        <div class="notification-title">

                            ${escapeHtml(
                                title
                            )}

                        </div>


                        <div class="notification-text">

                            ${escapeHtml(
                                text
                            )}

                        </div>

                    </div>

                </div>

            `;


            window.setTimeout(
                function() {

                    eventMessage.innerHTML =
                        '';

                },
                4000
            );

        }


        /*
        ========================================
        HELPERS
        ========================================
        */

        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const parts =
                String(
                    value
                )
                .substring(
                    0,
                    10
                )
                .split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return value;

            }


            return (
                parts[2]
                +
                '/'
                +
                parts[1]
                +
                '/'
                +
                parts[0]
            );

        }


        function formatTime(
            value
        ) {

            if (!value) {

                return '-';

            }


            return String(
                value
            ).substring(
                0,
                5
            );

        }


        function formatTimeInput(
            value
        ) {

            if (!value) {

                return '';

            }


            return String(
                value
            ).substring(
                0,
                5
            );

        }


        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }


        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );


            localStorage.removeItem(
                'eventify_user'
            );


            window.location.href =
                'login.php';

        }

    </script>


</body>

</html>