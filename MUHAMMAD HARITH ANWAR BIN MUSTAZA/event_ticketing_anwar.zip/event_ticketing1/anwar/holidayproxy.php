<?php

header("Content-Type: application/json; charset=UTF-8");


/*
    EVENTIFY
    MALAYSIA HOLIDAY API PROXY
*/


if (!isset($_GET["date"])) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "Date is required"
    ]);

    exit;

}


$date =
    trim(
        $_GET["date"]
    );


/*
    VALIDATE YYYY-MM-DD
*/

if (
    !preg_match(
        '/^\d{4}-\d{2}-\d{2}$/',
        $date
    )
) {

    http_response_code(400);

    echo json_encode([
        "status" => "error",
        "message" => "Invalid date format"
    ]);

    exit;

}


/*
    EXTERNAL API
*/

$url =
    "https://malaysia-holiday.dydxsoft.my"
    . "/api/v1/holidays/check?date="
    . urlencode($date);


/*
    CURL
*/

if (!function_exists("curl_init")) {

    http_response_code(500);

    echo json_encode([
        "status" => "error",
        "message" => "PHP cURL extension is not enabled"
    ]);

    exit;

}


$curl =
    curl_init();


curl_setopt_array(
    $curl,
    [

        CURLOPT_URL =>
            $url,

        CURLOPT_RETURNTRANSFER =>
            true,

        CURLOPT_FOLLOWLOCATION =>
            true,

        CURLOPT_CONNECTTIMEOUT =>
            10,

        CURLOPT_TIMEOUT =>
            15,

        CURLOPT_HTTPHEADER =>
            [

                "Accept: application/json",

                "User-Agent: Eventify/1.0"

            ],

        CURLOPT_SSL_VERIFYPEER =>
            false,

        CURLOPT_SSL_VERIFYHOST =>
            false

    ]
);


$response =
    curl_exec(
        $curl
    );


$httpCode =
    curl_getinfo(
        $curl,
        CURLINFO_HTTP_CODE
    );


$curlError =
    curl_error(
        $curl
    );


curl_close(
    $curl
);


/*
    CONNECTION ERROR
*/

if (
    $response === false
) {

    http_response_code(502);

    echo json_encode([

        "status" =>
            "error",

        "message" =>
            "Unable to connect to Malaysia Holiday API",

        "details" =>
            $curlError

    ]);

    exit;

}


/*
    EXTERNAL API HTTP ERROR
*/

if (
    $httpCode < 200 ||
    $httpCode >= 300
) {

    http_response_code(502);

    echo json_encode([

        "status" =>
            "error",

        "message" =>
            "Malaysia Holiday API returned HTTP "
            . $httpCode

    ]);

    exit;

}


/*
    JSON
*/

$data =
    json_decode(
        $response,
        true
    );


if (!is_array($data)) {

    http_response_code(502);

    echo json_encode([

        "status" =>
            "error",

        "message" =>
            "Invalid JSON response from Malaysia Holiday API"

    ]);

    exit;

}


/*
    SUCCESS
*/

http_response_code(200);


echo json_encode(
    [

        "status" =>
            "success",

        "source" =>
            "Malaysia Holiday API",

        "date" =>
            $date,

        "data" =>
            $data

    ],
    JSON_UNESCAPED_UNICODE |
    JSON_PRETTY_PRINT
);

?>