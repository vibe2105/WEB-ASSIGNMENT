<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Event Details - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;

            display: flex;
            flex-direction: column;
        }


        .details-shell {
            width: min(1180px, 92%);

            margin:
                0
                auto;

            flex: 1;
        }


        /*
        ========================================
        BACK
        ========================================
        */

        .back-row {
            margin-bottom: 12px;
        }


        .back-link {
            display: inline-flex;
            align-items: center;

            gap: 7px;

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;

            color:
                rgba(255, 255, 255, 0.48);
        }


        .back-link:hover {
            color: #ffffff;
        }


        .back-link svg {
            width: 14px;
            height: 14px;
        }


        /*
        ========================================
        STATE MESSAGE
        ========================================
        */

        .page-state {
            width: 100%;

            min-height: 170px;

            display: flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            padding: 25px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 10px;

            background:
                rgba(255, 255, 255, 0.02);

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.6;

            color:
                rgba(255, 255, 255, 0.50);
        }


        .page-state.error {
            border-color:
                rgba(239, 130, 149, 0.35);

            background:
                rgba(239, 130, 149, 0.07);

            color: #EF8295;
        }


        /*
        ========================================
        MAIN GRID
        ========================================
        */

        .event-details {
            display: none;

            grid-template-columns:
                minmax(0, 1.25fr)
                minmax(330px, 0.75fr);

            gap: 18px;

            align-items: start;
        }


        .event-details.active {
            display: grid;
        }


        /*
        ========================================
        LEFT
        ========================================
        */

        .event-main {
            min-width: 0;
        }


        /*
        IMAGE
        */

        .event-image-card {
            position: relative;

            width: 100%;
            height: 315px;

            overflow: hidden;

            margin-bottom: 14px;

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 11px;

            background:
                linear-gradient(
                    135deg,
                    #1B1745,
                    #5B2A86,
                    #B0449E
                );
        }


        .event-image {
            width: 100%;
            height: 100%;

            display: block;

            object-fit: cover;
        }


        .event-image-fallback {
            position: absolute;
            inset: 0;

            display: none;
            align-items: center;
            justify-content: center;

            flex-direction: column;

            gap: 10px;

            background:
                radial-gradient(
                    circle at 80% 20%,
                    rgba(224, 107, 174, 0.24),
                    transparent 34%
                ),
                linear-gradient(
                    135deg,
                    #1B1745,
                    #5B2A86
                );
        }


        .event-image-fallback svg {
            width: 42px;
            height: 42px;

            color:
                rgba(255, 255, 255, 0.46);
        }


        .event-image-fallback span {
            font-family:
                "Press Start 2P",
                monospace;

            font-size: 8px;

            color:
                rgba(255, 255, 255, 0.43);
        }


        /*
        IMAGE BADGES
        */

        .status-badge {
            position: absolute;

            top: 12px;
            left: 12px;

            z-index: 3;

            min-width: 78px;

            padding:
                6px
                9px;

            box-sizing: border-box;

            text-align: center;

            border-radius: 5px;

            backdrop-filter: blur(10px);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.35px;
        }


        .status-upcoming {
            border:
                1px solid
                rgba(143, 216, 198, 0.28);

            background:
                rgba(21, 40, 45, 0.74);

            color: #8FD8C6;
        }


        .status-ongoing {
            border:
                1px solid
                rgba(246, 197, 142, 0.28);

            background:
                rgba(55, 45, 25, 0.74);

            color: #F6C58E;
        }


        .status-completed {
            border:
                1px solid
                rgba(169, 185, 236, 0.28);

            background:
                rgba(30, 34, 55, 0.76);

            color: #A9B9EC;
        }


        .status-cancelled {
            border:
                1px solid
                rgba(239, 130, 149, 0.30);

            background:
                rgba(60, 25, 35, 0.76);

            color: #EF8295;
        }


        .category-badge {
            position: absolute;

            top: 12px;
            right: 12px;

            z-index: 3;

            max-width: 180px;

            padding:
                6px
                9px;

            border:
                1px solid
                rgba(255, 255, 255, 0.14);

            border-radius: 5px;

            background:
                rgba(11, 11, 46, 0.76);

            backdrop-filter: blur(10px);

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;

            color: #ffffff;
        }


        /*
        TITLE AREA
        */

        .event-content-card {
            box-sizing: border-box;

            padding:
                17px
                18px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 10px;

            background:
                rgba(255, 255, 255, 0.02);
        }


        .event-name {
            margin:
                0
                0
                7px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 23px;
            font-weight: 850;
            line-height: 1.3;

            color: #ffffff;
        }


        .event-organiser {
            margin-bottom: 14px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.43);
        }


        .event-organiser strong {
            color:
                rgba(255, 255, 255, 0.67);
        }


        /*
        DESCRIPTION
        */

        .section-title {
            margin-bottom: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 850;

            letter-spacing: 0.45px;

            color: #F6C58E;
        }


        .event-description {
            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.7;

            color:
                rgba(255, 255, 255, 0.57);

            white-space: pre-line;
        }


        /*
        ========================================
        RIGHT BOOKING PANEL
        ========================================
        */

        .event-sidebar {
            position: sticky;
            top: 20px;

            box-sizing: border-box;

            padding:
                18px;

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 11px;

            background:
                linear-gradient(
                    180deg,
                    rgba(36, 28, 86, 0.82),
                    rgba(21, 17, 58, 0.90)
                );
        }


        .sidebar-eyebrow {
            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.7px;

            color: #E06BAE;
        }


        .sidebar-title {
            margin-bottom: 15px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 17px;
            font-weight: 850;

            color: #ffffff;
        }


        /*
        INFO ROW
        */

        .event-info-list {
            display: grid;

            gap: 9px;

            margin-bottom: 15px;
        }


        .event-info-item {
            display: grid;

            grid-template-columns:
                31px
                minmax(0, 1fr);

            gap: 9px;

            align-items: center;

            padding:
                9px
                10px;

            border:
                1px solid
                rgba(255, 255, 255, 0.065);

            border-radius: 7px;

            background:
                rgba(255, 255, 255, 0.022);
        }


        .info-icon {
            width: 30px;
            height: 30px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 6px;

            background:
                rgba(224, 107, 174, 0.07);

            color: #E06BAE;
        }


        .info-icon svg {
            width: 14px;
            height: 14px;
        }


        .info-label {
            display: block;

            margin-bottom: 2px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 800;

            letter-spacing: 0.4px;

            color:
                rgba(255, 255, 255, 0.34);
        }


        .info-value {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 700;
            line-height: 1.4;

            color: #ffffff;
        }


        /*
        PRICE
        */

        .price-box {
            display: flex;
            align-items: end;
            justify-content: space-between;

            gap: 12px;

            margin-bottom: 12px;

            padding:
                12px;

            border:
                1px solid
                rgba(246, 197, 142, 0.14);

            border-radius: 8px;

            background:
                rgba(246, 197, 142, 0.04);
        }


        .price-label {
            display: block;

            margin-bottom: 3px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 800;

            color:
                rgba(255, 255, 255, 0.36);
        }


        .price-value {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 20px;
            font-weight: 850;

            color: #F6C58E;
        }


        .tickets-box {
            text-align: right;
        }


        .tickets-number {
            display: block;

            margin-bottom: 2px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 12px;
            font-weight: 850;

            color: #ffffff;
        }


        .tickets-label {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;

            color:
                rgba(255, 255, 255, 0.33);
        }


        /*
        ACTION
        */

        .booking-action {
            width: 100%;
            min-height: 42px;

            display: flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            padding:
                0
                14px;

            border:
                1px solid
                rgba(224, 107, 174, 0.26);

            border-radius: 7px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            letter-spacing: 0.45px;

            color: #ffffff;

            cursor: pointer;
        }


        .booking-action:hover {
            opacity: 0.92;
        }


        .booking-action.disabled {
            border-color:
                rgba(255, 255, 255, 0.08);

            background:
                rgba(255, 255, 255, 0.035);

            color:
                rgba(255, 255, 255, 0.35);

            cursor: not-allowed;

            pointer-events: none;
        }


        .sidebar-note {
            margin-top: 9px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.30);
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                12px !important;

            padding-top:
                11px !important;

            padding-bottom:
                11px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 900px) {

            .event-details {
                grid-template-columns: 1fr;
            }


            .event-sidebar {
                position: static;
            }

        }


        @media (max-width: 650px) {

            .event-image-card {
                height: 220px;
            }


            .event-name {
                font-size: 19px;
            }


            .price-value {
                font-size: 17px;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <h1>EVENT DETAILS</h1>


    <div class="details-shell">


        <!-- BACK -->

        <div class="back-row">

            <a
                href="events.php"
                class="back-link"
            >

                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <path d="M19 12H5"></path>

                    <path d="M12 19l-7-7 7-7"></path>

                </svg>

                BACK TO EVENTS

            </a>

        </div>


        <!-- STATE -->

        <div
            class="page-state"
            id="pageState"
        >
            Loading event details...
        </div>


        <!-- DETAILS -->

        <div
            class="event-details"
            id="eventDetails"
        >


            <!-- LEFT -->

            <div class="event-main">


                <!-- IMAGE -->

                <div class="event-image-card">


                    <img
                        src=""
                        alt="Event image"
                        class="event-image"
                        id="eventImage"
                    >


                    <div
                        class="event-image-fallback"
                        id="eventImageFallback"
                    >

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <rect
                                x="3"
                                y="5"
                                width="18"
                                height="16"
                                rx="2"
                            ></rect>

                            <path d="M8 3v4"></path>

                            <path d="M16 3v4"></path>

                            <path d="M3 10h18"></path>

                        </svg>

                        <span>
                            EVENTIFY EVENT
                        </span>

                    </div>


                    <div
                        class="status-badge"
                        id="eventStatusBadge"
                    >
                        UPCOMING
                    </div>


                    <div
                        class="category-badge"
                        id="eventCategoryBadge"
                    >
                        EVENT
                    </div>


                </div>


                <!-- CONTENT -->

                <div class="event-content-card">


                    <h2
                        class="event-name"
                        id="eventName"
                    >
                        Event Name
                    </h2>


                    <div class="event-organiser">

                        Organised by

                        <strong id="eventOrganiser">
                            -
                        </strong>

                    </div>


                    <div class="section-title">
                        ABOUT THIS EVENT
                    </div>


                    <p
                        class="event-description"
                        id="eventDescription"
                    >
                        -
                    </p>


                </div>


            </div>


            <!-- RIGHT -->

            <aside class="event-sidebar">


                <div class="sidebar-eyebrow">
                    EVENT INFORMATION
                </div>


                <div class="sidebar-title">
                    Plan your visit.
                </div>


                <div class="event-info-list">


                    <!-- DATE -->

                    <div class="event-info-item">


                        <div class="info-icon">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <rect
                                    x="3"
                                    y="5"
                                    width="18"
                                    height="16"
                                    rx="2"
                                ></rect>

                                <path d="M8 3v4"></path>

                                <path d="M16 3v4"></path>

                                <path d="M3 10h18"></path>

                            </svg>

                        </div>


                        <div>

                            <span class="info-label">
                                DATE
                            </span>

                            <span
                                class="info-value"
                                id="eventDate"
                            >
                                -
                            </span>

                        </div>


                    </div>


                    <!-- TIME -->

                    <div class="event-info-item">


                        <div class="info-icon">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <circle
                                    cx="12"
                                    cy="12"
                                    r="9"
                                ></circle>

                                <path
                                    d="M12 7v5l3 2"
                                ></path>

                            </svg>

                        </div>


                        <div>

                            <span class="info-label">
                                TIME
                            </span>

                            <span
                                class="info-value"
                                id="eventTime"
                            >
                                -
                            </span>

                        </div>


                    </div>


                    <!-- VENUE -->

                    <div class="event-info-item">


                        <div class="info-icon">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <path
                                    d="M12 21s7-5.5 7-12a7 7 0 1 0-14 0c0 6.5 7 12 7 12z"
                                ></path>

                                <circle
                                    cx="12"
                                    cy="9"
                                    r="2.2"
                                ></circle>

                            </svg>

                        </div>


                        <div>

                            <span class="info-label">
                                VENUE
                            </span>

                            <span
                                class="info-value"
                                id="eventVenue"
                            >
                                -
                            </span>

                        </div>


                    </div>


                    <!-- LOCATION -->

                    <div class="event-info-item">


                        <div class="info-icon">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <path
                                    d="M4 20h16"
                                ></path>

                                <path
                                    d="M6 20V8l6-4 6 4v12"
                                ></path>

                            </svg>

                        </div>


                        <div>

                            <span class="info-label">
                                LOCATION
                            </span>

                            <span
                                class="info-value"
                                id="eventLocation"
                            >
                                -
                            </span>

                        </div>


                    </div>


                </div>


                <!-- PRICE -->

                <div class="price-box">


                    <div>

                        <span class="price-label">
                            TICKET PRICE
                        </span>

                        <span
                            class="price-value"
                            id="eventPrice"
                        >
                            RM 0.00
                        </span>

                    </div>


                    <div class="tickets-box">

                        <span
                            class="tickets-number"
                            id="eventTickets"
                        >
                            0 / 0
                        </span>

                        <span
                            class="tickets-label"
                            id="ticketLabel"
                        >
                            TICKETS LEFT
                        </span>

                    </div>


                </div>


                <!-- ACTION -->

                <a
                    href="#"
                    class="booking-action"
                    id="bookingAction"
                >
                    BOOK TICKET
                </a>


                <div
                    class="sidebar-note"
                    id="bookingNote"
                >
                    Login is required before booking.
                </div>


            </aside>


        </div>


    </div>


    <div class="footer">

        EVENTIFY

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        URL PARAMETER
        ========================================
        */

        const urlParams =
            new URLSearchParams(
                window.location.search
            );


        /*
        THIS IS THE IMPORTANT FIX

        Browse Events sends:
        eventdetails.php?event_id=6
        */

        const eventId =
            urlParams.get(
                'event_id'
            );


        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const pageState =
            document.getElementById(
                'pageState'
            );


        const eventDetails =
            document.getElementById(
                'eventDetails'
            );


        const eventImage =
            document.getElementById(
                'eventImage'
            );


        const eventImageFallback =
            document.getElementById(
                'eventImageFallback'
            );


        const bookingAction =
            document.getElementById(
                'bookingAction'
            );


        const bookingNote =
            document.getElementById(
                'bookingNote'
            );


        /*
        ========================================
        USER
        ========================================
        */

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser =
            null;


        if (storedUser) {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                currentUser =
                    null;

            }

        }


        /*
        ========================================
        VALIDATE EVENT ID
        ========================================
        */

        if (
            !eventId ||
            isNaN(
                Number(
                    eventId
                )
            )
        ) {

            showError(
                'Event ID not found. Please return to Browse Events and select an event.'
            );

        }

        else {

            loadEvent();

        }


        /*
        ========================================
        LOAD EVENT
        ========================================
        */

        async function loadEvent() {

            try {

                /*
                IMPORTANT:

                API receives:
                ../api/events.php?event_id=6
                */

                const response =
                    await fetch(

                        `../api/events.php?event_id=${encodeURIComponent(
                            eventId
                        )}`

                    );


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    'success'
                ) {

                    throw new Error(
                        result.message ||
                        'Event could not be found.'
                    );

                }


                /*
                Some APIs return:
                data: {...}

                Others may return:
                data: [{...}]

                Handle both safely.
                */

                let event =
                    result.data;


                if (
                    Array.isArray(
                        event
                    )
                ) {

                    event =
                        event.find(
                            function(item) {

                                return (
                                    Number(
                                        item.event_id
                                    )
                                    ===
                                    Number(
                                        eventId
                                    )
                                );

                            }
                        );

                }


                if (
                    !event ||
                    !event.event_id
                ) {

                    throw new Error(
                        'Event could not be found.'
                    );

                }


                displayEvent(
                    event
                );

            }

            catch (error) {

                console.error(
                    'Event details error:',
                    error
                );


                showError(
                    error.message ||
                    'Unable to load event details.'
                );

            }

        }


        /*
        ========================================
        DISPLAY EVENT
        ========================================
        */

        function displayEvent(
            event
        ) {

            pageState.style.display =
                'none';


            eventDetails.classList.add(
                'active'
            );


            /*
            IMAGE

            event_id 6 =
            assets/events/event-6.jpg
            */

            eventImage.src =
                `assets/events/event-${event.event_id}.jpg`;


            eventImage.alt =
                event.event_name ||
                'Event image';


            eventImage.onerror =
                function() {

                    eventImage.style.display =
                        'none';


                    eventImageFallback.style.display =
                        'flex';

                };


            /*
            BADGES
            */

            const status =
                event.status ||
                'Upcoming';


            const availableTickets =
                Number(
                    event.available_tickets ||
                    0
                );


            const totalTickets =
                Number(
                    event.total_tickets ||
                    0
                );


            const soldOut =
                availableTickets <=
                0;


            const statusBadge =
                document.getElementById(
                    'eventStatusBadge'
                );


            statusBadge.className =
                `status-badge ${getStatusClass(
                    status
                )}`;


            statusBadge.textContent =
                soldOut &&
                status ===
                'Upcoming'

                ? 'SOLD OUT'

                : status.toUpperCase();


            document
                .getElementById(
                    'eventCategoryBadge'
                )
                .textContent =
                    event.category ||
                    'EVENT';


            /*
            MAIN INFO
            */

            document
                .getElementById(
                    'eventName'
                )
                .textContent =
                    event.event_name ||
                    'Untitled Event';


            document
                .getElementById(
                    'eventOrganiser'
                )
                .textContent =
                    event.organiser_name ||
                    'Eventify Organiser';


            document
                .getElementById(
                    'eventDescription'
                )
                .textContent =
                    event.description ||
                    'No event description has been provided.';


            /*
            SIDEBAR
            */

            document
                .getElementById(
                    'eventDate'
                )
                .textContent =
                    formatDate(
                        event.event_date
                    );


            document
                .getElementById(
                    'eventTime'
                )
                .textContent =
                    `${formatTime(
                        event.start_time
                    )} - ${formatTime(
                        event.end_time
                    )}`;


            document
                .getElementById(
                    'eventVenue'
                )
                .textContent =
                    event.venue_name ||
                    'Venue TBA';


            document
                .getElementById(
                    'eventLocation'
                )
                .textContent =
                    event.location ||
                    'Location unavailable';


            document
                .getElementById(
                    'eventPrice'
                )
                .textContent =
                    `RM ${Number(
                        event.ticket_price ||
                        0
                    ).toFixed(
                        2
                    )}`;


            document
                .getElementById(
                    'eventTickets'
                )
                .textContent =
                    `${availableTickets} / ${totalTickets}`;


            document
                .getElementById(
                    'ticketLabel'
                )
                .textContent =
                    soldOut
                    ? 'SOLD OUT'
                    : 'TICKETS LEFT';


            /*
            BOOKING BUTTON
            */

            configureBookingAction(
                event,
                soldOut
            );

        }


        /*
        ========================================
        BOOKING BUTTON ROLE LOGIC
        ========================================
        */

        function configureBookingAction(
            event,
            soldOut
        ) {

            const status =
                event.status ||
                'Upcoming';


            /*
            CANCELLED
            */

            if (
                status ===
                'Cancelled'
            ) {

                disableBookingButton(
                    'EVENT CANCELLED',
                    'This event is no longer available for booking.'
                );


                return;

            }


            /*
            COMPLETED
            */

            if (
                status ===
                'Completed'
            ) {

                disableBookingButton(
                    'EVENT COMPLETED',
                    'Booking is closed because this event has ended.'
                );


                return;

            }


            /*
            SOLD OUT
            */

            if (soldOut) {

                disableBookingButton(
                    'SOLD OUT',
                    'There are no tickets available for this event.'
                );


                return;

            }


            /*
            NOT LOGGED IN
            */

            if (
                !token ||
                !currentUser
            ) {

                bookingAction.textContent =
                    'LOGIN TO BOOK';


                bookingAction.classList.remove(
                    'disabled'
                );


                bookingAction.href =
                    'login.php';


                bookingNote.textContent =
                    'Login or create a customer account before booking.';


                return;

            }


            /*
            CUSTOMER
            */

            if (
                currentUser.role ===
                'Customer'
            ) {

                bookingAction.textContent =
                    'BOOK TICKET';


                bookingAction.classList.remove(
                    'disabled'
                );


                bookingAction.href =
                    `booking.php?event_id=${encodeURIComponent(
                        event.event_id
                    )}`;


                bookingNote.textContent =
                    'You will confirm ticket quantity on the next page.';


                return;

            }


            /*
            ORGANISER
            */

            if (
                currentUser.role ===
                'Organiser'
            ) {

                disableBookingButton(
                    'ORGANISER VIEW ONLY',
                    'Organiser accounts cannot make customer bookings.'
                );


                return;

            }


            /*
            ADMIN
            */

            if (
                currentUser.role ===
                'Administrator'
            ) {

                disableBookingButton(
                    'ADMIN VIEW ONLY',
                    'Administrator accounts cannot make customer bookings.'
                );


                return;

            }


            disableBookingButton(
                'BOOKING UNAVAILABLE',
                'This account cannot create bookings.'
            );

        }


        /*
        ========================================
        DISABLE BUTTON
        ========================================
        */

        function disableBookingButton(
            buttonText,
            noteText
        ) {

            bookingAction.textContent =
                buttonText;


            bookingAction.href =
                '#';


            bookingAction.classList.add(
                'disabled'
            );


            bookingNote.textContent =
                noteText;

        }


        /*
        ========================================
        ERROR
        ========================================
        */

        function showError(
            text
        ) {

            eventDetails.classList.remove(
                'active'
            );


            pageState.style.display =
                'flex';


            pageState.classList.add(
                'error'
            );


            pageState.innerHTML = `

                <div>

                    <strong>
                        ERROR
                    </strong>

                    <br><br>

                    ${escapeHtml(
                        text
                    )}

                    <br><br>

                    <a
                        href="events.php"
                        style="
                            color:#F6C58E;
                            font-weight:800;
                            text-decoration:none;
                        "
                    >
                        RETURN TO EVENTS
                    </a>

                </div>

            `;

        }


        /*
        ========================================
        STATUS CLASS
        ========================================
        */

        function getStatusClass(
            status
        ) {

            if (
                status ===
                'Ongoing'
            ) {

                return 'status-ongoing';

            }


            if (
                status ===
                'Completed'
            ) {

                return 'status-completed';

            }


            if (
                status ===
                'Cancelled'
            ) {

                return 'status-cancelled';

            }


            return 'status-upcoming';

        }


        /*
        ========================================
        DATE
        ========================================
        */

        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const parts =
                String(
                    value
                )
                .substring(
                    0,
                    10
                )
                .split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return value;

            }


            const months =
                [
                    'JAN',
                    'FEB',
                    'MAR',
                    'APR',
                    'MAY',
                    'JUN',
                    'JUL',
                    'AUG',
                    'SEP',
                    'OCT',
                    'NOV',
                    'DEC'
                ];


            const monthIndex =
                Number(
                    parts[1]
                )
                -
                1;


            return (
                parts[2]
                +
                ' '
                +
                months[
                    monthIndex
                ]
                +
                ' '
                +
                parts[0]
            );

        }


        /*
        ========================================
        TIME
        ========================================
        */

        function formatTime(
            value
        ) {

            if (!value) {

                return '-';

            }


            return String(
                value
            ).substring(
                0,
                5
            );

        }


        /*
        ========================================
        ESCAPE HTML
        ========================================
        */

        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    </script>


</body>

</html>