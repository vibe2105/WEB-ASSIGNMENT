<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Admin Dashboard - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >

    <style>

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .dashboard-shell {
            width: min(1180px, 92%);
            margin: 0 auto;
            flex: 1;
        }

        .dashboard-hero {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;

            margin-bottom: 20px;
            padding: 18px 22px;

            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 10px;

            background:
                linear-gradient(
                    135deg,
                    rgba(91,42,134,0.22),
                    rgba(27,23,69,0.75)
                );
        }

        .dashboard-hero-text {
            flex: 1;
            min-width: 250px;
        }

        .dashboard-hero-text h2 {
            margin: 0 0 6px 0;

            font-family: Inter, Arial, sans-serif;
            font-size: 21px;
            font-weight: 800;
            line-height: 1.25;

            color: #ffffff;
        }

        .dashboard-hero-text p {
            margin: 0;

            max-width: 650px;

            font-family: Inter, Arial, sans-serif;
            font-size: 13px;
            line-height: 1.5;

            color: rgba(255,255,255,0.65);
        }

        .dashboard-role-badge {
            padding: 9px 13px;

            border: 1px solid rgba(224,107,174,0.35);
            border-radius: 6px;

            background: rgba(224,107,174,0.08);

            font-family: Inter, Arial, sans-serif;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 1px;

            color: var(--pink, #E06BAE);

            white-space: nowrap;
        }

        .dashboard-section {
            margin-bottom: 22px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: end;
            gap: 12px;
            flex-wrap: wrap;

            margin-bottom: 11px;
        }

        .section-heading {
            margin: 0;

            font-family: Inter, Arial, sans-serif;
            font-size: 16px;
            font-weight: 800;

            color: #ffffff;
        }

        .section-description {
            margin-top: 3px;

            font-family: Inter, Arial, sans-serif;
            font-size: 11px;
            line-height: 1.4;

            color: rgba(255,255,255,0.50);
        }

        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
        }

        .stat-card {
            position: relative;

            display: flex;
            flex-direction: column;

            min-height: 150px;

            box-sizing: border-box;

            padding: 16px;

            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 10px;

            background:
                linear-gradient(
                    180deg,
                    rgba(255,255,255,0.045),
                    rgba(255,255,255,0.015)
                );

            overflow: hidden;

            transition:
                transform 0.18s ease,
                border-color 0.18s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            border-color: rgba(224,107,174,0.32);
        }

        .stat-card::after {
            content: "";

            position: absolute;
            top: -45px;
            right: -45px;

            width: 105px;
            height: 105px;

            border-radius: 50%;

            background: rgba(176,68,158,0.07);

            pointer-events: none;
        }

        .stat-label {
            position: relative;
            z-index: 2;

            margin-bottom: 7px;

            font-family: Inter, Arial, sans-serif;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 0.8px;

            color: rgba(255,255,255,0.58);
        }

        .stat-value {
            position: relative;
            z-index: 2;

            margin-bottom: 5px;

            font-family: "Press Start 2P", monospace;
            font-size: 21px;
            line-height: 1.35;

            color: var(--sun, #F6C58E);
        }

        .stat-description {
            position: relative;
            z-index: 2;

            margin-bottom: 12px;

            font-family: Inter, Arial, sans-serif;
            font-size: 10px;
            line-height: 1.35;

            color: rgba(255,255,255,0.46);
        }

        .dashboard-action-btn {
            position: relative;
            z-index: 2;

            display: inline-flex;
            align-items: center;
            justify-content: center;

            width: 100%;
            min-height: 34px;

            box-sizing: border-box;

            margin-top: auto;
            padding: 8px 10px;

            border: 1px solid rgba(224,107,174,0.28);
            border-radius: 6px;

            background:
                linear-gradient(
                    135deg,
                    var(--purple, #5B2A86),
                    var(--magenta, #B0449E)
                );

            color: #ffffff;

            text-decoration: none;

            font-family: Inter, Arial, sans-serif;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 0.4px;

            cursor: pointer;
        }

        .dashboard-action-btn:hover {
            opacity: 0.9;
        }

        .summary-panel {
            padding: 14px;

            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 10px;

            background:
                linear-gradient(
                    180deg,
                    rgba(255,255,255,0.035),
                    rgba(255,255,255,0.015)
                );
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
        }

        .summary-item {
            min-height: 74px;

            box-sizing: border-box;

            padding: 13px 15px;

            border: 1px solid rgba(255,255,255,0.07);
            border-radius: 8px;

            background: rgba(255,255,255,0.025);
        }

        .summary-label {
            display: block;

            margin-bottom: 6px;

            font-family: Inter, Arial, sans-serif;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 0.6px;

            color: var(--pink, #E06BAE);
        }

        .summary-value {
            display: block;

            font-family: Inter, Arial, sans-serif;
            font-size: 14px;
            font-weight: 700;
            line-height: 1.35;

            color: #ffffff;
        }

        .footer {
            margin-top: 10px !important;
            padding-top: 12px !important;
            padding-bottom: 12px !important;
        }

        @media (max-width: 950px) {

            .dashboard-stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .summary-grid {
                grid-template-columns: 1fr;
            }

        }

        @media (max-width: 600px) {

            .dashboard-stats {
                grid-template-columns: 1fr;
            }

            .dashboard-role-badge {
                width: 100%;
                box-sizing: border-box;
                text-align: center;
            }

        }

    </style>

</head>

<body>

    <?php include 'navbar.php'; ?>

    <h1>ADMIN DASHBOARD</h1>

    <div class="dashboard-shell">

        <div id="dashboardMessage"></div>

        <div class="dashboard-hero">

            <div class="dashboard-hero-text">

                <h2 id="adminWelcome">
                    Welcome back
                </h2>

                <p>
                    Review key system activity and access
                    Eventify management tools from your dashboard.
                </p>

            </div>

            <div class="dashboard-role-badge">
                ADMINISTRATOR
            </div>

        </div>

        <div class="dashboard-section">

            <div class="section-header">

                <div>

                    <h2 class="section-heading">
                        Platform Overview
                    </h2>

                    <div class="section-description">
                        Current records available across the Eventify platform.
                    </div>

                </div>

            </div>

            <div class="dashboard-stats">

                <div class="stat-card">

                    <div class="stat-label">
                        TOTAL USERS
                    </div>

                    <div
                        class="stat-value"
                        id="totalUsers"
                    >
                        -
                    </div>

                    <div class="stat-description">
                        Registered accounts across all user roles.
                    </div>

                    <a
                        href="adminusers.php"
                        class="dashboard-action-btn"
                    >
                        VIEW USERS
                    </a>

                </div>

                <div class="stat-card">

                    <div class="stat-label">
                        TOTAL EVENTS
                    </div>

                    <div
                        class="stat-value"
                        id="totalEvents"
                    >
                        -
                    </div>

                    <div class="stat-description">
                        Events currently registered in the system.
                    </div>

                    <a
                        href="adminevents.php"
                        class="dashboard-action-btn"
                    >
                        VIEW EVENTS
                    </a>

                </div>

                <div class="stat-card">

                    <div class="stat-label">
                        TOTAL VENUES
                    </div>

                    <div
                        class="stat-value"
                        id="totalVenues"
                    >
                        -
                    </div>

                    <div class="stat-description">
                        Venue records available for event scheduling.
                    </div>

                    <a
                        href="adminvenues.php"
                        class="dashboard-action-btn"
                    >
                        VIEW VENUES
                    </a>

                </div>

                <div class="stat-card">

                    <div class="stat-label">
                        TOTAL BOOKINGS
                    </div>

                    <div
                        class="stat-value"
                        id="totalBookings"
                    >
                        -
                    </div>

                    <div class="stat-description">
                        Customer booking records in Eventify.
                    </div>

                    <a
                        href="adminbookings.php"
                        class="dashboard-action-btn"
                    >
                        VIEW BOOKINGS
                    </a>

                </div>

            </div>

        </div>

        <div class="dashboard-section">

            <div class="section-header">

                <div>

                    <h2 class="section-heading">
                        System Overview
                    </h2>

                    <div class="section-description">
                        Quick operational summary of events,
                        bookings and venue availability.
                    </div>

                </div>

            </div>

            <div class="summary-panel">

                <div class="summary-grid">

                    <div class="summary-item">

                        <span class="summary-label">
                            UPCOMING EVENTS
                        </span>

                        <span
                            class="summary-value"
                            id="upcomingEvents"
                        >
                            Loading...
                        </span>

                    </div>

                    <div class="summary-item">

                        <span class="summary-label">
                            CONFIRMED BOOKINGS
                        </span>

                        <span
                            class="summary-value"
                            id="confirmedBookings"
                        >
                            Loading...
                        </span>

                    </div>

                    <div class="summary-item">

                        <span class="summary-label">
                            AVAILABLE VENUES
                        </span>

                        <span
                            class="summary-value"
                            id="availableVenues"
                        >
                            Loading...
                        </span>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="footer">

        EVENTIFY ADMIN PORTAL

        <br>

        Frontend developed by Anwar

    </div>

    <script>

        const token =
            localStorage.getItem(
                'eventify_token'
            );

        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );

        let currentUser = null;

        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }

            if (
                currentUser &&
                currentUser.role !==
                'Administrator'
            ) {

                alert(
                    'Administrator access only.'
                );

                window.location.href =
                    'login.php';

            }

            else if (currentUser) {

                document
                    .getElementById(
                        'adminWelcome'
                    )
                    .textContent =
                        `Welcome, ${currentUser.name}`;

                loadDashboard();

            }

        }

        async function loadDashboard() {

            try {

                const [
                    usersResponse,
                    eventsResponse,
                    venuesResponse,
                    bookingsResponse
                ] =
                    await Promise.all([

                        fetch(
                            '../api/users.php',
                            {
                                headers: {
                                    'Authorization':
                                        `Bearer ${token}`
                                }
                            }
                        ),

                        fetch(
                            '../api/events.php'
                        ),

                        fetch(
                            '../api/venues.php'
                        ),

                        fetch(
                            '../api/bookings.php',
                            {
                                headers: {
                                    'Authorization':
                                        `Bearer ${token}`
                                }
                            }
                        )

                    ]);

                if (
                    usersResponse.status === 401 ||
                    bookingsResponse.status === 401
                ) {

                    alert(
                        'Your session has expired. Please login again.'
                    );

                    clearSessionAndLogin();

                    return;

                }

                const [
                    usersResult,
                    eventsResult,
                    venuesResult,
                    bookingsResult
                ] =
                    await Promise.all([

                        usersResponse.json(),
                        eventsResponse.json(),
                        venuesResponse.json(),
                        bookingsResponse.json()

                    ]);

                const users =
                    usersResult.status === 'success'
                    ? usersResult.data || []
                    : [];

                const events =
                    eventsResult.status === 'success'
                    ? eventsResult.data || []
                    : [];

                const venues =
                    venuesResult.status === 'success'
                    ? venuesResult.data || []
                    : [];

                const bookings =
                    bookingsResult.status === 'success'
                    ? bookingsResult.data || []
                    : [];

                document
                    .getElementById(
                        'totalUsers'
                    )
                    .textContent =
                        users.length;

                document
                    .getElementById(
                        'totalEvents'
                    )
                    .textContent =
                        events.length;

                document
                    .getElementById(
                        'totalVenues'
                    )
                    .textContent =
                        venues.length;

                document
                    .getElementById(
                        'totalBookings'
                    )
                    .textContent =
                        bookings.length;

                const upcomingCount =
                    events.filter(
                        function(event) {

                            return (
                                event.status ===
                                'Upcoming'
                            );

                        }
                    ).length;

                document
                    .getElementById(
                        'upcomingEvents'
                    )
                    .textContent =
                        upcomingCount +
                        (
                            upcomingCount === 1
                            ? ' upcoming event'
                            : ' upcoming events'
                        );

                const confirmedCount =
                    bookings.filter(
                        function(booking) {

                            return (
                                booking.booking_status ===
                                'Confirmed'
                            );

                        }
                    ).length;

                document
                    .getElementById(
                        'confirmedBookings'
                    )
                    .textContent =
                        confirmedCount +
                        (
                            confirmedCount === 1
                            ? ' confirmed booking'
                            : ' confirmed bookings'
                        );

                const availableCount =
                    venues.filter(
                        function(venue) {

                            return (
                                venue.status ===
                                'Available'
                            );

                        }
                    ).length;

                document
                    .getElementById(
                        'availableVenues'
                    )
                    .textContent =
                        availableCount +
                        (
                            availableCount === 1
                            ? ' available venue'
                            : ' available venues'
                        );

            }

            catch (error) {

                console.error(
                    'Dashboard error:',
                    error
                );

                document
                    .getElementById(
                        'dashboardMessage'
                    )
                    .innerHTML = `

                        <div class="login-status login-error">

                            Unable to load dashboard data.

                        </div>

                    `;

            }

        }

        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );

            localStorage.removeItem(
                'eventify_user'
            );

            window.location.href =
                'login.php';

        }

    </script>

</body>

</html>