<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Browse Events - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;

            display: flex;
            flex-direction: column;
        }


        .events-shell {
            width: min(1180px, 92%);

            margin:
                0
                auto;

            flex: 1;
        }


        /*
        ========================================
        HERO
        ========================================
        */

        .events-hero {
            position: relative;

            width: 100%;

            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 25px;
            flex-wrap: wrap;

            box-sizing: border-box;

            margin-bottom: 18px;

            padding:
                20px
                22px;

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 11px;

            overflow: hidden;

            background:
                linear-gradient(
                    135deg,
                    rgba(91, 42, 134, 0.25),
                    rgba(21, 17, 58, 0.80)
                );
        }


        .events-hero::after {
            content: "";

            position: absolute;

            width: 250px;
            height: 250px;

            right: -80px;
            top: -100px;

            border-radius: 50%;

            background:
                radial-gradient(
                    circle,
                    rgba(224, 107, 174, 0.18),
                    transparent 68%
                );

            pointer-events: none;
        }


        .events-hero-content {
            position: relative;
            z-index: 2;

            flex: 1;

            min-width: 280px;
        }


        .events-eyebrow {
            display: inline-flex;
            align-items: center;

            gap: 7px;

            margin-bottom: 8px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.9px;

            color: #E06BAE;
        }


        .events-eyebrow-dot {
            width: 6px;
            height: 6px;

            border-radius: 50%;

            background: #E06BAE;

            box-shadow:
                0
                0
                10px
                rgba(224, 107, 174, 0.70);
        }


        .events-hero h2 {
            margin:
                0
                0
                7px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 22px;
            font-weight: 850;

            color: #ffffff;
        }


        .events-hero p {
            max-width: 650px;

            margin: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.6;

            color:
                rgba(255, 255, 255, 0.55);
        }


        /*
        HERO COUNT
        */

        .events-count-card {
            position: relative;
            z-index: 2;

            min-width: 125px;

            display: flex;
            align-items: center;

            gap: 10px;

            box-sizing: border-box;

            padding:
                11px
                13px;

            border:
                1px solid
                rgba(224, 107, 174, 0.20);

            border-radius: 8px;

            background:
                rgba(255, 255, 255, 0.035);
        }


        .events-count-icon {
            width: 32px;
            height: 32px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 7px;

            background:
                rgba(224, 107, 174, 0.09);

            color: #E06BAE;
        }


        .events-count-icon svg {
            width: 16px;
            height: 16px;
        }


        .events-count-number {
            display: block;

            margin-bottom: 1px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 12px;

            color: #F6C58E;
        }


        .events-count-label {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 800;

            letter-spacing: 0.5px;

            color:
                rgba(255, 255, 255, 0.40);
        }


        /*
        ========================================
        TOOLBAR
        ========================================
        */

        .events-toolbar {
            display: grid;

            grid-template-columns:
                minmax(300px, 1fr)
                180px
                160px;

            gap: 11px;

            margin-bottom: 15px;
        }


        .search-wrapper {
            position: relative;
        }


        .search-icon {
            position: absolute;

            left: 14px;
            top: 50%;

            width: 16px;
            height: 16px;

            transform:
                translateY(-50%);

            color:
                rgba(255, 255, 255, 0.58);

            pointer-events: none;
        }


        .search-wrapper input {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                14px
                0
                41px;

            border:
                1px solid
                rgba(224, 107, 174, 0.22);

            border-radius: 8px;

            outline: none;

            background:
                rgba(255, 255, 255, 0.085);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
        }


        .search-wrapper input::placeholder {
            color:
                rgba(255, 255, 255, 0.42);
        }


        .search-wrapper input:focus {
            border-color:
                rgba(224, 107, 174, 0.52);

            background:
                rgba(255, 255, 255, 0.105);

            box-shadow:
                0
                0
                0
                3px
                rgba(224, 107, 174, 0.06);
        }


        .events-filter select {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            padding:
                0
                12px;

            border:
                1px solid
                rgba(255, 255, 255, 0.11);

            border-radius: 8px;

            outline: none;

            background:
                rgba(255, 255, 255, 0.055);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            font-weight: 650;

            cursor: pointer;
        }


        .events-filter option {
            background: #1B1745;

            color: #ffffff;
        }


        /*
        ========================================
        RESULTS HEADER
        ========================================
        */

        .results-header {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 12px;

            margin-bottom: 10px;
        }


        .results-title {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 13px;
            font-weight: 800;

            color: #ffffff;
        }


        .results-subtitle {
            margin-top: 2px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.40);
        }


        /*
        ========================================
        EVENTS GRID
        ========================================
        */

        .events-grid {
            display: grid;

            grid-template-columns:
                repeat(3, minmax(0, 1fr));

            gap: 14px;
        }


        /*
        ========================================
        EVENT CARD
        ========================================
        */

        .event-card {
            min-width: 0;

            display: flex;
            flex-direction: column;

            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 10px;

            background:
                linear-gradient(
                    180deg,
                    rgba(36, 28, 86, 0.55),
                    rgba(21, 17, 58, 0.75)
                );

            transition:
                transform
                0.18s ease,
                border-color
                0.18s ease,
                box-shadow
                0.18s ease;
        }


        .event-card:hover {
            transform:
                translateY(-3px);

            border-color:
                rgba(224, 107, 174, 0.26);

            box-shadow:
                0
                15px
                35px
                rgba(0, 0, 0, 0.16);
        }


        /*
        ========================================
        EVENT IMAGE
        ========================================
        */

        .event-image-wrapper {
            position: relative;

            width: 100%;
            height: 135px;

            overflow: hidden;

            background:
                linear-gradient(
                    135deg,
                    #241C56,
                    #5B2A86,
                    #B0449E
                );
        }


        .event-image {
            width: 100%;
            height: 100%;

            display: block;

            object-fit: cover;

            transition:
                transform
                0.25s ease;
        }


        .event-card:hover
        .event-image {
            transform:
                scale(1.035);
        }


        /*
        FALLBACK
        */

        .event-image-fallback {
            position: absolute;
            inset: 0;

            display: none;
            align-items: center;
            justify-content: center;

            flex-direction: column;

            gap: 8px;

            background:
                radial-gradient(
                    circle at 80% 15%,
                    rgba(224, 107, 174, 0.22),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #1B1745,
                    #5B2A86
                );
        }


        .event-image-fallback svg {
            width: 29px;
            height: 29px;

            color:
                rgba(255, 255, 255, 0.50);
        }


        .event-image-fallback span {
            font-family:
                "Press Start 2P",
                monospace;

            font-size: 7px;

            color:
                rgba(255, 255, 255, 0.40);
        }


        /*
        IMAGE TOP BADGES
        */

        .image-status-badge {
            position: absolute;

            top: 10px;
            left: 10px;

            z-index: 3;

            min-width: 70px;

            padding:
                5px
                8px;

            box-sizing: border-box;

            text-align: center;

            border-radius: 5px;

            backdrop-filter:
                blur(10px);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 850;

            letter-spacing: 0.35px;
        }


        .status-upcoming {
            border:
                1px solid
                rgba(143, 216, 198, 0.28);

            background:
                rgba(21, 40, 45, 0.72);

            color: #8FD8C6;
        }


        .status-ongoing {
            border:
                1px solid
                rgba(246, 197, 142, 0.28);

            background:
                rgba(55, 45, 25, 0.72);

            color: #F6C58E;
        }


        .status-completed {
            border:
                1px solid
                rgba(169, 185, 236, 0.26);

            background:
                rgba(30, 34, 55, 0.75);

            color: #A9B9EC;
        }


        .status-cancelled {
            border:
                1px solid
                rgba(239, 130, 149, 0.30);

            background:
                rgba(60, 25, 35, 0.75);

            color: #EF8295;
        }


        .event-category-badge {
            position: absolute;

            top: 10px;
            right: 10px;

            z-index: 3;

            max-width: 130px;

            padding:
                5px
                7px;

            border:
                1px solid
                rgba(255, 255, 255, 0.14);

            border-radius: 5px;

            background:
                rgba(11, 11, 46, 0.72);

            backdrop-filter:
                blur(10px);

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 800;

            color: #ffffff;
        }


        /*
        ========================================
        CARD BODY
        ========================================
        */

        .event-card-body {
            flex: 1;

            display: flex;
            flex-direction: column;

            padding:
                13px
                14px
                14px
                14px;
        }


        .event-card-name {
            margin-bottom: 8px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 13px;
            font-weight: 850;
            line-height: 1.35;

            color: #ffffff;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        /*
        EVENT INFO
        */

        .event-info-list {
            display: grid;

            gap: 6px;

            margin-bottom: 11px;
        }


        .event-info-item {
            display: flex;
            align-items: center;

            gap: 7px;

            min-width: 0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.51);
        }


        .event-info-item svg {
            width: 13px;
            height: 13px;

            flex-shrink: 0;

            color:
                #E06BAE;
        }


        .event-info-text {
            min-width: 0;

            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        /*
        ========================================
        PRICE / TICKETS
        ========================================
        */

        .event-card-bottom {
            display: flex;
            align-items: end;
            justify-content: space-between;

            gap: 10px;

            margin-top: auto;

            padding-top: 10px;

            border-top:
                1px solid
                rgba(255, 255, 255, 0.065);
        }


        .event-price-label {
            margin-bottom: 3px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            font-weight: 750;

            letter-spacing: 0.4px;

            color:
                rgba(255, 255, 255, 0.34);
        }


        .event-price {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 13px;
            font-weight: 850;

            color: #F6C58E;
        }


        .ticket-availability {
            text-align: right;
        }


        .ticket-number {
            display: block;

            margin-bottom: 2px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;

            color: #ffffff;
        }


        .ticket-label {
            display: block;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;

            color:
                rgba(255, 255, 255, 0.32);
        }


        /*
        VIEW EVENT
        */

        .view-event-btn {
            width: 100%;
            height: 34px;

            display: flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            margin-top: 11px;

            border:
                1px solid
                rgba(224, 107, 174, 0.24);

            border-radius: 6px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.4px;

            color: #ffffff;
        }


        .view-event-btn:hover {
            opacity: 0.90;
        }


        .view-event-btn.disabled {
            border-color:
                rgba(255, 255, 255, 0.08);

            background:
                rgba(255, 255, 255, 0.035);

            color:
                rgba(255, 255, 255, 0.35);

            pointer-events: none;
        }


        /*
        ========================================
        EMPTY / LOADING
        ========================================
        */

        .events-state {
            grid-column:
                1 / -1;

            min-height: 180px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-direction: column;

            gap: 9px;

            box-sizing: border-box;

            padding: 25px;

            border:
                1px solid
                rgba(255, 255, 255, 0.08);

            border-radius: 10px;

            background:
                rgba(255, 255, 255, 0.018);

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 10px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.44);
        }


        .events-state svg {
            width: 27px;
            height: 27px;

            color:
                rgba(224, 107, 174, 0.65);
        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        .pagination-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 13px;
            flex-wrap: wrap;

            margin-top: 14px;
        }


        .pagination-info {
            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.42);
        }


        .pagination-controls {
            display: flex;
            align-items: center;

            gap: 8px;
        }


        .pagination-btn {
            min-width: 82px;
            height: 31px;

            padding:
                0
                11px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 5px;

            background:
                rgba(255, 255, 255, 0.035);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 750;

            cursor: pointer;
        }


        .pagination-btn:hover:not(:disabled) {
            background:
                rgba(255, 255, 255, 0.075);
        }


        .pagination-btn:disabled {
            opacity: 0.25;

            cursor: not-allowed;
        }


        .pagination-page {
            min-width: 76px;

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 700;

            color:
                rgba(255, 255, 255, 0.54);
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                10px !important;

            padding-top:
                11px !important;

            padding-bottom:
                11px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 950px) {

            .events-grid {
                grid-template-columns:
                    repeat(2, minmax(0, 1fr));
            }


            .events-toolbar {
                grid-template-columns:
                    1fr
                    1fr;
            }


            .search-wrapper {
                grid-column:
                    1 / -1;
            }

        }


        @media (max-width: 650px) {

            .events-grid {
                grid-template-columns:
                    1fr;
            }


            .events-toolbar {
                grid-template-columns:
                    1fr;
            }


            .search-wrapper {
                grid-column: auto;
            }


            .events-count-card {
                width: 100%;
            }


            .pagination-bar {
                justify-content: center;
            }


            .pagination-info {
                width: 100%;

                text-align: center;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <h1>BROWSE EVENTS</h1>


    <div class="events-shell">


        <!--
        ========================================
        HERO
        ========================================
        -->

        <section class="events-hero">


            <div class="events-hero-content">


                <div class="events-eyebrow">

                    <span class="events-eyebrow-dot"></span>

                    EVENTIFY DISCOVERY

                </div>


                <h2>
                    Find something worth showing up for.
                </h2>


                <p>

                    Explore upcoming events, discover venues and
                    check ticket availability before securing your place.

                </p>


            </div>


            <div class="events-count-card">


                <div class="events-count-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >

                        <rect
                            x="3"
                            y="5"
                            width="18"
                            height="16"
                            rx="2"
                        ></rect>

                        <path d="M8 3v4"></path>

                        <path d="M16 3v4"></path>

                        <path d="M3 10h18"></path>

                    </svg>

                </div>


                <div>

                    <span
                        class="events-count-number"
                        id="eventsCount"
                    >
                        0
                    </span>

                    <span class="events-count-label">
                        EVENTS FOUND
                    </span>

                </div>


            </div>


        </section>


        <!--
        ========================================
        TOOLBAR
        ========================================
        -->

        <div class="events-toolbar">


            <div class="search-wrapper">


                <svg
                    class="search-icon"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20l-3.5-3.5"
                    ></path>

                </svg>


                <input
                    type="text"
                    id="eventSearch"
                    placeholder="Search event, venue, location or category..."
                >


            </div>


            <div class="events-filter">

                <select id="categoryFilter">

                    <option value="All">
                        All Categories
                    </option>

                </select>

            </div>


            <div class="events-filter">

                <select id="statusFilter">

                    <option value="All">
                        All Status
                    </option>

                    <option value="Upcoming">
                        Upcoming
                    </option>

                    <option value="Ongoing">
                        Ongoing
                    </option>

                    <option value="Completed">
                        Completed
                    </option>

                    <option value="Cancelled">
                        Cancelled
                    </option>

                </select>

            </div>


        </div>


        <!--
        ========================================
        RESULTS TITLE
        ========================================
        -->

        <div class="results-header">


            <div>

                <div class="results-title">
                    Available Events
                </div>

                <div
                    class="results-subtitle"
                    id="resultsSubtitle"
                >
                    Loading Eventify events...
                </div>

            </div>


        </div>


        <!--
        ========================================
        EVENT GRID
        ========================================
        -->

        <div
            class="events-grid"
            id="eventsGrid"
        >


            <div class="events-state">

                Loading events...

            </div>


        </div>


        <!--
        ========================================
        PAGINATION
        ========================================
        -->

        <div class="pagination-bar">


            <div
                class="pagination-info"
                id="paginationInfo"
            >
                Showing 0 events
            </div>


            <div class="pagination-controls">


                <button
                    type="button"
                    class="pagination-btn"
                    id="previousPageButton"
                    onclick="previousPage()"
                >
                    PREVIOUS
                </button>


                <div
                    class="pagination-page"
                    id="paginationPage"
                >
                    Page 1 of 1
                </div>


                <button
                    type="button"
                    class="pagination-btn"
                    id="nextPageButton"
                    onclick="nextPage()"
                >
                    NEXT
                </button>


            </div>


        </div>


    </div>


    <div class="footer">

        EVENTIFY

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const eventsGrid =
            document.getElementById(
                'eventsGrid'
            );


        const eventSearch =
            document.getElementById(
                'eventSearch'
            );


        const categoryFilter =
            document.getElementById(
                'categoryFilter'
            );


        const statusFilter =
            document.getElementById(
                'statusFilter'
            );


        const eventsCount =
            document.getElementById(
                'eventsCount'
            );


        const resultsSubtitle =
            document.getElementById(
                'resultsSubtitle'
            );


        const paginationInfo =
            document.getElementById(
                'paginationInfo'
            );


        const paginationPage =
            document.getElementById(
                'paginationPage'
            );


        const previousPageButton =
            document.getElementById(
                'previousPageButton'
            );


        const nextPageButton =
            document.getElementById(
                'nextPageButton'
            );


        /*
        ========================================
        DATA
        ========================================
        */

        let allEvents =
            [];


        let filteredEvents =
            [];


        /*
        6 cards = 3 x 2 layout.
        Nampak balance untuk browse page.
        */

        const eventsPerPage =
            6;


        let currentPage =
            1;


        /*
        ========================================
        LISTENERS
        ========================================
        */

        eventSearch.addEventListener(
            'input',
            function() {

                currentPage =
                    1;


                filterEvents();

            }
        );


        categoryFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterEvents();

            }
        );


        statusFilter.addEventListener(
            'change',
            function() {

                currentPage =
                    1;


                filterEvents();

            }
        );


        /*
        ========================================
        LOAD
        ========================================
        */

        loadEvents();


        async function loadEvents() {

            eventsGrid.innerHTML = `

                <div class="events-state">

                    Loading Eventify events...

                </div>

            `;


            try {

                const response =
                    await fetch(
                        '../api/events.php'
                    );


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    'success'
                ) {

                    throw new Error(
                        result.message ||
                        'Unable to load events'
                    );

                }


                allEvents =
                    result.data ||
                    [];


                /*
                Sort nearest event first
                */

                allEvents.sort(
                    function(a, b) {

                        return String(
                            a.event_date ||
                            ''
                        )
                        .localeCompare(
                            String(
                                b.event_date ||
                                ''
                            )
                        );

                    }
                );


                buildCategoryFilter();


                filterEvents();

            }

            catch (error) {

                console.error(
                    'Events API error:',
                    error
                );


                eventsGrid.innerHTML = `

                    <div class="events-state">

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <circle
                                cx="12"
                                cy="12"
                                r="9"
                            ></circle>

                            <path
                                d="M12 8v5"
                            ></path>

                            <path
                                d="M12 17h.01"
                            ></path>

                        </svg>

                        Unable to load Eventify events.

                    </div>

                `;


                eventsCount.textContent =
                    '0';


                resultsSubtitle.textContent =
                    'Event data is currently unavailable.';


                updatePagination();

            }

        }


        /*
        ========================================
        CATEGORY FILTER
        ========================================
        */

        function buildCategoryFilter() {

            const categories =
                [
                    ...new Set(

                        allEvents
                            .map(
                                function(event) {

                                    return String(
                                        event.category ||
                                        ''
                                    ).trim();

                                }
                            )
                            .filter(
                                function(category) {

                                    return (
                                        category !==
                                        ''
                                    );

                                }
                            )

                    )
                ]
                .sort();


            categoryFilter.innerHTML = `

                <option value="All">
                    All Categories
                </option>

            `;


            categories.forEach(
                function(category) {

                    const option =
                        document.createElement(
                            'option'
                        );


                    option.value =
                        category;


                    option.textContent =
                        category;


                    categoryFilter.appendChild(
                        option
                    );

                }
            );

        }


        /*
        ========================================
        FILTER
        ========================================
        */

        function filterEvents() {

            const searchValue =
                eventSearch
                    .value
                    .trim()
                    .toLowerCase();


            const selectedCategory =
                categoryFilter.value;


            const selectedStatus =
                statusFilter.value;


            filteredEvents =
                allEvents.filter(
                    function(event) {


                        const eventId =
                            String(
                                event.event_id ||
                                ''
                            )
                            .toLowerCase();


                        const eventName =
                            String(
                                event.event_name ||
                                ''
                            )
                            .toLowerCase();


                        const category =
                            String(
                                event.category ||
                                ''
                            )
                            .toLowerCase();


                        const venue =
                            String(
                                event.venue_name ||
                                ''
                            )
                            .toLowerCase();


                        const location =
                            String(
                                event.location ||
                                ''
                            )
                            .toLowerCase();


                        const matchesSearch =

                            !searchValue

                            ||

                            eventId.includes(
                                searchValue
                            )

                            ||

                            eventName.includes(
                                searchValue
                            )

                            ||

                            category.includes(
                                searchValue
                            )

                            ||

                            venue.includes(
                                searchValue
                            )

                            ||

                            location.includes(
                                searchValue
                            );


                        const matchesCategory =

                            selectedCategory ===
                            'All'

                            ||

                            event.category ===
                            selectedCategory;


                        const matchesStatus =

                            selectedStatus ===
                            'All'

                            ||

                            event.status ===
                            selectedStatus;


                        return (
                            matchesSearch &&
                            matchesCategory &&
                            matchesStatus
                        );

                    }
                );


            const totalPages =
                getTotalPages();


            if (
                currentPage >
                totalPages
            ) {

                currentPage =
                    totalPages;

            }


            if (
                currentPage <
                1
            ) {

                currentPage =
                    1;

            }


            displayEvents();

        }


        /*
        ========================================
        DISPLAY
        ========================================
        */

        function displayEvents() {

            eventsCount.textContent =
                filteredEvents.length;


            resultsSubtitle.textContent =

                filteredEvents.length ===
                1

                ? '1 event matches your current filters.'

                : `${filteredEvents.length} events match your current filters.`;


            if (
                filteredEvents.length ===
                0
            ) {

                eventsGrid.innerHTML = `

                    <div class="events-state">

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <circle
                                cx="11"
                                cy="11"
                                r="7"
                            ></circle>

                            <path
                                d="M20 20l-3.5-3.5"
                            ></path>

                        </svg>

                        No events match your search or filters.

                    </div>

                `;


                updatePagination();

                return;

            }


            const startIndex =
                (
                    currentPage -
                    1
                )
                *
                eventsPerPage;


            const endIndex =
                startIndex +
                eventsPerPage;


            const pageEvents =
                filteredEvents.slice(
                    startIndex,
                    endIndex
                );


            eventsGrid.innerHTML =
                '';


            pageEvents.forEach(
                function(event) {


                    const availableTickets =
                        Number(
                            event.available_tickets ||
                            0
                        );


                    const totalTickets =
                        Number(
                            event.total_tickets ||
                            0
                        );


                    const soldOut =
                        availableTickets <=
                        0;


                    /*
                    IMAGE PATH

                    Example:
                    event_id 4
                    =>
                    assets/events/event-4.jpg
                    */

                    const imagePath =
                        `assets/events/event-${event.event_id}.jpg`;


                    const canView =
                        event.status !==
                        'Cancelled';


                    eventsGrid.innerHTML += `

                        <article class="event-card">


                            <div class="event-image-wrapper">


                                <img
                                    src="${imagePath}"
                                    alt="${escapeHtml(
                                        event.event_name
                                    )}"
                                    class="event-image"
                                    onerror="handleImageError(this)"
                                >


                                <div class="event-image-fallback">

                                    <svg
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor"
                                        stroke-width="1.8"
                                    >

                                        <rect
                                            x="3"
                                            y="5"
                                            width="18"
                                            height="16"
                                            rx="2"
                                        ></rect>

                                        <path d="M8 3v4"></path>

                                        <path d="M16 3v4"></path>

                                        <path d="M3 10h18"></path>

                                    </svg>

                                    <span>
                                        EVENTIFY EVENT
                                    </span>

                                </div>


                                <div
                                    class="
                                        image-status-badge
                                        ${getStatusClass(
                                            event.status
                                        )}
                                    "
                                >

                                    ${
                                        soldOut &&
                                        event.status ===
                                        'Upcoming'

                                        ? 'SOLD OUT'

                                        : escapeHtml(
                                            event.status
                                        )
                                    }

                                </div>


                                <div class="event-category-badge">

                                    ${escapeHtml(
                                        event.category ||
                                        'EVENT'
                                    )}

                                </div>


                            </div>


                            <div class="event-card-body">


                                <div class="event-card-name">

                                    ${escapeHtml(
                                        event.event_name ||
                                        'Untitled Event'
                                    )}

                                </div>


                                <div class="event-info-list">


                                    <!-- DATE -->

                                    <div class="event-info-item">

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.8"
                                        >

                                            <rect
                                                x="3"
                                                y="5"
                                                width="18"
                                                height="16"
                                                rx="2"
                                            ></rect>

                                            <path d="M8 3v4"></path>

                                            <path d="M16 3v4"></path>

                                            <path d="M3 10h18"></path>

                                        </svg>


                                        <span class="event-info-text">

                                            ${formatDate(
                                                event.event_date
                                            )}

                                            •

                                            ${formatTime(
                                                event.start_time
                                            )}

                                            -

                                            ${formatTime(
                                                event.end_time
                                            )}

                                        </span>

                                    </div>


                                    <!-- VENUE -->

                                    <div class="event-info-item">

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.8"
                                        >

                                            <path
                                                d="M12 21s7-5.5 7-12a7 7 0 1 0-14 0c0 6.5 7 12 7 12z"
                                            ></path>

                                            <circle
                                                cx="12"
                                                cy="9"
                                                r="2.2"
                                            ></circle>

                                        </svg>


                                        <span class="event-info-text">

                                            ${escapeHtml(
                                                event.venue_name ||
                                                'Venue TBA'
                                            )}

                                        </span>

                                    </div>


                                    <!-- LOCATION -->

                                    <div class="event-info-item">

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.8"
                                        >

                                            <path
                                                d="M4 20h16"
                                            ></path>

                                            <path
                                                d="M6 20V8l6-4 6 4v12"
                                            ></path>

                                        </svg>


                                        <span class="event-info-text">

                                            ${escapeHtml(
                                                event.location ||
                                                'Location unavailable'
                                            )}

                                        </span>

                                    </div>


                                </div>


                                <div class="event-card-bottom">


                                    <div>

                                        <div class="event-price-label">
                                            TICKET PRICE
                                        </div>

                                        <div class="event-price">

                                            RM ${Number(
                                                event.ticket_price ||
                                                0
                                            ).toFixed(
                                                2
                                            )}

                                        </div>

                                    </div>


                                    <div class="ticket-availability">

                                        <span class="ticket-number">

                                            ${availableTickets}
                                            /
                                            ${totalTickets}

                                        </span>

                                        <span class="ticket-label">

                                            ${
                                                soldOut

                                                ? 'SOLD OUT'

                                                : 'TICKETS LEFT'
                                            }

                                        </span>

                                    </div>


                                </div>


                                <a
                                    href="${
                                        canView

                                        ? `eventdetails.php?event_id=${encodeURIComponent(
                                            event.event_id
                                        )}`

                                        : '#'
                                    }"
                                    class="
                                        view-event-btn
                                        ${
                                            canView
                                            ? ''
                                            : 'disabled'
                                        }
                                    "
                                >

                                    ${
                                        canView
                                        ? 'VIEW EVENT'
                                        : 'EVENT CANCELLED'
                                    }

                                </a>


                            </div>


                        </article>

                    `;

                }
            );


            updatePagination();

        }


        /*
        ========================================
        IMAGE ERROR
        ========================================
        */

        function handleImageError(
            image
        ) {

            image.style.display =
                'none';


            const fallback =
                image.nextElementSibling;


            if (fallback) {

                fallback.style.display =
                    'flex';

            }

        }


        /*
        ========================================
        STATUS
        ========================================
        */

        function getStatusClass(
            status
        ) {

            if (
                status ===
                'Ongoing'
            ) {

                return 'status-ongoing';

            }


            if (
                status ===
                'Completed'
            ) {

                return 'status-completed';

            }


            if (
                status ===
                'Cancelled'
            ) {

                return 'status-cancelled';

            }


            return 'status-upcoming';

        }


        /*
        ========================================
        PAGINATION
        ========================================
        */

        function getTotalPages() {

            return Math.max(

                1,

                Math.ceil(
                    filteredEvents.length /
                    eventsPerPage
                )

            );

        }


        function updatePagination() {

            const totalPages =
                getTotalPages();


            const start =

                filteredEvents.length ===
                0

                ? 0

                : (
                    (
                        currentPage -
                        1
                    )
                    *
                    eventsPerPage
                )
                +
                1;


            const end =
                Math.min(

                    currentPage *
                    eventsPerPage,

                    filteredEvents.length

                );


            paginationInfo.textContent =

                filteredEvents.length ===
                0

                ? 'Showing 0 events'

                : `Showing ${start}-${end} of ${filteredEvents.length} events`;


            paginationPage.textContent =
                `Page ${currentPage} of ${totalPages}`;


            previousPageButton.disabled =
                currentPage <=
                1;


            nextPageButton.disabled =
                currentPage >=
                totalPages;

        }


        function previousPage() {

            if (
                currentPage <=
                1
            ) {

                return;

            }


            currentPage--;


            displayEvents();


            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });

        }


        function nextPage() {

            const totalPages =
                getTotalPages();


            if (
                currentPage >=
                totalPages
            ) {

                return;

            }


            currentPage++;


            displayEvents();


            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });

        }


        /*
        ========================================
        FORMAT DATE
        ========================================
        */

        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const parts =
                String(
                    value
                )
                .substring(
                    0,
                    10
                )
                .split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return value;

            }


            return (
                parts[2]
                +
                '/'
                +
                parts[1]
                +
                '/'
                +
                parts[0]
            );

        }


        /*
        ========================================
        FORMAT TIME
        ========================================
        */

        function formatTime(
            value
        ) {

            if (!value) {

                return '-';

            }


            return String(
                value
            ).substring(
                0,
                5
            );

        }


        /*
        ========================================
        ESCAPE HTML
        ========================================
        */

        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    </script>


</body>

</html>