<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - Eventify</title>
</head>

<body>

    <script>

        // Remove saved login data
        localStorage.removeItem('eventify_token');
        localStorage.removeItem('eventify_user');

        // Redirect to login page
        window.location.href = 'login.php';

    </script>

</body>
</html>