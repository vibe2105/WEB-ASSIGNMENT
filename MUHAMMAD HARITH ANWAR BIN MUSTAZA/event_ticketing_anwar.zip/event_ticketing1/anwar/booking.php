<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Book Ticket - Eventify</title>

    <link
        rel="stylesheet"
        href="style.css"
    >


    <style>

        body {
            min-height: 100vh;

            display: flex;
            flex-direction: column;
        }


        .booking-shell {
            width: min(1100px, 92%);

            margin:
                0
                auto;

            flex: 1;
        }


        /*
        ========================================
        BACK
        ========================================
        */

        .back-row {
            margin-bottom: 12px;
        }


        .back-link {
            display: inline-flex;
            align-items: center;

            gap: 7px;

            text-decoration: none;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 800;

            color:
                rgba(255, 255, 255, 0.48);
        }


        .back-link:hover {
            color: #ffffff;
        }


        .back-link svg {
            width: 14px;
            height: 14px;
        }


        /*
        ========================================
        PAGE STATE
        ========================================
        */

        .page-state {
            width: 100%;

            min-height: 170px;

            display: flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;

            padding: 25px;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 10px;

            background:
                rgba(255, 255, 255, 0.02);

            text-align: center;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 11px;
            line-height: 1.6;

            color:
                rgba(255, 255, 255, 0.50);
        }


        .page-state.error {
            border-color:
                rgba(239, 130, 149, 0.35);

            background:
                rgba(239, 130, 149, 0.07);

            color: #EF8295;
        }


        /*
        ========================================
        BOOKING GRID
        ========================================
        */

        .booking-layout {
            display: none;

            grid-template-columns:
                minmax(0, 1.05fr)
                minmax(340px, 0.95fr);

            gap: 18px;

            align-items: start;
        }


        .booking-layout.active {
            display: grid;
        }


        /*
        ========================================
        EVENT CARD
        ========================================
        */

        .event-panel {
            overflow: hidden;

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 11px;

            background:
                linear-gradient(
                    180deg,
                    rgba(36, 28, 86, 0.62),
                    rgba(21, 17, 58, 0.82)
                );
        }


        /*
        IMAGE
        */

        .event-image-wrapper {
            position: relative;

            width: 100%;
            height: 245px;

            overflow: hidden;

            background:
                linear-gradient(
                    135deg,
                    #1B1745,
                    #5B2A86,
                    #B0449E
                );
        }


        .event-image {
            width: 100%;
            height: 100%;

            display: block;

            object-fit: cover;
        }


        .event-image-fallback {
            position: absolute;
            inset: 0;

            display: none;
            align-items: center;
            justify-content: center;

            flex-direction: column;

            gap: 9px;

            background:
                radial-gradient(
                    circle at 80% 20%,
                    rgba(224, 107, 174, 0.22),
                    transparent 34%
                ),
                linear-gradient(
                    135deg,
                    #1B1745,
                    #5B2A86
                );
        }


        .event-image-fallback svg {
            width: 38px;
            height: 38px;

            color:
                rgba(255, 255, 255, 0.46);
        }


        .event-image-fallback span {
            font-family:
                "Press Start 2P",
                monospace;

            font-size: 7px;

            color:
                rgba(255, 255, 255, 0.42);
        }


        /*
        STATUS
        */

        .event-status {
            position: absolute;

            top: 12px;
            left: 12px;

            z-index: 3;

            padding:
                6px
                9px;

            border:
                1px solid
                rgba(143, 216, 198, 0.28);

            border-radius: 5px;

            background:
                rgba(21, 40, 45, 0.76);

            backdrop-filter: blur(10px);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            color: #8FD8C6;
        }


        .event-category {
            position: absolute;

            top: 12px;
            right: 12px;

            z-index: 3;

            max-width: 180px;

            padding:
                6px
                9px;

            border:
                1px solid
                rgba(255, 255, 255, 0.14);

            border-radius: 5px;

            background:
                rgba(11, 11, 46, 0.76);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;

            color: #ffffff;
        }


        /*
        EVENT CONTENT
        */

        .event-panel-content {
            padding:
                16px
                17px;
        }


        .event-panel-title {
            margin:
                0
                0
                8px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 19px;
            font-weight: 850;
            line-height: 1.35;

            color: #ffffff;
        }


        .event-info-list {
            display: grid;

            gap: 8px;

            margin-top: 13px;
        }


        .event-info-item {
            display: flex;
            align-items: center;

            gap: 8px;

            padding:
                8px
                9px;

            border:
                1px solid
                rgba(255, 255, 255, 0.06);

            border-radius: 6px;

            background:
                rgba(255, 255, 255, 0.02);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.55);
        }


        .event-info-item svg {
            width: 14px;
            height: 14px;

            flex-shrink: 0;

            color: #E06BAE;
        }


        /*
        ========================================
        BOOKING PANEL
        ========================================
        */

        .booking-panel {
            box-sizing: border-box;

            padding:
                20px;

            border:
                1px solid
                rgba(255, 255, 255, 0.11);

            border-radius: 11px;

            background:
                linear-gradient(
                    180deg,
                    rgba(36, 28, 86, 0.88),
                    rgba(21, 17, 58, 0.94)
                );
        }


        .booking-eyebrow {
            margin-bottom: 6px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.75px;

            color: #E06BAE;
        }


        .booking-panel h2 {
            margin:
                0
                0
                5px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 19px;
            font-weight: 850;

            color: #ffffff;
        }


        .booking-description {
            margin:
                0
                0
                16px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            line-height: 1.5;

            color:
                rgba(255, 255, 255, 0.45);
        }


        /*
        ========================================
        PRICE SUMMARY
        ========================================
        */

        .booking-summary {
            margin-bottom: 15px;

            padding:
                13px;

            border:
                1px solid
                rgba(246, 197, 142, 0.14);

            border-radius: 8px;

            background:
                rgba(246, 197, 142, 0.04);
        }


        .summary-row {
            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 15px;

            padding:
                6px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;

            color:
                rgba(255, 255, 255, 0.50);
        }


        .summary-row strong {
            color: #ffffff;
        }


        .summary-row.total {
            margin-top: 5px;

            padding-top: 10px;

            border-top:
                1px solid
                rgba(255, 255, 255, 0.08);
        }


        .summary-row.total span:first-child {
            font-weight: 800;

            color:
                rgba(255, 255, 255, 0.68);
        }


        .total-price {
            font-size: 17px;

            font-weight: 850;

            color: #F6C58E !important;
        }


        /*
        ========================================
        QUANTITY
        ========================================
        */

        .quantity-label {
            display: block;

            margin-bottom: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 850;

            letter-spacing: 0.6px;

            color:
                rgba(255, 255, 255, 0.60);
        }


        .quantity-control {
            width: 100%;

            display: grid;

            grid-template-columns:
                42px
                minmax(0, 1fr)
                42px;

            gap: 7px;

            margin-bottom: 6px;
        }


        .quantity-btn {
            height: 42px;

            border:
                1px solid
                rgba(255, 255, 255, 0.10);

            border-radius: 6px;

            background:
                rgba(255, 255, 255, 0.045);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 17px;
            font-weight: 700;

            cursor: pointer;
        }


        .quantity-btn:hover {
            background:
                rgba(224, 107, 174, 0.08);

            border-color:
                rgba(224, 107, 174, 0.20);
        }


        .quantity-input {
            width: 100%;
            height: 42px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(224, 107, 174, 0.20);

            border-radius: 6px;

            outline: none;

            text-align: center;

            background:
                rgba(11, 11, 46, 0.50);

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 13px;
            font-weight: 850;
        }


        .quantity-input:focus {
            border-color:
                rgba(224, 107, 174, 0.52);

            box-shadow:
                0
                0
                0
                3px
                rgba(224, 107, 174, 0.06);
        }


        .quantity-note {
            margin-bottom: 15px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 7px;
            line-height: 1.45;

            color:
                rgba(255, 255, 255, 0.33);
        }


        /*
        ========================================
        BOOK BUTTON
        ========================================
        */

        .confirm-booking-btn {
            width: 100%;
            height: 43px;

            display: flex;
            align-items: center;
            justify-content: center;

            gap: 8px;

            box-sizing: border-box;

            border:
                1px solid
                rgba(224, 107, 174, 0.28);

            border-radius: 7px;

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );

            color: #ffffff;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            font-weight: 850;

            letter-spacing: 0.5px;

            cursor: pointer;
        }


        .confirm-booking-btn:hover:not(:disabled) {
            transform:
                translateY(-1px);

            opacity: 0.93;
        }


        .confirm-booking-btn:disabled {
            opacity: 0.45;

            cursor: not-allowed;
        }


        /*
        ========================================
        MESSAGE
        ========================================
        */

        #bookingMessage:empty {
            display: none;
        }


        #bookingMessage {
            margin-top: 12px;
        }


        .booking-message {
            display: flex;
            align-items: flex-start;

            gap: 9px;

            padding:
                10px
                11px;

            border-radius: 7px;

            font-family:
                Inter,
                Arial,
                sans-serif;
        }


        .booking-message.success {
            border:
                1px solid
                rgba(95, 180, 160, 0.28);

            background:
                rgba(95, 180, 160, 0.075);
        }


        .booking-message.error {
            border:
                1px solid
                rgba(230, 95, 120, 0.28);

            background:
                rgba(230, 95, 120, 0.075);
        }


        .message-icon {
            width: 25px;
            height: 25px;

            display: flex;
            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            border-radius: 6px;

            font-size: 11px;
            font-weight: 850;
        }


        .booking-message.success
        .message-icon {
            background:
                rgba(95, 180, 160, 0.13);

            color: #8FD8C6;
        }


        .booking-message.error
        .message-icon {
            background:
                rgba(230, 95, 120, 0.13);

            color: #EF8295;
        }


        .message-title {
            margin-bottom: 2px;

            font-size: 8px;
            font-weight: 850;

            color: #ffffff;
        }


        .message-text {
            font-size: 8px;
            line-height: 1.45;

            color:
                rgba(255, 255, 255, 0.55);
        }


        /*
        ========================================
        SUCCESS PANEL
        ========================================
        */

        .booking-success-panel {
            display: none;

            text-align: center;

            padding:
                17px
                10px
                4px
                10px;
        }


        .booking-success-panel.active {
            display: block;
        }


        .success-icon {
            width: 54px;
            height: 54px;

            display: flex;
            align-items: center;
            justify-content: center;

            margin:
                0
                auto
                12px
                auto;

            border:
                1px solid
                rgba(143, 216, 198, 0.26);

            border-radius: 50%;

            background:
                rgba(143, 216, 198, 0.07);

            color: #8FD8C6;

            font-size: 22px;
            font-weight: 850;
        }


        .booking-success-panel h3 {
            margin:
                0
                0
                6px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 16px;
            font-weight: 850;

            color: #ffffff;
        }


        .booking-success-panel p {
            margin:
                0
                0
                14px
                0;

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 9px;
            line-height: 1.55;

            color:
                rgba(255, 255, 255, 0.45);
        }


        .success-booking-id {
            margin-bottom: 14px;

            font-family:
                "Press Start 2P",
                monospace;

            font-size: 8px;

            color: #F6C58E;
        }


        .success-actions {
            display: grid;

            grid-template-columns:
                1fr
                1fr;

            gap: 8px;
        }


        .success-action {
            height: 36px;

            display: flex;
            align-items: center;
            justify-content: center;

            border:
                1px solid
                rgba(255, 255, 255, 0.09);

            border-radius: 6px;

            text-decoration: none;

            background:
                rgba(255, 255, 255, 0.035);

            font-family:
                Inter,
                Arial,
                sans-serif;

            font-size: 8px;
            font-weight: 800;

            color: #ffffff;
        }


        .success-action.primary {
            border-color:
                rgba(224, 107, 174, 0.24);

            background:
                linear-gradient(
                    135deg,
                    #5B2A86,
                    #B0449E
                );
        }


        /*
        ========================================
        FOOTER
        ========================================
        */

        .footer {
            margin-top:
                12px !important;

            padding-top:
                11px !important;

            padding-bottom:
                11px !important;
        }


        /*
        ========================================
        RESPONSIVE
        ========================================
        */

        @media (max-width: 850px) {

            .booking-layout {
                grid-template-columns: 1fr;
            }

        }


        @media (max-width: 600px) {

            .event-image-wrapper {
                height: 210px;
            }


            .success-actions {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>


<body>

    <?php include 'navbar.php'; ?>


    <h1>BOOK TICKET</h1>


    <div class="booking-shell">


        <!-- BACK -->

        <div class="back-row">

            <a
                href="events.php"
                class="back-link"
                id="backEventLink"
            >

                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <path d="M19 12H5"></path>

                    <path d="M12 19l-7-7 7-7"></path>

                </svg>

                BACK TO EVENT

            </a>

        </div>


        <!-- STATE -->

        <div
            class="page-state"
            id="pageState"
        >
            Loading booking information...
        </div>


        <!--
        ========================================
        BOOKING LAYOUT
        ========================================
        -->

        <div
            class="booking-layout"
            id="bookingLayout"
        >


            <!--
            ========================================
            LEFT EVENT
            ========================================
            -->

            <section class="event-panel">


                <div class="event-image-wrapper">


                    <img
                        src=""
                        alt="Event image"
                        class="event-image"
                        id="eventImage"
                    >


                    <div
                        class="event-image-fallback"
                        id="eventImageFallback"
                    >

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <rect
                                x="3"
                                y="5"
                                width="18"
                                height="16"
                                rx="2"
                            ></rect>

                            <path d="M8 3v4"></path>

                            <path d="M16 3v4"></path>

                            <path d="M3 10h18"></path>

                        </svg>

                        <span>
                            EVENTIFY EVENT
                        </span>

                    </div>


                    <div class="event-status">
                        UPCOMING
                    </div>


                    <div
                        class="event-category"
                        id="eventCategory"
                    >
                        EVENT
                    </div>


                </div>


                <div class="event-panel-content">


                    <h2
                        class="event-panel-title"
                        id="eventName"
                    >
                        Event Name
                    </h2>


                    <div class="event-info-list">


                        <div class="event-info-item">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <rect
                                    x="3"
                                    y="5"
                                    width="18"
                                    height="16"
                                    rx="2"
                                ></rect>

                                <path d="M8 3v4"></path>

                                <path d="M16 3v4"></path>

                                <path d="M3 10h18"></path>

                            </svg>

                            <span id="eventDateTime">
                                -
                            </span>

                        </div>


                        <div class="event-info-item">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <path
                                    d="M12 21s7-5.5 7-12a7 7 0 1 0-14 0c0 6.5 7 12 7 12z"
                                ></path>

                                <circle
                                    cx="12"
                                    cy="9"
                                    r="2.2"
                                ></circle>

                            </svg>

                            <span id="eventVenue">
                                -
                            </span>

                        </div>


                        <div class="event-info-item">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >

                                <path
                                    d="M4 20h16"
                                ></path>

                                <path
                                    d="M6 20V8l6-4 6 4v12"
                                ></path>

                            </svg>

                            <span id="eventLocation">
                                -
                            </span>

                        </div>


                    </div>


                </div>


            </section>


            <!--
            ========================================
            RIGHT BOOKING
            ========================================
            -->

            <section class="booking-panel">


                <div id="bookingFormContent">


                    <div class="booking-eyebrow">
                        BOOKING CHECKOUT
                    </div>


                    <h2>
                        Confirm your tickets.
                    </h2>


                    <p class="booking-description">
                        Select your ticket quantity and review the total
                        before confirming your booking.
                    </p>


                    <!-- SUMMARY -->

                    <div class="booking-summary">


                        <div class="summary-row">

                            <span>
                                Ticket price
                            </span>

                            <strong id="ticketPrice">
                                RM 0.00
                            </strong>

                        </div>


                        <div class="summary-row">

                            <span>
                                Available tickets
                            </span>

                            <strong id="availableTickets">
                                0
                            </strong>

                        </div>


                        <div class="summary-row">

                            <span>
                                Quantity
                            </span>

                            <strong id="summaryQuantity">
                                1
                            </strong>

                        </div>


                        <div class="summary-row total">

                            <span>
                                TOTAL
                            </span>

                            <strong
                                class="total-price"
                                id="totalPrice"
                            >
                                RM 0.00
                            </strong>

                        </div>


                    </div>


                    <!-- QUANTITY -->

                    <label class="quantity-label">
                        TICKET QUANTITY
                    </label>


                    <div class="quantity-control">


                        <button
                            type="button"
                            class="quantity-btn"
                            onclick="changeQuantity(-1)"
                        >
                            −
                        </button>


                        <input
                            type="number"
                            id="ticketQuantity"
                            class="quantity-input"
                            min="1"
                            max="10"
                            value="1"
                        >


                        <button
                            type="button"
                            class="quantity-btn"
                            onclick="changeQuantity(1)"
                        >
                            +
                        </button>


                    </div>


                    <div class="quantity-note">

                        Maximum 10 tickets per booking.
                        Quantity cannot exceed the available ticket balance.

                    </div>


                    <!-- BUTTON -->

                    <button
                        type="button"
                        class="confirm-booking-btn"
                        id="confirmBookingButton"
                        onclick="createBooking()"
                    >
                        CONFIRM BOOKING
                    </button>


                    <div id="bookingMessage"></div>


                </div>


                <!-- SUCCESS -->

                <div
                    class="booking-success-panel"
                    id="bookingSuccessPanel"
                >


                    <div class="success-icon">
                        ✓
                    </div>


                    <h3>
                        Booking confirmed.
                    </h3>


                    <p>
                        Your tickets have been successfully reserved
                        and added to your Eventify account.
                    </p>


                    <div
                        class="success-booking-id"
                        id="successBookingId"
                    >
                        BOOKING #-
                    </div>


                    <div class="success-actions">


                        <a
                            href="mybookings.php"
                            class="success-action primary"
                        >
                            MY BOOKINGS
                        </a>


                        <a
                            href="events.php"
                            class="success-action"
                        >
                            BROWSE EVENTS
                        </a>


                    </div>


                </div>


            </section>


        </div>


    </div>


    <div class="footer">

        EVENTIFY CUSTOMER PORTAL

        <br>

        Frontend developed by Anwar

    </div>


    <script>

        /*
        ========================================
        SESSION
        ========================================
        */

        const token =
            localStorage.getItem(
                'eventify_token'
            );


        const storedUser =
            localStorage.getItem(
                'eventify_user'
            );


        let currentUser =
            null;


        /*
        ========================================
        URL
        ========================================
        */

        const urlParams =
            new URLSearchParams(
                window.location.search
            );


        /*
        IMPORTANT FIX

        eventdetails.php sends:

        booking.php?event_id=6
        */

        const eventId =
            urlParams.get(
                'event_id'
            );


        /*
        ========================================
        DATA
        ========================================
        */

        let currentEvent =
            null;


        let ticketPriceValue =
            0;


        let maximumQuantity =
            10;


        /*
        ========================================
        ELEMENTS
        ========================================
        */

        const pageState =
            document.getElementById(
                'pageState'
            );


        const bookingLayout =
            document.getElementById(
                'bookingLayout'
            );


        const ticketQuantity =
            document.getElementById(
                'ticketQuantity'
            );


        const confirmBookingButton =
            document.getElementById(
                'confirmBookingButton'
            );


        const bookingMessage =
            document.getElementById(
                'bookingMessage'
            );


        /*
        ========================================
        AUTH CHECK
        ========================================
        */

        if (
            !token ||
            !storedUser
        ) {

            window.location.href =
                'login.php';

        }

        else {

            try {

                currentUser =
                    JSON.parse(
                        storedUser
                    );

            }

            catch (error) {

                clearSessionAndLogin();

            }


            if (
                currentUser &&
                currentUser.role !==
                'Customer'
            ) {

                showError(
                    'Only customer accounts can create ticket bookings.'
                );

            }

            else if (
                !eventId ||
                isNaN(
                    Number(
                        eventId
                    )
                )
            ) {

                showError(
                    'Event ID not found. Please return to Browse Events and select an event.'
                );

            }

            else {

                loadEvent();

            }

        }


        /*
        ========================================
        QUANTITY INPUT
        ========================================
        */

        ticketQuantity.addEventListener(
            'input',
            function() {

                normaliseQuantity();

                updatePrice();

            }
        );


        /*
        ========================================
        LOAD EVENT
        ========================================
        */

        async function loadEvent() {

            try {

                const response =
                    await fetch(

                        `../api/events.php?event_id=${encodeURIComponent(
                            eventId
                        )}`

                    );


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    result.status !==
                    'success'
                ) {

                    throw new Error(
                        result.message ||
                        'Unable to load event.'
                    );

                }


                let event =
                    result.data;


                /*
                Handle API array/object safely
                */

                if (
                    Array.isArray(
                        event
                    )
                ) {

                    event =
                        event.find(
                            function(item) {

                                return (
                                    Number(
                                        item.event_id
                                    )
                                    ===
                                    Number(
                                        eventId
                                    )
                                );

                            }
                        );

                }


                if (
                    !event ||
                    !event.event_id
                ) {

                    throw new Error(
                        'Event could not be found.'
                    );

                }


                /*
                Booking API only accepts Upcoming events.
                */

                if (
                    event.status !==
                    'Upcoming'
                ) {

                    throw new Error(
                        'This event is not available for booking.'
                    );

                }


                if (
                    Number(
                        event.available_tickets ||
                        0
                    )
                    <=
                    0
                ) {

                    throw new Error(
                        'This event is sold out.'
                    );

                }


                currentEvent =
                    event;


                displayEvent();

            }

            catch (error) {

                console.error(
                    'Load booking event error:',
                    error
                );


                showError(
                    error.message ||
                    'Unable to load booking information.'
                );

            }

        }


        /*
        ========================================
        DISPLAY EVENT
        ========================================
        */

        function displayEvent() {

            pageState.style.display =
                'none';


            bookingLayout.classList.add(
                'active'
            );


            /*
            BACK LINK
            */

            document
                .getElementById(
                    'backEventLink'
                )
                .href =
                    `eventdetails.php?event_id=${encodeURIComponent(
                        currentEvent.event_id
                    )}`;


            /*
            IMAGE
            */

            const eventImage =
                document.getElementById(
                    'eventImage'
                );


            const fallback =
                document.getElementById(
                    'eventImageFallback'
                );


            eventImage.src =
                `assets/events/event-${currentEvent.event_id}.jpg`;


            eventImage.alt =
                currentEvent.event_name ||
                'Event image';


            eventImage.onerror =
                function() {

                    eventImage.style.display =
                        'none';


                    fallback.style.display =
                        'flex';

                };


            /*
            EVENT INFO
            */

            document
                .getElementById(
                    'eventName'
                )
                .textContent =
                    currentEvent.event_name ||
                    'Untitled Event';


            document
                .getElementById(
                    'eventCategory'
                )
                .textContent =
                    currentEvent.category ||
                    'EVENT';


            document
                .getElementById(
                    'eventDateTime'
                )
                .textContent =
                    `${formatDate(
                        currentEvent.event_date
                    )} • ${formatTime(
                        currentEvent.start_time
                    )} - ${formatTime(
                        currentEvent.end_time
                    )}`;


            document
                .getElementById(
                    'eventVenue'
                )
                .textContent =
                    currentEvent.venue_name ||
                    'Venue TBA';


            document
                .getElementById(
                    'eventLocation'
                )
                .textContent =
                    currentEvent.location ||
                    'Location unavailable';


            /*
            PRICE
            */

            ticketPriceValue =
                Number(
                    currentEvent.ticket_price ||
                    0
                );


            const available =
                Number(
                    currentEvent.available_tickets ||
                    0
                );


            /*
            Backend max = 10.
            Also cannot exceed available tickets.
            */

            maximumQuantity =
                Math.min(
                    10,
                    available
                );


            ticketQuantity.max =
                maximumQuantity;


            ticketQuantity.value =
                1;


            document
                .getElementById(
                    'ticketPrice'
                )
                .textContent =
                    `RM ${ticketPriceValue.toFixed(
                        2
                    )}`;


            document
                .getElementById(
                    'availableTickets'
                )
                .textContent =
                    available;


            updatePrice();

        }


        /*
        ========================================
        QUANTITY
        ========================================
        */

        function changeQuantity(
            change
        ) {

            let value =
                Number(
                    ticketQuantity.value
                )
                ||
                1;


            value +=
                change;


            value =
                Math.max(
                    1,
                    Math.min(
                        maximumQuantity,
                        value
                    )
                );


            ticketQuantity.value =
                value;


            updatePrice();

        }


        function normaliseQuantity() {

            let value =
                Number(
                    ticketQuantity.value
                );


            if (
                !Number.isInteger(
                    value
                )
            ) {

                value =
                    Math.floor(
                        value
                    );

            }


            if (
                !value ||
                value <
                1
            ) {

                value =
                    1;

            }


            if (
                value >
                maximumQuantity
            ) {

                value =
                    maximumQuantity;

            }


            ticketQuantity.value =
                value;

        }


        /*
        ========================================
        PRICE
        ========================================
        */

        function updatePrice() {

            normaliseQuantity();


            const quantity =
                Number(
                    ticketQuantity.value
                );


            const total =
                ticketPriceValue *
                quantity;


            document
                .getElementById(
                    'summaryQuantity'
                )
                .textContent =
                    quantity;


            document
                .getElementById(
                    'totalPrice'
                )
                .textContent =
                    `RM ${total.toFixed(
                        2
                    )}`;

        }


        /*
        ========================================
        CREATE BOOKING
        ========================================
        */

        async function createBooking() {

            if (
                !currentEvent
            ) {

                return;

            }


            normaliseQuantity();


            const quantity =
                Number(
                    ticketQuantity.value
                );


            /*
            Same limits as backend.
            */

            if (
                quantity <
                1
                ||
                quantity >
                10
            ) {

                showBookingMessage(
                    'error',
                    'Invalid quantity',
                    'You can book between 1 and 10 tickets.'
                );


                return;

            }


            if (
                quantity >
                Number(
                    currentEvent.available_tickets
                )
            ) {

                showBookingMessage(
                    'error',
                    'Not enough tickets',
                    'The selected quantity exceeds the available ticket balance.'
                );


                return;

            }


            const total =
                ticketPriceValue *
                quantity;


            const confirmed =
                confirm(

                    `Confirm this booking?\n\n` +

                    `Event: ${currentEvent.event_name}\n` +

                    `Tickets: ${quantity}\n` +

                    `Total: RM ${total.toFixed(
                        2
                    )}`

                );


            if (!confirmed) {

                return;

            }


            confirmBookingButton.disabled =
                true;


            confirmBookingButton.textContent =
                'PROCESSING BOOKING...';


            bookingMessage.innerHTML =
                '';


            try {

                /*
                BACKEND REQUIRES:

                event_id
                quantity

                JWT Bearer Customer
                */

                const response =
                    await fetch(
                        '../api/bookings.php',
                        {

                            method:
                                'POST',

                            headers: {

                                'Content-Type':
                                    'application/json',

                                'Authorization':
                                    `Bearer ${token}`

                            },

                            body:
                                JSON.stringify({

                                    event_id:
                                        Number(
                                            currentEvent.event_id
                                        ),

                                    quantity:
                                        quantity

                                })

                        }
                    );


                if (
                    response.status ===
                    401
                ) {

                    clearSessionAndLogin();

                    return;

                }


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.status ===
                    'success'
                ) {

                    /*
                    Backend returns booking_id,
                    quantity and total_amount.
                    */

                    showBookingSuccess(
                        result
                    );

                }

                else {

                    showBookingMessage(
                        'error',
                        'Booking failed',
                        result.message ||
                        'Unable to create this booking.'
                    );


                    confirmBookingButton.disabled =
                        false;


                    confirmBookingButton.textContent =
                        'CONFIRM BOOKING';

                }

            }

            catch (error) {

                console.error(
                    'Create booking error:',
                    error
                );


                showBookingMessage(
                    'error',
                    'Connection error',
                    'Unable to connect to the Eventify Booking API.'
                );


                confirmBookingButton.disabled =
                    false;


                confirmBookingButton.textContent =
                    'CONFIRM BOOKING';

            }

        }


        /*
        ========================================
        SUCCESS
        ========================================
        */

        function showBookingSuccess(
            result
        ) {

            document
                .getElementById(
                    'bookingFormContent'
                )
                .style
                .display =
                    'none';


            const successPanel =
                document.getElementById(
                    'bookingSuccessPanel'
                );


            successPanel.classList.add(
                'active'
            );


            document
                .getElementById(
                    'successBookingId'
                )
                .textContent =
                    `BOOKING #${result.booking_id || '-'}`;

        }


        /*
        ========================================
        MESSAGE
        ========================================
        */

        function showBookingMessage(
            type,
            title,
            text
        ) {

            bookingMessage.innerHTML = `

                <div
                    class="
                        booking-message
                        ${type}
                    "
                >

                    <div class="message-icon">

                        ${
                            type ===
                            'success'

                            ? '✓'
                            : '!'
                        }

                    </div>


                    <div>

                        <div class="message-title">

                            ${escapeHtml(
                                title
                            )}

                        </div>


                        <div class="message-text">

                            ${escapeHtml(
                                text
                            )}

                        </div>

                    </div>

                </div>

            `;

        }


        /*
        ========================================
        PAGE ERROR
        ========================================
        */

        function showError(
            text
        ) {

            bookingLayout.classList.remove(
                'active'
            );


            pageState.style.display =
                'flex';


            pageState.classList.add(
                'error'
            );


            pageState.innerHTML = `

                <div>

                    <strong>
                        BOOKING UNAVAILABLE
                    </strong>

                    <br><br>

                    ${escapeHtml(
                        text
                    )}

                    <br><br>

                    <a
                        href="events.php"
                        style="
                            color:#F6C58E;
                            font-weight:800;
                            text-decoration:none;
                        "
                    >
                        RETURN TO EVENTS
                    </a>

                </div>

            `;

        }


        /*
        ========================================
        DATE
        ========================================
        */

        function formatDate(
            value
        ) {

            if (!value) {

                return '-';

            }


            const parts =
                String(
                    value
                )
                .substring(
                    0,
                    10
                )
                .split(
                    '-'
                );


            if (
                parts.length !==
                3
            ) {

                return value;

            }


            const months =
                [
                    'JAN',
                    'FEB',
                    'MAR',
                    'APR',
                    'MAY',
                    'JUN',
                    'JUL',
                    'AUG',
                    'SEP',
                    'OCT',
                    'NOV',
                    'DEC'
                ];


            const monthIndex =
                Number(
                    parts[1]
                )
                -
                1;


            return (
                parts[2]
                +
                ' '
                +
                months[
                    monthIndex
                ]
                +
                ' '
                +
                parts[0]
            );

        }


        /*
        ========================================
        TIME
        ========================================
        */

        function formatTime(
            value
        ) {

            if (!value) {

                return '-';

            }


            return String(
                value
            ).substring(
                0,
                5
            );

        }


        /*
        ========================================
        SESSION
        ========================================
        */

        function clearSessionAndLogin() {

            localStorage.removeItem(
                'eventify_token'
            );


            localStorage.removeItem(
                'eventify_user'
            );


            window.location.href =
                'login.php';

        }


        /*
        ========================================
        ESCAPE
        ========================================
        */

        function escapeHtml(
            value
        ) {

            return String(
                value ?? ''
            )

            .replace(
                /&/g,
                '&amp;'
            )

            .replace(
                /</g,
                '&lt;'
            )

            .replace(
                />/g,
                '&gt;'
            )

            .replace(
                /"/g,
                '&quot;'
            )

            .replace(
                /'/g,
                '&#039;'
            );

        }

    </script>


</body>

</html>