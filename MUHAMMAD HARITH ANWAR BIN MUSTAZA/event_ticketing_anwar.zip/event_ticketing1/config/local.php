<?php
// Copy to config/local.php, then set your own 64-character random JWT secret.
// NEVER commit local.php to GitHub or share it with teammates.
return [
    'EVENTIFY_TICKET_SECRET' => 'a460417349690039677dbfbbc82812d828d137a653fbd822d0d2b406461ae852',
    'EVENTIFY_JWT_SECRET' => '76feb02fb6b7bf1087dc717885b9063aec5fb82bb150079bec1d9e9bd8409742',
    'EVENTIFY_INTERNAL_API_KEY' => '758369817bc9414d5e227a98f77580009350887d9b9272a6b45eb2f64ae925df',
    'EVENTIFY_DB_HOST' => '127.0.0.1',
    'EVENTIFY_DB_NAME' => 'event_ticketing_db',
    'EVENTIFY_DB_USER' => 'root', // local XAMPP only
    'EVENTIFY_DB_PASSWORD' => '', // local XAMPP only
];
