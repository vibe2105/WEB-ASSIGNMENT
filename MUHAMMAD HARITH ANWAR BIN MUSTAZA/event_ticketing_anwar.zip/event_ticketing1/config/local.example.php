<?php
// Copy to config/local.php, then set your own 64-character random JWT secret.
// NEVER commit local.php to GitHub or share it with teammates.
return [
    'EVENTIFY_TICKET_SECRET' => 'PASTE_A_DIFFERENT_RANDOM_64_CHARACTER_HEX_SECRET_HERE',
    'EVENTIFY_JWT_SECRET' => 'PASTE_YOUR_OWN_RANDOM_64_CHARACTER_HEX_SECRET_HERE',
    'EVENTIFY_INTERNAL_API_KEY' => 'PASTE_A_THIRD_RANDOM_64_CHARACTER_HEX_SECRET_HERE',
    'EVENTIFY_DB_HOST' => '127.0.0.1',
    'EVENTIFY_DB_NAME' => 'event_ticketing_db',
    'EVENTIFY_DB_USER' => 'root', // local XAMPP only
    'EVENTIFY_DB_PASSWORD' => '', // local XAMPP only
];
