<?php

/* ==========================================
   JWT CONFIGURATION
========================================== */

require_once __DIR__ . '/settings.php';

function eventifyJWTSecret() {
    $secret = (string) eventifySetting('EVENTIFY_JWT_SECRET', '');
    if (strlen($secret) < 32 || str_starts_with($secret, 'PASTE_')) {
        throw new RuntimeException('EVENTIFY_JWT_SECRET is not configured (minimum 32 characters).');
    }
    return $secret;
}

function eventifyTicketSecret() {
    $secret = (string) eventifySetting('EVENTIFY_TICKET_SECRET', '');
    if (strlen($secret) < 32 || str_starts_with($secret, 'PASTE_')) {
        throw new RuntimeException('EVENTIFY_TICKET_SECRET is not configured (minimum 32 characters).');
    }
    return $secret;
}

define(
    "JWT_EXPIRY",
    7200
);


/* ==========================================
   BASE64 URL ENCODE
========================================== */

function base64UrlEncode($data)
{
    return rtrim(
        strtr(
            base64_encode($data),
            "+/",
            "-_"
        ),
        "="
    );
}


/* ==========================================
   BASE64 URL DECODE
========================================== */

function base64UrlDecode($data)
{
    $remainder =
        strlen($data) % 4;

    if ($remainder) {

        $data .= str_repeat(
            "=",
            4 - $remainder
        );
    }

    return base64_decode(
        strtr(
            $data,
            "-_",
            "+/"
        )
    );
}


/* ==========================================
   CREATE JWT
========================================== */

function createJWT($user)
{
    $header = [
        "alg" => "HS256",
        "typ" => "JWT"
    ];


    $issuedAt = time();

    $expiration =
        $issuedAt + JWT_EXPIRY;


    $payload = [

        "user_id" =>
            intval(
                $user["user_id"]
            ),

        "name" =>
            $user["name"],

        "email" =>
            $user["email"],

        "role" =>
            $user["role"],

        "iat" =>
            $issuedAt,

        "exp" =>
            $expiration
    ];


    $headerEncoded =
        base64UrlEncode(
            json_encode($header)
        );


    $payloadEncoded =
        base64UrlEncode(
            json_encode($payload)
        );


    $signature =
        hash_hmac(
            "sha256",
            $headerEncoded .
            "." .
            $payloadEncoded,
            eventifyJWTSecret(),
            true
        );


    $signatureEncoded =
        base64UrlEncode(
            $signature
        );


    return
        $headerEncoded .
        "." .
        $payloadEncoded .
        "." .
        $signatureEncoded;
}


/* ==========================================
   VERIFY JWT
========================================== */

function verifyJWT($token)
{
    $parts =
        explode(
            ".",
            $token
        );


    if (count($parts) !== 3) {

        return false;
    }


    [
        $headerEncoded,
        $payloadEncoded,
        $signatureEncoded
    ] = $parts;


    // Disallow algorithm substitution and invalid JWT header types.
    $header = json_decode(base64UrlDecode($headerEncoded), true);
    if (!is_array($header) || ($header['alg'] ?? null) !== 'HS256'
        || ($header['typ'] ?? null) !== 'JWT') {
        return false;
    }

    if (!preg_match('/^[A-Za-z0-9_-]+$/D', $signatureEncoded)) return false;

    $expectedSignature =
        hash_hmac(
            "sha256",
            $headerEncoded .
            "." .
            $payloadEncoded,
            eventifyJWTSecret(),
            true
        );


    $providedSignature =
        base64UrlDecode(
            $signatureEncoded
        );


    if (!is_string($providedSignature) || !hash_equals($expectedSignature, $providedSignature)) {

        return false;
    }


    $payload =
        json_decode(
            base64UrlDecode(
                $payloadEncoded
            ),
            true
        );


    if (!is_array($payload)) {

        return false;
    }


    if (
        !isset($payload["exp"], $payload["user_id"]) ||
        !is_numeric($payload["exp"]) ||
        (int) $payload["exp"] <= time() ||
        filter_var($payload["user_id"], FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]) === false
    ) {

        return false;
    }


    return $payload;
}

?>