<?php
require_once __DIR__ . '/settings.php';
class Database {
    public $conn = null;

    public function getConnection() {
        try {
            $host = (string) eventifySetting('EVENTIFY_DB_HOST', '127.0.0.1');
            $name = (string) eventifySetting('EVENTIFY_DB_NAME', 'event_ticketing_db');
            $user = (string) eventifySetting('EVENTIFY_DB_USER', 'root');
            $password = (string) eventifySetting('EVENTIFY_DB_PASSWORD', '');
            $dsn = 'mysql:host=' . $host . ';dbname=' . $name . ';charset=utf8mb4';
            $this->conn = new PDO($dsn, $user, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $error) {
            // Never send DSN, MySQL credentials or SQL details to API clients.
            error_log('Eventify database connection: ' . $error->getMessage());
            $this->conn = null;
        }
        return $this->conn;
    }
}
