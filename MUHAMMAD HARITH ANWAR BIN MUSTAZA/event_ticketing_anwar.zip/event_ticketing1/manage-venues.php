<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta

        name="viewport"

        content="width=device-width, initial-scale=1.0"

    >

    <title>Manage Venues | Eventify</title>

    <link

        rel="stylesheet"

        href="css/style.css"

    >

    <style>

        body {

            background: #f5f5fa;

        }

        /* ======================================

           HERO

        ====================================== */

        .venue-hero {

            padding: 55px 0;

            color: white;

            background:

                radial-gradient(

                    circle at 82% 15%,

                    rgba(117,89,255,.27),

                    transparent 35%

                ),

                linear-gradient(

                    135deg,

                    #11101d,

                    #211943

                );

        }

        .venue-hero-content {

            display: flex;

            justify-content: space-between;

            align-items: end;

            gap: 25px;

        }

        .venue-hero .eyebrow {

            color: #a997ff;

        }

        .venue-hero h1 {

            font-family: "Manrope", sans-serif;

            font-size: 48px;

            letter-spacing: -2px;

            margin-top: 8px;

        }

        .venue-hero p {

            color: #aaa6b8;

            margin-top: 9px;

        }

        .new-venue-btn {

            padding: 14px 20px;

            border: none;

            border-radius: 11px;

            background: #7559ff;

            color: white;

            cursor: pointer;

            font-weight: 800;

            transition: .25s;

        }

        .new-venue-btn:hover {

            background: #6449e8;

            transform: translateY(-2px);

        }

        /* ======================================

           CONTENT

        ====================================== */

        .venue-section {

            padding: 45px 0 100px;

        }

        .venue-stats {

            display: grid;

            grid-template-columns:

                repeat(4, 1fr);

            gap: 18px;

            margin-bottom: 30px;

        }

        .venue-stat {

            padding: 22px;

            background: white;

            border: 1px solid #e8e6ee;

            border-radius: 16px;

            box-shadow:

                0 12px 30px

                rgba(24,20,50,.035);

        }

        .venue-stat span {

            color: #9995a4;

            font-size: 10px;

            font-weight: 700;

            letter-spacing: .8px;

            text-transform: uppercase;

        }

        .venue-stat strong {

            display: block;

            margin-top: 7px;

            font-family: "Manrope", sans-serif;

            font-size: 28px;

        }

        /* ======================================

           TOOLBAR

        ====================================== */

        .venue-toolbar {

            display: flex;

            gap: 12px;

            padding: 17px;

            margin-bottom: 22px;

            background: white;

            border: 1px solid #e8e6ee;

            border-radius: 15px;

        }

        .venue-toolbar input {

            flex: 1;

            height: 47px;

            padding: 0 15px;

            border: 1px solid #e3e1e8;

            border-radius: 10px;

            outline: none;

            font-family: inherit;

        }

        .venue-toolbar input:focus {

            border-color: #9c8bf5;

        }

        .venue-toolbar select {

            min-width: 180px;

            height: 47px;

            padding: 0 13px;

            background: white;

            border: 1px solid #e3e1e8;

            border-radius: 10px;

        }

        /* ======================================

           CARDS

        ====================================== */

        .venue-grid {

            display: grid;

            grid-template-columns:

                repeat(3, 1fr);

            gap: 22px;

        }

        .venue-card {

            overflow: hidden;

            background: white;

            border: 1px solid #e8e6ee;

            border-radius: 18px;

            box-shadow:

                0 14px 35px

                rgba(24,20,50,.05);

            transition: .3s;

        }

        .venue-card:hover {

            transform: translateY(-5px);

            box-shadow:

                0 22px 45px

                rgba(24,20,50,.09);

        }

        .venue-cover {

            height: 145px;

            position: relative;

            overflow: hidden;

            display: flex;

            align-items: center;

            justify-content: center;

            background:

                radial-gradient(

                    circle at 75% 20%,

                    rgba(155,132,255,.4),

                    transparent 35%

                ),

                linear-gradient(

                    135deg,

                    #17152a,

                    #3a2c78

                );

        }

        .venue-cover::before {

            content: "";

            position: absolute;

            width: 170px;

            height: 170px;

            border-radius: 50%;

            border:

                1px solid

                rgba(255,255,255,.12);

            right: -55px;

            top: -70px;

        }

        .venue-symbol {

            color:

                rgba(255,255,255,.8);

            font-size: 42px;

            font-weight: 800;

        }

        .venue-status {

            position: absolute;

            left: 15px;

            top: 15px;

            padding: 6px 10px;

            border-radius: 100px;

            font-size: 9px;

            font-weight: 800;

            backdrop-filter: blur(8px);

        }

        .venue-available {

            color: #dffbed;

            background:

                rgba(32,137,97,.36);

            border:

                1px solid

                rgba(141,239,200,.2);

        }

        .venue-unavailable {

            color: #ffdada;

            background:

                rgba(184,65,65,.35);

            border:

                1px solid

                rgba(255,170,170,.2);

        }

        .venue-content {

            padding: 22px;

        }

        .venue-content h3 {

            min-height: 47px;

            font-family: "Manrope", sans-serif;

            font-size: 19px;

            line-height: 1.4;

        }

        .venue-location {

            color: #817d8c;

            font-size: 12px;

            margin-top: 9px;

            min-height: 35px;

        }

        .venue-information {

            display: grid;

            grid-template-columns:

                repeat(2, 1fr);

            gap: 10px;

            margin-top: 19px;

        }

        .venue-info-box {

            padding: 12px;

            background: #f8f7fb;

            border: 1px solid #eeecf2;

            border-radius: 10px;

        }

        .venue-info-box small {

            display: block;

            color: #9995a4;

            font-size: 9px;

            text-transform: uppercase;

            letter-spacing: .5px;

        }

        .venue-info-box strong {

            display: block;

            margin-top: 4px;

            font-size: 14px;

        }

        .venue-actions {

            display: flex;

            gap: 9px;

            margin-top: 20px;

            padding-top: 18px;

            border-top:

                1px solid #efedf3;

        }

        .venue-actions button {

            flex: 1;

            padding: 10px;

            border: none;

            border-radius: 9px;

            cursor: pointer;

            font-size: 11px;

            font-weight: 800;

        }

        .venue-edit {

            color: #654be0;

            background: #eeeaff;

        }

        .venue-delete {

            color: #b64545;

            background: #fff0f0;

        }

        .empty-venues {

            grid-column: 1 / -1;

            min-height: 260px;

            display: flex;

            justify-content: center;

            align-items: center;

            background: white;

            border: 1px solid #e8e6ee;

            border-radius: 18px;

            color: #898595;

        }

        /* ======================================

           MODAL

        ====================================== */

        .modal-overlay {

            position: fixed;

            inset: 0;

            z-index: 5000;

            display: none;

            align-items: center;

            justify-content: center;

            padding: 20px;

            background:

                rgba(10,9,17,.7);

            backdrop-filter: blur(6px);

        }

        .modal-overlay.show {

            display: flex;

        }

        .venue-modal {

            width: min(570px, 100%);

            background: white;

            border-radius: 22px;

            box-shadow:

                0 35px 90px

                rgba(0,0,0,.3);

            overflow: hidden;

        }

        .venue-modal-header {

            padding: 25px 27px;

            display: flex;

            justify-content: space-between;

            align-items: center;

            border-bottom:

                1px solid #eeecf2;

        }

        .venue-modal-header span {

            color: #7559ff;

            font-size: 10px;

            font-weight: 800;

            letter-spacing: 1.4px;

        }

        .venue-modal-header h2 {

            margin-top: 5px;

            font-family: "Manrope", sans-serif;

        }

        .close-modal {

            width: 36px;

            height: 36px;

            border: none;

            border-radius: 9px;

            cursor: pointer;

            background: #f3f2f6;

            font-size: 18px;

        }

        .venue-form {

            padding: 27px;

        }

        .venue-form-group {

            margin-bottom: 18px;

        }

        .venue-form-group label {

            display: block;

            margin-bottom: 7px;

            color: #4e4a59;

            font-size: 11px;

            font-weight: 700;

        }

        .venue-form-group input,

        .venue-form-group select {

            width: 100%;

            height: 49px;

            padding: 0 13px;

            border: 1px solid #e2e0e8;

            border-radius: 10px;

            background: #fafafd;

            outline: none;

            font-family: inherit;

        }

        .venue-form-group input:focus,

        .venue-form-group select:focus {

            border-color: #9d8cf5;

            background: white;

            box-shadow:

                0 0 0 4px

                rgba(117,89,255,.07);

        }

        .venue-form-grid {

            display: grid;

            grid-template-columns:

                1fr 1fr;

            gap: 15px;

        }

        .venue-form-actions {

            display: flex;

            justify-content: flex-end;

            gap: 10px;

            padding-top: 20px;

            border-top:

                1px solid #efedf3;

        }

        .venue-cancel-btn,

        .venue-save-btn {

            padding: 12px 18px;

            border: none;

            border-radius: 9px;

            cursor: pointer;

            font-weight: 700;

        }

        .venue-cancel-btn {

            background: #f1f0f5;

            color: #5d5968;

        }

        .venue-save-btn {

            background: #7559ff;

            color: white;

        }

        .venue-save-btn:disabled {

            opacity: .6;

            cursor: not-allowed;

        }

        .form-message {

            display: none;

            padding: 12px 14px;

            margin-bottom: 18px;

            border-radius: 9px;

            font-size: 11px;

        }

        .form-message.error {

            display: block;

            color: #ae4141;

            background: #fff0f0;

        }

        .form-message.success {

            display: block;

            color: #187858;

            background: #edf9f4;

        }

        /* DELETE */

        .delete-modal {

            width: min(420px, 100%);

            padding: 32px;

            text-align: center;

            background: white;

            border-radius: 20px;

        }

        .delete-modal-icon {

            width: 58px;

            height: 58px;

            display: grid;

            place-items: center;

            margin: auto;

            border-radius: 50%;

            background: #fff0f0;

            color: #b84545;

            font-size: 24px;

        }

        .delete-modal h2 {

            margin-top: 17px;

            font-family: "Manrope", sans-serif;

        }

        .delete-modal p {

            margin-top: 9px;

            color: #807c8d;

            font-size: 12px;

            line-height: 1.6;

        }

        .delete-buttons {

            display: flex;

            gap: 10px;

            margin-top: 24px;

        }

        .delete-buttons button {

            flex: 1;

            padding: 12px;

            border: none;

            border-radius: 9px;

            cursor: pointer;

            font-weight: 700;

        }

        .confirm-delete {

            background: #c34848;

            color: white;

        }

        /* TOAST */

        .toast {

            position: fixed;

            z-index: 7000;

            right: 25px;

            bottom: 25px;

            min-width: 280px;

            padding: 15px 19px;

            color: white;

            border-radius: 11px;

            opacity: 0;

            transform: translateY(80px);

            pointer-events: none;

            box-shadow:

                0 18px 45px

                rgba(0,0,0,.2);

            transition: .3s;

            font-size: 12px;

        }

        .toast.show {

            opacity: 1;

            transform: translateY(0);

        }

        .toast.success {

            background: #207b5c;

        }

        .toast.error {

            background: #b34343;

        }

        @media (max-width: 950px) {

            .venue-grid {

                grid-template-columns:

                    repeat(2, 1fr);

            }

            .venue-stats {

                grid-template-columns:

                    repeat(2, 1fr);

            }

        }

        @media (max-width: 650px) {

            .venue-hero-content {

                flex-direction: column;

                align-items: flex-start;

            }

            .venue-grid,

            .venue-stats,

            .venue-form-grid {

                grid-template-columns: 1fr;

            }

            .venue-toolbar {

                flex-direction: column;

            }

            .venue-toolbar input,

            .venue-toolbar select {

                width: 100%;

            }

        }

    
        /* Prevent displaying venue controls until authentication is checked. */
        body.venue-access-pending .venue-hero,
        body.venue-access-pending .venue-section {
            visibility: hidden;
        }

    </style>

</head>

<body class="venue-access-pending">

<!-- NAVBAR -->

<header class="navbar">

    <div class="container nav-container">

        <a

            href="index.php"

            class="brand"

        >

            <div class="brand-icon">

                E

            </div>

            <span>

                Event<span class="brand-purple">ify</span>

            </span>

        </a>

        <nav class="nav-links">

            <a href="dashboard.php">

                Dashboard

            </a>

            <a href="manage-events.php">

                Manage Events

            </a>

            <a

                href="manage-venues.php"

                class="active"

            >

                Manage Venues

            </a>

            <a href="events.php">

                Website

            </a>

        </nav>

        <div

            class="nav-actions"

            id="authNavigation"

        >

        </div>

    </div>

</header>

<!-- HERO -->

<section class="venue-hero">

    <div

        class="

            container

            venue-hero-content

        "

    >

        <div>

            <span class="eyebrow">

                VENUE MANAGEMENT

            </span>

            <h1>

                Manage Venues

            </h1>

            <p>

                Create and maintain locations

                used by your events.

            </p>

        </div>

        <button

            type="button"

            class="new-venue-btn"

            id="newVenueButton"

        >

            + Add New Venue

        </button>

    </div>

</section>

<!-- CONTENT -->

<main class="venue-section">

    <div class="container">

        <!-- STATS -->

        <section class="venue-stats">

            <article class="venue-stat">

                <span>

                    Total Venues

                </span>

                <strong id="totalVenues">

                    0

                </strong>

            </article>

            <article class="venue-stat">

                <span>

                    Available

                </span>

                <strong id="availableVenues">

                    0

                </strong>

            </article>

            <article class="venue-stat">

                <span>

                    Unavailable

                </span>

                <strong id="unavailableVenues">

                    0

                </strong>

            </article>

            <article class="venue-stat">

                <span>

                    Total Capacity

                </span>

                <strong id="totalCapacity">

                    0

                </strong>

            </article>

        </section>

        <!-- SEARCH -->

        <section class="venue-toolbar">

            <input

                type="text"

                id="venueSearch"

                placeholder="Search venue name or location..."

            >

            <select id="venueStatusFilter">

                <option value="">

                    All Statuses

                </option>

                <option value="Available">

                    Available

                </option>

                <option value="Unavailable">

                    Unavailable

                </option>

            </select>

        </section>

        <!-- VENUES -->

        <section

            class="venue-grid"

            id="venueGrid"

        >

            <div class="empty-venues">

                Loading venues...

            </div>

        </section>

    </div>

</main>

<!-- CREATE / EDIT MODAL -->

<div

    class="modal-overlay"

    id="venueModal"

>

    <div class="venue-modal">

        <div class="venue-modal-header">

            <div>

                <span id="venueModalEyebrow">

                    CREATE VENUE

                </span>

                <h2 id="venueModalTitle">

                    New Venue

                </h2>

            </div>

            <button

                type="button"

                class="close-modal"

                id="closeVenueModal"

            >

                ×

            </button>

        </div>

        <form

            class="venue-form"

            id="venueForm"

        >

            <input

                type="hidden"

                id="venueId"

            >

            <div

                class="form-message"

                id="venueFormMessage"

            >

            </div>

            <div class="venue-form-group">

                <label for="venueName">

                    Venue Name

                </label>

                <input

                    type="text"

                    id="venueName"

                    placeholder="Example: Eventify Convention Centre"

                    required

                >

            </div>

            <div class="venue-form-group">

                <label for="venueLocation">

                    Location

                </label>

                <input

                    type="text"

                    id="venueLocation"

                    placeholder="Example: Kuala Lumpur"

                    required

                >

            </div>

            <div class="venue-form-grid">

                <div class="venue-form-group">

                    <label for="venueCapacity">

                        Capacity

                    </label>

                    <input

                        type="number"

                        id="venueCapacity"

                        min="1"

                        placeholder="500"

                        required

                    >

                </div>

                <div class="venue-form-group">

                    <label for="venueStatus">

                        Status

                    </label>

                    <select

                        id="venueStatus"

                        required

                    >

                        <option value="Available">

                            Available

                        </option>

                        <option value="Unavailable">

                            Unavailable

                        </option>

                    </select>

                </div>

            </div>

            <div class="venue-form-actions">

                <button

                    type="button"

                    class="venue-cancel-btn"

                    id="cancelVenueButton"

                >

                    Cancel

                </button>

                <button

                    type="submit"

                    class="venue-save-btn"

                    id="saveVenueButton"

                >

                    Create Venue

                </button>

            </div>

        </form>

    </div>

</div>

<!-- DELETE MODAL -->

<div

    class="modal-overlay"

    id="deleteVenueModal"

>

    <div class="delete-modal">

        <div class="delete-modal-icon">

            !

        </div>

        <h2>

            Delete Venue?

        </h2>

        <p id="deleteVenueText">

            The venue will be permanently removed.

        </p>

        <div class="delete-buttons">

            <button

                type="button"

                class="venue-cancel-btn"

                id="keepVenueButton"

            >

                Keep Venue

            </button>

            <button

                type="button"

                class="confirm-delete"

                id="confirmVenueDelete"

            >

                Delete Venue

            </button>

        </div>

    </div>

</div>

<div

    class="toast"

    id="toast"

>

</div>

<script>

/* =========================================

   VARIABLES

========================================= */

const token =

    localStorage.getItem(

        "eventify_token"

    );

let currentUser =

    null;

let venues =

    [];

let formMode =

    "create";

let deleteVenueId =

    null;

const venueGrid =

    document.getElementById(

        "venueGrid"

    );

const venueModal =

    document.getElementById(

        "venueModal"

    );

const deleteVenueModal =

    document.getElementById(

        "deleteVenueModal"

    );

const venueForm =

    document.getElementById(

        "venueForm"

    );

const formMessage =

    document.getElementById(

        "venueFormMessage"

    );

const saveVenueButton =

    document.getElementById(

        "saveVenueButton"

    );

const toast =

    document.getElementById(

        "toast"

    );

/* =========================================

   INITIALISE

========================================= */

async function initialise() {

    if (!token) {

        window.location.href =

            "login.php";

        return;

    }

    try {

        const authResponse =

            await fetch(

                "auth/me.php",

                {

                    headers: {

                        Authorization:

                            "Bearer "

                            + token

                    }

                }

            );

        const authResult =

            await authResponse.json();

        if (

            !authResponse.ok ||

            authResult.status

            !== "success"

        ) {

            logout();

            return;

        }

        currentUser =

            authResult.user;

        // Venue management is reserved for Administrators.
        // Organisers choose an existing venue on Manage Events instead.
        if (currentUser.role !== "Administrator") {

            alert("Only Administrators can manage venues.");

            window.location.replace(
                currentUser.role === "Organiser"
                    ? "dashboard.php"
                    : "events.php"
            );

            return;
        }

        // Reveal the management tools only after the JWT and role are verified.
        document.body.classList.remove("venue-access-pending");

        updateNavbar();

        await loadVenues();

    } catch (error) {

        showToast(

            "Unable to load venue management.",

            "error"

        );

    }

}

/* =========================================

   LOAD VENUES

========================================= */

async function loadVenues() {

    const response =

        await fetch(

            "api/venues.php"

        );

    const result =

        await response.json();

    if (

        !response.ok ||

        result.status !== "success"

    ) {

        throw new Error(

            result.message ||

            "Unable to load venues"

        );

    }

    venues =

        result.data;

    displayVenues(

        venues

    );

    updateStats();

}

/* =========================================

   DISPLAY

========================================= */

function displayVenues(

    venueList

) {

    venueGrid.innerHTML =

        "";

    if (

        venueList.length === 0

    ) {

        venueGrid.innerHTML = `

            <div class="empty-venues">

                No venues found.

            </div>

        `;

        return;

    }

    venueList.forEach(

        venue => {

            const available =

                venue.status

                === "Available";

            const card =

                document.createElement(

                    "article"

                );

            card.className =

                "venue-card";

            card.innerHTML = `

                <div class="venue-cover">

                    <span

                        class="

                            venue-status

                            ${

                                available

                                ?

                                "venue-available"

                                :

                                "venue-unavailable"

                            }

                        "

                    >

                        ${escapeHTML(

                            venue.status

                        )}

                    </span>

                    <div class="venue-symbol">

                        ⌖

                    </div>

                </div>

                <div class="venue-content">

                    <h3>

                        ${escapeHTML(

                            venue.venue_name

                        )}

                    </h3>

                    <p class="venue-location">

                        ⌖

                        ${escapeHTML(

                            venue.location

                        )}

                    </p>

                    <div class="venue-information">

                        <div class="venue-info-box">

                            <small>

                                Capacity

                            </small>

                            <strong>

                                ${Number(

                                    venue.capacity

                                ).toLocaleString()}

                            </strong>

                        </div>

                        <div class="venue-info-box">

                            <small>

                                Events

                            </small>

                            <strong>

                                ${Number(

                                    venue.event_count

                                )}

                            </strong>

                        </div>

                    </div>

                    <div class="venue-actions">

                        <button

                            type="button"

                            class="venue-edit"

                            onclick="

                                editVenue(

                                    ${venue.venue_id}

                                )

                            "

                        >

                            Edit Venue

                        </button>

                        <button

                            type="button"

                            class="venue-delete"

                            onclick="

                                askDeleteVenue(

                                    ${venue.venue_id}

                                )

                            "

                        >

                            Delete

                        </button>

                    </div>

                </div>

            `;

            venueGrid.appendChild(

                card

            );

        }

    );

}

/* =========================================

   STATS

========================================= */

function updateStats() {

    const available =

        venues.filter(

            venue =>

                venue.status

                === "Available"

        ).length;

    const unavailable =

        venues.filter(

            venue =>

                venue.status

                === "Unavailable"

        ).length;

    const capacity =

        venues.reduce(

            (

                total,

                venue

            ) =>

                total +

                Number(

                    venue.capacity

                ),

            0

        );

    document

        .getElementById(

            "totalVenues"

        )

        .textContent =

            venues.length;

    document

        .getElementById(

            "availableVenues"

        )

        .textContent =

            available;

    document

        .getElementById(

            "unavailableVenues"

        )

        .textContent =

            unavailable;

    document

        .getElementById(

            "totalCapacity"

        )

        .textContent =

            capacity

                .toLocaleString();

}

/* =========================================

   CREATE

========================================= */

document

    .getElementById(

        "newVenueButton"

    )

    .addEventListener(

        "click",

        openCreateVenue

    );

function openCreateVenue() {

    formMode =

        "create";

    venueForm.reset();

    document

        .getElementById(

            "venueId"

        )

        .value =

            "";

    document

        .getElementById(

            "venueModalEyebrow"

        )

        .textContent =

            "CREATE VENUE";

    document

        .getElementById(

            "venueModalTitle"

        )

        .textContent =

            "New Venue";

    saveVenueButton.textContent =

        "Create Venue";

    clearFormMessage();

    venueModal

        .classList

        .add(

            "show"

        );

}

/* =========================================

   EDIT

========================================= */

function editVenue(

    venueId

) {

    const venue =

        venues.find(

            item =>

                Number(

                    item.venue_id

                )

                ===

                Number(venueId)

        );

    if (!venue) {

        return;

    }

    formMode =

        "edit";

    document

        .getElementById(

            "venueId"

        )

        .value =

            venue.venue_id;

    document

        .getElementById(

            "venueName"

        )

        .value =

            venue.venue_name;

    document

        .getElementById(

            "venueLocation"

        )

        .value =

            venue.location;

    document

        .getElementById(

            "venueCapacity"

        )

        .value =

            venue.capacity;

    document

        .getElementById(

            "venueStatus"

        )

        .value =

            venue.status;

    document

        .getElementById(

            "venueModalEyebrow"

        )

        .textContent =

            "EDIT VENUE";

    document

        .getElementById(

            "venueModalTitle"

        )

        .textContent =

            "Update Venue";

    saveVenueButton.textContent =

        "Save Changes";

    clearFormMessage();

    venueModal

        .classList

        .add(

            "show"

        );

}

/* =========================================

   SAVE CREATE / EDIT

========================================= */

venueForm.addEventListener(

    "submit",

    async function (

        event

    ) {

        event.preventDefault();

        const payload = {

            venue_name:

                document

                    .getElementById(

                        "venueName"

                    )

                    .value

                    .trim(),

            location:

                document

                    .getElementById(

                        "venueLocation"

                    )

                    .value

                    .trim(),

            capacity:

                Number(

                    document

                        .getElementById(

                            "venueCapacity"

                        )

                        .value

                ),

            status:

                document

                    .getElementById(

                        "venueStatus"

                    )

                    .value

        };

        if (

            formMode === "edit"

        ) {

            payload.venue_id =

                Number(

                    document

                        .getElementById(

                            "venueId"

                        )

                        .value

                );

        }

        saveVenueButton.disabled =

            true;

        saveVenueButton.textContent =

            formMode === "create"

            ?

            "Creating..."

            :

            "Saving...";

        try {

            const response =

                await fetch(

                    "api/venues.php",

                    {

                        method:

                            formMode ===

                            "create"

                            ?

                            "POST"

                            :

                            "PUT",

                        headers: {

                            "Content-Type":

                                "application/json",

                            Authorization:

                                "Bearer "

                                + token

                        },

                        body:

                            JSON.stringify(

                                payload

                            )

                    }

                );

            const result =

                await response.json();

            if (

                response.status ===

                401

            ) {

                logout();

                return;

            }

            if (

                !response.ok ||

                result.status !==

                "success"

            ) {

                throw new Error(

                    result.message ||

                    "Unable to save venue"

                );

            }

            showFormMessage(

                result.message,

                "success"

            );

            await loadVenues();

            setTimeout(

                function () {

                    venueModal

                        .classList

                        .remove(

                            "show"

                        );

                    showToast(

                        result.message,

                        "success"

                    );

                },

                600

            );

        } catch (error) {

            showFormMessage(

                error.message,

                "error"

            );

        } finally {

            saveVenueButton.disabled =

                false;

            saveVenueButton.textContent =

                formMode === "create"

                ?

                "Create Venue"

                :

                "Save Changes";

        }

    }

);

/* =========================================

   DELETE

========================================= */

function askDeleteVenue(

    venueId

) {

    deleteVenueId =

        venueId;

    const venue =

        venues.find(

            item =>

                Number(

                    item.venue_id

                )

                ===

                Number(venueId)

        );

    document

        .getElementById(

            "deleteVenueText"

        )

        .textContent =

            venue

            ?

            'Delete "'

            +

            venue.venue_name

            +

            '"? A venue assigned to an event cannot be deleted.'

            :

            "Delete this venue?";

    deleteVenueModal

        .classList

        .add(

            "show"

        );

}

document

    .getElementById(

        "confirmVenueDelete"

    )

    .addEventListener(

        "click",

        async function () {

            if (!deleteVenueId) {

                return;

            }

            this.disabled =

                true;

            this.textContent =

                "Deleting...";

            try {

                const response =

                    await fetch(

                        "api/venues.php",

                        {

                            method:

                                "DELETE",

                            headers: {

                                "Content-Type":

                                    "application/json",

                                Authorization:

                                    "Bearer "

                                    + token

                            },

                            body:

                                JSON.stringify({

                                    venue_id:

                                        deleteVenueId

                                })

                        }

                    );

                const result =

                    await response.json();

                if (

                    !response.ok ||

                    result.status !==

                    "success"

                ) {

                    throw new Error(

                        result.message ||

                        "Unable to delete venue"

                    );

                }

                deleteVenueModal

                    .classList

                    .remove(

                        "show"

                    );

                deleteVenueId =

                    null;

                await loadVenues();

                showToast(

                    result.message,

                    "success"

                );

            } catch (error) {

                deleteVenueModal

                    .classList

                    .remove(

                        "show"

                    );

                showToast(

                    error.message,

                    "error"

                );

            } finally {

                this.disabled =

                    false;

                this.textContent =

                    "Delete Venue";

            }

        }

    );

/* =========================================

   SEARCH

========================================= */

document

    .getElementById(

        "venueSearch"

    )

    .addEventListener(

        "input",

        filterVenues

    );

document

    .getElementById(

        "venueStatusFilter"

    )

    .addEventListener(

        "change",

        filterVenues

    );

function filterVenues() {

    const search =

        document

            .getElementById(

                "venueSearch"

            )

            .value

            .toLowerCase();

    const status =

        document

            .getElementById(

                "venueStatusFilter"

            )

            .value;

    const filtered =

        venues.filter(

            venue => {

                const searchText =

                    (

                        venue.venue_name

                        + " "

                        + venue.location

                    )

                    .toLowerCase();

                const searchMatch =

                    searchText

                        .includes(

                            search

                        );

                const statusMatch =

                    status === ""

                    ||

                    venue.status

                    === status;

                return (

                    searchMatch &&

                    statusMatch

                );

            }

        );

    displayVenues(

        filtered

    );

}

/* =========================================

   MODAL

========================================= */

function closeVenueModal() {

    venueModal

        .classList

        .remove(

            "show"

        );

}

document

    .getElementById(

        "closeVenueModal"

    )

    .addEventListener(

        "click",

        closeVenueModal

    );

document

    .getElementById(

        "cancelVenueButton"

    )

    .addEventListener(

        "click",

        closeVenueModal

    );

document

    .getElementById(

        "keepVenueButton"

    )

    .addEventListener(

        "click",

        function () {

            deleteVenueId =

                null;

            deleteVenueModal

                .classList

                .remove(

                    "show"

                );

        }

    );

/* =========================================

   FORM MESSAGE

========================================= */

function clearFormMessage() {

    formMessage.className =

        "form-message";

    formMessage.textContent =

        "";

}

function showFormMessage(

    message,

    type

) {

    formMessage.textContent =

        message;

    formMessage.className =

        "form-message "

        +

        type;

}

/* =========================================

   NAVBAR

========================================= */

function updateNavbar() {

    document

        .getElementById(

            "authNavigation"

        )

        .innerHTML = `

            <span

                style="

                    color:#555263;

                    font-size:13px;

                    font-weight:700;

                "

            >

                ${escapeHTML(

                    currentUser.name

                )}

                <small

                    style="

                        color:#9995a4;

                    "

                >

                    (${escapeHTML(

                        currentUser.role

                    )})

                </small>

            </span>

            <button

                type="button"

                onclick="logout()"

                style="

                    border:none;

                    padding:11px 17px;

                    border-radius:9px;

                    background:#11101d;

                    color:white;

                    cursor:pointer;

                    font-weight:700;

                "

            >

                Logout

            </button>

        `;

}

/* =========================================

   LOGOUT

========================================= */

function logout() {

    localStorage.removeItem(

        "eventify_token"

    );

    localStorage.removeItem(

        "eventify_user"

    );

    window.location.href =

        "login.php";

}

/* =========================================

   TOAST

========================================= */

function showToast(

    message,

    type

) {

    toast.textContent =

        message;

    toast.className =

        "toast "

        +

        type

        +

        " show";

    setTimeout(

        function () {

            toast

                .classList

                .remove(

                    "show"

                );

        },

        3500

    );

}

/* =========================================

   ESCAPE

========================================= */

function escapeHTML(

    value

) {

    return String(

        value ?? ""

    )

        .replaceAll(

            "&",

            "&amp;"

        )

        .replaceAll(

            "<",

            "&lt;"

        )

        .replaceAll(

            ">",

            "&gt;"

        )

        .replaceAll(

            '"',

            "&quot;"

        )

        .replaceAll(

            "'",

            "&#039;"

        );

}

/* =========================================

   START

========================================= */

initialise();

</script>

</body>

</html>