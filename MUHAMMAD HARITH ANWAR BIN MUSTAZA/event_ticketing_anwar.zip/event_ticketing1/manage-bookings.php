<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >
    <title>Manage Bookings | Eventify</title>
    <link
        rel="stylesheet"
        href="css/style.css"
    >
    <style>
        body {
            background: #f5f5fa;
        }
        /* =====================================
           HERO
        ===================================== */
        .booking-management-hero {
            padding: 55px 0;
            color: white;
            background:
                radial-gradient(
                    circle at 80% 15%,
                    rgba(117,89,255,.28),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #11101d,
                    #211943
                );
        }
        .booking-management-hero h1 {
            margin-top: 8px;
            font-family:
                "Manrope",
                sans-serif;
            font-size: 48px;
            letter-spacing: -2px;
        }
        .booking-management-hero p {
            margin-top: 9px;
            color: #aaa6b8;
        }
        .booking-management-hero
        .eyebrow {
            color: #a997ff;
        }
        /* =====================================
           SECTION
        ===================================== */
        .management-section {
            padding:
                45px 0 100px;
        }
        /* =====================================
           STATISTICS
        ===================================== */
        .booking-stats {
            display: grid;
            grid-template-columns:
                repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 30px;
        }
        .booking-stat {
            padding: 22px;
            background: white;
            border:
                1px solid #e8e6ee;
            border-radius: 16px;
            box-shadow:
                0 12px 30px
                rgba(24,20,50,.035);
        }
        .booking-stat span {
            color: #9995a4;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .8px;
        }
        .booking-stat strong {
            display: block;
            margin-top: 7px;
            font-family:
                "Manrope",
                sans-serif;
            font-size: 28px;
        }
        /* =====================================
           TOOLBAR
        ===================================== */
        .booking-toolbar {
            display: flex;
            gap: 12px;
            padding: 17px;
            margin-bottom: 22px;
            background: white;
            border:
                1px solid #e8e6ee;
            border-radius: 15px;
        }
        .booking-toolbar input {
            flex: 1;
            height: 48px;
            padding: 0 15px;
            border:
                1px solid #e3e1e8;
            border-radius: 10px;
            outline: none;
            font-family: inherit;
        }
        .booking-toolbar input:focus {
            border-color: #9987f4;
        }
        .booking-toolbar select {
            min-width: 190px;
            height: 48px;
            padding: 0 13px;
            border:
                1px solid #e3e1e8;
            border-radius: 10px;
            background: white;
        }
        /* =====================================
           TABLE
        ===================================== */
        .booking-table-card {
            overflow: hidden;
            background: white;
            border:
                1px solid #e8e6ee;
            border-radius: 18px;
            box-shadow:
                0 14px 35px
                rgba(24,20,50,.05);
        }
        .table-scroll {
            overflow-x: auto;
        }
        .booking-table {
            width: 100%;
            min-width: 1100px;
            border-collapse: collapse;
        }
        .booking-table th {
            padding: 15px 17px;
            text-align: left;
            background: #f8f7fb;
            color: #918e9d;
            border-bottom:
                1px solid #eceaf0;
            text-transform: uppercase;
            font-size: 9px;
            letter-spacing: .7px;
        }
        .booking-table td {
            padding: 18px 17px;
            border-bottom:
                1px solid #f0eef3;
            vertical-align: middle;
            font-size: 12px;
        }
        .booking-table tr:last-child td {
            border-bottom: none;
        }
        .customer-cell strong {
            display: block;
            color: #292633;
            font-size: 12px;
        }
        .customer-cell span {
            display: block;
            color: #9995a4;
            margin-top: 4px;
            font-size: 10px;
        }
        .event-cell {
            max-width: 200px;
        }
        .event-cell strong {
            display: block;
            color: #292633;
        }
        .event-cell span {
            display: block;
            margin-top: 4px;
            color: #9995a4;
            font-size: 10px;
        }
        /* =====================================
           STATUS
        ===================================== */
        .status-badge {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 100px;
            font-size: 9px;
            font-weight: 800;
        }
        .status-confirmed {
            color: #187c59;
            background: #eaf8f2;
        }
        .status-pending {
            color: #987010;
            background: #fff6df;
        }
        .status-cancelled {
            color: #b54a4a;
            background: #fff0f0;
        }
        /* =====================================
           ACTION BUTTON
        ===================================== */
        .manage-btn {
            padding: 9px 13px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            color: #654be0;
            background: #eeeaff;
            font-size: 10px;
            font-weight: 800;
        }
        .manage-btn:hover {
            background: #e1dcff;
        }
        .empty-bookings {
            padding: 70px;
            text-align: center;
            color: #898595;
        }
        /* =====================================
           MODAL
        ===================================== */
        .modal-overlay {
            position: fixed;
            inset: 0;
            z-index: 5000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background:
                rgba(10,9,17,.7);
            backdrop-filter: blur(6px);
        }
        .modal-overlay.show {
            display: flex;
        }
        .booking-modal {
            width:
                min(500px, 100%);
            overflow: hidden;
            background: white;
            border-radius: 22px;
            box-shadow:
                0 35px 90px
                rgba(0,0,0,.3);
        }
        .booking-modal-header {
            padding: 25px 27px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom:
                1px solid #eeecf2;
        }
        .booking-modal-header span {
            color: #7559ff;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 1.3px;
        }
        .booking-modal-header h2 {
            margin-top: 5px;
            font-family:
                "Manrope",
                sans-serif;
        }
        .close-modal {
            width: 36px;
            height: 36px;
            border: none;
            border-radius: 9px;
            background: #f2f1f5;
            cursor: pointer;
            font-size: 18px;
        }
        .booking-modal-body {
            padding: 27px;
        }
        .booking-summary {
            padding: 17px;
            margin-bottom: 22px;
            background: #f8f7fc;
            border:
                1px solid #eceaf2;
            border-radius: 12px;
        }
        .booking-summary strong {
            display: block;
            font-size: 14px;
        }
        .booking-summary span {
            display: block;
            margin-top: 6px;
            color: #888493;
            font-size: 11px;
            line-height: 1.6;
        }
        .status-field label {
            display: block;
            margin-bottom: 8px;
            color: #4e4a59;
            font-size: 11px;
            font-weight: 700;
        }
        .status-field select {
            width: 100%;
            height: 49px;
            padding: 0 13px;
            border:
                1px solid #e2e0e8;
            border-radius: 10px;
            outline: none;
            background: white;
        }
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 24px;
            padding-top: 20px;
            border-top:
                1px solid #efedf3;
        }
        .cancel-modal-btn,
        .save-status-btn {
            padding: 12px 17px;
            border: none;
            border-radius: 9px;
            cursor: pointer;
            font-weight: 700;
        }
        .cancel-modal-btn {
            background: #f1f0f5;
            color: #5d5968;
        }
        .save-status-btn {
            background: #7559ff;
            color: white;
        }
        .save-status-btn:disabled {
            opacity: .6;
            cursor: not-allowed;
        }
        .modal-message {
            display: none;
            margin-top: 15px;
            padding: 12px 14px;
            border-radius: 9px;
            font-size: 11px;
        }
        .modal-message.error {
            display: block;
            color: #ac4040;
            background: #fff0f0;
        }
        .modal-message.success {
            display: block;
            color: #197859;
            background: #edf9f4;
        }
        /* =====================================
           TOAST
        ===================================== */
        .toast {
            position: fixed;
            right: 25px;
            bottom: 25px;
            z-index: 7000;
            min-width: 280px;
            padding: 15px 19px;
            border-radius: 11px;
            color: white;
            opacity: 0;
            transform:
                translateY(80px);
            pointer-events: none;
            transition: .3s;
            font-size: 12px;
            box-shadow:
                0 18px 45px
                rgba(0,0,0,.2);
        }
        .toast.show {
            opacity: 1;
            transform:
                translateY(0);
        }
        .toast.success {
            background: #207b5c;
        }
        .toast.error {
            background: #b34343;
        }
        @media (max-width: 900px) {
            .booking-stats {
                grid-template-columns:
                    repeat(2, 1fr);
            }
            .booking-toolbar {
                flex-direction: column;
            }
            .booking-toolbar input,
            .booking-toolbar select {
                width: 100%;
            }
        }
        @media (max-width: 550px) {
            .booking-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<!-- NAVIGATION -->
<header class="navbar">
    <div class="container nav-container">
        <a
            href="index.php"
            class="brand"
        >
            <div class="brand-icon">
                E
            </div>
            <span>
                Event<span class="brand-purple">ify</span>
            </span>
        </a>
        <nav class="nav-links">
            <a href="dashboard.php">
                Dashboard
            </a>
            <a href="manage-events.php">
                Events
            </a>
            <a
                href="manage-venues.php"
                id="adminVenueLink"
                style="display: none;"
            >
                Venues
            </a>
            <a
                href="manage-bookings.php"
                class="active"
            >
                Bookings
            </a>
        </nav>
        <div
            class="nav-actions"
            id="authNavigation"
        >
        </div>
    </div>
</header>
<!-- HERO -->
<section class="booking-management-hero">
    <div class="container">
        <span class="eyebrow">
            RESERVATION MANAGEMENT
        </span>
        <h1>
            Manage Bookings
        </h1>
        <p id="pageDescription">
            Review and manage customer reservations.
        </p>
    </div>
</section>
<!-- CONTENT -->
<main class="management-section">
    <div class="container">
        <!-- STATISTICS -->
        <section class="booking-stats">
            <article class="booking-stat">
                <span>
                    Total Bookings
                </span>
                <strong id="totalBookings">
                    0
                </strong>
            </article>
            <article class="booking-stat">
                <span>
                    Confirmed
                </span>
                <strong id="confirmedBookings">
                    0
                </strong>
            </article>
            <article class="booking-stat">
                <span>
                    Cancelled
                </span>
                <strong id="cancelledBookings">
                    0
                </strong>
            </article>
            <article class="booking-stat">
                <span>
                    Confirmed Value
                </span>
                <strong id="confirmedValue">
                    RM 0.00
                </strong>
            </article>
        </section>
        <!-- FILTERS -->
        <section class="booking-toolbar">
            <input
                type="text"
                id="bookingSearch"
                placeholder="Search customer, event, venue or booking ID..."
            >
            <select id="bookingStatusFilter">
                <option value="">
                    All Statuses
                </option>
                <option value="Confirmed">
                    Confirmed
                </option>
                <option value="Pending">
                    Pending
                </option>
                <option value="Cancelled">
                    Cancelled
                </option>
            </select>
        </section>
        <!-- TABLE -->
        <section class="booking-table-card">
            <div class="table-scroll">
                <table class="booking-table">
                    <thead>
                        <tr>
                            <th>
                                Booking
                            </th>
                            <th>
                                Customer
                            </th>
                            <th>
                                Event
                            </th>
                            <th>
                                Tickets
                            </th>
                            <th>
                                Total
                            </th>
                            <th>
                                Status
                            </th>
                            <th>
                                Booking Date
                            </th>
                            <th>
                                Action
                            </th>
                        </tr>
                    </thead>
                    <tbody id="bookingTableBody">
                        <tr>
                            <td
                                colspan="8"
                                class="empty-bookings"
                            >
                                Loading bookings...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</main>
<!-- STATUS MODAL -->
<div
    class="modal-overlay"
    id="bookingModal"
>
    <div class="booking-modal">
        <div class="booking-modal-header">
            <div>
                <span>
                    MANAGE BOOKING
                </span>
                <h2>
                    Update Status
                </h2>
            </div>
            <button
                type="button"
                class="close-modal"
                id="closeBookingModal"
            >
                ×
            </button>
        </div>
        <div class="booking-modal-body">
            <div
                class="booking-summary"
                id="modalBookingSummary"
            >
            </div>
            <div class="status-field">
                <label for="newBookingStatus">
                    Booking Status
                </label>
                <select id="newBookingStatus">
                    <option value="Confirmed">
                        Confirmed
                    </option>
                    <option value="Cancelled">
                        Cancelled
                    </option>
                </select>
            </div>
            <div
                class="modal-message"
                id="modalMessage"
            >
            </div>
            <div class="modal-actions">
                <button
                    type="button"
                    class="cancel-modal-btn"
                    id="cancelModalButton"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="save-status-btn"
                    id="saveStatusButton"
                >
                    Save Status
                </button>
            </div>
        </div>
    </div>
</div>
<div
    class="toast"
    id="toast"
>
</div>
<script>
/* ========================================
   VARIABLES
======================================== */
const token =
    localStorage.getItem(
        "eventify_token"
    );
let currentUser =
    null;
let bookings =
    [];
let selectedBooking =
    null;
const bookingTableBody =
    document.getElementById(
        "bookingTableBody"
    );
const bookingModal =
    document.getElementById(
        "bookingModal"
    );
const modalMessage =
    document.getElementById(
        "modalMessage"
    );
const saveStatusButton =
    document.getElementById(
        "saveStatusButton"
    );
const toast =
    document.getElementById(
        "toast"
    );
/* ========================================
   INITIALISE
======================================== */
async function initialise() {
    if (!token) {
        window.location.href =
            "login.php";
        return;
    }
    try {
        const response =
            await fetch(
                "auth/me.php",
                {
                    headers: {
                        Authorization:
                            "Bearer " +
                            token
                    }
                }
            );
        const result =
            await response.json();
        if (
            !response.ok ||
            result.status !== "success"
        ) {
            logout();
            return;
        }
        currentUser =
            result.user;
        if (
            currentUser.role !==
            "Administrator"
            &&
            currentUser.role !==
            "Organiser"
        ) {
            alert(
                "You do not have permission to manage bookings."
            );
            window.location.href =
                "events.php";
            return;
        }
        updateNavbar();
        if (
            currentUser.role ===
            "Organiser"
        ) {
            document
                .getElementById(
                    "pageDescription"
                )
                .textContent =
                    "Review reservations for the events you organise.";
        }
        await loadBookings();
    } catch (error) {
        showToast(
            "Unable to load booking management.",
            "error"
        );
    }
}
/* ========================================
   LOAD BOOKINGS
======================================== */
async function loadBookings() {
    const response =
        await fetch(
            "api/bookings.php",
            {
                headers: {
                    Authorization:
                        "Bearer "
                        + token
                }
            }
        );
    const result =
        await response.json();
    if (
        response.status === 401
    ) {
        logout();
        return;
    }
    if (
        !response.ok ||
        result.status !== "success"
    ) {
        throw new Error(
            result.message ||
            "Unable to load bookings"
        );
    }
    bookings =
        result.data;
    displayBookings(
        bookings
    );
    updateStatistics();
}
/* ========================================
   DISPLAY BOOKINGS
======================================== */
function displayBookings(
    bookingList
) {
    bookingTableBody.innerHTML =
        "";
    if (
        bookingList.length === 0
    ) {
        bookingTableBody.innerHTML = `
            <tr>
                <td
                    colspan="8"
                    class="empty-bookings"
                >
                    No bookings found.
                </td>
            </tr>
        `;
        return;
    }
    bookingList.forEach(
        booking => {
            const eventDate =
                new Date(
                    booking.event_date
                    + "T00:00:00"
                );
            const eventDateText =
                eventDate.toLocaleDateString(
                    "en-MY",
                    {
                        day: "numeric",
                        month: "short",
                        year: "numeric"
                    }
                );
            const bookingDate =
                new Date(
                    String(
                        booking.booking_date
                    ).replace(
                        " ",
                        "T"
                    )
                );
            const bookingDateText =
                isNaN(
                    bookingDate.getTime()
                )
                ?
                booking.booking_date
                :
                bookingDate.toLocaleString(
                    "en-MY",
                    {
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                        hour: "numeric",
                        minute: "2-digit"
                    }
                );
            const row =
                document.createElement(
                    "tr"
                );
            row.innerHTML = `
                <td>
                    <strong>
                        #${booking.booking_id}
                    </strong>
                </td>
                <td>
                    <div class="customer-cell">
                        <strong>
                            ${escapeHTML(
                                booking.customer_name
                                || "Customer"
                            )}
                        </strong>
                        <span>
                            ${escapeHTML(
                                booking.customer_email
                                || ""
                            )}
                        </span>
                    </div>
                </td>
                <td>
                    <div class="event-cell">
                        <strong>
                            ${escapeHTML(
                                booking.event_name
                            )}
                        </strong>
                        <span>
                            ${eventDateText}
                            •
                            ${escapeHTML(
                                booking.venue_name
                            )}
                        </span>
                    </div>
                </td>
                <td>
                    ${Number(
                        booking.quantity
                    )}
                </td>
                <td>
                    <strong>
                        RM ${Number(
                            booking.total_amount
                        ).toFixed(2)}
                    </strong>
                </td>
                <td>
                    <span
                        class="
                            status-badge
                            ${getStatusClass(
                                booking.booking_status
                            )}
                        "
                    >
                        ${escapeHTML(
                            booking.booking_status
                        )}
                    </span>
                </td>
                <td>
                    ${bookingDateText}
                </td>
                <td>
                    <button
                        type="button"
                        class="manage-btn"
                        onclick="
                            openManageBooking(
                                ${booking.booking_id}
                            )
                        "
                    >
                        Manage
                    </button>
                </td>
            `;
            bookingTableBody
                .appendChild(
                    row
                );
        }
    );
}
/* ========================================
   STATISTICS
======================================== */
function updateStatistics() {
    const confirmed =
        bookings.filter(
            booking =>
                booking.booking_status
                === "Confirmed"
        );
    const cancelled =
        bookings.filter(
            booking =>
                booking.booking_status
                === "Cancelled"
        );
    const value =
        confirmed.reduce(
            (
                total,
                booking
            ) => {
                return total +
                    Number(
                        booking.total_amount
                    );
            },
            0
        );
    document
        .getElementById(
            "totalBookings"
        )
        .textContent =
            bookings.length;
    document
        .getElementById(
            "confirmedBookings"
        )
        .textContent =
            confirmed.length;
    document
        .getElementById(
            "cancelledBookings"
        )
        .textContent =
            cancelled.length;
    document
        .getElementById(
            "confirmedValue"
        )
        .textContent =
            "RM "
            + value.toFixed(2);
}
/* ========================================
   SEARCH AND FILTER
======================================== */
document
    .getElementById(
        "bookingSearch"
    )
    .addEventListener(
        "input",
        filterBookings
    );
document
    .getElementById(
        "bookingStatusFilter"
    )
    .addEventListener(
        "change",
        filterBookings
    );
function filterBookings() {
    const search =
        document
            .getElementById(
                "bookingSearch"
            )
            .value
            .toLowerCase();
    const status =
        document
            .getElementById(
                "bookingStatusFilter"
            )
            .value;
    const filtered =
        bookings.filter(
            booking => {
                const searchText =
                    (
                        booking.booking_id
                        + " "
                        + (
                            booking.customer_name
                            || ""
                        )
                        + " "
                        + (
                            booking.customer_email
                            || ""
                        )
                        + " "
                        + booking.event_name
                        + " "
                        + booking.venue_name
                    )
                    .toLowerCase();
                const searchMatch =
                    searchText.includes(
                        search
                    );
                const statusMatch =
                    status === ""
                    ||
                    booking.booking_status
                    === status;
                return (
                    searchMatch &&
                    statusMatch
                );
            }
        );
    displayBookings(
        filtered
    );
}
/* ========================================
   OPEN MANAGE MODAL
======================================== */
function openManageBooking(
    bookingId
) {
    selectedBooking =
        bookings.find(
            booking =>
                Number(
                    booking.booking_id
                )
                ===
                Number(
                    bookingId
                )
        );
    if (!selectedBooking) {
        return;
    }
    document
        .getElementById(
            "modalBookingSummary"
        )
        .innerHTML = `
            <strong>
                Booking
                #${selectedBooking.booking_id}
                —
                ${escapeHTML(
                    selectedBooking.event_name
                )}
            </strong>
            <span>
                Customer:
                ${escapeHTML(
                    selectedBooking.customer_name
                    || "Customer"
                )}
                <br>
                Quantity:
                ${selectedBooking.quantity}
                ticket(s)
                <br>
                Total:
                RM
                ${Number(
                    selectedBooking.total_amount
                ).toFixed(2)}
            </span>
        `;
    const statusSelect =
        document.getElementById(
            "newBookingStatus"
        );
    if (
        selectedBooking.booking_status
        === "Cancelled"
    ) {
        statusSelect.value =
            "Cancelled";
    } else {
        statusSelect.value =
            "Confirmed";
    }
    clearModalMessage();
    bookingModal
        .classList
        .add(
            "show"
        );
}
/* ========================================
   SAVE STATUS
======================================== */
saveStatusButton.addEventListener(
    "click",
    async function () {
        if (!selectedBooking) {
            return;
        }
        const newStatus =
            document
                .getElementById(
                    "newBookingStatus"
                )
                .value;
        saveStatusButton.disabled =
            true;
        saveStatusButton.textContent =
            "Saving...";
        try {
            const response =
                await fetch(
                    "api/bookings.php",
                    {
                        method: "PUT",
                        headers: {
                            "Content-Type":
                                "application/json",
                            Authorization:
                                "Bearer "
                                + token
                        },
                        body:
                            JSON.stringify({
                                booking_id:
                                    Number(
                                        selectedBooking.booking_id
                                    ),
                                booking_status:
                                    newStatus
                            })
                    }
                );
            const result =
                await response.json();
            if (
                response.status === 401
            ) {
                logout();
                return;
            }
            if (
                !response.ok ||
                result.status !== "success"
            ) {
                throw new Error(
                    result.message ||
                    "Unable to update booking"
                );
            }
            showModalMessage(
                result.message,
                "success"
            );
            await loadBookings();
            setTimeout(
                function () {
                    bookingModal
                        .classList
                        .remove(
                            "show"
                        );
                    selectedBooking =
                        null;
                    showToast(
                        result.message,
                        "success"
                    );
                },
                600
            );
        } catch (error) {
            showModalMessage(
                error.message,
                "error"
            );
        } finally {
            saveStatusButton.disabled =
                false;
            saveStatusButton.textContent =
                "Save Status";
        }
    }
);
/* ========================================
   MODAL CONTROLS
======================================== */
function closeBookingModal() {
    bookingModal
        .classList
        .remove(
            "show"
        );
    selectedBooking =
        null;
}
document
    .getElementById(
        "closeBookingModal"
    )
    .addEventListener(
        "click",
        closeBookingModal
    );
document
    .getElementById(
        "cancelModalButton"
    )
    .addEventListener(
        "click",
        closeBookingModal
    );
/* ========================================
   MESSAGE
======================================== */
function clearModalMessage() {
    modalMessage.className =
        "modal-message";
    modalMessage.textContent =
        "";
}
function showModalMessage(
    message,
    type
) {
    modalMessage.textContent =
        message;
    modalMessage.className =
        "modal-message "
        + type;
}
/* ========================================
   STATUS CSS
======================================== */
function getStatusClass(
    status
) {
    if (
        status === "Confirmed"
    ) {
        return "status-confirmed";
    }
    if (
        status === "Cancelled"
    ) {
        return "status-cancelled";
    }
    return "status-pending";
}
/* ========================================
   NAVIGATION
======================================== */
function updateNavbar() {
    // The API already restricts venue management to Administrators.
    // Show this navigation link only after verifying the user's JWT and role.
    const venueLink = document.getElementById("adminVenueLink");
    if (venueLink) {
        venueLink.style.display =
            currentUser && currentUser.role === "Administrator"
                ? "inline-flex"
                : "none";
    }
    document
        .getElementById(
            "authNavigation"
        )
        .innerHTML = `
            <span
                style="
                    color:#555263;
                    font-size:13px;
                    font-weight:700;
                "
            >
                ${escapeHTML(
                    currentUser.name
                )}
                <small
                    style="
                        color:#9995a4;
                    "
                >
                    (${escapeHTML(
                        currentUser.role
                    )})
                </small>
            </span>
            <button
                type="button"
                onclick="logout()"
                style="
                    border:none;
                    padding:11px 17px;
                    border-radius:9px;
                    background:#11101d;
                    color:white;
                    cursor:pointer;
                    font-weight:700;
                "
            >
                Logout
            </button>
        `;
}
/* ========================================
   LOGOUT
======================================== */
function logout() {
    localStorage.removeItem(
        "eventify_token"
    );
    localStorage.removeItem(
        "eventify_user"
    );
    window.location.href =
        "login.php";
}
/* ========================================
   TOAST
======================================== */
function showToast(
    message,
    type
) {
    toast.textContent =
        message;
    toast.className =
        "toast "
        + type
        + " show";
    setTimeout(
        function () {
            toast
                .classList
                .remove(
                    "show"
                );
        },
        3500
    );
}
/* ========================================
   ESCAPE HTML
======================================== */
function escapeHTML(
    value
) {
    return String(
        value ?? ""
    )
        .replaceAll(
            "&",
            "&amp;"
        )
        .replaceAll(
            "<",
            "&lt;"
        )
        .replaceAll(
            ">",
            "&gt;"
        )
        .replaceAll(
            '"',
            "&quot;"
        )
        .replaceAll(
            "'",
            "&#039;"
        );
}
/* ========================================
   START
======================================== */
initialise();
</script>
</body>
</html>
