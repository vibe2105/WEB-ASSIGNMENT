<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Create Account | Eventify</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >


    <style>

        /* ==========================================
           REGISTER PAGE
        ========================================== */

        .auth-page {

            min-height: 100vh;

            background:
                linear-gradient(
                    135deg,
                    #11101d 0%,
                    #19162e 45%,
                    #241b4b 100%
                );

            position: relative;

            overflow-x: hidden;
            overflow-y: auto;

        }


        .auth-page::before {

            content: "";

            position: fixed;

            inset: 0;

            background-image:

                linear-gradient(
                    rgba(255,255,255,.035) 1px,
                    transparent 1px
                ),

                linear-gradient(
                    90deg,
                    rgba(255,255,255,.035) 1px,
                    transparent 1px
                );

            background-size:
                60px 60px;

            pointer-events: none;

        }


        .auth-glow-one {

            position: fixed;

            width: 500px;

            height: 500px;

            border-radius: 50%;

            right: -170px;

            top: -180px;

            background:
                radial-gradient(
                    circle,
                    rgba(117,89,255,.32),
                    transparent 65%
                );

            pointer-events: none;

        }


        .auth-glow-two {

            position: fixed;

            width: 400px;

            height: 400px;

            border-radius: 50%;

            left: -180px;

            bottom: -180px;

            background:
                radial-gradient(
                    circle,
                    rgba(129,79,208,.20),
                    transparent 65%
                );

            pointer-events: none;

        }


        .auth-wrapper {

            min-height:
                calc(100vh - 78px);

            display: grid;

            grid-template-columns:
                1fr 480px;

            align-items: center;

            gap: 80px;

            padding:
                70px 0;

            position: relative;

            z-index: 2;

        }


        /* ==========================================
           LEFT SIDE
        ========================================== */

        .auth-intro {

            color: white;

            max-width: 610px;

        }


        .auth-eyebrow {

            display: inline-block;

            padding:
                8px 13px;

            border-radius:
                100px;

            background:
                rgba(255,255,255,.06);

            border:
                1px solid
                rgba(255,255,255,.12);

            color: #b7abff;

            font-size: 11px;

            letter-spacing: 2px;

            font-weight: 800;

            margin-bottom: 25px;

        }


        .auth-intro h1 {

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                clamp(
                    48px,
                    6vw,
                    74px
                );

            line-height: 1.05;

            letter-spacing:
                -3px;

        }


        .auth-intro h1 span {

            display: block;

            background:
                linear-gradient(
                    90deg,
                    #947fff,
                    #d1c8ff
                );

            -webkit-background-clip:
                text;

            color:
                transparent;

        }


        .auth-intro > p {

            max-width:
                540px;

            margin-top:
                23px;

            color:
                #aaa7b9;

            font-size:
                16px;

            line-height:
                1.8;

        }


        .auth-benefits {

            display:
                grid;

            gap:
                16px;

            margin-top:
                35px;

        }


        .auth-benefit {

            display:
                flex;

            gap:
                13px;

            align-items:
                center;

            color:
                #c7c3d1;

            font-size:
                13px;

        }


        .benefit-icon {

            width:
                35px;

            height:
                35px;

            display:
                grid;

            place-items:
                center;

            border-radius:
                10px;

            background:
                rgba(117,89,255,.15);

            color:
                #a995ff;

            flex-shrink:
                0;

        }


        /* ==========================================
           FORM CARD
        ========================================== */

        .register-card {

            padding:
                38px;

            background:
                rgba(
                    255,
                    255,
                    255,
                    .97
                );

            border-radius:
                24px;

            border:
                1px solid
                rgba(
                    255,
                    255,
                    255,
                    .2
                );

            box-shadow:
                0 30px 80px
                rgba(
                    0,
                    0,
                    0,
                    .28
                );

        }


        .register-card-header {

            margin-bottom:
                28px;

        }


        .register-card-header span {

            color:
                #7559ff;

            font-size:
                10px;

            font-weight:
                800;

            letter-spacing:
                1.8px;

        }


        .register-card-header h2 {

            font-family:
                "Manrope",
                sans-serif;

            font-size:
                30px;

            margin-top:
                7px;

            color:
                #1f1d2b;

        }


        .register-card-header p {

            color:
                #8b8797;

            font-size:
                13px;

            margin-top:
                7px;

        }


        /* ==========================================
           FORM
        ========================================== */

        .form-group {

            margin-bottom:
                18px;

        }


        .form-group label {

            display:
                block;

            margin-bottom:
                8px;

            color:
                #4b4858;

            font-size:
                12px;

            font-weight:
                700;

        }


        .input-wrapper {

            position:
                relative;

        }


        .input-icon {

            position:
                absolute;

            left:
                15px;

            top:
                50%;

            transform:
                translateY(-50%);

            color:
                #aaa6b5;

            width:
                20px;

            text-align:
                center;

        }


        .form-input {

            width:
                100%;

            height:
                52px;

            padding:
                0 45px;

            border:
                1px solid
                #e5e3eb;

            border-radius:
                11px;

            outline:
                none;

            background:
                #fafafd;

            color:
                #282633;

            font-size:
                13px;

            transition:
                .25s;

        }


        .form-input:focus {

            background:
                white;

            border-color:
                #9887f6;

            box-shadow:
                0 0 0 4px
                rgba(
                    117,
                    89,
                    255,
                    .08
                );

        }


        .password-toggle {

            position:
                absolute;

            right:
                14px;

            top:
                50%;

            transform:
                translateY(-50%);

            border:
                none;

            background:
                none;

            cursor:
                pointer;

            color:
                #898694;

            font-size:
                11px;

            font-weight:
                700;

        }


        .password-hint {

            margin-top:
                7px;

            color:
                #a19daa;

            font-size:
                10px;

        }


        /* ==========================================
           TERMS
        ========================================== */

        .terms-row {

            display:
                flex;

            align-items:
                flex-start;

            gap:
                10px;

            margin:
                22px 0;

        }


        .terms-row input {

            width:
                16px;

            height:
                16px;

            accent-color:
                #7559ff;

            margin-top:
                2px;

        }


        .terms-row label {

            color:
                #817e8d;

            font-size:
                11px;

            line-height:
                1.5;

        }


        /* ==========================================
           BUTTON
        ========================================== */

        .register-submit {

            width:
                100%;

            height:
                52px;

            border:
                none;

            border-radius:
                11px;

            background:
                linear-gradient(
                    135deg,
                    #8064ff,
                    #6347e8
                );

            color:
                white;

            cursor:
                pointer;

            font-size:
                13px;

            font-weight:
                800;

            box-shadow:
                0 12px 25px
                rgba(
                    117,
                    89,
                    255,
                    .25
                );

            transition:
                .25s;

        }


        .register-submit:hover {

            transform:
                translateY(-2px);

            box-shadow:
                0 17px 30px
                rgba(
                    117,
                    89,
                    255,
                    .32
                );

        }


        .register-submit:disabled {

            opacity:
                .65;

            cursor:
                not-allowed;

            transform:
                none;

        }


        /* ==========================================
           MESSAGE
        ========================================== */

        .register-message {

            display:
                none;

            margin-top:
                16px;

            padding:
                13px 15px;

            border-radius:
                10px;

            font-size:
                12px;

            line-height:
                1.55;

        }


        .register-message.error {

            display:
                block;

            color:
                #ad3d3d;

            background:
                #fff0f0;

            border:
                1px solid
                #ffdada;

        }


        .register-message.success {

            display:
                block;

            color:
                #177657;

            background:
                #edf9f4;

            border:
                1px solid
                #d6f0e5;

        }


        /* ==========================================
           LOGIN LINK
        ========================================== */

        .login-redirect {

            text-align:
                center;

            margin-top:
                24px;

            color:
                #85818f;

            font-size:
                12px;

        }


        .login-redirect a {

            color:
                #7559ff;

            font-weight:
                800;

        }


        /* ==========================================
           RESPONSIVE
        ========================================== */

        @media (
            max-width: 950px
        ) {

            .auth-wrapper {

                grid-template-columns:
                    1fr;

                max-width:
                    600px;

            }


            .auth-intro {

                text-align:
                    center;

                margin:
                    auto;

            }


            .auth-intro > p {

                margin-left:
                    auto;

                margin-right:
                    auto;

            }


            .auth-benefits {

                display:
                    none;

            }

        }


        @media (
            max-width: 550px
        ) {

            .register-card {

                padding:
                    27px 22px;

            }


            .auth-wrapper {

                padding:
                    45px 0;

            }


            .auth-intro h1 {

                font-size:
                    44px;

            }

        }

    </style>

</head>


<body class="auth-page">


<div class="auth-glow-one"></div>

<div class="auth-glow-two"></div>



<!-- ==========================================
     NAVBAR
========================================== -->

<header class="navbar">

    <div class="container nav-container">


        <a
            href="index.php"
            class="brand"
        >

            <div class="brand-icon">
                E
            </div>

            <span>

                Event<span class="brand-purple">ify</span>

            </span>

        </a>


        <nav class="nav-links">

            <a href="index.php">
                Home
            </a>

            <a href="events.php">
                Events
            </a>

            <a href="bookings.php">
                My Bookings
            </a>

        </nav>


        <div class="nav-actions">

            <a
                href="login.php"
                class="sign-in"
            >
                Sign In
            </a>

        </div>


    </div>

</header>



<!-- ==========================================
     REGISTER CONTENT
========================================== -->

<main>

    <div class="container auth-wrapper">


        <!-- LEFT -->

        <section class="auth-intro">


            <div class="auth-eyebrow">

                ✦ JOIN EVENTIFY

            </div>


            <h1>

                Your next memory

                <span>
                    starts here.
                </span>

            </h1>


            <p>

                Create your account and discover events,
                reserve tickets and manage all of your
                experiences from one place.

            </p>



            <div class="auth-benefits">


                <div class="auth-benefit">

                    <div class="benefit-icon">
                        ✓
                    </div>

                    <span>
                        Discover upcoming events and experiences
                    </span>

                </div>



                <div class="auth-benefit">

                    <div class="benefit-icon">
                        ✓
                    </div>

                    <span>
                        Reserve tickets securely in a few clicks
                    </span>

                </div>



                <div class="auth-benefit">

                    <div class="benefit-icon">
                        ✓
                    </div>

                    <span>
                        View and manage all of your bookings
                    </span>

                </div>


            </div>


        </section>



        <!-- FORM -->

        <section class="register-card">


            <div class="register-card-header">

                <span>
                    CREATE ACCOUNT
                </span>

                <h2>
                    Welcome to Eventify
                </h2>

                <p>
                    Enter your information to get started.
                </p>

            </div>



            <form
                id="registerForm"
                novalidate
            >


                <!-- NAME -->

                <div class="form-group">

                    <label for="name">
                        Full Name
                    </label>


                    <div class="input-wrapper">

                        <span class="input-icon">
                            ◯
                        </span>

                        <input
                            type="text"
                            id="name"
                            class="form-input"
                            placeholder="Enter your full name"
                            autocomplete="name"
                            required
                        >

                    </div>

                </div>



                <!-- EMAIL -->

                <div class="form-group">

                    <label for="email">
                        Email Address
                    </label>


                    <div class="input-wrapper">

                        <span class="input-icon">
                            @
                        </span>

                        <input
                            type="email"
                            id="email"
                            class="form-input"
                            placeholder="you@example.com"
                            autocomplete="email"
                            required
                        >

                    </div>

                </div>



                <!-- PASSWORD -->

                <div class="form-group">

                    <label for="password">
                        Password
                    </label>


                    <div class="input-wrapper">

                        <span class="input-icon">
                            ◈
                        </span>

                        <input
                            type="password"
                            id="password"
                            class="form-input"
                            placeholder="Create a password"
                            autocomplete="new-password"
                            required
                        >


                        <button
                            type="button"
                            class="password-toggle"
                            data-target="password"
                        >
                            SHOW
                        </button>

                    </div>


                    <div class="password-hint">

                        Minimum 6 characters.

                    </div>

                </div>



                <!-- CONFIRM PASSWORD -->

                <div class="form-group">

                    <label for="confirmPassword">
                        Confirm Password
                    </label>


                    <div class="input-wrapper">

                        <span class="input-icon">
                            ◈
                        </span>

                        <input
                            type="password"
                            id="confirmPassword"
                            class="form-input"
                            placeholder="Enter password again"
                            autocomplete="new-password"
                            required
                        >


                        <button
                            type="button"
                            class="password-toggle"
                            data-target="confirmPassword"
                        >
                            SHOW
                        </button>

                    </div>

                </div>



                <!-- TERMS -->

                <div class="terms-row">

                    <input
                        type="checkbox"
                        id="terms"
                    >

                    <label for="terms">

                        I confirm that the information
                        provided is correct and I agree
                        to create an Eventify customer
                        account.

                    </label>

                </div>



                <!-- BUTTON -->

                <button
                    type="submit"
                    class="register-submit"
                    id="registerButton"
                >

                    Create My Account →

                </button>



                <!-- MESSAGE -->

                <div
                    class="register-message"
                    id="registerMessage"
                >
                </div>


            </form>



            <div class="login-redirect">

                Already have an account?

                <a href="login.php">
                    Sign In
                </a>

            </div>


        </section>


    </div>

</main>



<script>

/* ==========================================
   ELEMENTS
========================================== */

const registerForm =
    document.getElementById(
        "registerForm"
    );


const registerButton =
    document.getElementById(
        "registerButton"
    );


const registerMessage =
    document.getElementById(
        "registerMessage"
    );



/* ==========================================
   PASSWORD SHOW / HIDE
========================================== */

document
    .querySelectorAll(
        ".password-toggle"
    )
    .forEach(
        button => {


            button.addEventListener(
                "click",
                function () {


                    const target =
                        document.getElementById(
                            this.dataset.target
                        );


                    if (
                        target.type
                        === "password"
                    ) {

                        target.type =
                            "text";

                        this.textContent =
                            "HIDE";

                    } else {

                        target.type =
                            "password";

                        this.textContent =
                            "SHOW";

                    }

                }
            );


        }
    );



/* ==========================================
   REGISTER
========================================== */

registerForm.addEventListener(
    "submit",
    async function (event) {


        event.preventDefault();


        const name =
            document
                .getElementById(
                    "name"
                )
                .value
                .trim();


        const email =
            document
                .getElementById(
                    "email"
                )
                .value
                .trim();


        const password =
            document
                .getElementById(
                    "password"
                )
                .value;


        const confirmPassword =
            document
                .getElementById(
                    "confirmPassword"
                )
                .value;


        const terms =
            document
                .getElementById(
                    "terms"
                )
                .checked;



        registerMessage.className =
            "register-message";


        registerMessage.textContent =
            "";



        /* CLIENT VALIDATION */

        if (
            name === "" ||
            email === "" ||
            password === "" ||
            confirmPassword === ""
        ) {

            showMessage(
                "Please complete all fields.",
                "error"
            );

            return;
        }


        if (name.length < 3) {

            showMessage(
                "Please enter your full name.",
                "error"
            );

            return;
        }


        if (password.length < 6) {

            showMessage(
                "Password must contain at least 6 characters.",
                "error"
            );

            return;
        }


        if (
            password !==
            confirmPassword
        ) {

            showMessage(
                "The passwords do not match.",
                "error"
            );

            return;
        }


        if (!terms) {

            showMessage(
                "Please confirm the account information before registering.",
                "error"
            );

            return;
        }



        /* SEND REQUEST */

        registerButton.disabled =
            true;


        registerButton.textContent =
            "Creating Account...";


        try {


            const response =
                await fetch(
                    "auth/register.php",
                    {

                        method:
                            "POST",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body:
                            JSON.stringify({

                                name:
                                    name,

                                email:
                                    email,

                                password:
                                    password,

                                confirm_password:
                                    confirmPassword

                            })

                    }
                );


            const result =
                await response.json();



            if (
                response.ok &&
                result.status === "success"
            ) {


                showMessage(
                    "✓ Account created successfully. You can now sign in.",
                    "success"
                );


                registerForm.reset();


                registerButton.textContent =
                    "Account Created ✓";


                setTimeout(
                    function () {

                        window.location.href =
                            "login.php?registered=1";

                    },
                    1800
                );


            } else {


                throw new Error(
                    result.message ||
                    "Unable to create account"
                );

            }


        } catch (error) {


            showMessage(
                error.message,
                "error"
            );


            registerButton.disabled =
                false;


            registerButton.textContent =
                "Create My Account →";


        }


    }
);



/* ==========================================
   MESSAGE
========================================== */

function showMessage(
    message,
    type
) {

    registerMessage.textContent =
        message;


    registerMessage.className =
        "register-message "
        + type;

}

</script>

<script src="js/auth.js"></script>
</body>

</html>