/* =====================================================
   EVENTIFY GLOBAL AUTHENTICATION & NAVIGATION

   - Guest: Home, Events, Sign In, Create Account
   - Customer: Home, Events, My Bookings, Logout
   - Organiser: Home, Events, Dashboard, Logout
   - Administrator: Home, Events, Dashboard, Logout
===================================================== */

(function () {
  "use strict";

  function startNavbar() {
    const nav =
      document.getElementById("authNavigation") ||
      document.querySelector(".nav-actions");

    /* ==========================================
           CONTROL MY BOOKINGS VISIBILITY
        ========================================== */

    function setBookingsVisibility(isCustomer) {
      document.body.classList.toggle("eventify-customer-logged-in", isCustomer);

      const bookingLinks = document.querySelectorAll(
        '.nav-links a[href="bookings.php"]',
      );

      bookingLinks.forEach(function (link) {
        link.style.display = isCustomer ? "inline-flex" : "none";
      });
    }

    /*
           Hide My Bookings immediately while
           authentication is being verified.
        */

    setBookingsVisibility(false);

    // Pages without this navbar do not need updating.
    if (!nav) {
      return;
    }

    /* ==========================================
           CREATE NAVIGATION LINK
        ========================================== */

    function makeLink(label, href, className) {
      const link = document.createElement("a");

      link.href = href;
      link.className = className;
      link.textContent = label;

      return link;
    }

    /* ==========================================
           GUEST NAVIGATION
        ========================================== */

    function showGuest() {
      setBookingsVisibility(false);

      nav.replaceChildren(
        makeLink("Sign In", "login.php", "sign-in"),
        makeLink("Create Account", "register.php", "nav-button"),
      );
    }

    /* ==========================================
           LOGGED-IN NAVIGATION
        ========================================== */

    function showLoggedIn(user) {
      const role = String(user.role || "");

      /*
               My Bookings only appears
               for logged-in Customers.
            */

      setBookingsVisibility(role === "Customer");

      nav.replaceChildren();

      /* DASHBOARD FOR STAFF */

      if (role === "Administrator" || role === "Organiser") {
        nav.appendChild(makeLink("Dashboard", "dashboard.php", "sign-in"));
      }

      /* DISPLAY USER NAME */

      const userDetails = document.createElement("span");

      userDetails.style.cssText = `
                font-size: 13px;
                font-weight: 700;
                color: #555263;
                line-height: 1.3;
            `;

      userDetails.textContent = String(user.name || "Account");

      /* DISPLAY USER ROLE */

      const roleLabel = document.createElement("small");

      roleLabel.style.cssText = `
                display: block;
                font-size: 10px;
                font-weight: 500;
                color: #9995a4;
                margin-top: 3px;
            `;

      roleLabel.textContent = role;

      userDetails.appendChild(roleLabel);

      nav.appendChild(userDetails);

      /* LOGOUT BUTTON */

      const logout = document.createElement("button");

      logout.type = "button";
      logout.className = "nav-button";
      logout.textContent = "Logout";

      logout.style.cssText = `
                border: none;
                cursor: pointer;
                background: #11101d;
                color: white;
                padding: 11px 17px;
                border-radius: 9px;
                font-weight: 700;
            `;

      logout.addEventListener("click", function () {
        localStorage.removeItem("eventify_token");

        localStorage.removeItem("eventify_user");

        setBookingsVisibility(false);

        window.location.href = "login.php";
      });

      nav.appendChild(logout);
    }

    /* ==========================================
           VERIFY JWT AUTHENTICATION
        ========================================== */

    async function checkLogin() {
      const token = localStorage.getItem("eventify_token");

      /* NOT LOGGED IN */

      if (!token) {
        showGuest();

        return;
      }

      try {
        const response = await fetch("auth/me.php", {
          headers: {
            Authorization: "Bearer " + token,
          },
          cache: "no-store",
        });

        /* INVALID OR EXPIRED TOKEN */

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("eventify_token");

          localStorage.removeItem("eventify_user");

          showGuest();

          return;
        }

        if (!response.ok) {
          showGuest();

          return;
        }

        const result = await response.json();

        if (result.status !== "success" || !result.user) {
          showGuest();

          return;
        }

        /* SAVE VERIFIED USER */

        localStorage.setItem("eventify_user", JSON.stringify(result.user));

        /* UPDATE NAVBAR BASED ON ROLE */

        showLoggedIn(result.user);
      } catch (error) {
        /*
                   If the server is temporarily
                   unavailable, do not delete
                   the user's existing token.
                */

        showGuest();
      }
    }

    /* ==========================================
           START AUTHENTICATION CHECK
        ========================================== */

    checkLogin();
  }

  /* ==========================================
       WAIT FOR PAGE TO LOAD
    ========================================== */

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startNavbar);
  } else {
    startNavbar();
  }
})();
