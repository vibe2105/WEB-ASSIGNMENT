<?php

require_once __DIR__ . "/../config/jwt.php";


/* ==========================================
   GET AUTHORIZATION HEADER
========================================== */

function getAuthorizationHeader()
{
    if (
        isset($_SERVER["HTTP_AUTHORIZATION"])
    ) {
        return trim(
            $_SERVER["HTTP_AUTHORIZATION"]
        );
    }


    if (
        isset($_SERVER["REDIRECT_HTTP_AUTHORIZATION"])
    ) {
        return trim(
            $_SERVER["REDIRECT_HTTP_AUTHORIZATION"]
        );
    }


    if (function_exists("getallheaders")) {

        $headers = getallheaders();

        foreach ($headers as $key => $value) {

            if (
                strtolower($key)
                === "authorization"
            ) {
                return trim($value);
            }
        }
    }


    return null;
}



/* ==========================================
   GET BEARER TOKEN
========================================== */

function getBearerToken()
{
    $header =
        getAuthorizationHeader();


    if (!$header) {
        return null;
    }


    if (
        preg_match(
            "/Bearer\s+(.+)/i",
            $header,
            $matches
        )
    ) {

        return trim(
            $matches[1]
        );
    }


    return null;
}



/* ==========================================
   REQUIRE AUTHENTICATION
========================================== */

function requireAuth() {
    $token = getBearerToken();
    if (!$token) {
        http_response_code(401);
        echo json_encode(['status'=>'error', 'message'=>'Authentication token is required']);
        exit;
    }
    try {
        $claims = verifyJWT($token);
    } catch (RuntimeException $error) {
        error_log('Eventify JWT setup: ' . $error->getMessage());
        http_response_code(503);
        echo json_encode(['status'=>'error', 'message'=>'Authentication service unavailable']);
        exit;
    }
    if (!$claims) {
        http_response_code(401);
        echo json_encode(['status'=>'error', 'message'=>'Invalid or expired authentication token']);
        exit;
    }

    // IMPORTANT: roles in JWT can be outdated after demotion or deletion.
    // Always load the latest account role and data from MySQL.
    require_once __DIR__ . '/../config/database.php';
    $db = (new Database())->getConnection();
    if (!$db) {
        http_response_code(503);
        echo json_encode(['status'=>'error', 'message'=>'Authentication service unavailable']);
        exit;
    }
    try {
        $statement = $db->prepare(
            'SELECT user_id, name, email, role FROM users WHERE user_id = :id LIMIT 1'
        );
        $statement->execute([':id'=>(int)$claims['user_id']]);
        $user = $statement->fetch();
    } catch (Throwable $error) {
        error_log('Eventify auth lookup: ' . $error->getMessage());
        http_response_code(503);
        echo json_encode(['status'=>'error', 'message'=>'Authentication service unavailable']);
        exit;
    }
    if (!$user) {
        http_response_code(401);
        echo json_encode(['status'=>'error', 'message'=>'Account no longer exists']);
        exit;
    }
    return $user;
}


/* ==========================================
   REQUIRE ROLE
========================================== */

function requireRole(
    $user,
    $allowedRoles
) {

    if (
        !isset($user["role"])
    ) {

        http_response_code(403);

        echo json_encode([
            "status" => "error",
            "message" =>
                "User role is unavailable"
        ]);

        exit;
    }


    if (
        !in_array(
            $user["role"],
            $allowedRoles,
            true
        )
    ) {

        http_response_code(403);

        echo json_encode([
            "status" => "error",
            "message" =>
                "You do not have permission to access this resource"
        ]);

        exit;
    }


    return true;
}

?>