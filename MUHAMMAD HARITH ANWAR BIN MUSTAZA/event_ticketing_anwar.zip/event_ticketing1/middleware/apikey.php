<?php
require_once __DIR__ . '/../config/settings.php';
function eventifyRequireInternalApiKey(): void {
    $expected=(string)eventifySetting('EVENTIFY_INTERNAL_API_KEY','');
    if (strlen($expected)<32 || str_starts_with($expected,'PASTE_')) {
        error_log('Eventify internal API key not configured');
        http_response_code(503);
        echo json_encode(['status'=>'error','message'=>'Internal API service unavailable']);
        exit;
    }
    $provided=$_SERVER['HTTP_X_API_KEY'] ?? '';
    if (!is_string($provided) || !hash_equals($expected,$provided)) {
        http_response_code(401);
        echo json_encode(['status'=>'error','message'=>'Valid X-API-Key header required']);
        exit;
    }
}
