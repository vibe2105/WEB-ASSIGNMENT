<?php
/** Shared API error handling and safe, non-sensitive request logging. */
function eventifyApiInit(): void {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    error_reporting(E_ALL);
    header('Cache-Control: no-store');
    $start = microtime(true);
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'CLI';
    register_shutdown_function(function () use ($start, $path, $method) {
        $ms = round((microtime(true) - $start) * 1000);
        // Never log tokens, query strings, passwords or request bodies.
        error_log("Eventify API $method $path status=" . http_response_code() . " duration_ms=$ms");
    });
    set_exception_handler(function (Throwable $error) {
        error_log('Eventify uncaught API exception: ' . $error->getMessage());
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode(['status'=>'error','message'=>'Internal server error']);
    });
}
