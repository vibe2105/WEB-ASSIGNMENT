<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Event Details | Eventify</title>

    <link rel="stylesheet" href="css/style.css">


    <style>

        /* =====================================
           EVENT DETAILS PAGE
        ===================================== */

        .details-page {
            min-height: 100vh;
            background: #f7f7fb;
        }


        .details-hero {
            min-height: 420px;

            position: relative;

            display: flex;
            align-items: flex-end;

            overflow: hidden;

            color: white;

            background:
                radial-gradient(
                    circle at 80% 20%,
                    rgba(122, 91, 255, 0.32),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #11101d,
                    #211a46
                );
        }


        .details-hero::before {
            content: "";

            position: absolute;

            inset: 0;

            background-image:
                linear-gradient(
                    rgba(255,255,255,.05) 1px,
                    transparent 1px
                ),
                linear-gradient(
                    90deg,
                    rgba(255,255,255,.05) 1px,
                    transparent 1px
                );

            background-size: 55px 55px;
        }


        .details-hero-content {
            position: relative;

            z-index: 2;

            width: 100%;

            padding: 80px 0 65px;
        }


        .back-link {
            display: inline-flex;

            align-items: center;

            gap: 8px;

            color: #c8c4d8;

            font-size: 13px;

            font-weight: 600;

            margin-bottom: 35px;

            transition: 0.25s;
        }


        .back-link:hover {
            color: white;

            transform: translateX(-3px);
        }


        .details-category {
            display: inline-block;

            padding: 8px 14px;

            border-radius: 100px;

            background:
                rgba(255,255,255,.09);

            border:
                1px solid rgba(255,255,255,.14);

            color: #c7bdff;

            font-size: 11px;

            font-weight: 700;

            letter-spacing: 1px;

            margin-bottom: 18px;
        }


        .details-title {
            max-width: 830px;

            font-family: "Manrope", sans-serif;

            font-size:
                clamp(42px, 6vw, 70px);

            line-height: 1.05;

            letter-spacing: -2px;

            margin-bottom: 24px;
        }


        .details-short-info {
            display: flex;

            flex-wrap: wrap;

            gap: 25px;

            color: #b9b6c7;

            font-size: 14px;
        }


        .details-short-info div {
            display: flex;

            align-items: center;

            gap: 8px;
        }


        .details-content {
            padding: 60px 0 95px;
        }


        .details-layout {
            display: grid;

            grid-template-columns:
                minmax(0, 1.6fr)
                minmax(300px, .75fr);

            gap: 35px;

            align-items: start;
        }


        .details-main-card,
        .booking-card {
            background: white;

            border:
                1px solid #ebeaf0;

            border-radius: 20px;

            box-shadow:
                0 18px 45px
                rgba(20,18,38,.06);
        }


        .details-main-card {
            padding: 34px;
        }


        .detail-section +
        .detail-section {
            margin-top: 35px;

            padding-top: 35px;

            border-top:
                1px solid #efedf3;
        }


        .detail-section-label {
            display: block;

            color: #7559ff;

            font-size: 11px;

            font-weight: 800;

            letter-spacing: 1.5px;

            margin-bottom: 9px;
        }


        .detail-section h2 {
            font-family: "Manrope", sans-serif;

            font-size: 27px;

            margin-bottom: 14px;
        }


        .detail-description {
            color: #747182;

            line-height: 1.8;

            font-size: 15px;
        }


        .detail-info-grid {
            display: grid;

            grid-template-columns:
                repeat(2, 1fr);

            gap: 18px;

            margin-top: 20px;
        }


        .detail-info-box {
            padding: 20px;

            background: #f8f7fc;

            border:
                1px solid #efedf4;

            border-radius: 14px;
        }


        .detail-info-box span {
            display: block;

            color: #9996a5;

            font-size: 11px;

            text-transform: uppercase;

            letter-spacing: .7px;

            margin-bottom: 7px;
        }


        .detail-info-box strong {
            color: #211f2c;

            font-size: 14px;

            line-height: 1.5;
        }


        .booking-card {
            position: sticky;

            top: 105px;

            overflow: hidden;
        }


        .booking-card-top {
            padding: 30px;

            background:
                linear-gradient(
                    135deg,
                    #17152a,
                    #292052
                );

            color: white;
        }


        .booking-card-top span {
            display: block;

            color: #a9a4b8;

            font-size: 11px;

            text-transform: uppercase;

            letter-spacing: 1px;

            margin-bottom: 7px;
        }


        .booking-price {
            font-family: "Manrope", sans-serif;

            font-size: 34px;

            font-weight: 800;
        }


        .booking-card-body {
            padding: 27px;
        }


        .booking-row {
            display: flex;

            justify-content: space-between;

            gap: 20px;

            padding: 14px 0;

            border-bottom:
                1px solid #efedf3;

            font-size: 13px;
        }


        .booking-row span {
            color: #8c8999;
        }


        .booking-row strong {
            color: #292734;

            text-align: right;
        }


        .availability {
            margin-top: 20px;

            padding: 13px 15px;

            border-radius: 10px;

            background: #edf9f4;

            color: #1b8c62;

            font-size: 13px;

            font-weight: 700;

            text-align: center;
        }


        .book-now-btn {
            width: 100%;

            display: flex;

            align-items: center;

            justify-content: center;

            gap: 10px;

            margin-top: 18px;

            padding: 15px;

            background: #7559ff;

            color: white;

            border: none;

            border-radius: 11px;

            font-size: 14px;

            font-weight: 700;

            cursor: pointer;

            transition: .25s;
        }


        .book-now-btn:hover {
            background: #6245ed;

            transform: translateY(-2px);

            box-shadow:
                0 12px 25px
                rgba(117,89,255,.25);
        }


        .booking-note {
            margin-top: 13px;

            color: #9996a5;

            font-size: 11px;

            text-align: center;
        }


        .loading-detail,
        .detail-error {
            min-height: 350px;

            display: flex;

            flex-direction: column;

            align-items: center;

            justify-content: center;

            gap: 12px;

            text-align: center;

            color: #858291;
        }


        .detail-error h2 {
            color: #24222f;
        }


        .detail-error a {
            color: #7559ff;

            font-weight: 700;
        }


        @media (max-width: 900px) {

            .details-layout {
                grid-template-columns: 1fr;
            }

            .booking-card {
                position: static;
            }

        }


        @media (max-width: 600px) {

            .detail-info-grid {
                grid-template-columns: 1fr;
            }

            .details-main-card {
                padding: 24px;
            }

            .details-title {
                font-size: 42px;
            }

        }

    </style>

</head>


<body class="details-page">


<!-- =====================================
     NAVIGATION
===================================== -->

<header class="navbar">

    <div class="container nav-container">


        <a href="index.php" class="brand">

            <div class="brand-icon">
                E
            </div>

            <span>
                Event<span class="brand-purple">ify</span>
            </span>

        </a>


        <nav class="nav-links">

            <a href="index.php">
                Home
            </a>

            <a href="events.php" class="active">
                Events
            </a>

            <a href="bookings.php">
                My Bookings
            </a>

        </nav>


        <div class="nav-actions">

            <a href="login.php" class="sign-in">
                Sign In
            </a>

            <a href="register.php" class="nav-button">
                Create Account
            </a>

        </div>


    </div>

</header>



<!-- =====================================
     HERO
===================================== -->

<section class="details-hero">

    <div class="container details-hero-content">

        <a href="events.php" class="back-link">

            ← Back to Events

        </a>


        <div id="heroContent">

            <div class="loading-detail">

                Loading event details...

            </div>

        </div>

    </div>

</section>



<!-- =====================================
     EVENT INFORMATION
===================================== -->

<main class="details-content">

    <div class="container">

        <div id="detailsContainer">

            <div class="loading-detail">

                Loading event information...

            </div>

        </div>

    </div>

</main>



<!-- =====================================
     FOOTER
===================================== -->

<footer class="footer">

    <div class="container footer-content">


        <a
            href="index.php"
            class="brand footer-brand"
        >

            <div class="brand-icon">
                E
            </div>

            <span>

                Event<span class="brand-purple">ify</span>

            </span>

        </a>


        <p>
            Event Ticketing & Venue Booking System
        </p>


        <p class="copyright">
            © 2026 Eventify
        </p>


    </div>

</footer>



<script>

/* =====================================
   GET EVENT ID FROM URL
===================================== */

const params =
    new URLSearchParams(
        window.location.search
    );


const eventId =
    params.get("id");


const heroContent =
    document.getElementById(
        "heroContent"
    );


const detailsContainer =
    document.getElementById(
        "detailsContainer"
    );



/* =====================================
   LOAD EVENT
===================================== */

async function loadEventDetails() {


    if (!eventId) {

        showError(
            "No event was selected."
        );

        return;

    }


    try {

        const response =
            await fetch(
                "api/events.php?event_id="
                + encodeURIComponent(
                    eventId
                )
            );


        const result =
            await response.json();


        if (
            !response.ok ||
            result.status !== "success"
        ) {

            showError(
                result.message ||
                "Event not found."
            );

            return;

        }


        displayEvent(
            result.data
        );


    } catch (error) {

        console.error(
            error
        );


        showError(
            "Unable to connect to the server."
        );

    }

}



/* =====================================
   DISPLAY EVENT
===================================== */

function displayEvent(event) {


    document.title =
        event.event_name +
        " | Eventify";



    const eventDate =
        new Date(
            event.event_date +
            "T00:00:00"
        );


    const formattedDate =
        eventDate.toLocaleDateString(
            "en-MY",
            {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        );


    const startTime =
        formatTime(
            event.start_time
        );


    const endTime =
        formatTime(
            event.end_time
        );



    heroContent.innerHTML = `

        <span class="details-category">

            ${escapeHTML(
                event.category
            )}

        </span>


        <h1 class="details-title">

            ${escapeHTML(
                event.event_name
            )}

        </h1>


        <div class="details-short-info">

            <div>

                <span>◷</span>

                ${formattedDate}

            </div>


            <div>

                <span>⌖</span>

                ${escapeHTML(
                    event.venue_name
                )}

            </div>


            <div>

                <span>●</span>

                ${escapeHTML(
                    event.status
                )}

            </div>

        </div>

    `;



    detailsContainer.innerHTML = `

        <div class="details-layout">


            <!-- LEFT CONTENT -->

            <section class="details-main-card">


                <div class="detail-section">

                    <span class="detail-section-label">

                        ABOUT THE EVENT

                    </span>


                    <h2>

                        Event Overview

                    </h2>


                    <p class="detail-description">

                        ${escapeHTML(
                            event.description ||
                            "No description is currently available for this event."
                        )}

                    </p>

                </div>



                <div class="detail-section">

                    <span class="detail-section-label">

                        EVENT INFORMATION

                    </span>


                    <h2>

                        When & Where

                    </h2>


                    <div class="detail-info-grid">


                        <div class="detail-info-box">

                            <span>
                                Date
                            </span>

                            <strong>

                                ${formattedDate}

                            </strong>

                        </div>



                        <div class="detail-info-box">

                            <span>
                                Time
                            </span>

                            <strong>

                                ${startTime}
                                —
                                ${endTime}

                            </strong>

                        </div>



                        <div class="detail-info-box">

                            <span>
                                Venue
                            </span>

                            <strong>

                                ${escapeHTML(
                                    event.venue_name
                                )}

                            </strong>

                        </div>



                        <div class="detail-info-box">

                            <span>
                                Location
                            </span>

                            <strong>

                                ${escapeHTML(
                                    event.location
                                )}

                            </strong>

                        </div>



                        <div class="detail-info-box">

                            <span>
                                Organised By
                            </span>

                            <strong>

                                ${escapeHTML(
                                    event.organiser_name
                                )}

                            </strong>

                        </div>



                        <div class="detail-info-box">

                            <span>
                                Venue Capacity
                            </span>

                            <strong>

                                ${Number(
                                    event.capacity
                                ).toLocaleString()}

                                people

                            </strong>

                        </div>


                    </div>

                </div>



                <div class="detail-section">

                    <span class="detail-section-label">

                        TICKET INFORMATION

                    </span>


                    <h2>

                        Availability

                    </h2>


                    <p class="detail-description">

                        This event currently has

                        <strong>

                            ${Number(
                                event.available_tickets
                            ).toLocaleString()}

                        </strong>

                        tickets available out of

                        <strong>

                            ${Number(
                                event.total_tickets
                            ).toLocaleString()}

                        </strong>

                        total tickets.

                    </p>

                </div>


            </section>



            <!-- BOOKING CARD -->

            <aside class="booking-card">


                <div class="booking-card-top">

                    <span>

                        Ticket Price

                    </span>


                    <div class="booking-price">

                        RM ${Number(
                            event.ticket_price
                        ).toFixed(2)}

                    </div>

                </div>



                <div class="booking-card-body">


                    <div class="booking-row">

                        <span>
                            Event
                        </span>

                        <strong>

                            ${escapeHTML(
                                event.event_name
                            )}

                        </strong>

                    </div>



                    <div class="booking-row">

                        <span>
                            Date
                        </span>

                        <strong>

                            ${formattedDate}

                        </strong>

                    </div>



                    <div class="booking-row">

                        <span>
                            Venue
                        </span>

                        <strong>

                            ${escapeHTML(
                                event.venue_name
                            )}

                        </strong>

                    </div>



                    <div class="booking-row">

                        <span>
                            Available
                        </span>

                        <strong>

                            ${Number(
                                event.available_tickets
                            ).toLocaleString()}

                            tickets

                        </strong>

                    </div>



                    <div class="availability">

                        ✓ Tickets are currently available

                    </div>



                    <button
                        class="book-now-btn"
                        onclick="startBooking(${event.event_id})"
                    >

                        Book Ticket

                        <span>
                            →
                        </span>

                    </button>


                    <p class="booking-note">

                        You will confirm your ticket
                        quantity before booking.

                    </p>


                </div>


            </aside>


        </div>

    `;

}



/* =====================================
   BOOKING BUTTON
===================================== */

function startBooking(eventId) {

    window.location.href =
        "book-ticket.php?event_id="
        + eventId;

}



/* =====================================
   FORMAT TIME
===================================== */

function formatTime(time) {


    if (!time) {

        return "Unavailable";

    }


    const parts =
        time.split(":");


    const date =
        new Date();


    date.setHours(
        Number(parts[0])
    );


    date.setMinutes(
        Number(parts[1])
    );


    return date.toLocaleTimeString(
        "en-US",
        {
            hour: "numeric",
            minute: "2-digit"
        }
    );

}



/* =====================================
   SHOW ERROR
===================================== */

function showError(message) {


    heroContent.innerHTML = `

        <h1 class="details-title">

            Event unavailable

        </h1>

    `;


    detailsContainer.innerHTML = `

        <div class="detail-error">

            <h2>

                We couldn't load this event.

            </h2>

            <p>

                ${escapeHTML(
                    message
                )}

            </p>

            <a href="events.php">

                ← Return to Events

            </a>

        </div>

    `;

}



/* =====================================
   ESCAPE HTML
===================================== */

function escapeHTML(value) {


    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replaceAll(
            "&",
            "&amp;"
        )

        .replaceAll(
            "<",
            "&lt;"
        )

        .replaceAll(
            ">",
            "&gt;"
        )

        .replaceAll(
            '"',
            "&quot;"
        )

        .replaceAll(
            "'",
            "&#039;"
        );

}



/* =====================================
   START PAGE
===================================== */

loadEventDetails();

</script>


</body>
<script src="js/auth.js"></script>

</html>