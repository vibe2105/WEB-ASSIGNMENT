<?php
// Copy to config/local.php, then set your own 64-character random JWT secret.
// NEVER commit local.php to GitHub or share it with teammates.
return [
    'EVENTIFY_TICKET_SECRET' => 'ce2a1f8d481258fe7c2fe9b945e36f60f5c88b24e6eff3131584f5ee274437aa',
    'EVENTIFY_JWT_SECRET' => '5c77941f078a72921421d4a137e512f10cf8ee4dfafd0ea5dbf10fafe6a7f71d',
    'EVENTIFY_INTERNAL_API_KEY' => '2f95460d28ec566ebb86981b92a61bef8e87a59b0b5bcded546d6887bb01268a',
    'EVENTIFY_DB_HOST' => '127.0.0.1',
    'EVENTIFY_DB_NAME' => 'event_ticketing_db',
    'EVENTIFY_DB_USER' => 'root', // local XAMPP only
    'EVENTIFY_DB_PASSWORD' => '', // local XAMPP only
];
