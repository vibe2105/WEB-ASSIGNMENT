/* =====================================================
   EVENTIFY GLOBAL AUTHENTICATION / NAVIGATION
===================================================== */

(function () {
  const token = localStorage.getItem("eventify_token");

  const navContainer = document.querySelector(
    "#authNavigation, #topNavigation, .nav-actions",
  );

  /* =================================================
       LOGOUT
    ================================================= */

  window.eventifyLogout = function () {
    localStorage.removeItem("eventify_token");

    localStorage.removeItem("eventify_user");

    window.location.href = "login.php";
  };

  /* =================================================
       LOGGED OUT NAVBAR
    ================================================= */

  function showGuestNavigation() {
    if (!navContainer) {
      return;
    }

    navContainer.innerHTML = `

            <a
                href="login.php"
                class="sign-in"
            >
                Sign In
            </a>

            <a
                href="register.php"
                class="nav-button"
            >
                Create Account
            </a>

        `;
  }

  /* =================================================
       LOGGED IN NAVBAR
    ================================================= */

  function showUserNavigation(user) {
    if (!navContainer) {
      return;
    }

    let dashboardButton = "";

    if (user.role === "Administrator" || user.role === "Organiser") {
      dashboardButton = `

                <a
                    href="dashboard.php"
                    class="sign-in"
                >
                    Dashboard
                </a>

            `;
    }

    navContainer.innerHTML = `

            ${dashboardButton}

            <span
                style="
                    font-size:13px;
                    font-weight:700;
                    color:#555263;
                "
            >

                ${escapeAuthHTML(user.name)}

                <small
                    style="
                        display:block;
                        color:#9995a4;
                        font-size:9px;
                        text-align:right;
                        margin-top:2px;
                    "
                >

                    ${escapeAuthHTML(user.role)}

                </small>

            </span>


            <button
                type="button"
                onclick="eventifyLogout()"

                style="
                    border:none;
                    padding:11px 17px;
                    border-radius:9px;
                    background:#11101d;
                    color:white;
                    cursor:pointer;
                    font-weight:700;
                "
            >
                Logout
            </button>

        `;
  }

  /* =================================================
       VERIFY TOKEN
    ================================================= */

  async function verifyAuthentication() {
    if (!token) {
      showGuestNavigation();

      return;
    }

    try {
      const response = await fetch("auth/me.php", {
        headers: {
          Authorization: "Bearer " + token,
        },
      });

      const result = await response.json();

      if (!response.ok || result.status !== "success") {
        localStorage.removeItem("eventify_token");

        localStorage.removeItem("eventify_user");

        showGuestNavigation();

        return;
      }

      /* KEEP USER INFORMATION UPDATED */

      localStorage.setItem("eventify_user", JSON.stringify(result.user));

      showUserNavigation(result.user);
    } catch (error) {
      console.error("Authentication check failed:", error);

      /*
               Do not automatically logout
               for a temporary network/server error.
            */

      const cachedUser = JSON.parse(
        localStorage.getItem("eventify_user") || "null",
      );

      if (cachedUser) {
        showUserNavigation(cachedUser);
      } else {
        showGuestNavigation();
      }
    }
  }

  /* =================================================
       ESCAPE HTML
    ================================================= */

  function escapeAuthHTML(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")

      .replaceAll("<", "&lt;")

      .replaceAll(">", "&gt;")

      .replaceAll('"', "&quot;")

      .replaceAll("'", "&#039;");
  }

  /* =================================================
       START
    ================================================= */

  verifyAuthentication();
})();
