<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<?php $sitePage = 'events'; include __DIR__ . '/partials/site-header.php'; ?>

<section class="page-band">
    <div class="wrap page-band-row">
        <div>
            <h1>Events</h1>
            <p class="lede">Everything on the calendar, soonest first. Select an event to see the details and book.</p>
        </div>
        <p class="event-count-line" aria-live="polite"><strong id="eventCount">0</strong> events</p>
    </div>
</section>

<div class="filter-bar">
    <div class="wrap" role="search">
        <label class="search">
            <span class="visually-hidden">Search events</span>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            <input class="input" type="search" id="searchInput" placeholder="Search by event, venue or description">
        </label>

        <label>
            <span class="visually-hidden">Category</span>
            <select class="input" id="categoryFilter">
                <option value="">All categories</option>
                <option value="Technology">Technology</option>
                <option value="Workshop">Workshop</option>
                <option value="Music">Music</option>
                <option value="Seminar">Seminar</option>
                <option value="Food">Food</option>
                <option value="Conference">Conference</option>
                <option value="Other">Other</option>
            </select>
        </label>

        <button type="button" class="btn btn-ink" id="searchButton">Search</button>
    </div>
</div>

<main class="events-body">
    <div class="wrap" id="eventGrid" aria-live="polite">
        <p class="loading-line">Loading events…</p>
    </div>
</main>

<?php include __DIR__ . '/partials/site-footer.php'; ?>

<script src="js/app.js"></script>
<script src="js/auth.js"></script>
</body>
</html>
