<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Find concerts, workshops, talks and food festivals, and book your tickets with Eventify.">
    <title>Eventify | Tickets for what's on</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<?php $sitePage = 'home'; include __DIR__ . '/partials/site-header.php'; ?>

<main>
    <section class="home-hero">
        <div class="wrap">
            <div>
                <h1>Get in to what's on.</h1>
                <p class="lede">
                    Concerts, workshops, talks and food festivals. Pick an event, choose how many
                    tickets you need, and show your QR code at the door.
                </p>
                <div class="home-hero-actions">
                    <a class="btn btn-marigold btn-lg" href="events.php">Browse events</a>
                    <a class="btn btn-outline-light btn-lg" href="#how-it-works">How booking works</a>
                </div>
                <p class="home-totals" aria-live="polite">
                    <strong id="homeEventCount">—</strong> events listed at
                    <strong id="homeVenueCount">—</strong> venues
                </p>
            </div>

            <section class="next-up" aria-labelledby="nextUpTitle">
                <div class="next-up-head">
                    <h2 id="nextUpTitle">Coming up next</h2>
                    <a href="events.php">See all events</a>
                </div>
                <div id="homeFeaturedEvents" aria-live="polite">
                    <p class="next-up-empty">Loading upcoming events…</p>
                </div>
            </section>
        </div>
    </section>

    <section class="home-section" id="how-it-works">
        <div class="wrap">
            <div class="section-head">
                <div>
                    <h2>How booking works</h2>
                    <p>Three steps from finding an event to getting through the door.</p>
                </div>
            </div>
            <ol class="steps">
                <li>
                    <h3>Find an event</h3>
                    <p>Search the listing by name or venue, or filter by category.</p>
                </li>
                <li>
                    <h3>Choose your tickets</h3>
                    <p>Sign in with a customer account and book up to 10 tickets at a time.</p>
                </li>
                <li>
                    <h3>Show your QR code</h3>
                    <p>Open My bookings at the venue. Staff scan your code to check you in.</p>
                </li>
            </ol>
        </div>
    </section>

    <section class="home-section">
        <div class="wrap">
            <div class="section-head">
                <div>
                    <h2>Browse by category</h2>
                    <p>Jump straight to the kind of event you're after.</p>
                </div>
            </div>
            <nav class="chips" aria-label="Event categories">
                <a class="chip" href="events.php?category=Music">Music</a>
                <a class="chip" href="events.php?category=Technology">Technology</a>
                <a class="chip" href="events.php?category=Workshop">Workshops</a>
                <a class="chip" href="events.php?category=Seminar">Seminars</a>
                <a class="chip" href="events.php?category=Food">Food</a>
            </nav>

            <div class="organiser-strip">
                <p><strong>Running an event?</strong> Organisers and administrators manage listings from the staff dashboard.</p>
                <a class="btn" href="login.php">Staff sign in</a>
            </div>
        </div>
    </section>
</main>

<?php include __DIR__ . '/partials/site-footer.php'; ?>

<script>
(function () {
    const featuredContainer = document.getElementById('homeFeaturedEvents');

    function escapeHTML(value) {
        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function formatPrice(value) {
        const price = Number(value);
        if (!Number.isFinite(price)) return 'Price unavailable';
        return price === 0 ? 'Free' : 'RM ' + price.toFixed(2);
    }

    function formatDate(isoDate) {
        const date = new Date(String(isoDate) + 'T00:00:00');
        if (Number.isNaN(date.getTime())) return { day: '—', month: 'Date' };
        return {
            day: date.toLocaleDateString('en-MY', { day: '2-digit' }),
            month: date.toLocaleDateString('en-MY', { month: 'short' })
        };
    }

    function formatTime(time) {
        if (!time) return '';
        const parts = String(time).split(':');
        const date = new Date();
        date.setHours(Number(parts[0]), Number(parts[1]), 0);
        return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    }

    function displayFeatured(events) {
        const today = new Date();
        const todayString = today.getFullYear() + '-' +
            String(today.getMonth() + 1).padStart(2, '0') + '-' +
            String(today.getDate()).padStart(2, '0');

        const upcoming = events
            .filter(event => event.status === 'Upcoming' && String(event.event_date) >= todayString)
            .sort((a, b) => (String(a.event_date) + String(a.start_time)).localeCompare(String(b.event_date) + String(b.start_time)))
            .slice(0, 4);

        if (!upcoming.length) {
            featuredContainer.innerHTML = '<p class="next-up-empty">Nothing is scheduled right now. New events are added regularly, so check the <a href="events.php">full listing</a> later.</p>';
            return;
        }

        featuredContainer.innerHTML = upcoming.map(event => {
            const eventId = Number(event.event_id);
            const safeId = Number.isSafeInteger(eventId) && eventId > 0 ? eventId : 0;
            const date = formatDate(event.event_date);
            const venue = event.venue_name || 'Venue to be confirmed';
            return `
                <a href="${safeId ? 'event-details.php?id=' + safeId : 'events.php'}" class="event-row">
                    <span class="stamp"><span class="stamp-day">${escapeHTML(date.day)}</span><span class="stamp-month">${escapeHTML(date.month)}</span></span>
                    <span class="event-row-main">
                        <span class="event-row-cat">${escapeHTML(event.category || 'Event')}</span>
                        <span class="event-row-title">${escapeHTML(event.event_name)}</span>
                        <span class="event-row-meta">${escapeHTML(venue)}, ${escapeHTML(formatTime(event.start_time))}</span>
                    </span>
                    <span class="event-row-side">
                        <span class="event-row-price">${formatPrice(event.ticket_price)}</span>
                    </span>
                </a>`;
        }).join('');
    }

    async function loadHomeData() {
        const results = await Promise.allSettled([
            fetch('api/events.php').then(async response => {
                if (!response.ok) throw new Error('Events request failed');
                return response.json();
            }),
            fetch('api/venues.php').then(async response => {
                if (!response.ok) throw new Error('Venues request failed');
                return response.json();
            })
        ]);

        const [eventsResult, venuesResult] = results;
        if (eventsResult.status === 'fulfilled' &&
            eventsResult.value.status === 'success' &&
            Array.isArray(eventsResult.value.data)) {
            const events = eventsResult.value.data;
            document.getElementById('homeEventCount').textContent = events.length;
            displayFeatured(events);
        } else {
            featuredContainer.innerHTML = '<p class="next-up-empty">Upcoming events could not be loaded. Try the <a href="events.php">events page</a>.</p>';
        }

        if (venuesResult.status === 'fulfilled' &&
            venuesResult.value.status === 'success' &&
            Array.isArray(venuesResult.value.data)) {
            document.getElementById('homeVenueCount').textContent = venuesResult.value.data.length;
        }
    }

    loadHomeData().catch(() => {
        featuredContainer.innerHTML = '<p class="next-up-empty">Upcoming events could not be loaded. Refresh the page to try again.</p>';
    });
})();
</script>
<script src="js/auth.js"></script>
</body>
</html>
