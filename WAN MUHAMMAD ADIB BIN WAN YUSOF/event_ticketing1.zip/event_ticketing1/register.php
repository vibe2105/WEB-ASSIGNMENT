<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create an account | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<div class="auth">
    <aside class="auth-aside">
        <a href="index.php" class="brand" aria-label="Eventify home"><span class="brand-mark" aria-hidden="true"></span>eventify</a>

        <div>
            <h1>Book your first event.</h1>
            <p>A free customer account lets you book tickets and keep them all in one place.</p>
        </div>

        <ul>
            <li>Book up to 10 tickets at a time.</li>
            <li>Get a QR code for each confirmed booking.</li>
            <li>Cancel a booking yourself if your plans change.</li>
        </ul>
    </aside>

    <main class="auth-main">
        <div class="auth-form">
            <h2>Create an account</h2>
            <p>It takes less than a minute.</p>

            <form id="registerForm" novalidate>
                <div class="field">
                    <label for="name">Full name</label>
                    <input type="text" id="name" class="form-input" placeholder="As you'd like it on your bookings" autocomplete="name" required>
                </div>

                <div class="field">
                    <label for="email">Email address</label>
                    <input type="email" id="email" class="form-input" placeholder="you@example.com" autocomplete="email" required>
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <div class="input-with-action">
                        <input type="password" id="password" class="form-input" placeholder="Create a password" autocomplete="new-password" required aria-describedby="passwordHint">
                        <button type="button" class="input-action password-toggle" data-target="password" aria-controls="password">Show</button>
                    </div>
                    <span class="hint" id="passwordHint">Use at least 6 characters.</span>
                </div>

                <div class="field">
                    <label for="confirmPassword">Confirm password</label>
                    <div class="input-with-action">
                        <input type="password" id="confirmPassword" class="form-input" placeholder="Type it again" autocomplete="new-password" required>
                        <button type="button" class="input-action password-toggle" data-target="confirmPassword" aria-controls="confirmPassword">Show</button>
                    </div>
                </div>

                <label class="check" for="terms">
                    <input type="checkbox" id="terms">
                    <span>I confirm these details are correct and I want to create an Eventify customer account.</span>
                </label>

                <div class="register-message" id="registerMessage" role="status"></div>

                <button type="submit" class="btn btn-primary btn-lg btn-block register-submit" id="registerButton">Create account</button>
            </form>

            <p class="auth-switch">Already have an account? <a href="login.php">Sign in</a></p>
        </div>
    </main>
</div>

<script>
/* ==========================================
   ELEMENTS
========================================== */

const registerForm = document.getElementById("registerForm");
const registerButton = document.getElementById("registerButton");
const registerMessage = document.getElementById("registerMessage");

/* ==========================================
   PASSWORD SHOW / HIDE
========================================== */

document.querySelectorAll(".password-toggle").forEach((button) => {
  button.addEventListener("click", function () {
    const target = document.getElementById(this.dataset.target);

    if (target.type === "password") {
      target.type = "text";
      this.textContent = "Hide";
    } else {
      target.type = "password";
      this.textContent = "Show";
    }
  });
});

/* ==========================================
   REGISTER
========================================== */

registerForm.addEventListener("submit", async function (event) {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;
  const terms = document.getElementById("terms").checked;

  registerMessage.className = "register-message";
  registerMessage.textContent = "";

  /* CLIENT VALIDATION */

  if (name === "" || email === "" || password === "" || confirmPassword === "") {
    showMessage("Fill in every field to create your account.", "error");
    return;
  }

  if (name.length < 3) {
    showMessage("Enter your full name (at least 3 characters).", "error");
    return;
  }

  if (password.length < 6) {
    showMessage("Your password needs at least 6 characters.", "error");
    return;
  }

  if (password !== confirmPassword) {
    showMessage("The two passwords don't match.", "error");
    return;
  }

  if (!terms) {
    showMessage("Tick the box to confirm your details before creating the account.", "error");
    return;
  }

  /* SEND REQUEST */

  registerButton.disabled = true;
  registerButton.textContent = "Creating account…";

  try {
    const response = await fetch("auth/register.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: name,
        email: email,
        password: password,
        confirm_password: confirmPassword,
      }),
    });

    const result = await response.json();

    if (response.ok && result.status === "success") {
      showMessage("Account created. Taking you to sign in…", "success");
      registerForm.reset();
      registerButton.textContent = "Account created";

      setTimeout(function () {
        window.location.href = "login.php?registered=1";
      }, 1800);
    } else {
      throw new Error(result.message || "Unable to create account");
    }
  } catch (error) {
    showMessage(error.message, "error");
    registerButton.disabled = false;
    registerButton.textContent = "Create account";
  }
});

/* ==========================================
   MESSAGE
========================================== */

function showMessage(message, type) {
  registerMessage.textContent = message;
  registerMessage.className = "register-message " + type;
}
</script>
</body>
</html>
