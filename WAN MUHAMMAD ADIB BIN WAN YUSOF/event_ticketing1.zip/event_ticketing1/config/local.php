<?php
// Copy to config/local.php, then set your own 64-character random JWT secret.
// NEVER commit local.php to GitHub or share it with teammates.
return [
    'EVENTIFY_TICKET_SECRET' => '26ac83728f0f1e0fc76fd02c77d7c4986650ed3c51bef9cf1c30701ce4eacabc',
    'EVENTIFY_JWT_SECRET' => '9f2ab5e5c2da044aff3c7a7c38896926b11f7998e5c002ba340cae8a175e93b7',
    'EVENTIFY_INTERNAL_API_KEY' => 'f163f54123545fea74595df3e96bc8231d0bdb8cbe6e855b40314a6cd72bd987',
    'EVENTIFY_DB_HOST' => '127.0.0.1',
    'EVENTIFY_DB_NAME' => 'event_ticketing_db',
    'EVENTIFY_DB_USER' => 'root', // local XAMPP only
    'EVENTIFY_DB_PASSWORD' => '', // local XAMPP only
];
