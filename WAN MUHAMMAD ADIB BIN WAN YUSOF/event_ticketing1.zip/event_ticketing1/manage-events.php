<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage events | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<div class="shell">
    <?php $staffPage = 'events'; include __DIR__ . '/partials/staff-sidebar.php'; ?>

    <div class="shell-main">
        <?php include __DIR__ . '/partials/staff-topbar.php'; ?>

        <main class="shell-content">
            <header class="page-head">
                <div>
                    <h1>Events</h1>
                    <p id="eventsIntro">Create events, change their details and keep ticket numbers up to date.</p>
                </div>
                <button type="button" class="btn btn-primary" id="createEventButton">New event</button>
            </header>

            <section class="stat-strip" aria-label="Event summary">
                <div class="stat">
                    <span class="stat-label">Events</span>
                    <span class="stat-value" id="totalEvents">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Upcoming</span>
                    <span class="stat-value" id="upcomingEvents">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Tickets issued</span>
                    <span class="stat-value" id="totalTickets">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Tickets still available</span>
                    <span class="stat-value" id="availableTickets">0</span>
                </div>
            </section>

            <div class="toolbar" role="search">
                <label class="search">
                    <span class="visually-hidden">Search events</span>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
                    <input type="search" id="eventSearch" placeholder="Search by event, venue, organiser or category">
                </label>
                <label>
                    <span class="visually-hidden">Status</span>
                    <select id="statusFilter">
                        <option value="">All statuses</option>
                        <option value="Upcoming">Upcoming</option>
                        <option value="Ongoing">Ongoing</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </label>
            </div>

            <section class="panel">
                <div class="table-scroll">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th scope="col">Event</th>
                                <th scope="col">Date</th>
                                <th scope="col">Venue</th>
                                <th scope="col">Tickets sold</th>
                                <th scope="col" class="num">Price</th>
                                <th scope="col">Status</th>
                                <th scope="col"><span class="visually-hidden">Actions</span></th>
                            </tr>
                        </thead>
                        <tbody id="eventTableBody">
                            <tr><td colspan="7" class="table-empty">Loading events…</td></tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</div>

<!-- CREATE / EDIT DRAWER -->
<div class="overlay" id="eventModal">
    <div class="drawer" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
        <div class="drawer-head">
            <div>
                <span class="kicker" id="modalEyebrow">Create</span>
                <h2 id="modalTitle">New event</h2>
            </div>
            <button type="button" class="icon-btn" id="closeEventModal">
                <span class="visually-hidden">Close</span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
            </button>
        </div>

        <form id="eventForm">
            <input type="hidden" id="eventId">

            <div class="drawer-body">
                <div class="field">
                    <label for="eventName">Event name</label>
                    <input type="text" id="eventName" placeholder="For example, Klang Valley Music Expo" required>
                </div>

                <div class="form-grid">
                    <div class="field">
                        <label for="category">Category</label>
                        <select id="category" required>
                            <option value="">Choose a category</option>
                            <option value="Technology">Technology</option>
                            <option value="Workshop">Workshop</option>
                            <option value="Music">Music</option>
                            <option value="Seminar">Seminar</option>
                            <option value="Food">Food</option>
                            <option value="Conference">Conference</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="field">
                        <label for="status">Status</label>
                        <select id="status" required>
                            <option value="Upcoming">Upcoming</option>
                            <option value="Ongoing">Ongoing</option>
                            <option value="Completed">Completed</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>

                    <div class="field full">
                        <label for="venue">Venue</label>
                        <select id="venue" required>
                            <option value="">Loading venues…</option>
                        </select>
                        <span class="hint">Only available venues are listed. Ticket numbers can't exceed the venue's capacity.</span>
                    </div>

                    <div class="field full">
                        <label for="eventDate">Date</label>
                        <input type="date" id="eventDate" required>
                    </div>

                    <div class="field">
                        <label for="startTime">Starts</label>
                        <input type="time" id="startTime" required>
                    </div>

                    <div class="field">
                        <label for="endTime">Ends</label>
                        <input type="time" id="endTime" required>
                    </div>

                    <div class="field">
                        <label for="ticketPrice">Ticket price (RM)</label>
                        <input type="number" id="ticketPrice" min="0" step="0.01" placeholder="0.00" required>
                    </div>

                    <div class="field">
                        <label for="totalTicketCount">Total tickets</label>
                        <input type="number" id="totalTicketCount" min="1" placeholder="100" required>
                    </div>

                    <div class="field full">
                        <label for="description">Description</label>
                        <textarea id="description" placeholder="What should people know before they book?"></textarea>
                    </div>
                </div>

                <div class="form-message" id="formMessage" role="status"></div>
            </div>

            <div class="drawer-foot">
                <button type="button" class="btn" id="cancelEventModal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="saveEventButton">Create event</button>
            </div>
        </form>
    </div>
</div>

<!-- DELETE DIALOG -->
<div class="overlay" id="deleteModal">
    <div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="deleteTitle" aria-describedby="deleteMessage">
        <h2 id="deleteTitle">Delete this event?</h2>
        <p id="deleteMessage">The event will be removed permanently. Events that already have bookings can't be deleted.</p>
        <div class="dialog-actions">
            <button type="button" class="btn" id="keepEventButton">Keep event</button>
            <button type="button" class="btn btn-danger" id="confirmDeleteButton">Delete event</button>
        </div>
    </div>
</div>

<div class="toast" id="toast" role="status" aria-live="polite"></div>

<script src="js/staff-shell.js"></script>
<script>
/* ==========================================
   VARIABLES
========================================== */

const token = localStorage.getItem("eventify_token");

let currentUser = null;
let events = [];
let venues = [];
let selectedDeleteId = null;
let formMode = "create";

const eventTableBody = document.getElementById("eventTableBody");
const eventModal = document.getElementById("eventModal");
const deleteModal = document.getElementById("deleteModal");
const eventForm = document.getElementById("eventForm");
const formMessage = document.getElementById("formMessage");
const saveEventButton = document.getElementById("saveEventButton");
const toast = document.getElementById("toast");

/* ==========================================
   INITIALISE
========================================== */

async function initialise() {
  if (!token) {
    window.location.href = "login.php";
    return;
  }

  try {
    const authResponse = await fetch("auth/me.php", {
      headers: {
        Authorization: "Bearer " + token,
      },
    });

    const authResult = await authResponse.json();

    if (!authResponse.ok || authResult.status !== "success") {
      logout();
      return;
    }

    currentUser = authResult.user;

    if (currentUser.role !== "Administrator" && currentUser.role !== "Organiser") {
      alert("You do not have permission to manage events.");
      window.location.href = "events.php";
      return;
    }

    updateNavbar();

    if (currentUser.role === "Organiser") {
      document.getElementById("eventsIntro").textContent =
        "Events you organise. Create new ones, change their details and keep ticket numbers up to date.";
    }

    await Promise.all([loadEvents(), loadVenues()]);

    // dashboard.php links here with ?new=1 to open the create form straight away.
    if (new URLSearchParams(window.location.search).get("new") === "1") {
      openCreateModal();
    }
  } catch (error) {
    console.error(error);
    showToast("Event management couldn't load. Refresh the page to try again.", "error");
  }
}

/* ==========================================
   LOAD EVENTS
========================================== */

async function loadEvents() {
  const response = await fetch("api/events.php");
  const result = await response.json();

  if (!response.ok || result.status !== "success") {
    throw new Error(result.message || "Unable to load events");
  }

  if (currentUser.role === "Organiser") {
    events = result.data.filter((event) => Number(event.organiser_id) === Number(currentUser.user_id));
  } else {
    events = result.data;
  }

  displayEvents(events);
  updateStats();
}

/* ==========================================
   LOAD VENUES
========================================== */

async function loadVenues() {
  const response = await fetch("api/venues.php");
  const result = await response.json();

  if (!response.ok || result.status !== "success") {
    throw new Error(result.message || "Unable to load venues");
  }

  venues = result.data;

  populateVenues();
}

/* ==========================================
   DISPLAY EVENTS
========================================== */

function displayEvents(eventList) {
  eventTableBody.innerHTML = "";

  if (eventList.length === 0) {
    eventTableBody.innerHTML = `
      <tr>
        <td colspan="7" class="table-empty">
          ${events.length === 0 ? "No events yet. Use “New event” to create the first one." : "No events match your search."}
        </td>
      </tr>
    `;
    return;
  }

  eventList.forEach((event) => {
    const date = new Date(event.event_date + "T00:00:00");

    const formattedDate = date.toLocaleDateString("en-MY", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });

    const total = Number(event.total_tickets);
    const available = Number(event.available_tickets);
    const sold = Math.max(0, total - available);
    const percent = total > 0 ? Math.round((sold / total) * 100) : 0;

    const row = document.createElement("tr");

    row.innerHTML = `
      <td>
        <div class="cell-main">
          <strong>${escapeHTML(event.event_name)}</strong>
          <span>${escapeHTML(event.category)}, by ${escapeHTML(event.organiser_name)}</span>
        </div>
      </td>
      <td class="nowrap">
        ${formattedDate}
        <span class="cell-sub">${formatTime(event.start_time)}</span>
      </td>
      <td>${escapeHTML(event.venue_name)}</td>
      <td>
        <div class="meter">
          <span class="meter-text"><strong>${sold.toLocaleString()}</strong> of ${total.toLocaleString()}</span>
          <div class="meter-track"><div class="meter-fill" style="width:${percent}%"></div></div>
        </div>
      </td>
      <td class="num">RM ${Number(event.ticket_price).toFixed(2)}</td>
      <td><span class="badge ${getStatusClass(event.status)}">${escapeHTML(event.status)}</span></td>
      <td>
        <div class="row-actions">
          <button type="button" class="btn btn-sm" onclick="editEvent(${Number(event.event_id)})">Edit</button>
          <button type="button" class="btn btn-sm btn-danger-quiet" onclick="askDelete(${Number(event.event_id)})">Delete</button>
        </div>
      </td>
    `;

    eventTableBody.appendChild(row);
  });
}

/* ==========================================
   STATISTICS
========================================== */

function updateStats() {
  const upcoming = events.filter((event) => event.status === "Upcoming").length;

  const totalTickets = events.reduce((total, event) => total + Number(event.total_tickets), 0);

  const available = events.reduce((total, event) => total + Number(event.available_tickets), 0);

  document.getElementById("totalEvents").textContent = events.length;
  document.getElementById("upcomingEvents").textContent = upcoming;
  document.getElementById("totalTickets").textContent = totalTickets.toLocaleString();
  document.getElementById("availableTickets").textContent = available.toLocaleString();
}

/* ==========================================
   VENUE OPTIONS
========================================== */

function populateVenues(selectedVenueId = null) {
  const venueSelect = document.getElementById("venue");

  venueSelect.replaceChildren();

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "Choose an available venue";
  venueSelect.appendChild(placeholder);

  const eligibleVenues = venues.filter(
    (venue) =>
      venue.status === "Available" ||
      (selectedVenueId !== null && Number(venue.venue_id) === Number(selectedVenueId)),
  );

  eligibleVenues.forEach((venue) => {
    const option = document.createElement("option");
    option.value = venue.venue_id;

    const label = `${venue.venue_name}, ${venue.location} (capacity ${venue.capacity})`;
    const isUnavailable = venue.status !== "Available";

    option.textContent = isUnavailable ? `${label}, now unavailable (kept for this event only)` : label;

    venueSelect.appendChild(option);
  });

  if (selectedVenueId !== null) {
    venueSelect.value = String(selectedVenueId);
  } else {
    venueSelect.value = "";
  }

  if (eligibleVenues.length === 0) {
    placeholder.textContent = "No venues available. Ask an Administrator to add one.";
  }
}

/* ==========================================
   CREATE EVENT
========================================== */

document.getElementById("createEventButton").addEventListener("click", openCreateModal);

function openCreateModal() {
  formMode = "create";

  eventForm.reset();

  // Remove any unavailable venue retained from a previous edit.
  populateVenues();

  document.getElementById("eventId").value = "";
  document.getElementById("modalEyebrow").textContent = "Create";
  document.getElementById("modalTitle").textContent = "New event";

  saveEventButton.textContent = "Create event";

  clearFormMessage();
  eventModal.classList.add("show");
  document.getElementById("eventName").focus();
}

/* ==========================================
   EDIT EVENT
========================================== */

function editEvent(eventId) {
  const event = events.find((item) => Number(item.event_id) === Number(eventId));

  if (!event) {
    return;
  }

  formMode = "edit";

  document.getElementById("eventId").value = event.event_id;
  document.getElementById("eventName").value = event.event_name;
  document.getElementById("category").value = event.category;

  // Existing events may keep their venue if Admin later marks it unavailable.
  populateVenues(event.venue_id);

  document.getElementById("venue").value = event.venue_id;
  document.getElementById("eventDate").value = event.event_date;
  document.getElementById("startTime").value = event.start_time.substring(0, 5);
  document.getElementById("endTime").value = event.end_time.substring(0, 5);
  document.getElementById("ticketPrice").value = event.ticket_price;
  document.getElementById("totalTicketCount").value = event.total_tickets;
  document.getElementById("status").value = event.status;
  document.getElementById("description").value = event.description || "";

  document.getElementById("modalEyebrow").textContent = "Edit event";
  document.getElementById("modalTitle").textContent = event.event_name;

  saveEventButton.textContent = "Save changes";

  clearFormMessage();
  eventModal.classList.add("show");
}

/* ==========================================
   SAVE EVENT
========================================== */

eventForm.addEventListener("submit", async function (event) {
  event.preventDefault();

  const payload = {
    event_name: document.getElementById("eventName").value.trim(),
    category: document.getElementById("category").value,
    venue_id: Number(document.getElementById("venue").value),
    event_date: document.getElementById("eventDate").value,
    start_time: document.getElementById("startTime").value,
    end_time: document.getElementById("endTime").value,
    ticket_price: Number(document.getElementById("ticketPrice").value),
    total_tickets: Number(document.getElementById("totalTicketCount").value),
    status: document.getElementById("status").value,
    description: document.getElementById("description").value.trim(),
  };

  if (formMode === "edit") {
    payload.event_id = Number(document.getElementById("eventId").value);
  }

  saveEventButton.disabled = true;
  saveEventButton.textContent = formMode === "create" ? "Creating…" : "Saving…";

  try {
    const response = await fetch("api/events.php", {
      method: formMode === "create" ? "POST" : "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify(payload),
    });

    const result = await response.json();

    if (response.status === 401) {
      logout();
      return;
    }

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message || "Unable to save event");
    }

    showFormMessage(result.message, "success");

    await loadEvents();

    setTimeout(function () {
      eventModal.classList.remove("show");
      showToast(result.message, "success");
    }, 650);
  } catch (error) {
    showFormMessage(error.message, "error");
  } finally {
    saveEventButton.disabled = false;
    saveEventButton.textContent = formMode === "create" ? "Create event" : "Save changes";
  }
});

/* ==========================================
   DELETE EVENT
========================================== */

function askDelete(eventId) {
  selectedDeleteId = eventId;

  const event = events.find((item) => Number(item.event_id) === Number(eventId));

  document.getElementById("deleteMessage").textContent = event
    ? "“" + event.event_name + "” will be removed permanently. Events that already have bookings can't be deleted."
    : "This event will be removed permanently.";

  deleteModal.classList.add("show");
  document.getElementById("keepEventButton").focus();
}

document.getElementById("confirmDeleteButton").addEventListener("click", async function () {
  if (!selectedDeleteId) {
    return;
  }

  this.disabled = true;
  this.textContent = "Deleting…";

  try {
    const response = await fetch("api/events.php", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify({
        event_id: selectedDeleteId,
      }),
    });

    const result = await response.json();

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message || "Unable to delete event");
    }

    deleteModal.classList.remove("show");
    selectedDeleteId = null;

    await loadEvents();

    showToast(result.message, "success");
  } catch (error) {
    deleteModal.classList.remove("show");
    showToast(error.message, "error");
  } finally {
    this.disabled = false;
    this.textContent = "Delete event";
  }
});

/* ==========================================
   SEARCH + FILTER
========================================== */

document.getElementById("eventSearch").addEventListener("input", filterEvents);
document.getElementById("statusFilter").addEventListener("change", filterEvents);

function filterEvents() {
  const search = document.getElementById("eventSearch").value.toLowerCase();
  const status = document.getElementById("statusFilter").value;

  const filtered = events.filter((event) => {
    const searchable = (
      event.event_name +
      " " +
      event.venue_name +
      " " +
      event.organiser_name +
      " " +
      event.category
    ).toLowerCase();

    const searchMatch = searchable.includes(search);
    const statusMatch = status === "" || event.status === status;

    return searchMatch && statusMatch;
  });

  displayEvents(filtered);
}

/* ==========================================
   MODAL CONTROLS
========================================== */

function closeEventModal() {
  eventModal.classList.remove("show");
}

document.getElementById("closeEventModal").addEventListener("click", closeEventModal);
document.getElementById("cancelEventModal").addEventListener("click", closeEventModal);

document.getElementById("keepEventButton").addEventListener("click", function () {
  selectedDeleteId = null;
  deleteModal.classList.remove("show");
});

document.addEventListener("keydown", function (event) {
  if (event.key !== "Escape") return;
  if (eventModal.classList.contains("show")) closeEventModal();
  if (deleteModal.classList.contains("show")) {
    selectedDeleteId = null;
    deleteModal.classList.remove("show");
  }
});

/* ==========================================
   FORM MESSAGES
========================================== */

function clearFormMessage() {
  formMessage.className = "form-message";
  formMessage.textContent = "";
}

function showFormMessage(message, type) {
  formMessage.textContent = message;
  formMessage.className = "form-message " + type;
}

/* ==========================================
   NAVBAR (sidebar account block)
========================================== */

function updateNavbar() {
  EventifyShell.setUser(currentUser);
}

/* ==========================================
   LOGOUT
========================================== */

function logout() {
  localStorage.removeItem("eventify_token");
  localStorage.removeItem("eventify_user");
  window.location.href = "login.php";
}

/* ==========================================
   STATUS
========================================== */

function getStatusClass(status) {
  switch (status) {
    case "Upcoming":
      return "status-upcoming";
    case "Ongoing":
      return "status-ongoing";
    case "Completed":
      return "status-completed";
    case "Cancelled":
      return "status-cancelled";
    default:
      return "status-completed";
  }
}

/* ==========================================
   TIME
========================================== */

function formatTime(time) {
  if (!time) {
    return "";
  }

  const pieces = time.split(":");
  const date = new Date();

  date.setHours(Number(pieces[0]));
  date.setMinutes(Number(pieces[1]));

  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
}

/* ==========================================
   TOAST
========================================== */

function showToast(message, type) {
  toast.textContent = message;
  toast.className = "toast " + type + " show";

  setTimeout(function () {
    toast.classList.remove("show");
  }, 3500);
}

/* ==========================================
   ESCAPE HTML
========================================== */

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* ==========================================
   START
========================================== */

initialise();
</script>
</body>
</html>
