/* =====================================================
   EVENTIFY STAFF SHELL
   Shared by dashboard.php and the manage-*.php pages.

   - EventifyShell.setUser(user) fills the sidebar account
     block and reveals Administrator-only links. Each page
     calls it after verifying the JWT with auth/me.php.
   - Opens and closes the sidebar on small screens.
===================================================== */

(function () {
  "use strict";

  const shell = document.querySelector(".shell");
  const menuButton = document.getElementById("shellMenuButton");

  function setNavOpen(open) {
    if (!shell) return;
    shell.classList.toggle("nav-open", open);
    if (menuButton) menuButton.setAttribute("aria-expanded", String(open));
  }

  if (menuButton) {
    menuButton.addEventListener("click", function () {
      setNavOpen(!shell.classList.contains("nav-open"));
    });
  }

  document.addEventListener("click", function (event) {
    if (event.target.closest("[data-shell-close]")) setNavOpen(false);
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") setNavOpen(false);
  });

  function signOut() {
    if (typeof window.logout === "function") {
      window.logout();
      return;
    }
    localStorage.removeItem("eventify_token");
    localStorage.removeItem("eventify_user");
    window.location.href = "login.php";
  }

  function setUser(user) {
    if (!shell || !user) return;

    const role = String(user.role || "");
    const name = String(user.name || "Account");

    shell.classList.toggle("is-admin", role === "Administrator");

    const box = document.getElementById("sidebarUser");
    if (!box) return;

    const avatar = document.createElement("span");
    avatar.className = "avatar";
    avatar.setAttribute("aria-hidden", "true");
    avatar.textContent = name.charAt(0).toUpperCase();

    const nameEl = document.createElement("strong");
    nameEl.textContent = name;

    const roleEl = document.createElement("small");
    roleEl.textContent = role;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "sidebar-signout";
    button.textContent = "Sign out";
    button.addEventListener("click", signOut);

    box.replaceChildren(avatar, nameEl, roleEl, button);
  }

  window.EventifyShell = { setUser: setUser };
})();
