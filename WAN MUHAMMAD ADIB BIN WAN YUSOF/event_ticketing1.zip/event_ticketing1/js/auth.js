/* =====================================================
   EVENTIFY GLOBAL AUTHENTICATION & NAVIGATION

   - Guest: Home, Events, Sign in, Create account
   - Customer: Home, Events, My Bookings, Sign out
   - Organiser: Home, Events, Dashboard, Sign out
   - Administrator: Home, Events, Dashboard, Sign out
===================================================== */

(function () {
  "use strict";

  function startNavbar() {
    const nav =
      document.getElementById("authNavigation") ||
      document.querySelector(".nav-actions");

    /* ==========================================
           CONTROL MY BOOKINGS VISIBILITY
        ========================================== */

    function setBookingsVisibility(isCustomer) {
      document.body.classList.toggle("eventify-customer-logged-in", isCustomer);

      const bookingLinks = document.querySelectorAll(
        '.nav-links a[href="bookings.php"]',
      );

      bookingLinks.forEach(function (link) {
        link.style.display = isCustomer ? "inline-flex" : "none";
      });
    }

    /*
           Hide My Bookings immediately while
           authentication is being verified.
        */

    setBookingsVisibility(false);

    // Pages without this navbar do not need updating.
    if (!nav) {
      return;
    }

    /* ==========================================
           CREATE NAVIGATION LINK
        ========================================== */

    function makeLink(label, href, className) {
      const link = document.createElement("a");

      link.href = href;
      link.className = className;
      link.textContent = label;

      return link;
    }

    /* ==========================================
           GUEST NAVIGATION
        ========================================== */

    function showGuest() {
      setBookingsVisibility(false);

      nav.replaceChildren(
        makeLink("Sign in", "login.php", "sign-in"),
        makeLink("Create account", "register.php", "nav-button"),
      );
    }

    /* ==========================================
           LOGGED-IN NAVIGATION
        ========================================== */

    function showLoggedIn(user) {
      const role = String(user.role || "");

      /*
               My Bookings only appears
               for logged-in Customers.
            */

      setBookingsVisibility(role === "Customer");

      nav.replaceChildren();

      /* DASHBOARD FOR STAFF */

      if (role === "Administrator" || role === "Organiser") {
        nav.appendChild(makeLink("Dashboard", "dashboard.php", "sign-in"));
      }

      /* DISPLAY USER NAME AND ROLE */

      const userDetails = document.createElement("span");
      userDetails.className = "nav-user";
      userDetails.textContent = String(user.name || "Account");

      const roleLabel = document.createElement("small");
      roleLabel.textContent = role;
      userDetails.appendChild(roleLabel);

      nav.appendChild(userDetails);

      /* SIGN OUT BUTTON */

      const logout = document.createElement("button");
      logout.type = "button";
      logout.className = "nav-button";
      logout.textContent = "Sign out";

      logout.addEventListener("click", function () {
        localStorage.removeItem("eventify_token");

        localStorage.removeItem("eventify_user");

        setBookingsVisibility(false);

        window.location.href = "login.php";
      });

      nav.appendChild(logout);
    }

    /* ==========================================
           VERIFY JWT AUTHENTICATION
        ========================================== */

    async function checkLogin() {
      const token = localStorage.getItem("eventify_token");

      /* NOT LOGGED IN */

      if (!token) {
        showGuest();

        return;
      }

      try {
        const response = await fetch("auth/me.php", {
          headers: {
            Authorization: "Bearer " + token,
          },
          cache: "no-store",
        });

        /* INVALID OR EXPIRED TOKEN */

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("eventify_token");

          localStorage.removeItem("eventify_user");

          showGuest();

          return;
        }

        if (!response.ok) {
          showGuest();

          return;
        }

        const result = await response.json();

        if (result.status !== "success" || !result.user) {
          showGuest();

          return;
        }

        /* SAVE VERIFIED USER */

        localStorage.setItem("eventify_user", JSON.stringify(result.user));

        /* UPDATE NAVBAR BASED ON ROLE */

        showLoggedIn(result.user);
      } catch (error) {
        /*
                   If the server is temporarily
                   unavailable, do not delete
                   the user's existing token.
                */

        showGuest();
      }
    }

    /* ==========================================
           START AUTHENTICATION CHECK
        ========================================== */

    checkLogin();
  }

  /* ==========================================
       WAIT FOR PAGE TO LOAD
    ========================================== */

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startNavbar);
  } else {
    startNavbar();
  }
})();
