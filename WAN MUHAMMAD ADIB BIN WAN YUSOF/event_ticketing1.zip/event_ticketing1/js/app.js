/* =========================================
   EVENTIFY - EVENTS PAGE
   Loads events from the API, lists them by
   month and filters them as the user types.
========================================= */

/* =========================================
   ELEMENTS
========================================= */

const eventGrid = document.getElementById("eventGrid");

const eventCount = document.getElementById("eventCount");

const searchInput = document.getElementById("searchInput");

const categoryFilter = document.getElementById("categoryFilter");

const searchButton = document.getElementById("searchButton");

let allEvents = [];

/* =========================================
   LOAD EVENTS FROM API
========================================= */

async function loadEvents() {
  if (!eventGrid) {
    return;
  }

  try {
    const response = await fetch("api/events.php");

    if (!response.ok) {
      throw new Error("Server returned status " + response.status);
    }

    const result = await response.json();

    if (result.status === "success" && Array.isArray(result.data)) {
      allEvents = result.data;

      displayEvents(allEvents);
    } else {
      showError("Unable to load events.");
    }
  } catch (error) {
    console.error("Events API Error:", error);

    showError("Unable to connect to the event server.");
  }
}

/* =========================================
   DISPLAY EVENTS
   Events are listed soonest first and grouped
   under a heading for each month.
========================================= */

function displayEvents(events) {
  if (!eventGrid) {
    return;
  }

  if (eventCount) {
    eventCount.textContent = events.length;
  }

  if (events.length === 0) {
    eventGrid.innerHTML = `
      <div class="state">
        <h3>No events match your search</h3>
        <p>Try a different word, or choose “All categories” to see everything.</p>
      </div>
    `;
    return;
  }

  const sorted = [...events].sort((a, b) =>
    (String(a.event_date) + String(a.start_time)).localeCompare(
      String(b.event_date) + String(b.start_time),
    ),
  );

  const groups = new Map();

  sorted.forEach((event) => {
    const key = String(event.event_date).slice(0, 7);
    if (!groups.has(key)) {
      groups.set(key, []);
    }
    groups.get(key).push(event);
  });

  let html = "";

  groups.forEach((groupEvents, key) => {
    const monthDate = new Date(key + "-01T00:00:00");
    const monthLabel = Number.isNaN(monthDate.getTime())
      ? "Date to be confirmed"
      : monthDate.toLocaleDateString("en-MY", { month: "long", year: "numeric" });

    html += `
      <section class="month-group">
        <div class="month-title">
          <h2>${escapeHTML(monthLabel)}</h2>
          <span>${groupEvents.length} ${groupEvents.length === 1 ? "event" : "events"}</span>
        </div>
        <div class="event-list">
          ${groupEvents.map(eventRow).join("")}
        </div>
      </section>
    `;
  });

  eventGrid.innerHTML = html;
}

/* =========================================
   ONE EVENT ROW
========================================= */

function eventRow(event) {
  const date = new Date(event.event_date + "T00:00:00");
  const day = String(date.getDate()).padStart(2, "0");
  const month = date.toLocaleString("en-US", { month: "short" });

  const status = String(event.status ?? "");
  const isOpen = status === "Upcoming" || status === "Ongoing";
  const price = Number(event.ticket_price);
  const available = Number(event.available_tickets);
  const total = Number(event.total_tickets);

  let leftClass = "event-row-left";
  let leftText = available.toLocaleString() + " tickets left";

  if (available <= 0) {
    leftClass += " is-out";
    leftText = "Sold out";
  } else if (total > 0 && available / total <= 0.1) {
    leftClass += " is-low";
    leftText = "Only " + available.toLocaleString() + " left";
  }

  const flag = isOpen
    ? ""
    : `<span class="event-row-flags"><span class="badge ${getStatusClass(status)}">${escapeHTML(status)}</span></span>`;

  return `
    <a class="event-row" href="event-details.php?id=${Number(event.event_id)}">
      <span class="stamp${isOpen ? "" : " is-past"}">
        <span class="stamp-day">${day}</span>
        <span class="stamp-month">${month}</span>
      </span>
      <span class="event-row-main">
        <span class="event-row-cat">${escapeHTML(event.category)}</span>
        <span class="event-row-title">${escapeHTML(event.event_name)}</span>
        <span class="event-row-meta">
          ${escapeHTML(event.venue_name)}, ${formatTime(event.start_time)} to ${formatTime(event.end_time)}
        </span>
        ${flag}
      </span>
      <span class="event-row-side">
        <span class="event-row-price">${price === 0 ? "Free" : "RM " + price.toFixed(2)}</span>
        ${isOpen ? `<span class="${leftClass}">${leftText}</span>` : ""}
      </span>
    </a>
  `;
}

/* =========================================
   SEARCH & FILTER
========================================= */

function filterEvents() {
  if (!searchInput || !categoryFilter) {
    return;
  }

  const searchValue = searchInput.value.trim().toLowerCase();

  const categoryValue = categoryFilter.value.trim().toLowerCase();

  const filteredEvents = allEvents.filter((event) => {
    const eventName = String(event.event_name ?? "").toLowerCase();

    const venueName = String(event.venue_name ?? "").toLowerCase();

    const description = String(event.description ?? "").toLowerCase();

    const category = String(event.category ?? "").toLowerCase();

    const matchesSearch =
      eventName.includes(searchValue) ||
      venueName.includes(searchValue) ||
      description.includes(searchValue);

    const matchesCategory = categoryValue === "" || category === categoryValue;

    return matchesSearch && matchesCategory;
  });

  displayEvents(filteredEvents);
}

/* =========================================
   FORMAT TIME
========================================= */

function formatTime(time) {
  if (!time) {
    return "Time unavailable";
  }

  const timeParts = time.split(":");

  const hour = Number(timeParts[0]);

  const minute = Number(timeParts[1]);

  const date = new Date();

  date.setHours(hour);

  date.setMinutes(minute);

  date.setSeconds(0);

  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
}

/* =========================================
   STATUS
========================================= */

function getStatusClass(status) {
  const value = String(status ?? "").toLowerCase();

  if (value === "cancelled") {
    return "status-cancelled";
  }

  if (value === "completed") {
    return "status-completed";
  }

  if (value === "ongoing") {
    return "status-ongoing";
  }

  return "status-upcoming";
}

/* =========================================
   ERROR MESSAGE
========================================= */

function showError(message) {
  if (!eventGrid) {
    return;
  }

  if (eventCount) {
    eventCount.textContent = "0";
  }

  eventGrid.innerHTML = `
    <div class="state">
      <h3>Events could not be loaded</h3>
      <p>${escapeHTML(message)} Refresh the page to try again.</p>
    </div>
  `;
}

/* =========================================
   ESCAPE HTML
========================================= */

function escapeHTML(value) {
  if (value === null || value === undefined) {
    return "";
  }

  return String(value)
    .replaceAll("&", "&amp;")

    .replaceAll("<", "&lt;")

    .replaceAll(">", "&gt;")

    .replaceAll('"', "&quot;")

    .replaceAll("'", "&#039;");
}

/* =========================================
   EVENT LISTENERS
========================================= */

if (searchInput) {
  searchInput.addEventListener("input", filterEvents);
}

if (categoryFilter) {
  categoryFilter.addEventListener("change", filterEvents);
}

if (searchButton) {
  searchButton.addEventListener("click", filterEvents);
}

/* =========================================
   START
   ?category=Music or ?q=jazz in the address
   pre-fills the filters (used by the Home page).
========================================= */

const startParams = new URLSearchParams(window.location.search);

if (searchInput && startParams.get("q")) {
  searchInput.value = startParams.get("q");
}

if (categoryFilter && startParams.get("category")) {
  categoryFilter.value = startParams.get("category");
}

loadEvents().then(function () {
  if (startParams.get("q") || startParams.get("category")) {
    filterEvents();
  }
});
