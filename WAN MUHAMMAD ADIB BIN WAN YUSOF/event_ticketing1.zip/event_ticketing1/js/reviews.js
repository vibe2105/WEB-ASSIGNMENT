/* =====================================================
   EVENTIFY REVIEWS & RATINGS (event-details.php)

   Talks to api/reviews.php:
   - shows the average rating, a 5-to-1 breakdown and
     the list of reviews
   - lets a customer who attended write, edit or delete
     their own review
   - lets an Administrator remove any review

   Usage: EventifyReviews.load(eventId) after the event
   has been rendered. Needs #reviewsRoot, #heroRating and
   the #reviewDeleteModal dialog on the page.
===================================================== */

(function () {
  "use strict";

  const COMMENT_MAX = 1000;

  let eventId = null;
  let state = null; // last GET response
  let editing = false; // customer is editing their existing review
  let pendingDeleteId = null;

  /* ---------------------------------------------
     SMALL HELPERS
  --------------------------------------------- */

  function token() {
    return localStorage.getItem("eventify_token");
  }

  function escapeHTML(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  const STAR_PATH =
    "M12 2.8l2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17.2l-5.7 3.1 1.2-6.4-4.7-4.4 6.4-.8z";

  function starIcons() {
    return Array.from(
      { length: 5 },
      () => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${STAR_PATH}"/></svg>`,
    ).join("");
  }

  /* Five stars filled to the given rating (e.g. 4.3 fills 86%). */
  function starsHTML(rating, sizeClass = "") {
    const value = Math.max(0, Math.min(5, Number(rating) || 0));
    const percent = (value / 5) * 100;
    const label = value.toFixed(1).replace(".0", "") + " out of 5 stars";

    return `
      <span class="stars ${sizeClass}" role="img" aria-label="${label}" style="--fill:${percent}%">
        <span class="stars-base">${starIcons()}</span>
        <span class="stars-top">${starIcons()}</span>
      </span>
    `;
  }

  function formatDate(value) {
    const date = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(date.getTime())) return "";
    return date.toLocaleDateString("en-MY", { day: "numeric", month: "short", year: "numeric" });
  }

  function plural(count, word) {
    return count + " " + word + (count === 1 ? "" : "s");
  }

  async function request(method, body) {
    const response = await fetch("api/reviews.php", {
      method: method,
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token(),
      },
      body: JSON.stringify(body),
    });

    const result = await response.json().catch(() => ({}));

    if (response.status === 401) {
      throw new Error("Your session has expired. Sign in again to continue.");
    }

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message || "Something went wrong. Try again.");
    }

    return result;
  }

  /* ---------------------------------------------
     LOAD
  --------------------------------------------- */

  async function load(id) {
    eventId = id;

    const root = document.getElementById("reviewsRoot");
    if (!root) return;

    try {
      const headers = token() ? { Authorization: "Bearer " + token() } : {};

      const response = await fetch("api/reviews.php?event_id=" + encodeURIComponent(eventId), {
        headers: headers,
        cache: "no-store",
      });

      const result = await response.json();

      if (!response.ok || result.status !== "success") {
        throw new Error(result.message || "Reviews could not be loaded");
      }

      state = result;
      render();

      // The page builds this section after loading, so jump to it now if the link asked for it.
      if (window.location.hash === "#reviews") {
        document.getElementById("reviews").scrollIntoView();
      }
    } catch (error) {
      root.innerHTML = `<p class="muted">Reviews could not be loaded. Refresh the page to try again.</p>`;
    }
  }

  /* ---------------------------------------------
     RENDER
  --------------------------------------------- */

  function render() {
    const root = document.getElementById("reviewsRoot");
    const summary = state.summary;
    const reviews = state.data;
    const viewer = state.viewer || null;

    renderHeroRating(summary);

    root.innerHTML = `
      ${summaryHTML(summary)}
      <div id="reviewComposer">${composerHTML(viewer)}</div>
      ${listHTML(reviews, viewer)}
    `;

    bindComposer();
  }

  function renderHeroRating(summary) {
    const hero = document.getElementById("heroRating");
    if (!hero) return;

    if (!summary.review_count) {
      hero.hidden = true;
      return;
    }

    hero.hidden = false;
    hero.innerHTML = `
      ${starsHTML(summary.average_rating, "stars-sm")}
      <span>${Number(summary.average_rating).toFixed(1)} from ${plural(summary.review_count, "review")}</span>
    `;
  }

  function summaryHTML(summary) {
    if (!summary.review_count) {
      return `<p class="review-empty">No reviews yet. People who went to this event can rate it once it has finished.</p>`;
    }

    const rows = ["5", "4", "3", "2", "1"]
      .map((star) => {
        const count = Number(summary.breakdown[star] || 0);
        const percent = Math.round((count / summary.review_count) * 100);
        return `
          <div class="rating-bar">
            <span>${star} star</span>
            <div class="meter-track"><div class="meter-fill" style="width:${percent}%"></div></div>
            <span class="num">${count}</span>
          </div>
        `;
      })
      .join("");

    return `
      <div class="rating-summary">
        <div class="rating-score">
          <strong>${Number(summary.average_rating).toFixed(1)}</strong>
          ${starsHTML(summary.average_rating)}
          <span>${plural(summary.review_count, "review")}</span>
        </div>
        <div class="rating-bars" aria-label="Ratings breakdown">${rows}</div>
      </div>
    `;
  }

  function composerHTML(viewer) {
    // Guests: invite them to sign in.
    if (!viewer) {
      const back = encodeURIComponent(window.location.pathname + window.location.search + "#reviews");
      return `
        <p class="review-note">
          Went to this event? <a href="login.php?return=${back}">Sign in</a> to leave a rating.
        </p>
      `;
    }

    const mine = viewer.my_review;

    // Customer with an existing review: show it, or the edit form.
    if (mine && !editing) {
      return `
        <div class="my-review">
          <div class="my-review-head">
            <strong>Your review</strong>
            ${starsHTML(mine.rating, "stars-sm")}
          </div>
          ${mine.comment ? `<p>${escapeHTML(mine.comment)}</p>` : `<p class="muted">You didn't add a comment.</p>`}
          <div class="my-review-actions">
            <button type="button" class="btn btn-sm" data-review-action="edit">Edit review</button>
            <button type="button" class="btn btn-sm btn-danger-quiet" data-review-action="delete" data-review-id="${mine.review_id}">Delete</button>
          </div>
        </div>
      `;
    }

    if (mine && editing) {
      return formHTML(mine.rating, mine.comment || "", "Save changes", true);
    }

    if (viewer.can_review) {
      return formHTML(0, "", "Post review", false);
    }

    // Customers who can't review yet get the reason; staff see nothing here.
    if (viewer.role === "Customer" && viewer.reason_message) {
      return `<p class="review-note">${escapeHTML(viewer.reason_message)}</p>`;
    }

    return "";
  }

  function formHTML(rating, comment, buttonLabel, isEdit) {
    const radios = [5, 4, 3, 2, 1]
      .map(
        (value) => `
          <input type="radio" name="reviewRating" id="reviewRating${value}" value="${value}" ${rating === value ? "checked" : ""}>
          <label for="reviewRating${value}" title="${plural(value, "star")}">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="${STAR_PATH}"/></svg>
            <span class="visually-hidden">${plural(value, "star")}</span>
          </label>
        `,
      )
      .join("");

    return `
      <form class="review-form" id="reviewForm" novalidate>
        <h3>${isEdit ? "Edit your review" : "Rate this event"}</h3>

        <fieldset class="star-input">
          <legend>Your rating</legend>
          <div class="star-input-row">${radios}</div>
        </fieldset>

        <div class="field">
          <label for="reviewComment">Comment <span class="faint">(optional)</span></label>
          <textarea id="reviewComment" maxlength="${COMMENT_MAX}" placeholder="What was good? What could be better?">${escapeHTML(comment)}</textarea>
          <span class="hint" id="reviewCount">${comment.length} / ${COMMENT_MAX}</span>
        </div>

        <div class="form-message" id="reviewMessage" role="status"></div>

        <div class="review-form-actions">
          ${isEdit ? `<button type="button" class="btn" data-review-action="cancel-edit">Cancel</button>` : ""}
          <button type="submit" class="btn btn-primary" id="reviewSubmit">${buttonLabel}</button>
        </div>
      </form>
    `;
  }

  function listHTML(reviews, viewer) {
    if (!reviews.length) return "";

    const canModerate = Boolean(viewer && viewer.can_moderate);

    const items = reviews
      .map(
        (review) => `
          <li class="review">
            <div class="review-head">
              <span class="avatar avatar-quiet" aria-hidden="true">${escapeHTML(review.reviewer_name.charAt(0))}</span>
              <div>
                <strong>${escapeHTML(review.reviewer_name)}${review.is_mine ? ' <span class="you-tag">You</span>' : ""}</strong>
                <span class="review-date">
                  ${formatDate(review.created_at)}${review.updated_at && review.updated_at !== review.created_at ? ", edited" : ""}
                </span>
              </div>
              ${starsHTML(review.rating, "stars-sm")}
            </div>
            ${review.comment ? `<p>${escapeHTML(review.comment)}</p>` : ""}
            ${
              canModerate
                ? `<button type="button" class="btn btn-sm btn-danger-quiet review-remove" data-review-action="delete" data-review-id="${review.review_id}">Remove review</button>`
                : ""
            }
          </li>
        `,
      )
      .join("");

    return `<ol class="review-list">${items}</ol>`;
  }

  /* ---------------------------------------------
     FORM: POST (new) or PUT (edit)
  --------------------------------------------- */

  function bindComposer() {
    const form = document.getElementById("reviewForm");
    if (!form) return;

    const comment = document.getElementById("reviewComment");
    const counter = document.getElementById("reviewCount");

    comment.addEventListener("input", function () {
      counter.textContent = comment.value.length + " / " + COMMENT_MAX;
    });

    // Clear the "choose a rating" message as soon as a star is picked.
    form.querySelectorAll('input[name="reviewRating"]').forEach(function (radio) {
      radio.addEventListener("change", function () {
        document.getElementById("reviewMessage").className = "form-message";
      });
    });

    form.addEventListener("submit", async function (event) {
      event.preventDefault();

      const message = document.getElementById("reviewMessage");
      const button = document.getElementById("reviewSubmit");
      const chosen = form.querySelector('input[name="reviewRating"]:checked');

      if (!chosen) {
        message.className = "form-message error";
        message.textContent = "Choose a rating from 1 to 5 stars.";
        return;
      }

      const mine = state.viewer && state.viewer.my_review;
      const isEdit = Boolean(mine && editing);
      const label = button.textContent;

      button.disabled = true;
      button.textContent = isEdit ? "Saving…" : "Posting…";

      try {
        const body = { rating: Number(chosen.value), comment: comment.value.trim() };

        if (isEdit) {
          body.review_id = mine.review_id;
          await request("PUT", body);
        } else {
          body.event_id = eventId;
          await request("POST", body);
        }

        editing = false;
        await load(eventId);
      } catch (error) {
        message.className = "form-message error";
        message.textContent = error.message;
        button.disabled = false;
        button.textContent = label;
      }
    });
  }

  /* ---------------------------------------------
     BUTTONS: edit / cancel / delete
  --------------------------------------------- */

  document.addEventListener("click", function (event) {
    const button = event.target.closest("[data-review-action]");
    if (!button) return;

    const action = button.dataset.reviewAction;

    if (action === "edit") {
      editing = true;
      render();
      document.getElementById("reviewComment").focus();
    }

    if (action === "cancel-edit") {
      editing = false;
      render();
    }

    if (action === "delete") {
      pendingDeleteId = Number(button.dataset.reviewId);
      const mine = state.viewer && state.viewer.my_review;
      const own = mine && mine.review_id === pendingDeleteId;

      document.getElementById("reviewDeleteTitle").textContent = own ? "Delete your review?" : "Remove this review?";
      document.getElementById("reviewDeleteText").textContent = own
        ? "Your rating and comment will be removed permanently. You can write a new review afterwards."
        : "The review will be removed permanently. Use this for reviews that break the rules.";

      document.getElementById("reviewDeleteModal").classList.add("show");
      document.getElementById("reviewKeepButton").focus();
    }
  });

  function closeDeleteDialog() {
    pendingDeleteId = null;
    document.getElementById("reviewDeleteModal").classList.remove("show");
  }

  document.addEventListener("DOMContentLoaded", function () {
    const keep = document.getElementById("reviewKeepButton");
    const confirm = document.getElementById("reviewConfirmDelete");
    if (!keep || !confirm) return;

    keep.addEventListener("click", closeDeleteDialog);

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && pendingDeleteId) closeDeleteDialog();
    });

    confirm.addEventListener("click", async function () {
      if (!pendingDeleteId) return;

      confirm.disabled = true;
      confirm.textContent = "Deleting…";

      try {
        await request("DELETE", { review_id: pendingDeleteId });
        closeDeleteDialog();
        editing = false;
        await load(eventId);
      } catch (error) {
        closeDeleteDialog();
        alert(error.message);
      } finally {
        confirm.disabled = false;
        confirm.textContent = "Delete review";
      }
    });
  });

  window.EventifyReviews = { load: load, starsHTML: starsHTML };
})();
