# Eventify REST API Documentation (team handoff)

Base URL in local XAMPP: `http://localhost/event_ticketing1`. All standard APIs return JSON with `status: "success"` or `status: "error"`. Set `Content-Type: application/json` for JSON requests. Protected requests: `Authorization: Bearer <JWT>`.

| Endpoint | HTTP | Access | Request | Success | Typical errors |
|---|---|---|---|---|---|
| `auth/register.php` | POST | Guest | `name,email,password,confirm_password` | 201, Customer info | 400,409,500 |
| `auth/login.php` | POST | Guest | `email,password` | 200, JWT `token`, user | 400,401,500 |
| `auth/me.php` | GET | Any signed-in | JWT | 200, current user and role | 401,503 |
| `api/status.php` | GET | Public | none | 200, API running | 405 |
| `api/system-metrics.php` | GET | Administrator JWT **and** `X-API-Key: <internal key>` | none | 200, counts of users/events/venues/bookings | 401,403,405,503 |
| `api/users.php` | GET | Administrator | optional `?user_id=N` | 200, user(s), counts | 401,403,404 |
| `api/users.php` | POST | Administrator | `name,email,password,role` | 201, user created | 400,401,403,409 |
| `api/users.php` | PUT | Administrator | `user_id,name,email,role,password` (password optional) | 200 | 400,401,403,404,409 |
| `api/users.php` | DELETE | Administrator | `user_id` | 200 | 401,403,404,409 |
| `api/venues.php` | GET | Public | optional `?venue_id=N` | 200, venue(s) | 404 |
| `api/venues.php` | POST | Administrator | `venue_name,location,capacity,status` | 201, `venue_id` | 400,401,403,409 |
| `api/venues.php` | PUT | Administrator | `venue_id,venue_name,location,capacity,status` | 200 | 400,401,403,404,409 |
| `api/venues.php` | DELETE | Administrator | `venue_id` | 200 | 401,403,404,409 |
| `api/events.php` | GET | Public | `?event_id=N` OR list `?search=&category=&status=&page=&limit=&sort=&order=` | 200, event(s), optional pagination | 400,404 |
| `api/events.php` | POST | Administrator or Organiser | fields below | 201, `event_id` | 400,401,403 |
| `api/events.php` | PUT | Administrator or event-owning Organiser | `event_id` + fields below | 200 | 400,401,403,404 |
| `api/events.php` | DELETE | Administrator or event-owning Organiser | `event_id` | 200 | 401,403,404,409 |
| `api/bookings.php` | GET | Signed-in | optional `?booking_id=N` | 200, bookings authorized for role | 401,403,404 |
| `api/bookings.php` | POST | Customer | `event_id,quantity` | 201, booking details | 400,401,403,404,409 |
| `api/bookings.php` | PUT | Administrator / event-owning Organiser | `booking_id,booking_status` | 200 | 400,401,403,404,409 |
| `api/bookings.php` | DELETE | Customer own or permitted staff | `booking_id` | 200 (soft cancel) | 400,401,403,404,409 |
| `api/ticket-qr.php` | GET | Booking-owning Customer, owning Organiser or Administrator | `?booking_id=N`, JWT | 200, binary `image/png` from external API | 400,401,403,404,409,502,503 |
| `api/verify-ticket.php` | POST | Administrator / owning Organiser | `ticket_code` string | 200, `valid:true/false` + summary | 400,401,403,404 |
| `api/reviews.php` | GET | Public (JWT optional) | `?event_id=N`, optional `sort=newest\|highest\|lowest`, `limit` (1–100, default 50) | 200, `summary` (average, count, 5→1 breakdown) + reviews; with a JWT also `viewer` (can_review, reason, my_review) | 400,404 |
| `api/reviews.php` | GET | Customer | `?mine=1` | 200, the caller's own reviews | 401,403 |
| `api/reviews.php` | POST | Customer with a Confirmed booking, after the event has finished | `event_id,rating,comment` (comment optional) | 201, `review_id` | 400,401,403,404,409 |
| `api/reviews.php` | PUT | Review owner (Customer) | `review_id,rating,comment` | 200 | 400,401,403,404 |
| `api/reviews.php` | DELETE | Review owner, or Administrator (moderation) | `review_id` | 200 | 400,401,403,404 |

**Events request fields:** `event_name`, `category`, `venue_id`, `description` (optional), `event_date` (`YYYY-MM-DD`), `start_time` (`HH:MM:SS`), `end_time` (`HH:MM:SS`), `ticket_price` (>=0), `total_tickets` (>0), `status` (`Upcoming|Ongoing|Completed|Cancelled`). `organiser_id` is derived from JWT for creation; it must **not** be chosen by the client. Venue must be available for new assignments, within capacity, and not time-overlapping.

**Event list:** `search` searches event name, description and venue name; `category` and `status` filter exact values; `sort=event_date|event_name|ticket_price`, `order=asc|desc`; `page` and/or `limit` enables pagination (`limit` 1–100). Without page/limit, full list is returned to retain frontend compatibility. `total` is the filtered total and paged calls have `{pagination:{page,limit,total_pages}}`.

### Example create event
```http
POST /event_ticketing1/api/events.php
Authorization: Bearer <organiser-token>
Content-Type: application/json
```
```json
{"event_name":"Team API Demo","category":"Workshop","venue_id":1,"description":"Sample","event_date":"2027-03-25","start_time":"09:00:00","end_time":"12:00:00","ticket_price":20,"total_tickets":30,"status":"Upcoming"}
```
201 example: `{"status":"success","message":"Event created successfully","event_id":"13"}` (ID varies).
400 example: `{"status":"error","message":"Selected venue is unavailable. Choose an available venue"}`.
403 example: `{"status":"error","message":"You do not have permission to access this resource"}`.

### Example filtered events
`GET /event_ticketing1/api/events.php?search=concert&category=Music&page=1&limit=5`
```json
{"status":"success","total":1,"data":[{"event_id":1,"event_name":"Example Concert"}],"pagination":{"page":1,"limit":5,"total_pages":1}}
```
The example is illustrative, not a captured live response. The real API returns full event record fields.

### QR Code external API details

- Eventify calls goQR.me QR Code API server-side: `GET https://api.qrserver.com/v1/create-qr-code/?data=<URL-encoded signed ticket code>&size=240x240&format=png&qzone=4`.
- It returns **PNG image bytes**, not JSON. Eventify proxies these as `image/png` after checking JWT, ownership, confirmed status and PNG response.
- The code format is `EVF1|booking_id|24-hex-HMAC` signed with `EVENTIFY_TICKET_SECRET`. No name, email, password or bearer token is sent to the provider.
- Staff can decode the QR with a camera/scanner and submit its text to `POST /api/verify-ticket.php` using `{"ticket_code":"EVF1|...|..."}`. The server checks signature, current booking status and Organiser ownership. A confirmed ticket returns `valid:true`, cancelled returns `valid:false`.
- **No live third-party response has been captured by ChatGPT.** Your team must test it on a machine with internet access and include actual request/image screenshots in the report.
- Third-party provider documentation: https://goqr.me/api/doc/create-qr-code/

### Reviews and ratings API

Customers rate events they attended from 1 to 5 stars, with an optional comment (up to 1,000 characters). Data is stored in the `reviews` table (`database/add_reviews.sql`).

**Business rules (checked by the server, not just the page):**
- Only **Customer** accounts can write reviews (Organiser/Administrator POST ⇒ 403).
- The customer needs a **Confirmed** booking for the event (otherwise 403). Cancelled or pending bookings don't count.
- The event must have **finished**: status `Completed`, or its date and end time have passed (otherwise 409). **Cancelled** events can't be reviewed (409).
- **One review per customer per event**, enforced by a `UNIQUE (event_id, user_id)` key (second POST ⇒ 409). Customers edit with PUT instead.
- Only the author can edit a review. The author or an **Administrator** can delete one.
- Public responses show a shortened reviewer name (e.g. "Mei Ling W."), never the email or user ID.

**Example: post a review**
```http
POST /event_ticketing1/api/reviews.php
Authorization: Bearer <customer-token>
Content-Type: application/json
```
```json
{"event_id":7,"rating":5,"comment":"Patient instructor and a great hands-on session."}
```
201: `{"status":"success","message":"Thanks, your review has been posted","review_id":12}`
409: `{"status":"error","message":"You can review this event once it has finished"}`
403: `{"status":"error","message":"Only customers with a confirmed booking for this event can review it"}`

**Example: read reviews**
`GET /event_ticketing1/api/reviews.php?event_id=7&sort=highest`
```json
{"status":"success","event_id":7,
 "summary":{"review_count":4,"average_rating":4.3,"breakdown":{"5":2,"4":1,"3":1,"2":0,"1":0}},
 "data":[{"review_id":3,"rating":5,"comment":null,"reviewer_name":"Jason L.","created_at":"2026-09-22 20:05:00","updated_at":null,"is_mine":false}],
 "viewer":{"role":"Customer","can_review":true,"can_moderate":false,"reason":null,"reason_message":null,"my_review":null}}
```
`viewer` is only included when a valid JWT is sent. `reason` is one of `not_customer`, `already_reviewed`, `event_cancelled`, `no_booking`, `not_finished`. These responses were checked against a test copy of the API with sample data; capture your own from XAMPP/Postman for the report.

### Error conventions

400 invalid input; 401 no/expired JWT; 403 wrong role/owner; 404 missing record; 405 method not supported; 409 business-rule conflict; 500 internal server error; 502 remote QR provider failure; 503 service/config unavailable.

**Documentation note:** Verify exact success response examples and any role-specific business rules with your team's exported Postman tests before final submission. No test results are invented here.

### API key protection

For internal metrics only: `GET /api/system-metrics.php` requires both `Authorization: Bearer <admin-JWT>` and `X-API-Key: <EVENTIFY_INTERNAL_API_KEY>`. Use a third generated secret distinct from JWT/ticket signing keys; store it only in private settings. Never publish keys, even in screenshots.
