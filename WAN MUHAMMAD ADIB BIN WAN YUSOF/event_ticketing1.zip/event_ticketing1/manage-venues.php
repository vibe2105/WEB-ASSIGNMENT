<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage venues | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<!-- The page content stays hidden until the script confirms an Administrator is signed in. -->
<body class="venue-access-pending">
<div class="shell">
    <?php $staffPage = 'venues'; include __DIR__ . '/partials/staff-sidebar.php'; ?>

    <div class="shell-main">
        <?php include __DIR__ . '/partials/staff-topbar.php'; ?>

        <main class="shell-content">
            <header class="page-head">
                <div>
                    <h1>Venues</h1>
                    <p>The places events can be held. Organisers can only choose venues marked Available.</p>
                </div>
                <button type="button" class="btn btn-primary" id="newVenueButton">New venue</button>
            </header>

            <section class="stat-strip" aria-label="Venue summary">
                <div class="stat">
                    <span class="stat-label">Venues</span>
                    <span class="stat-value" id="totalVenues">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Available</span>
                    <span class="stat-value" id="availableVenues">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Unavailable</span>
                    <span class="stat-value" id="unavailableVenues">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Combined capacity</span>
                    <span class="stat-value" id="totalCapacity">0</span>
                </div>
            </section>

            <div class="toolbar" role="search">
                <label class="search">
                    <span class="visually-hidden">Search venues</span>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
                    <input type="search" id="venueSearch" placeholder="Search by venue name or location">
                </label>
                <label>
                    <span class="visually-hidden">Status</span>
                    <select id="venueStatusFilter">
                        <option value="">All statuses</option>
                        <option value="Available">Available</option>
                        <option value="Unavailable">Unavailable</option>
                    </select>
                </label>
            </div>

            <section class="panel">
                <div class="table-scroll">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th scope="col">Venue</th>
                                <th scope="col" class="num">Capacity</th>
                                <th scope="col" class="num">Events</th>
                                <th scope="col">Status</th>
                                <th scope="col"><span class="visually-hidden">Actions</span></th>
                            </tr>
                        </thead>
                        <tbody id="venueGrid">
                            <tr><td colspan="5" class="table-empty">Loading venues…</td></tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</div>

<!-- CREATE / EDIT DRAWER -->
<div class="overlay" id="venueModal">
    <div class="drawer" role="dialog" aria-modal="true" aria-labelledby="venueModalTitle">
        <div class="drawer-head">
            <div>
                <span class="kicker" id="venueModalEyebrow">Create</span>
                <h2 id="venueModalTitle">New venue</h2>
            </div>
            <button type="button" class="icon-btn" id="closeVenueModal">
                <span class="visually-hidden">Close</span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
            </button>
        </div>

        <form id="venueForm">
            <input type="hidden" id="venueId">

            <div class="drawer-body">
                <div class="field">
                    <label for="venueName">Venue name</label>
                    <input type="text" id="venueName" placeholder="For example, Dewan Seri Pinang" required>
                </div>

                <div class="field">
                    <label for="venueLocation">Location</label>
                    <input type="text" id="venueLocation" placeholder="Town or city, for example Kuala Lumpur" required>
                </div>

                <div class="form-grid">
                    <div class="field">
                        <label for="venueCapacity">Capacity</label>
                        <input type="number" id="venueCapacity" min="1" placeholder="500" required>
                    </div>

                    <div class="field">
                        <label for="venueStatus">Status</label>
                        <select id="venueStatus" required>
                            <option value="Available">Available</option>
                            <option value="Unavailable">Unavailable</option>
                        </select>
                    </div>
                </div>

                <p class="hint">Marking a venue Unavailable stops new events using it. Existing events keep it.</p>

                <div class="form-message" id="venueFormMessage" role="status"></div>
            </div>

            <div class="drawer-foot">
                <button type="button" class="btn" id="cancelVenueButton">Cancel</button>
                <button type="submit" class="btn btn-primary" id="saveVenueButton">Create venue</button>
            </div>
        </form>
    </div>
</div>

<!-- DELETE DIALOG -->
<div class="overlay" id="deleteVenueModal">
    <div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="deleteVenueTitle" aria-describedby="deleteVenueText">
        <h2 id="deleteVenueTitle">Delete this venue?</h2>
        <p id="deleteVenueText">The venue will be removed permanently.</p>
        <div class="dialog-actions">
            <button type="button" class="btn" id="keepVenueButton">Keep venue</button>
            <button type="button" class="btn btn-danger" id="confirmVenueDelete">Delete venue</button>
        </div>
    </div>
</div>

<div class="toast" id="toast" role="status" aria-live="polite"></div>

<script src="js/staff-shell.js"></script>
<script>
/* ==========================================
   VARIABLES
========================================== */

const token = localStorage.getItem("eventify_token");

let currentUser = null;
let venues = [];
let formMode = "create";
let deleteVenueId = null;

const venueGrid = document.getElementById("venueGrid");
const venueModal = document.getElementById("venueModal");
const deleteVenueModal = document.getElementById("deleteVenueModal");
const venueForm = document.getElementById("venueForm");
const formMessage = document.getElementById("venueFormMessage");
const saveVenueButton = document.getElementById("saveVenueButton");
const toast = document.getElementById("toast");

/* ==========================================
   INITIALISE
========================================== */

async function initialise() {
  if (!token) {
    window.location.href = "login.php";
    return;
  }

  try {
    const authResponse = await fetch("auth/me.php", {
      headers: {
        Authorization: "Bearer " + token,
      },
    });

    const authResult = await authResponse.json();

    if (!authResponse.ok || authResult.status !== "success") {
      logout();
      return;
    }

    currentUser = authResult.user;

    // Venue management is reserved for Administrators.
    // Organisers choose an existing venue on Manage Events instead.
    if (currentUser.role !== "Administrator") {
      alert("Only Administrators can manage venues.");
      window.location.replace(currentUser.role === "Organiser" ? "dashboard.php" : "events.php");
      return;
    }

    // Reveal the management tools only after the JWT and role are verified.
    document.body.classList.remove("venue-access-pending");

    updateNavbar();

    await loadVenues();
  } catch (error) {
    showToast("Venue management couldn't load. Refresh the page to try again.", "error");
  }
}

/* ==========================================
   LOAD VENUES
========================================== */

async function loadVenues() {
  const response = await fetch("api/venues.php");
  const result = await response.json();

  if (!response.ok || result.status !== "success") {
    throw new Error(result.message || "Unable to load venues");
  }

  venues = result.data;

  displayVenues(venues);
  updateStats();
}

/* ==========================================
   DISPLAY
========================================== */

function displayVenues(venueList) {
  venueGrid.innerHTML = "";

  if (venueList.length === 0) {
    venueGrid.innerHTML = `
      <tr>
        <td colspan="5" class="table-empty">
          ${venues.length === 0 ? "No venues yet. Use “New venue” to add the first one." : "No venues match your search."}
        </td>
      </tr>
    `;
    return;
  }

  venueList.forEach((venue) => {
    const available = venue.status === "Available";
    const eventCount = Number(venue.event_count);

    const row = document.createElement("tr");

    row.innerHTML = `
      <td>
        <div class="cell-main">
          <strong>${escapeHTML(venue.venue_name)}</strong>
          <span>${escapeHTML(venue.location)}</span>
        </div>
      </td>
      <td class="num">${Number(venue.capacity).toLocaleString()}</td>
      <td class="num">${eventCount}</td>
      <td>
        <span class="badge ${available ? "venue-available" : "venue-unavailable"}">${escapeHTML(venue.status)}</span>
      </td>
      <td>
        <div class="row-actions">
          <button type="button" class="btn btn-sm" onclick="editVenue(${Number(venue.venue_id)})">Edit</button>
          <button type="button" class="btn btn-sm btn-danger-quiet" onclick="askDeleteVenue(${Number(venue.venue_id)})">Delete</button>
        </div>
      </td>
    `;

    venueGrid.appendChild(row);
  });
}

/* ==========================================
   STATS
========================================== */

function updateStats() {
  const available = venues.filter((venue) => venue.status === "Available").length;
  const unavailable = venues.filter((venue) => venue.status === "Unavailable").length;
  const capacity = venues.reduce((total, venue) => total + Number(venue.capacity), 0);

  document.getElementById("totalVenues").textContent = venues.length;
  document.getElementById("availableVenues").textContent = available;
  document.getElementById("unavailableVenues").textContent = unavailable;
  document.getElementById("totalCapacity").textContent = capacity.toLocaleString();
}

/* ==========================================
   CREATE
========================================== */

document.getElementById("newVenueButton").addEventListener("click", openCreateVenue);

function openCreateVenue() {
  formMode = "create";

  venueForm.reset();

  document.getElementById("venueId").value = "";
  document.getElementById("venueModalEyebrow").textContent = "Create";
  document.getElementById("venueModalTitle").textContent = "New venue";

  saveVenueButton.textContent = "Create venue";

  clearFormMessage();
  venueModal.classList.add("show");
  document.getElementById("venueName").focus();
}

/* ==========================================
   EDIT
========================================== */

function editVenue(venueId) {
  const venue = venues.find((item) => Number(item.venue_id) === Number(venueId));

  if (!venue) {
    return;
  }

  formMode = "edit";

  document.getElementById("venueId").value = venue.venue_id;
  document.getElementById("venueName").value = venue.venue_name;
  document.getElementById("venueLocation").value = venue.location;
  document.getElementById("venueCapacity").value = venue.capacity;
  document.getElementById("venueStatus").value = venue.status;

  document.getElementById("venueModalEyebrow").textContent = "Edit venue";
  document.getElementById("venueModalTitle").textContent = venue.venue_name;

  saveVenueButton.textContent = "Save changes";

  clearFormMessage();
  venueModal.classList.add("show");
}

/* ==========================================
   SAVE CREATE / EDIT
========================================== */

venueForm.addEventListener("submit", async function (event) {
  event.preventDefault();

  const payload = {
    venue_name: document.getElementById("venueName").value.trim(),
    location: document.getElementById("venueLocation").value.trim(),
    capacity: Number(document.getElementById("venueCapacity").value),
    status: document.getElementById("venueStatus").value,
  };

  if (formMode === "edit") {
    payload.venue_id = Number(document.getElementById("venueId").value);
  }

  saveVenueButton.disabled = true;
  saveVenueButton.textContent = formMode === "create" ? "Creating…" : "Saving…";

  try {
    const response = await fetch("api/venues.php", {
      method: formMode === "create" ? "POST" : "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify(payload),
    });

    const result = await response.json();

    if (response.status === 401) {
      logout();
      return;
    }

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message || "Unable to save venue");
    }

    showFormMessage(result.message, "success");

    await loadVenues();

    setTimeout(function () {
      venueModal.classList.remove("show");
      showToast(result.message, "success");
    }, 600);
  } catch (error) {
    showFormMessage(error.message, "error");
  } finally {
    saveVenueButton.disabled = false;
    saveVenueButton.textContent = formMode === "create" ? "Create venue" : "Save changes";
  }
});

/* ==========================================
   DELETE
========================================== */

function askDeleteVenue(venueId) {
  deleteVenueId = venueId;

  const venue = venues.find((item) => Number(item.venue_id) === Number(venueId));

  document.getElementById("deleteVenueText").textContent = venue
    ? "“" + venue.venue_name + "” will be removed permanently. A venue that's assigned to an event can't be deleted."
    : "This venue will be removed permanently.";

  deleteVenueModal.classList.add("show");
  document.getElementById("keepVenueButton").focus();
}

document.getElementById("confirmVenueDelete").addEventListener("click", async function () {
  if (!deleteVenueId) {
    return;
  }

  this.disabled = true;
  this.textContent = "Deleting…";

  try {
    const response = await fetch("api/venues.php", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify({
        venue_id: deleteVenueId,
      }),
    });

    const result = await response.json();

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message || "Unable to delete venue");
    }

    deleteVenueModal.classList.remove("show");
    deleteVenueId = null;

    await loadVenues();

    showToast(result.message, "success");
  } catch (error) {
    deleteVenueModal.classList.remove("show");
    showToast(error.message, "error");
  } finally {
    this.disabled = false;
    this.textContent = "Delete venue";
  }
});

/* ==========================================
   SEARCH
========================================== */

document.getElementById("venueSearch").addEventListener("input", filterVenues);
document.getElementById("venueStatusFilter").addEventListener("change", filterVenues);

function filterVenues() {
  const search = document.getElementById("venueSearch").value.toLowerCase();
  const status = document.getElementById("venueStatusFilter").value;

  const filtered = venues.filter((venue) => {
    const searchText = (venue.venue_name + " " + venue.location).toLowerCase();

    const searchMatch = searchText.includes(search);
    const statusMatch = status === "" || venue.status === status;

    return searchMatch && statusMatch;
  });

  displayVenues(filtered);
}

/* ==========================================
   MODAL
========================================== */

function closeVenueModal() {
  venueModal.classList.remove("show");
}

document.getElementById("closeVenueModal").addEventListener("click", closeVenueModal);
document.getElementById("cancelVenueButton").addEventListener("click", closeVenueModal);

document.getElementById("keepVenueButton").addEventListener("click", function () {
  deleteVenueId = null;
  deleteVenueModal.classList.remove("show");
});

document.addEventListener("keydown", function (event) {
  if (event.key !== "Escape") return;
  if (venueModal.classList.contains("show")) closeVenueModal();
  if (deleteVenueModal.classList.contains("show")) {
    deleteVenueId = null;
    deleteVenueModal.classList.remove("show");
  }
});

/* ==========================================
   FORM MESSAGE
========================================== */

function clearFormMessage() {
  formMessage.className = "form-message";
  formMessage.textContent = "";
}

function showFormMessage(message, type) {
  formMessage.textContent = message;
  formMessage.className = "form-message " + type;
}

/* ==========================================
   NAVBAR (sidebar account block)
========================================== */

function updateNavbar() {
  EventifyShell.setUser(currentUser);
}

/* ==========================================
   LOGOUT
========================================== */

function logout() {
  localStorage.removeItem("eventify_token");
  localStorage.removeItem("eventify_user");
  window.location.href = "login.php";
}

/* ==========================================
   TOAST
========================================== */

function showToast(message, type) {
  toast.textContent = message;
  toast.className = "toast " + type + " show";

  setTimeout(function () {
    toast.classList.remove("show");
  }, 3500);
}

/* ==========================================
   ESCAPE
========================================== */

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* ==========================================
   START
========================================== */

initialise();
</script>
</body>
</html>
