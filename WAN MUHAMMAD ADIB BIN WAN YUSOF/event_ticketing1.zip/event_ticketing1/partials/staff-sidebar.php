<?php
/* Shared staff sidebar. Set $staffPage before including:
   dashboard | events | venues | bookings | users */
$staffPage = $staffPage ?? '';
function eventifyStaffLink(string $key, string $href, string $label, string $icon, string $current, bool $adminOnly = false): void {
    $attrs = $key === $current ? ' class="active" aria-current="page"' : '';
    $attrs .= $adminOnly ? ' data-admin-only' : '';
    echo '<a href="' . $href . '"' . $attrs . '>' . $icon . '<span>' . $label . '</span></a>';
}
$i = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';
$icons = [
    'dashboard' => "<svg $i><rect x=\"3\" y=\"3\" width=\"7\" height=\"9\" rx=\"1\"/><rect x=\"14\" y=\"3\" width=\"7\" height=\"5\" rx=\"1\"/><rect x=\"14\" y=\"12\" width=\"7\" height=\"9\" rx=\"1\"/><rect x=\"3\" y=\"16\" width=\"7\" height=\"5\" rx=\"1\"/></svg>",
    'events'    => "<svg $i><rect x=\"3\" y=\"4\" width=\"18\" height=\"17\" rx=\"2\"/><path d=\"M3 9h18M8 2v4M16 2v4\"/></svg>",
    'venues'    => "<svg $i><path d=\"M12 21s-7-5.6-7-11a7 7 0 0 1 14 0c0 5.4-7 11-7 11z\"/><circle cx=\"12\" cy=\"10\" r=\"2.5\"/></svg>",
    'bookings'  => "<svg $i><path d=\"M3 8a2 2 0 0 0 2-2h14a2 2 0 0 0 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 0-2 2H5a2 2 0 0 0-2-2v-2a2 2 0 0 0 0-4z\"/><path d=\"M14 6v12\" stroke-dasharray=\"2 2.5\"/></svg>",
    'users'     => "<svg $i><circle cx=\"9\" cy=\"8\" r=\"3.5\"/><path d=\"M2.5 20a6.5 6.5 0 0 1 13 0\"/><path d=\"M16 4.5a3.5 3.5 0 0 1 0 7M18.5 14.5A6.5 6.5 0 0 1 21.5 20\"/></svg>",
    'site'      => "<svg $i><path d=\"M14 4h6v6M20 4l-9 9\"/><path d=\"M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5\"/></svg>",
];
?>
<aside class="sidebar" id="staffSidebar" aria-label="Staff navigation">
    <a href="dashboard.php" class="brand" aria-label="Eventify dashboard"><span class="brand-mark" aria-hidden="true"></span>eventify</a>

    <nav class="sidebar-nav" aria-label="Overview">
        <?php eventifyStaffLink('dashboard', 'dashboard.php', 'Dashboard', $icons['dashboard'], $staffPage); ?>
    </nav>

    <div class="sidebar-group">Manage</div>
    <nav class="sidebar-nav" aria-label="Manage">
        <?php
        eventifyStaffLink('events', 'manage-events.php', 'Events', $icons['events'], $staffPage);
        eventifyStaffLink('venues', 'manage-venues.php', 'Venues', $icons['venues'], $staffPage, true);
        eventifyStaffLink('bookings', 'manage-bookings.php', 'Bookings', $icons['bookings'], $staffPage);
        eventifyStaffLink('users', 'manage-users.php', 'Users', $icons['users'], $staffPage, true);
        ?>
    </nav>

    <div class="sidebar-group">Public site</div>
    <nav class="sidebar-nav" aria-label="Public site">
        <?php eventifyStaffLink('site', 'events.php', 'View the event listing', $icons['site'], $staffPage); ?>
    </nav>

    <div class="sidebar-user" id="sidebarUser">
        <span class="avatar" aria-hidden="true">·</span>
        <strong>Checking your account</strong>
        <small>Please wait</small>
    </div>
</aside>
<div class="shell-scrim" data-shell-close></div>
