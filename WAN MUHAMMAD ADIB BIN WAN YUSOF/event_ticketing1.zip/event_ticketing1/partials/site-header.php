<?php
/* Shared public header. Set $sitePage before including: home | events | bookings
   Set $siteActions to false to leave #authNavigation empty for pages that fill it themselves. */
$sitePage = $sitePage ?? '';
$siteActions = $siteActions ?? true;
function eventifySiteLink(string $key, string $href, string $label, string $current): void {
    $attrs = $key === $current ? ' class="active" aria-current="page"' : '';
    echo '<a href="' . $href . '"' . $attrs . '>' . $label . '</a>';
}
?>
<header class="site-header">
    <div class="wrap">
        <a href="index.php" class="brand" aria-label="Eventify home"><span class="brand-mark" aria-hidden="true"></span>eventify</a>
        <nav class="site-nav nav-links" aria-label="Main">
            <?php
            eventifySiteLink('home', 'index.php', 'Home', $sitePage);
            eventifySiteLink('events', 'events.php', 'Events', $sitePage);
            eventifySiteLink('bookings', 'bookings.php', 'My bookings', $sitePage);
            ?>
        </nav>
        <div class="nav-actions" id="authNavigation">
            <?php if ($siteActions): ?>
            <a href="login.php" class="sign-in">Sign in</a>
            <a href="register.php" class="nav-button">Create account</a>
            <?php endif; ?>
        </div>
    </div>
</header>
