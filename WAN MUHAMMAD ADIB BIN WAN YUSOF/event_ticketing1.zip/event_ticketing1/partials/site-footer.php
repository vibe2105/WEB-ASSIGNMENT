<footer class="site-footer">
    <div class="wrap">
        <a href="index.php" class="brand"><span class="brand-mark" aria-hidden="true"></span>eventify</a>
        <nav aria-label="Footer">
            <a href="events.php">Events</a>
            <a href="bookings.php">My bookings</a>
            <a href="login.php">Staff sign in</a>
        </nav>
        <span>© 2026 Eventify. Event ticketing and venue booking.</span>
    </div>
</footer>
