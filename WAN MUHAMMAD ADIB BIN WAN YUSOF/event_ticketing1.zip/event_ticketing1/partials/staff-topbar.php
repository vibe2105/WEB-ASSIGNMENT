<header class="shell-topbar">
    <a href="dashboard.php" class="brand"><span class="brand-mark" aria-hidden="true"></span>eventify</a>
    <button type="button" class="icon-btn" id="shellMenuButton" aria-controls="staffSidebar" aria-expanded="false">
        <span class="visually-hidden">Open menu</span>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
    </button>
</header>
