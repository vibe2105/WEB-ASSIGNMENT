<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<div class="shell" id="dashboardRoot">
    <?php $staffPage = 'dashboard'; include __DIR__ . '/partials/staff-sidebar.php'; ?>

    <div class="shell-main">
        <?php include __DIR__ . '/partials/staff-topbar.php'; ?>

        <main class="shell-content">
            <header class="page-head">
                <div>
                    <h1>Dashboard</h1>
                    <p id="dashboardWelcome">Checking your account…</p>
                </div>
                <a class="btn btn-primary" href="manage-events.php?new=1">New event</a>
            </header>

            <section class="stat-strip" aria-label="Summary">
                <div class="stat">
                    <span class="stat-label">Events</span>
                    <span class="stat-value" id="totalEvents">—</span>
                    <span class="stat-note" id="eventsDescription">Events you can manage</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Bookings</span>
                    <span class="stat-value" id="totalBookings">—</span>
                    <span class="stat-note">All statuses</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Confirmed</span>
                    <span class="stat-value" id="confirmedBookings">—</span>
                    <span class="stat-note">Bookings that are going ahead</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Confirmed value</span>
                    <span class="stat-value" id="bookingValue">—</span>
                    <span class="stat-note">Total of confirmed bookings</span>
                </div>
            </section>

            <div class="dash-grid">
                <section class="panel">
                    <div class="panel-head">
                        <div>
                            <h2>Upcoming events</h2>
                            <span id="eventPanelSubtitle">Next five on the calendar</span>
                        </div>
                        <a href="manage-events.php">All events</a>
                    </div>
                    <div id="eventList">
                        <p class="dash-empty">Loading events…</p>
                    </div>
                </section>

                <section class="panel">
                    <div class="panel-head">
                        <div>
                            <h2>Recent bookings</h2>
                            <span>Latest five reservations</span>
                        </div>
                        <a href="manage-bookings.php">All bookings</a>
                    </div>
                    <div id="bookingList">
                        <p class="dash-empty">Loading bookings…</p>
                    </div>
                </section>
            </div>
        </main>
    </div>
</div>

<script src="js/staff-shell.js"></script>
<script>
/* ==========================================
   AUTH
========================================== */

const token = localStorage.getItem("eventify_token");

let currentUser = null;
let allEvents = [];
let dashboardEvents = [];
let allBookings = [];

/* ==========================================
   START DASHBOARD
========================================== */

async function initialiseDashboard() {
  if (!token) {
    window.location.href = "login.php";
    return;
  }

  try {
    /* VERIFY JWT */
    const authResponse = await fetch("auth/me.php", {
      headers: {
        Authorization: "Bearer " + token,
      },
    });

    const authResult = await authResponse.json();

    if (!authResponse.ok || authResult.status !== "success") {
      logout();
      return;
    }

    currentUser = authResult.user;

    /* ROLE CHECK */
    if (currentUser.role !== "Administrator" && currentUser.role !== "Organiser") {
      showAccessDenied();
      return;
    }

    updateUserInterface();

    await Promise.all([loadEvents(), loadBookings()]);

    prepareDashboardEvents();
    displayEvents();
    displayBookings();
    updateStatistics();
  } catch (error) {
    console.error("Dashboard error:", error);

    document.getElementById("dashboardRoot").innerHTML = `
      <div class="access-denied">
        <a href="index.php" class="brand"><span class="brand-mark" aria-hidden="true"></span>eventify</a>
        <h1>The dashboard didn't load</h1>
        <p>Eventify couldn't reach the server. Check that Apache and MySQL are running, then sign in again.</p>
        <a class="btn btn-primary" href="login.php">Go to sign in</a>
      </div>
    `;
  }
}

/* ==========================================
   LOAD EVENTS
========================================== */

async function loadEvents() {
  const response = await fetch("api/events.php");
  const result = await response.json();

  if (!response.ok || result.status !== "success") {
    throw new Error(result.message || "Unable to load events");
  }

  allEvents = result.data;
}

/* ==========================================
   ORGANISER VS ADMIN EVENTS
========================================== */

function prepareDashboardEvents() {
  if (currentUser.role === "Organiser") {
    dashboardEvents = allEvents.filter(
      (event) => Number(event.organiser_id) === Number(currentUser.user_id),
    );

    document.getElementById("eventsDescription").textContent = "Events you organise";
    document.getElementById("eventPanelSubtitle").textContent = "Your next five events";
  } else {
    dashboardEvents = allEvents;

    document.getElementById("eventsDescription").textContent = "All events in the system";
    document.getElementById("eventPanelSubtitle").textContent = "Next five on the calendar";
  }
}

/* ==========================================
   LOAD BOOKINGS
   The bookings API already handles roles:
   Organiser -> own event bookings
   Administrator -> all bookings
========================================== */

async function loadBookings() {
  const response = await fetch("api/bookings.php", {
    headers: {
      Authorization: "Bearer " + token,
    },
  });

  const result = await response.json();

  if (response.status === 401) {
    logout();
    return;
  }

  if (!response.ok || result.status !== "success") {
    throw new Error(result.message || "Unable to load bookings");
  }

  allBookings = result.data;
}

/* ==========================================
   STATISTICS
========================================== */

function updateStatistics() {
  const confirmed = allBookings.filter((booking) => booking.booking_status === "Confirmed");

  const value = confirmed.reduce((total, booking) => total + Number(booking.total_amount), 0);

  document.getElementById("totalEvents").textContent = dashboardEvents.length;
  document.getElementById("totalBookings").textContent = allBookings.length;
  document.getElementById("confirmedBookings").textContent = confirmed.length;
  document.getElementById("bookingValue").textContent = "RM " + value.toFixed(2);
}

/* ==========================================
   DISPLAY EVENTS
   Shows the next five events that are still
   going ahead, soonest first.
========================================== */

function displayEvents() {
  const container = document.getElementById("eventList");

  const today = new Date();
  const todayString =
    today.getFullYear() +
    "-" +
    String(today.getMonth() + 1).padStart(2, "0") +
    "-" +
    String(today.getDate()).padStart(2, "0");

  const events = [...dashboardEvents]
    .filter(
      (event) =>
        String(event.event_date) >= todayString &&
        (event.status === "Upcoming" || event.status === "Ongoing"),
    )
    .sort((a, b) => new Date(a.event_date) - new Date(b.event_date))
    .slice(0, 5);

  if (events.length === 0) {
    container.innerHTML = `
      <div class="dash-empty">
        Nothing is scheduled yet.
        <a href="manage-events.php?new=1">Create an event</a>
      </div>
    `;
    return;
  }

  container.innerHTML = events
    .map((event) => {
      const date = new Date(event.event_date + "T00:00:00");
      const day = String(date.getDate()).padStart(2, "0");
      const month = date.toLocaleString("en-US", { month: "short" });
      const available = Number(event.available_tickets);
      const total = Number(event.total_tickets);

      return `
        <div class="dash-row">
          <span class="stamp stamp-sm">
            <span class="stamp-day">${day}</span>
            <span class="stamp-month">${month}</span>
          </span>
          <div class="cell-main">
            <strong>${escapeHTML(event.event_name)}</strong>
            <span>${escapeHTML(event.venue_name)}</span>
          </div>
          <span class="dash-figure">${(total - available).toLocaleString()} / ${total.toLocaleString()} sold</span>
        </div>
      `;
    })
    .join("");
}

/* ==========================================
   DISPLAY BOOKINGS
========================================== */

function displayBookings() {
  const container = document.getElementById("bookingList");

  const bookings = allBookings.slice(0, 5);

  if (bookings.length === 0) {
    container.innerHTML = `<div class="dash-empty">No bookings yet. They'll appear here as customers book.</div>`;
    return;
  }

  container.innerHTML = bookings
    .map((booking) => {
      const name = booking.customer_name || "Customer";
      const quantity = Number(booking.quantity);
      const statusClass =
        booking.booking_status === "Confirmed"
          ? "status-green"
          : booking.booking_status === "Cancelled"
            ? "status-red"
            : "status-pending";

      return `
        <div class="dash-row">
          <span class="avatar avatar-quiet" aria-hidden="true">${escapeHTML(name.charAt(0).toUpperCase())}</span>
          <div class="cell-main">
            <strong>${escapeHTML(name)}</strong>
            <span>${escapeHTML(booking.event_name)}, ${quantity} ${quantity === 1 ? "ticket" : "tickets"}, RM ${Number(booking.total_amount).toFixed(2)}</span>
          </div>
          <span class="badge ${statusClass}">${escapeHTML(booking.booking_status)}</span>
        </div>
      `;
    })
    .join("");
}

/* ==========================================
   USER INTERFACE
========================================== */

function updateUserInterface() {
  // Sidebar account block, plus Venues and Users links for Administrators.
  // Organisers can still choose existing venues while creating events.
  EventifyShell.setUser(currentUser);

  document.getElementById("dashboardWelcome").textContent =
    currentUser.role === "Administrator"
      ? "Welcome back, " + currentUser.name + ". You can manage every event, venue, booking and user."
      : "Welcome back, " + currentUser.name + ". Here's how your events are doing.";
}

/* ==========================================
   ACCESS DENIED
========================================== */

function showAccessDenied() {
  document.getElementById("dashboardRoot").innerHTML = `
    <div class="access-denied">
      <a href="index.php" class="brand"><span class="brand-mark" aria-hidden="true"></span>eventify</a>
      <h1>This area is for staff</h1>
      <p>
        You're signed in as a ${escapeHTML(currentUser.role)}. The dashboard is only
        available to Organiser and Administrator accounts.
      </p>
      <a class="btn btn-primary" href="events.php">Go to events</a>
    </div>
  `;
}

/* ==========================================
   LOGOUT
========================================== */

function logout() {
  localStorage.removeItem("eventify_token");
  localStorage.removeItem("eventify_user");
  window.location.href = "login.php";
}

/* ==========================================
   ESCAPE HTML
========================================== */

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* ==========================================
   START
========================================== */

initialiseDashboard();
</script>
</body>
</html>
