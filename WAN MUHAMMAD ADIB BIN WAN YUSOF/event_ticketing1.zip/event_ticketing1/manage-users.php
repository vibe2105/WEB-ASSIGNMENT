<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage users | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<div class="shell">
    <?php $staffPage = 'users'; include __DIR__ . '/partials/staff-sidebar.php'; ?>

    <div class="shell-main">
        <?php include __DIR__ . '/partials/staff-topbar.php'; ?>

        <main class="shell-content">
            <header class="page-head">
                <div>
                    <h1>Users</h1>
                    <p>Customer, organiser and administrator accounts. The role decides what each person can do.</p>
                </div>
                <button type="button" class="btn btn-primary" id="addUserButton">New user</button>
            </header>

            <section class="stat-strip" aria-label="User summary">
                <div class="stat">
                    <span class="stat-label">Users</span>
                    <span class="stat-value" id="totalUsers">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Customers</span>
                    <span class="stat-value" id="customerCount">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Organisers</span>
                    <span class="stat-value" id="organiserCount">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Administrators</span>
                    <span class="stat-value" id="adminCount">0</span>
                </div>
            </section>

            <div class="toolbar" role="search">
                <label class="search">
                    <span class="visually-hidden">Search users</span>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
                    <input type="search" id="userSearch" placeholder="Search by name, email or user number">
                </label>
                <label>
                    <span class="visually-hidden">Role</span>
                    <select id="roleFilter">
                        <option value="">All roles</option>
                        <option value="Administrator">Administrator</option>
                        <option value="Organiser">Organiser</option>
                        <option value="Customer">Customer</option>
                    </select>
                </label>
            </div>

            <section class="panel">
                <div class="table-scroll">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th scope="col">User</th>
                                <th scope="col">Role</th>
                                <th scope="col" class="num">Events</th>
                                <th scope="col" class="num">Bookings</th>
                                <th scope="col">Joined</th>
                                <th scope="col"><span class="visually-hidden">Actions</span></th>
                            </tr>
                        </thead>
                        <tbody id="userTableBody">
                            <tr><td colspan="6" class="table-empty">Loading users…</td></tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</div>

<!-- CREATE / EDIT DRAWER -->
<div class="overlay" id="userModal">
    <div class="drawer" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
        <div class="drawer-head">
            <div>
                <span class="kicker" id="modalEyebrow">Create</span>
                <h2 id="modalTitle">New user</h2>
            </div>
            <button type="button" class="icon-btn" id="closeUserModal">
                <span class="visually-hidden">Close</span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
            </button>
        </div>

        <form id="userForm">
            <input type="hidden" id="userId">

            <div class="drawer-body">
                <div class="field">
                    <label for="userName">Full name</label>
                    <input type="text" id="userName" placeholder="Their full name" required>
                </div>

                <div class="field">
                    <label for="userEmail">Email address</label>
                    <input type="email" id="userEmail" placeholder="name@example.com" required>
                </div>

                <div class="field">
                    <label for="userRole">Role</label>
                    <select id="userRole" required>
                        <option value="Customer">Customer: books tickets</option>
                        <option value="Organiser">Organiser: runs their own events</option>
                        <option value="Administrator">Administrator: full access</option>
                    </select>
                </div>

                <div class="field">
                    <label for="userPassword">Password</label>
                    <input type="password" id="userPassword" placeholder="At least 6 characters" autocomplete="new-password" aria-describedby="passwordNote">
                    <span class="hint" id="passwordNote">Use at least 6 characters.</span>
                </div>

                <div class="form-message" id="formMessage" role="status"></div>
            </div>

            <div class="drawer-foot">
                <button type="button" class="btn" id="cancelUserButton">Cancel</button>
                <button type="submit" class="btn btn-primary" id="saveUserButton">Create user</button>
            </div>
        </form>
    </div>
</div>

<!-- DELETE DIALOG -->
<div class="overlay" id="deleteModal">
    <div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="deleteTitle" aria-describedby="deleteText">
        <h2 id="deleteTitle">Delete this user?</h2>
        <p id="deleteText">This account will be deleted permanently.</p>
        <div class="dialog-actions">
            <button type="button" class="btn" id="keepUserButton">Keep user</button>
            <button type="button" class="btn btn-danger" id="confirmDeleteButton">Delete user</button>
        </div>
    </div>
</div>

<div class="toast" id="toast" role="status" aria-live="polite"></div>

<script src="js/staff-shell.js"></script>
<script>
/* ==========================================
   VARIABLES
========================================== */

const token = localStorage.getItem("eventify_token");

let currentUser = null;
let users = [];
let formMode = "create";
let selectedDeleteId = null;

const userTableBody = document.getElementById("userTableBody");
const userModal = document.getElementById("userModal");
const deleteModal = document.getElementById("deleteModal");
const userForm = document.getElementById("userForm");
const formMessage = document.getElementById("formMessage");
const saveUserButton = document.getElementById("saveUserButton");
const toast = document.getElementById("toast");

/* ==========================================
   INITIALISE
========================================== */

async function initialise() {
  if (!token) {
    window.location.href = "login.php";
    return;
  }

  try {
    const response = await fetch("auth/me.php", {
      headers: {
        Authorization: "Bearer " + token,
      },
    });

    const result = await response.json();

    if (!response.ok || result.status !== "success") {
      logout();
      return;
    }

    currentUser = result.user;

    if (currentUser.role !== "Administrator") {
      alert("Administrator access is required.");
      window.location.href = currentUser.role === "Organiser" ? "dashboard.php" : "events.php";
      return;
    }

    updateNavbar();

    await loadUsers();
  } catch (error) {
    showToast("User management couldn't load. Refresh the page to try again.", "error");
  }
}

/* ==========================================
   LOAD USERS
========================================== */

async function loadUsers() {
  const response = await fetch("api/users.php", {
    headers: {
      Authorization: "Bearer " + token,
    },
  });

  const result = await response.json();

  if (response.status === 401) {
    logout();
    return;
  }

  if (!response.ok || result.status !== "success") {
    throw new Error(result.message || "Unable to load users");
  }

  users = result.data;

  displayUsers(users);
  updateStatistics();
}

/* ==========================================
   DISPLAY USERS
========================================== */

function displayUsers(userList) {
  userTableBody.innerHTML = "";

  if (userList.length === 0) {
    userTableBody.innerHTML = `
      <tr>
        <td colspan="6" class="table-empty">No users match your search.</td>
      </tr>
    `;
    return;
  }

  userList.forEach((user) => {
    const initial = String(user.name).charAt(0).toUpperCase();

    const joined = new Date(String(user.created_at).replace(" ", "T"));

    const joinedText = isNaN(joined.getTime())
      ? user.created_at
      : joined.toLocaleDateString("en-MY", {
          day: "numeric",
          month: "short",
          year: "numeric",
        });

    const isSelf = Number(user.user_id) === Number(currentUser.user_id);

    const row = document.createElement("tr");

    row.innerHTML = `
      <td>
        <div class="user-cell">
          <span class="avatar avatar-quiet" aria-hidden="true">${escapeHTML(initial)}</span>
          <div class="cell-main">
            <strong>${escapeHTML(user.name)}${isSelf ? ' <span class="you-tag">You</span>' : ""}</strong>
            <span>#${Number(user.user_id)}, ${escapeHTML(user.email)}</span>
          </div>
        </div>
      </td>
      <td><span class="badge ${getRoleClass(user.role)}">${escapeHTML(user.role)}</span></td>
      <td class="num">${Number(user.event_count)}</td>
      <td class="num">${Number(user.booking_count)}</td>
      <td class="nowrap">${escapeHTML(joinedText)}</td>
      <td>
        <div class="row-actions">
          <button type="button" class="btn btn-sm" onclick="editUser(${Number(user.user_id)})">Edit</button>
          ${
            !isSelf
              ? `<button type="button" class="btn btn-sm btn-danger-quiet" onclick="askDelete(${Number(user.user_id)})">Delete</button>`
              : ""
          }
        </div>
      </td>
    `;

    userTableBody.appendChild(row);
  });
}

/* ==========================================
   STATISTICS
========================================== */

function updateStatistics() {
  const customers = users.filter((user) => user.role === "Customer").length;
  const organisers = users.filter((user) => user.role === "Organiser").length;
  const administrators = users.filter((user) => user.role === "Administrator").length;

  document.getElementById("totalUsers").textContent = users.length;
  document.getElementById("customerCount").textContent = customers;
  document.getElementById("organiserCount").textContent = organisers;
  document.getElementById("adminCount").textContent = administrators;
}

/* ==========================================
   SEARCH
========================================== */

document.getElementById("userSearch").addEventListener("input", filterUsers);
document.getElementById("roleFilter").addEventListener("change", filterUsers);

function filterUsers() {
  const search = document.getElementById("userSearch").value.toLowerCase();
  const role = document.getElementById("roleFilter").value;

  const filtered = users.filter((user) => {
    const text = (user.user_id + " " + user.name + " " + user.email).toLowerCase();

    const searchMatch = text.includes(search);
    const roleMatch = role === "" || user.role === role;

    return searchMatch && roleMatch;
  });

  displayUsers(filtered);
}

/* ==========================================
   CREATE USER
========================================== */

document.getElementById("addUserButton").addEventListener("click", openCreateUser);

function openCreateUser() {
  formMode = "create";

  userForm.reset();

  document.getElementById("userId").value = "";
  document.getElementById("modalEyebrow").textContent = "Create";
  document.getElementById("modalTitle").textContent = "New user";
  document.getElementById("passwordNote").textContent = "Required. Use at least 6 characters.";
  document.getElementById("userPassword").required = true;

  saveUserButton.textContent = "Create user";

  clearMessage();
  userModal.classList.add("show");
  document.getElementById("userName").focus();
}

/* ==========================================
   EDIT USER
========================================== */

function editUser(userId) {
  const user = users.find((item) => Number(item.user_id) === Number(userId));

  if (!user) {
    return;
  }

  formMode = "edit";

  document.getElementById("userId").value = user.user_id;
  document.getElementById("userName").value = user.name;
  document.getElementById("userEmail").value = user.email;
  document.getElementById("userRole").value = user.role;
  document.getElementById("userPassword").value = "";
  document.getElementById("userPassword").required = false;
  document.getElementById("passwordNote").textContent =
    "Leave blank to keep the current password. To reset it, enter at least 6 characters.";

  document.getElementById("modalEyebrow").textContent = "Edit user";
  document.getElementById("modalTitle").textContent = user.name;

  saveUserButton.textContent = "Save changes";

  clearMessage();
  userModal.classList.add("show");
}

/* ==========================================
   SAVE USER
========================================== */

userForm.addEventListener("submit", async function (event) {
  event.preventDefault();

  const password = document.getElementById("userPassword").value;

  const payload = {
    name: document.getElementById("userName").value.trim(),
    email: document.getElementById("userEmail").value.trim(),
    role: document.getElementById("userRole").value,
    password: password,
  };

  if (formMode === "edit") {
    payload.user_id = Number(document.getElementById("userId").value);
  }

  if (formMode === "create" && password.length < 6) {
    showMessage("The password needs at least 6 characters.", "error");
    return;
  }

  if (formMode === "edit" && password !== "" && password.length < 6) {
    showMessage("The new password needs at least 6 characters.", "error");
    return;
  }

  saveUserButton.disabled = true;
  saveUserButton.textContent = formMode === "create" ? "Creating…" : "Saving…";

  try {
    const response = await fetch("api/users.php", {
      method: formMode === "create" ? "POST" : "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify(payload),
    });

    const result = await response.json();

    if (response.status === 401) {
      logout();
      return;
    }

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message || "Unable to save user");
    }

    showMessage(result.message, "success");

    await loadUsers();

    setTimeout(function () {
      userModal.classList.remove("show");
      showToast(result.message, "success");
    }, 600);
  } catch (error) {
    showMessage(error.message, "error");
  } finally {
    saveUserButton.disabled = false;
    saveUserButton.textContent = formMode === "create" ? "Create user" : "Save changes";
  }
});

/* ==========================================
   DELETE
========================================== */

function askDelete(userId) {
  selectedDeleteId = userId;

  const user = users.find((item) => Number(item.user_id) === Number(userId));

  document.getElementById("deleteText").textContent = user
    ? user.name + "'s account will be deleted permanently. Accounts linked to events or bookings can't be deleted."
    : "This account will be deleted permanently.";

  deleteModal.classList.add("show");
  document.getElementById("keepUserButton").focus();
}

document.getElementById("confirmDeleteButton").addEventListener("click", async function () {
  if (!selectedDeleteId) {
    return;
  }

  this.disabled = true;
  this.textContent = "Deleting…";

  try {
    const response = await fetch("api/users.php", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify({
        user_id: selectedDeleteId,
      }),
    });

    const result = await response.json();

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message || "Unable to delete user");
    }

    deleteModal.classList.remove("show");
    selectedDeleteId = null;

    await loadUsers();

    showToast(result.message, "success");
  } catch (error) {
    deleteModal.classList.remove("show");
    showToast(error.message, "error");
  } finally {
    this.disabled = false;
    this.textContent = "Delete user";
  }
});

/* ==========================================
   MODALS
========================================== */

function closeUserModal() {
  userModal.classList.remove("show");
}

document.getElementById("closeUserModal").addEventListener("click", closeUserModal);
document.getElementById("cancelUserButton").addEventListener("click", closeUserModal);

document.getElementById("keepUserButton").addEventListener("click", function () {
  selectedDeleteId = null;
  deleteModal.classList.remove("show");
});

document.addEventListener("keydown", function (event) {
  if (event.key !== "Escape") return;
  if (userModal.classList.contains("show")) closeUserModal();
  if (deleteModal.classList.contains("show")) {
    selectedDeleteId = null;
    deleteModal.classList.remove("show");
  }
});

/* ==========================================
   MESSAGES
========================================== */

function clearMessage() {
  formMessage.className = "form-message";
  formMessage.textContent = "";
}

function showMessage(message, type) {
  formMessage.textContent = message;
  formMessage.className = "form-message " + type;
}

/* ==========================================
   ROLE CLASS
========================================== */

function getRoleClass(role) {
  if (role === "Administrator") {
    return "role-admin";
  }

  if (role === "Organiser") {
    return "role-organiser";
  }

  return "role-customer";
}

/* ==========================================
   NAVBAR (sidebar account block)
========================================== */

function updateNavbar() {
  EventifyShell.setUser(currentUser);
}

/* ==========================================
   LOGOUT
========================================== */

function logout() {
  localStorage.removeItem("eventify_token");
  localStorage.removeItem("eventify_user");
  window.location.href = "login.php";
}

/* ==========================================
   TOAST
========================================== */

function showToast(message, type) {
  toast.textContent = message;
  toast.className = "toast " + type + " show";

  setTimeout(function () {
    toast.classList.remove("show");
  }, 3500);
}

/* ==========================================
   ESCAPE
========================================== */

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* ==========================================
   START
========================================== */

initialise();
</script>
</body>
</html>
