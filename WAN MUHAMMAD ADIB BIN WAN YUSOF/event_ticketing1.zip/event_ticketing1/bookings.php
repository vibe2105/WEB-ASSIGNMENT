<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My bookings | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<?php $sitePage = 'bookings'; $siteActions = false; include __DIR__ . '/partials/site-header.php'; ?>

<section class="page-band">
    <div class="wrap page-band-row">
        <div>
            <h1>My bookings</h1>
            <p class="lede" id="welcomeText">Loading your bookings…</p>
        </div>
        <p class="event-count-line" aria-live="polite"><strong id="bookingCount">0</strong> bookings</p>
    </div>
</section>

<main>
    <div class="wrap page-body">
        <div class="booking-list" id="bookingsGrid" aria-live="polite">
            <p class="loading-line">Loading your bookings…</p>
        </div>
    </div>
</main>

<?php include __DIR__ . '/partials/site-footer.php'; ?>

<div class="overlay" id="cancelModal" role="dialog" aria-modal="true" aria-labelledby="cancelTitle">
    <div class="dialog">
        <h2 id="cancelTitle">Cancel this booking?</h2>
        <p>Your tickets will be released so other people can book them. This can't be undone.</p>
        <div class="dialog-actions">
            <button type="button" class="btn" id="keepBtn">Keep booking</button>
            <button type="button" class="btn btn-danger" id="confirmCancel">Cancel booking</button>
        </div>
    </div>
</div>

<script src="js/reviews.js"></script>
<script>
const token = localStorage.getItem("eventify_token");
const authNavigation = document.getElementById("authNavigation");
const bookingsGrid = document.getElementById("bookingsGrid");
const bookingCount = document.getElementById("bookingCount");
const welcomeText = document.getElementById("welcomeText");
const modal = document.getElementById("cancelModal");
const keepBtn = document.getElementById("keepBtn");
const confirmCancel = document.getElementById("confirmCancel");

let currentUser = null;
let selectedBooking = null;

// The customer's own reviews, keyed by event_id (from api/reviews.php?mine=1).
let myReviews = new Map();

/* ====================================================
   EXTERNAL THIRD-PARTY QR CODE TICKET (confirmed only)
   The backend checks JWT and booking ownership.
==================================================== */

async function viewTicketQR(bookingId) {
  const overlay = document.createElement("div");
  overlay.className = "eventify-qr-overlay";

  const card = document.createElement("div");
  card.className = "eventify-qr-card";
  card.setAttribute("role", "dialog");
  card.setAttribute("aria-modal", "true");

  const heading = document.createElement("h3");
  heading.textContent = "Ticket for booking #" + Number(bookingId);

  const details = document.createElement("p");
  details.textContent = "Generating your QR code…";

  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "Close";

  let blobUrl = null;

  function cleanup() {
    if (blobUrl) URL.revokeObjectURL(blobUrl);
    overlay.remove();
  }

  close.addEventListener("click", cleanup);

  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) cleanup();
  });

  card.append(heading, details, close);
  overlay.appendChild(card);
  document.body.appendChild(overlay);
  close.focus();

  try {
    const response = await fetch("api/ticket-qr.php?booking_id=" + encodeURIComponent(bookingId), {
      headers: { Authorization: "Bearer " + token },
      cache: "no-store",
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.message || "Unable to load QR ticket");
    }

    const blob = await response.blob();

    if (!blob.type.startsWith("image/")) throw new Error("Invalid QR image");

    blobUrl = URL.createObjectURL(blob);

    const img = document.createElement("img");
    img.src = blobUrl;
    img.alt = "QR code for confirmed Eventify booking";

    details.textContent = "Show this code at the entrance. Staff will scan it to check you in.";

    card.insertBefore(img, close);
  } catch (error) {
    details.textContent = error.message;
  }
}

/* ========================================
   INIT
======================================== */

async function initialise() {
  if (!token) {
    window.location.href = "login.php";
    return;
  }

  try {
    const response = await fetch("auth/me.php", {
      headers: {
        Authorization: "Bearer " + token,
      },
    });

    const result = await response.json();

    if (!response.ok || result.status !== "success") {
      logout();
      return;
    }

    currentUser = result.user;

    updateNavbar();

    welcomeText.textContent = "Signed in as " + currentUser.name + ". Show your QR code at the venue, and rate events after you've been.";

    await loadMyReviews();
    await loadBookings();
  } catch (error) {
    bookingsGrid.innerHTML = `
      <div class="state">
        <h3>We couldn't check your account</h3>
        <p>Refresh the page, or sign in again.</p>
      </div>
    `;
  }
}

/* ========================================
   LOAD MY REVIEWS
   Used to show "Rate this event" or the rating the
   customer already gave. If it fails, bookings still show.
======================================== */

async function loadMyReviews() {
  if (!currentUser || currentUser.role !== "Customer") {
    return;
  }

  try {
    const response = await fetch("api/reviews.php?mine=1", {
      headers: { Authorization: "Bearer " + token },
      cache: "no-store",
    });

    const result = await response.json();

    if (response.ok && result.status === "success") {
      myReviews = new Map(result.data.map((review) => [Number(review.event_id), review]));
    }
  } catch (error) {
    myReviews = new Map();
  }
}

/* ========================================
   LOAD BOOKINGS
======================================== */

async function loadBookings() {
  try {
    const response = await fetch("api/bookings.php", {
      headers: {
        Authorization: "Bearer " + token,
      },
    });

    const result = await response.json();

    if (response.status === 401) {
      logout();
      return;
    }

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message);
    }

    displayBookings(result.data);
  } catch (error) {
    bookingsGrid.innerHTML = `
      <div class="state">
        <h3>Bookings could not be loaded</h3>
        <p>${escapeHTML(error.message)}</p>
      </div>
    `;
  }
}

/* ========================================
   DISPLAY
======================================== */

function displayBookings(bookings) {
  bookingsGrid.innerHTML = "";
  bookingCount.textContent = bookings.length;

  if (bookings.length === 0) {
    bookingsGrid.innerHTML = `
      <div class="state">
        <h3>You haven't booked anything yet</h3>
        <p>When you book tickets they'll appear here, with a QR code to show at the door.</p>
        <a href="events.php" class="btn btn-primary">Browse events</a>
      </div>
    `;
    return;
  }

  bookings.forEach((booking) => {
    const date = new Date(booking.event_date + "T00:00:00");
    const day = String(date.getDate()).padStart(2, "0");
    const month = date.toLocaleString("en-US", { month: "short" });

    const fullDate = date.toLocaleDateString("en-MY", {
      weekday: "short",
      day: "numeric",
      month: "long",
      year: "numeric",
    });

    const cancelled = booking.booking_status === "Cancelled";

    let statusClass = "pending";

    if (booking.booking_status === "Confirmed") {
      statusClass = "confirmed";
    }

    if (cancelled) {
      statusClass = "cancelled-status";
    }

    const quantity = Number(booking.quantity);

    // Has the event finished? (its date and end time are in the past)
    const endsAt = new Date(booking.event_date + "T" + (booking.end_time || "23:59:59"));
    const finished = !Number.isNaN(endsAt.getTime()) && endsAt < new Date();
    const confirmed = booking.booking_status === "Confirmed";
    const review = myReviews.get(Number(booking.event_id));
    const reviewLink = "event-details.php?id=" + Number(booking.event_id) + "#reviews";

    let buttons = "";

    if (confirmed && finished) {
      // After the event: rate it (or see and edit the rating already given).
      buttons = review
        ? `<span class="booking-rated">You rated it ${EventifyReviews.starsHTML(review.rating, "stars-sm")}</span>
           <a class="btn btn-sm" href="${reviewLink}">Edit review</a>`
        : `<a class="btn btn-marigold btn-sm" href="${reviewLink}">Rate this event</a>`;
    } else if (!finished) {
      // Before the event: show the ticket, and allow cancelling.
      buttons = `
        ${confirmed ? `<button class="btn btn-primary btn-sm" type="button" onclick="viewTicketQR(${Number(booking.booking_id)})">Show QR code</button>` : ""}
        ${!cancelled ? `<button class="btn btn-danger-quiet btn-sm" type="button" onclick="openCancel(${Number(booking.booking_id)})">Cancel</button>` : ""}
      `;
    }

    const card = document.createElement("article");
    card.className = "booking-item" + (cancelled ? " cancelled" : "");

    card.innerHTML = `
      <span class="stamp">
        <span class="stamp-day">${day}</span>
        <span class="stamp-month">${month}</span>
      </span>

      <div>
        <div class="booking-item-top">
          <span class="booking-ref">Booking #${Number(booking.booking_id)}</span>
          <span class="badge ${statusClass}">${escapeHTML(booking.booking_status)}</span>
        </div>
        <h3 class="booking-item-title">${escapeHTML(booking.event_name)}</h3>
        <div class="booking-item-meta">
          <span>${fullDate}</span>
          <span>${escapeHTML(booking.venue_name)}</span>
          <span>${quantity} ${quantity === 1 ? "ticket" : "tickets"}</span>
        </div>
      </div>

      <div class="booking-item-side">
        <div class="booking-total">
          <small>Total</small>
          <strong>RM ${Number(booking.total_amount).toFixed(2)}</strong>
        </div>
        <div class="booking-buttons">${buttons}</div>
      </div>
    `;

    bookingsGrid.appendChild(card);
  });
}

/* ========================================
   CANCEL
======================================== */

function openCancel(bookingId) {
  selectedBooking = bookingId;
  modal.classList.add("show");
  keepBtn.focus();
}

keepBtn.addEventListener("click", function () {
  selectedBooking = null;
  modal.classList.remove("show");
});

confirmCancel.addEventListener("click", async function () {
  if (!selectedBooking) {
    return;
  }

  confirmCancel.disabled = true;
  confirmCancel.textContent = "Cancelling…";

  try {
    const response = await fetch("api/bookings.php", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify({
        booking_id: selectedBooking,
      }),
    });

    const result = await response.json();

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message);
    }

    modal.classList.remove("show");
    selectedBooking = null;

    await loadBookings();
  } catch (error) {
    alert(error.message);
  } finally {
    confirmCancel.disabled = false;
    confirmCancel.textContent = "Cancel booking";
  }
});

/* ========================================
   NAVBAR
======================================== */

function updateNavbar() {
  authNavigation.innerHTML = `
    <span class="nav-user">
      ${escapeHTML(currentUser.name)}
      <small>${escapeHTML(currentUser.role)}</small>
    </span>
    <button type="button" class="nav-button" onclick="logout()">Sign out</button>
  `;
}

function logout() {
  localStorage.removeItem("eventify_token");
  localStorage.removeItem("eventify_user");
  window.location.href = "login.php";
}

/* ========================================
   ESCAPE
======================================== */

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

initialise();
</script>
</body>
</html>
