<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage bookings | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<div class="shell">
    <?php $staffPage = 'bookings'; include __DIR__ . '/partials/staff-sidebar.php'; ?>

    <div class="shell-main">
        <?php include __DIR__ . '/partials/staff-topbar.php'; ?>

        <main class="shell-content">
            <header class="page-head">
                <div>
                    <h1>Bookings</h1>
                    <p id="pageDescription">Every customer booking. Open one to confirm or cancel it.</p>
                </div>
            </header>

            <section class="stat-strip" aria-label="Booking summary">
                <div class="stat">
                    <span class="stat-label">Bookings</span>
                    <span class="stat-value" id="totalBookings">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Confirmed</span>
                    <span class="stat-value" id="confirmedBookings">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Cancelled</span>
                    <span class="stat-value" id="cancelledBookings">0</span>
                </div>
                <div class="stat">
                    <span class="stat-label">Confirmed value</span>
                    <span class="stat-value" id="confirmedValue">RM 0.00</span>
                </div>
            </section>

            <div class="toolbar" role="search">
                <label class="search">
                    <span class="visually-hidden">Search bookings</span>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
                    <input type="search" id="bookingSearch" placeholder="Search by customer, event, venue or booking number">
                </label>
                <label>
                    <span class="visually-hidden">Status</span>
                    <select id="bookingStatusFilter">
                        <option value="">All statuses</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Pending">Pending</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </label>
            </div>

            <section class="panel">
                <div class="table-scroll">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th scope="col">Booking</th>
                                <th scope="col">Customer</th>
                                <th scope="col">Event</th>
                                <th scope="col" class="num">Tickets</th>
                                <th scope="col" class="num">Total</th>
                                <th scope="col">Status</th>
                                <th scope="col">Booked on</th>
                                <th scope="col"><span class="visually-hidden">Actions</span></th>
                            </tr>
                        </thead>
                        <tbody id="bookingTableBody">
                            <tr><td colspan="8" class="table-empty">Loading bookings…</td></tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</div>

<!-- STATUS DIALOG -->
<div class="overlay" id="bookingModal">
    <div class="dialog" role="dialog" aria-modal="true" aria-labelledby="bookingModalTitle">
        <div class="dialog-head">
            <h2 id="bookingModalTitle">Change booking status</h2>
            <button type="button" class="icon-btn" id="closeBookingModal">
                <span class="visually-hidden">Close</span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
            </button>
        </div>

        <div class="summary-box" id="modalBookingSummary"></div>

        <div class="field">
            <label for="newBookingStatus">Status</label>
            <select id="newBookingStatus">
                <option value="Confirmed">Confirmed</option>
                <option value="Cancelled">Cancelled</option>
            </select>
        </div>

        <div class="modal-message" id="modalMessage" role="status"></div>

        <div class="dialog-actions">
            <button type="button" class="btn" id="cancelModalButton">Close</button>
            <button type="button" class="btn btn-primary" id="saveStatusButton">Save status</button>
        </div>
    </div>
</div>

<div class="toast" id="toast" role="status" aria-live="polite"></div>

<script src="js/staff-shell.js"></script>
<script>
/* ==========================================
   VARIABLES
========================================== */

const token = localStorage.getItem("eventify_token");

let currentUser = null;
let bookings = [];
let selectedBooking = null;

const bookingTableBody = document.getElementById("bookingTableBody");
const bookingModal = document.getElementById("bookingModal");
const modalMessage = document.getElementById("modalMessage");
const saveStatusButton = document.getElementById("saveStatusButton");
const toast = document.getElementById("toast");

/* ==========================================
   INITIALISE
========================================== */

async function initialise() {
  if (!token) {
    window.location.href = "login.php";
    return;
  }

  try {
    const response = await fetch("auth/me.php", {
      headers: {
        Authorization: "Bearer " + token,
      },
    });

    const result = await response.json();

    if (!response.ok || result.status !== "success") {
      logout();
      return;
    }

    currentUser = result.user;

    if (currentUser.role !== "Administrator" && currentUser.role !== "Organiser") {
      alert("You do not have permission to manage bookings.");
      window.location.href = "events.php";
      return;
    }

    updateNavbar();

    if (currentUser.role === "Organiser") {
      document.getElementById("pageDescription").textContent =
        "Bookings for the events you organise. Open one to confirm or cancel it.";
    }

    await loadBookings();
  } catch (error) {
    showToast("Booking management couldn't load. Refresh the page to try again.", "error");
  }
}

/* ==========================================
   LOAD BOOKINGS
========================================== */

async function loadBookings() {
  const response = await fetch("api/bookings.php", {
    headers: {
      Authorization: "Bearer " + token,
    },
  });

  const result = await response.json();

  if (response.status === 401) {
    logout();
    return;
  }

  if (!response.ok || result.status !== "success") {
    throw new Error(result.message || "Unable to load bookings");
  }

  bookings = result.data;

  displayBookings(bookings);
  updateStatistics();
}

/* ==========================================
   DISPLAY BOOKINGS
========================================== */

function displayBookings(bookingList) {
  bookingTableBody.innerHTML = "";

  if (bookingList.length === 0) {
    bookingTableBody.innerHTML = `
      <tr>
        <td colspan="8" class="table-empty">
          ${bookings.length === 0 ? "No bookings yet. They'll appear here as customers book." : "No bookings match your search."}
        </td>
      </tr>
    `;
    return;
  }

  bookingList.forEach((booking) => {
    const eventDate = new Date(booking.event_date + "T00:00:00");

    const eventDateText = eventDate.toLocaleDateString("en-MY", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });

    const bookingDate = new Date(String(booking.booking_date).replace(" ", "T"));

    const bookingDateText = isNaN(bookingDate.getTime())
      ? booking.booking_date
      : bookingDate.toLocaleDateString("en-MY", {
          day: "numeric",
          month: "short",
          year: "numeric",
        });

    const bookingTimeText = isNaN(bookingDate.getTime())
      ? ""
      : bookingDate.toLocaleTimeString("en-MY", {
          hour: "numeric",
          minute: "2-digit",
        });

    const row = document.createElement("tr");

    row.innerHTML = `
      <td class="nowrap"><strong>#${Number(booking.booking_id)}</strong></td>
      <td>
        <div class="cell-main">
          <strong>${escapeHTML(booking.customer_name || "Customer")}</strong>
          <span>${escapeHTML(booking.customer_email || "")}</span>
        </div>
      </td>
      <td>
        <div class="cell-main">
          <strong>${escapeHTML(booking.event_name)}</strong>
          <span>${eventDateText}, ${escapeHTML(booking.venue_name)}</span>
        </div>
      </td>
      <td class="num">${Number(booking.quantity)}</td>
      <td class="num"><strong>RM ${Number(booking.total_amount).toFixed(2)}</strong></td>
      <td><span class="badge ${getStatusClass(booking.booking_status)}">${escapeHTML(booking.booking_status)}</span></td>
      <td class="nowrap">
        ${escapeHTML(bookingDateText)}
        <span class="cell-sub">${escapeHTML(bookingTimeText)}</span>
      </td>
      <td>
        <div class="row-actions">
          <button type="button" class="btn btn-sm" onclick="openManageBooking(${Number(booking.booking_id)})">Change status</button>
        </div>
      </td>
    `;

    bookingTableBody.appendChild(row);
  });
}

/* ==========================================
   STATISTICS
========================================== */

function updateStatistics() {
  const confirmed = bookings.filter((booking) => booking.booking_status === "Confirmed");
  const cancelled = bookings.filter((booking) => booking.booking_status === "Cancelled");

  const value = confirmed.reduce((total, booking) => {
    return total + Number(booking.total_amount);
  }, 0);

  document.getElementById("totalBookings").textContent = bookings.length;
  document.getElementById("confirmedBookings").textContent = confirmed.length;
  document.getElementById("cancelledBookings").textContent = cancelled.length;
  document.getElementById("confirmedValue").textContent = "RM " + value.toFixed(2);
}

/* ==========================================
   SEARCH AND FILTER
========================================== */

document.getElementById("bookingSearch").addEventListener("input", filterBookings);
document.getElementById("bookingStatusFilter").addEventListener("change", filterBookings);

function filterBookings() {
  const search = document.getElementById("bookingSearch").value.toLowerCase();
  const status = document.getElementById("bookingStatusFilter").value;

  const filtered = bookings.filter((booking) => {
    const searchText = (
      booking.booking_id +
      " " +
      (booking.customer_name || "") +
      " " +
      (booking.customer_email || "") +
      " " +
      booking.event_name +
      " " +
      booking.venue_name
    ).toLowerCase();

    const searchMatch = searchText.includes(search);
    const statusMatch = status === "" || booking.booking_status === status;

    return searchMatch && statusMatch;
  });

  displayBookings(filtered);
}

/* ==========================================
   OPEN MANAGE DIALOG
========================================== */

function openManageBooking(bookingId) {
  selectedBooking = bookings.find((booking) => Number(booking.booking_id) === Number(bookingId));

  if (!selectedBooking) {
    return;
  }

  const quantity = Number(selectedBooking.quantity);

  document.getElementById("modalBookingSummary").innerHTML = `
    <strong>Booking #${Number(selectedBooking.booking_id)}, ${escapeHTML(selectedBooking.event_name)}</strong>
    <span>
      ${escapeHTML(selectedBooking.customer_name || "Customer")}, ${quantity} ${quantity === 1 ? "ticket" : "tickets"},
      RM ${Number(selectedBooking.total_amount).toFixed(2)}
    </span>
  `;

  const statusSelect = document.getElementById("newBookingStatus");

  if (selectedBooking.booking_status === "Cancelled") {
    statusSelect.value = "Cancelled";
  } else {
    statusSelect.value = "Confirmed";
  }

  clearModalMessage();
  bookingModal.classList.add("show");
  statusSelect.focus();
}

/* ==========================================
   SAVE STATUS
========================================== */

saveStatusButton.addEventListener("click", async function () {
  if (!selectedBooking) {
    return;
  }

  const newStatus = document.getElementById("newBookingStatus").value;

  saveStatusButton.disabled = true;
  saveStatusButton.textContent = "Saving…";

  try {
    const response = await fetch("api/bookings.php", {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify({
        booking_id: Number(selectedBooking.booking_id),
        booking_status: newStatus,
      }),
    });

    const result = await response.json();

    if (response.status === 401) {
      logout();
      return;
    }

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message || "Unable to update booking");
    }

    showModalMessage(result.message, "success");

    await loadBookings();

    setTimeout(function () {
      bookingModal.classList.remove("show");
      selectedBooking = null;
      showToast(result.message, "success");
    }, 600);
  } catch (error) {
    showModalMessage(error.message, "error");
  } finally {
    saveStatusButton.disabled = false;
    saveStatusButton.textContent = "Save status";
  }
});

/* ==========================================
   MODAL CONTROLS
========================================== */

function closeBookingModal() {
  bookingModal.classList.remove("show");
  selectedBooking = null;
}

document.getElementById("closeBookingModal").addEventListener("click", closeBookingModal);
document.getElementById("cancelModalButton").addEventListener("click", closeBookingModal);

document.addEventListener("keydown", function (event) {
  if (event.key === "Escape" && bookingModal.classList.contains("show")) closeBookingModal();
});

/* ==========================================
   MESSAGE
========================================== */

function clearModalMessage() {
  modalMessage.className = "modal-message";
  modalMessage.textContent = "";
}

function showModalMessage(message, type) {
  modalMessage.textContent = message;
  modalMessage.className = "modal-message " + type;
}

/* ==========================================
   STATUS CSS
========================================== */

function getStatusClass(status) {
  if (status === "Confirmed") {
    return "status-confirmed";
  }

  if (status === "Cancelled") {
    return "status-cancelled";
  }

  return "status-pending";
}

/* ==========================================
   NAVIGATION (sidebar account block)
   The API already restricts venue management to
   Administrators; the sidebar shows the Venues link
   only after the JWT and role are verified.
========================================== */

function updateNavbar() {
  EventifyShell.setUser(currentUser);
}

/* ==========================================
   LOGOUT
========================================== */

function logout() {
  localStorage.removeItem("eventify_token");
  localStorage.removeItem("eventify_user");
  window.location.href = "login.php";
}

/* ==========================================
   TOAST
========================================== */

function showToast(message, type) {
  toast.textContent = message;
  toast.className = "toast " + type + " show";

  setTimeout(function () {
    toast.classList.remove("show");
  }, 3500);
}

/* ==========================================
   ESCAPE HTML
========================================== */

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* ==========================================
   START
========================================== */

initialise();
</script>
</body>
</html>
