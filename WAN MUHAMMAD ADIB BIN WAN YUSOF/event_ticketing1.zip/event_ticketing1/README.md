# Eventify — Event Ticketing and Venue Booking REST API

**Team development package** — PHP 8.2+, MySQL 8+/MariaDB (XAMPP), HTML/CSS/JS, JWT HS256. This project contains the shared backend plus one Eventify frontend; each teammate must build and demonstrate their own frontend using the shared API.

## Install on Windows/XAMPP

1. Back up the currently working `C:\xampp\htdocs\event_ticketing1` directory and export its MySQL database.
2. Extract this package to `C:\xampp\htdocs\event_ticketing1` (merge/replace only after backing up). Start Apache and MySQL.
3. If building a **new clean installation**, import `database/schema.sql` and optionally `database/sample_data.sql` in phpMyAdmin. **For an existing working database, do not run those scripts; preserve its data.** See `database/EXPORT_LIVE_DATABASE.md`.
4. Copy `config/local.example.php` to `config/local.php` (which is gitignored).
5. Generate **three different** random secret keys in PowerShell/Command Prompt, separately, using:
   `C:\xampp\php\php.exe -r "echo bin2hex(random_bytes(32)), PHP_EOL;"`
   Replace the `EVENTIFY_JWT_SECRET`, `EVENTIFY_TICKET_SECRET`, and `EVENTIFY_INTERNAL_API_KEY` placeholders in `config/local.php` with three separate 64-character outputs. **Never commit, email, or upload `local.php`.**
6. Review `EVENTIFY_DB_HOST`, `EVENTIFY_DB_NAME`, `EVENTIFY_DB_USER`, `EVENTIFY_DB_PASSWORD` for your MySQL configuration. XAMPP may use `root`/blank only for isolated local testing; create a least-privilege account for shared servers. Alternatively provide the same keys as environment variables.
7. On a fresh sample database, use `C:\xampp\php\php.exe tools/create_admin.php` in a terminal opened at the project folder to create your own Administrator account. Do not use sample fixture accounts as login credentials (their passwords are unknown).
8. Open `http://localhost/event_ticketing1/`. Test login, events, booking, and management.
9. Import `postman/Eventify.postman_collection.json` into Postman. Set its credential variables and run requests individually (some requests create or delete records).

**Important**: Replacing the old hardcoded JWT secret invalidates previously issued browser tokens. Log out, clear old sessions and log back in after configuring secrets. Keep **ticket signing key stable** or old QR tickets will fail verification. In XAMPP, enable PHP `curl` and configure trusted CA certificates for external HTTPS QR requests. Local internet access is required.

## Frontend design ("Box Office")

All pages share one stylesheet, `css/eventify.css`, which holds the colours, type, buttons, forms, tables, drawers and dialogs. Page `<style>` blocks have been removed, so change the look there.

- **Font:** Archivo is bundled in `css/fonts/` (SIL Open Font License), so the site still looks right when the XAMPP machine is offline.
- **Shared layout pieces:** `partials/site-header.php`, `partials/site-footer.php`, `partials/staff-sidebar.php` and `partials/staff-topbar.php`. The pages pull them in with PHP `include`, so open the site through Apache (`http://localhost/...`), not by double-clicking the files. `partials/.htaccess` blocks direct access to the partials.
- **Staff pages** (`dashboard.php` and `manage-*.php`) use a sidebar layout. `js/staff-shell.js` fills in the signed-in user, shows the Venues and Users links only to Administrators, and opens the menu on phones.
- **Event links:** `event-details.php` accepts both `?id=` and `?event_id=`.
- **Events filters:** `events.php` accepts `?category=` and `?q=` to pre-fill the filters.
- **New event shortcut:** `manage-events.php?new=1` opens the create form straight away.

## Reviews and ratings (new)

Customers can rate an event from 1 to 5 stars, with an optional comment, after it has finished, as long as they had a Confirmed booking. Reviews show on the event page with the average rating and a breakdown. My bookings shows "Rate this event" for finished events. Administrators can remove any review.

**To switch it on for an existing database:** back up the database, then run `database/add_reviews.sql` once in phpMyAdmin. It only adds the new `reviews` table and doesn't touch existing data. (New installs get the table from `schema.sql`.)

Files: `api/reviews.php` (API), `js/reviews.js` (event page), `database/add_reviews.sql`. API details are in `docs/API_DOCUMENTATION.md`.

## Roles

| Feature | Administrator | Organiser | Customer |
|---|---|---|---|
| Manage users | ✓ | – | – |
| Add/edit/delete venues | ✓ | – | – |
| Read venues | ✓ | ✓ | ✓ |
| Manage events | All | Own events | – |
| Manage bookings | All | For own events | – |
| Make/cancel booking | – | – | Own bookings |
| Scan/verify ticket code | All | Own events | – |
| View QR ticket | All | Own events | Own confirmed bookings |
| Write/edit review | – | – | Own, after attending |
| Delete review | Any (moderation) | – | Own |

**Venue business rules:** new events must use an available venue; ticket count may not exceed venue capacity; time slots must not overlap for the same venue. Editing an existing event may retain its formerly available assigned venue. Venue CRUD is Administrator-only.

## Advanced API features

- JWT authentication and database-refresh of user role per protected request.
- Administrator JWT **plus X-API-Key** protection on `api/system-metrics.php` (internal metrics).
- Shared exception/structured-error middleware and safe request logging (Apache/PHP error log; no passwords/tokens logged).
- Event API search (`search`), category/status filtering, optional page/limit pagination (limit max 100) and sorting.
- Third-party HTTPS QR code image generation for confirmed bookings, via goQR.me QR API. No customer names, emails, passwords or JWTs are sent to the provider. An opaque signed booking code is sent.
- Verification API for staff validates the signed QR payload and checks booking status in the live database. It does **not** track check-in/attendance or prevent duplicate scans.

## Endpoints

See `docs/API_DOCUMENTATION.md` and the reference `database/ERD.mmd` (Mermaid diagram). Main resources: `api/events.php`, `api/venues.php`, `api/bookings.php`, `api/users.php`; auth: `auth/login.php`, `auth/register.php`, `auth/me.php`; public health: `api/status.php`; internal status: `api/system-metrics.php` (Admin JWT + API key); tickets: `api/ticket-qr.php` and `api/verify-ticket.php`; reviews and ratings: `api/reviews.php`.

## Submission/handoff items not supplied by this code package

- Real sanitized SQL export from your XAMPP installation; reference schema + synthetic fixtures are provided only as an alternative starting point.
- ERD, university project report PDF, video presentation links, and real Postman/browser screenshots.
- Live integration testing against your local MySQL and external QR provider. PHP/JS syntax checks are not proof of runtime behavior.

See `docs/TEAM_TEST_CHECKLIST.md` for the required manual tests before submission.

## Troubleshooting

- **Login fails after update:** verify both new keys in `config/local.php`, then sign in afresh; confirm MySQL has bcrypt hashes. Existing tokens from the old secret no longer work.
- **API sends 503:** database unavailable or JWT signing secret missing/invalid; examine private XAMPP Apache/PHP log. No SQL exception details are intentionally returned to clients.
- **QR returns 502/503:** verify internet, XAMPP `extension=curl`, trusted CA bundle, and service availability.
- **Organiser cannot create event:** verify venue is Available, capacity sufficient and no overlapping event schedule exists.
- **Other team members cannot connect:** `localhost` means *their own computer*. To share across devices, deploy the API to an accessible host using HTTPS; configure each team's frontend base URL. Never publish XAMPP root database credentials or secret keys.
