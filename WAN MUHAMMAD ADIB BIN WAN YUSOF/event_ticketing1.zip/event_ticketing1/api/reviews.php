<?php
/* =====================================================
   EVENTIFY REVIEWS & RATINGS API

   GET    api/reviews.php?event_id=N   Public. Reviews for one event plus
                                       a rating summary. If a valid JWT is
                                       sent, also says whether the caller
                                       can review and returns their review.
   GET    api/reviews.php?mine=1       Customer. The caller's own reviews.
   POST   api/reviews.php              Customer. {event_id, rating, comment}
   PUT    api/reviews.php              Review owner. {review_id, rating, comment}
   DELETE api/reviews.php              Review owner or Administrator. {review_id}

   Business rules
   - Only Customers can write reviews.
   - The customer needs a Confirmed booking for the event.
   - The event must have finished (status Completed, or its date and
     end time have passed) and must not be Cancelled.
   - One review per customer per event; they edit it instead.
   - Rating is a whole number from 1 to 5; comment is optional, up to
     1,000 characters.
===================================================== */

require_once __DIR__ . "/../middleware/api.php";
eventifyApiInit();

header("Content-Type: application/json; charset=utf-8");

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../middleware/validation.php";
require_once __DIR__ . "/../middleware/auth.php";

const EVENTIFY_REVIEW_COMMENT_MAX = 1000;

$db = (new Database())->getConnection();

if (!$db) {
    http_response_code(503);
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

$method = $_SERVER["REQUEST_METHOD"];

/* =====================================================
   HELPERS
===================================================== */

function reviewsRespond(int $code, array $body): void
{
    http_response_code($code);
    echo json_encode($body);
    exit;
}

function reviewsError(int $code, string $message): void
{
    reviewsRespond($code, ["status" => "error", "message" => $message]);
}

function reviewsTextLength(string $text): int
{
    return function_exists("mb_strlen") ? mb_strlen($text, "UTF-8") : strlen($text);
}

/* Shows "Mei Ling Wong" as "Mei Ling W." so full surnames are not published. */
function reviewsPublicName(string $name): string
{
    $parts = preg_split("/\s+/u", trim($name)) ?: [];
    if (count($parts) <= 1) {
        return $parts[0] ?? "Customer";
    }
    $last = array_pop($parts);
    $initial = function_exists("mb_substr") ? mb_substr($last, 0, 1, "UTF-8") : substr($last, 0, 1);
    return implode(" ", $parts) . " " . strtoupper($initial) . ".";
}

/* Validates rating (1-5) and optional comment from a JSON body. */
function reviewsReadRatingAndComment(array $data): array
{
    $rating = filter_var($data["rating"] ?? null, FILTER_VALIDATE_INT, [
        "options" => ["min_range" => 1, "max_range" => 5],
    ]);
    if ($rating === false) {
        reviewsError(400, "Rating must be a whole number from 1 to 5");
    }

    $comment = $data["comment"] ?? "";
    if ($comment === null) {
        $comment = "";
    }
    if (!is_string($comment)) {
        reviewsError(400, "Comment must be text");
    }
    $comment = trim($comment);
    if (reviewsTextLength($comment) > EVENTIFY_REVIEW_COMMENT_MAX) {
        reviewsError(400, "Comment must be " . EVENTIFY_REVIEW_COMMENT_MAX . " characters or fewer");
    }

    return [(int) $rating, $comment === "" ? null : $comment];
}

function reviewsReadId(array $data, string $key): int
{
    $id = filter_var($data[$key] ?? null, FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]);
    if ($id === false) {
        reviewsError(400, "A valid $key is required");
    }
    return (int) $id;
}

function reviewsJsonBody(): array
{
    $data = eventifyDecodedJsonBody();
    if ($data === null) {
        reviewsError(400, "Request body must be a JSON object");
    }
    return $data;
}

/* Returns the signed-in user if a valid JWT was sent, otherwise null.
   Used by the public GET so guests still see reviews. */
function reviewsOptionalUser(PDO $db): ?array
{
    $token = getBearerToken();
    if (!$token) {
        return null;
    }
    try {
        $claims = verifyJWT($token);
    } catch (Throwable $error) {
        return null;
    }
    if (!$claims) {
        return null;
    }
    $statement = $db->prepare("SELECT user_id, name, email, role FROM users WHERE user_id = :id LIMIT 1");
    $statement->execute([":id" => (int) $claims["user_id"]]);
    $user = $statement->fetch();
    return $user ?: null;
}

/* Event row plus whether it has finished. */
function reviewsFindEvent(PDO $db, int $eventId): ?array
{
    $statement = $db->prepare(
        "SELECT event_id, event_name, status,
                (status = 'Completed'
                 OR event_date < CURDATE()
                 OR (event_date = CURDATE() AND end_time <= CURTIME())) AS has_ended
         FROM events
         WHERE event_id = :id
         LIMIT 1"
    );
    $statement->execute([":id" => $eventId]);
    $event = $statement->fetch();
    return $event ?: null;
}

function reviewsHasConfirmedBooking(PDO $db, int $userId, int $eventId): bool
{
    $statement = $db->prepare(
        "SELECT COUNT(*) FROM bookings
         WHERE user_id = :user AND event_id = :event AND booking_status = 'Confirmed'"
    );
    $statement->execute([":user" => $userId, ":event" => $eventId]);
    return (int) $statement->fetchColumn() > 0;
}

function reviewsFindUserReview(PDO $db, int $userId, int $eventId): ?array
{
    $statement = $db->prepare(
        "SELECT review_id, event_id, rating, comment, created_at, updated_at
         FROM reviews WHERE user_id = :user AND event_id = :event LIMIT 1"
    );
    $statement->execute([":user" => $userId, ":event" => $eventId]);
    $review = $statement->fetch();
    if (!$review) {
        return null;
    }
    $review["review_id"] = (int) $review["review_id"];
    $review["event_id"] = (int) $review["event_id"];
    $review["rating"] = (int) $review["rating"];
    return $review;
}

/* Works out whether this user may write a review for this event.
   Returns [canReview, reasonCode, reasonMessage]. */
function reviewsEligibility(PDO $db, array $user, array $event): array
{
    if ($user["role"] !== "Customer") {
        return [false, "not_customer", "Only customer accounts can write reviews."];
    }
    if (reviewsFindUserReview($db, (int) $user["user_id"], (int) $event["event_id"])) {
        return [false, "already_reviewed", "You've already reviewed this event. You can edit your review."];
    }
    if ($event["status"] === "Cancelled") {
        return [false, "event_cancelled", "This event was cancelled, so it can't be reviewed."];
    }
    if (!reviewsHasConfirmedBooking($db, (int) $user["user_id"], (int) $event["event_id"])) {
        return [false, "no_booking", "Only customers with a confirmed booking for this event can review it."];
    }
    if (!(int) $event["has_ended"]) {
        return [false, "not_finished", "You can review this event once it has finished."];
    }
    return [true, null, null];
}

/* =====================================================
   ROUTES
===================================================== */

try {

    /* -------------------------------------------------
       GET ?mine=1  (Customer's own reviews)
    ------------------------------------------------- */

    if ($method === "GET" && isset($_GET["mine"])) {
        $user = requireAuth();
        requireRole($user, ["Customer"]);

        $statement = $db->prepare(
            "SELECT r.review_id, r.event_id, r.rating, r.comment, r.created_at, r.updated_at,
                    e.event_name
             FROM reviews r
             JOIN events e ON e.event_id = r.event_id
             WHERE r.user_id = :user
             ORDER BY r.created_at DESC"
        );
        $statement->execute([":user" => (int) $user["user_id"]]);

        $reviews = array_map(function ($row) {
            $row["review_id"] = (int) $row["review_id"];
            $row["event_id"] = (int) $row["event_id"];
            $row["rating"] = (int) $row["rating"];
            return $row;
        }, $statement->fetchAll());

        reviewsRespond(200, ["status" => "success", "total" => count($reviews), "data" => $reviews]);
    }

    /* -------------------------------------------------
       GET ?event_id=N  (public list + summary)
    ------------------------------------------------- */

    if ($method === "GET") {
        $eventId = eventifyQueryPositiveInt("event_id", 0);
        if (!$eventId) {
            reviewsError(400, "event_id is required");
        }

        $limit = eventifyQueryPositiveInt("limit", 50, 100);
        if ($limit === false) {
            reviewsError(400, "limit must be between 1 and 100");
        }

        $sort = eventifyQueryText("sort", 10, "newest");
        $orderBy = [
            "newest" => "r.created_at DESC, r.review_id DESC",
            "highest" => "r.rating DESC, r.created_at DESC",
            "lowest" => "r.rating ASC, r.created_at DESC",
        ][$sort] ?? null;
        if ($orderBy === null) {
            reviewsError(400, "sort must be newest, highest or lowest");
        }

        $event = reviewsFindEvent($db, $eventId);
        if (!$event) {
            reviewsError(404, "Event not found");
        }

        /* Summary over all reviews for the event */
        $statement = $db->prepare(
            "SELECT rating, COUNT(*) AS total FROM reviews WHERE event_id = :id GROUP BY rating"
        );
        $statement->execute([":id" => $eventId]);

        $breakdown = ["5" => 0, "4" => 0, "3" => 0, "2" => 0, "1" => 0];
        $count = 0;
        $sum = 0;
        foreach ($statement->fetchAll() as $row) {
            $breakdown[(string) (int) $row["rating"]] = (int) $row["total"];
            $count += (int) $row["total"];
            $sum += (int) $row["rating"] * (int) $row["total"];
        }

        /* Review list */
        $viewer = reviewsOptionalUser($db);

        $statement = $db->prepare(
            "SELECT r.review_id, r.user_id, r.rating, r.comment, r.created_at, r.updated_at,
                    u.name AS reviewer_name
             FROM reviews r
             JOIN users u ON u.user_id = r.user_id
             WHERE r.event_id = :id
             ORDER BY $orderBy
             LIMIT $limit"
        );
        $statement->execute([":id" => $eventId]);

        $reviews = array_map(function ($row) use ($viewer) {
            return [
                "review_id" => (int) $row["review_id"],
                "rating" => (int) $row["rating"],
                "comment" => $row["comment"],
                "reviewer_name" => reviewsPublicName((string) $row["reviewer_name"]),
                "created_at" => $row["created_at"],
                "updated_at" => $row["updated_at"],
                "is_mine" => $viewer !== null && (int) $row["user_id"] === (int) $viewer["user_id"],
            ];
        }, $statement->fetchAll());

        $response = [
            "status" => "success",
            "event_id" => $eventId,
            "summary" => [
                "review_count" => $count,
                "average_rating" => $count > 0 ? round($sum / $count, 1) : null,
                "breakdown" => $breakdown,
            ],
            "data" => $reviews,
        ];

        /* What the signed-in caller can do (omitted for guests) */
        if ($viewer) {
            [$canReview, $reasonCode, $reasonMessage] = reviewsEligibility($db, $viewer, $event);
            $response["viewer"] = [
                "role" => $viewer["role"],
                "can_review" => $canReview,
                "can_moderate" => $viewer["role"] === "Administrator",
                "reason" => $reasonCode,
                "reason_message" => $reasonMessage,
                "my_review" => $viewer["role"] === "Customer"
                    ? reviewsFindUserReview($db, (int) $viewer["user_id"], $eventId)
                    : null,
            ];
        }

        reviewsRespond(200, $response);
    }

    /* -------------------------------------------------
       POST  (Customer writes a review)
    ------------------------------------------------- */

    if ($method === "POST") {
        $user = requireAuth();
        requireRole($user, ["Customer"]);

        $data = reviewsJsonBody();
        $eventId = reviewsReadId($data, "event_id");
        [$rating, $comment] = reviewsReadRatingAndComment($data);

        $event = reviewsFindEvent($db, $eventId);
        if (!$event) {
            reviewsError(404, "Event not found");
        }

        [$canReview, $reasonCode, $reasonMessage] = reviewsEligibility($db, $user, $event);
        if (!$canReview) {
            // Missing booking is a permission problem; the rest are business-rule conflicts.
            reviewsError($reasonCode === "no_booking" ? 403 : 409, rtrim($reasonMessage, "."));
        }

        try {
            $statement = $db->prepare(
                "INSERT INTO reviews (event_id, user_id, rating, comment)
                 VALUES (:event, :user, :rating, :comment)"
            );
            $statement->execute([
                ":event" => $eventId,
                ":user" => (int) $user["user_id"],
                ":rating" => $rating,
                ":comment" => $comment,
            ]);
        } catch (PDOException $error) {
            // Two requests at once can both pass the check above; the UNIQUE key stops the second.
            if ($error->getCode() === "23000") {
                reviewsError(409, "You've already reviewed this event. Edit your review instead");
            }
            throw $error;
        }

        reviewsRespond(201, [
            "status" => "success",
            "message" => "Thanks, your review has been posted",
            "review_id" => (int) $db->lastInsertId(),
        ]);
    }

    /* -------------------------------------------------
       PUT  (owner edits their review)
    ------------------------------------------------- */

    if ($method === "PUT") {
        $user = requireAuth();
        requireRole($user, ["Customer"]);

        $data = reviewsJsonBody();
        $reviewId = reviewsReadId($data, "review_id");
        [$rating, $comment] = reviewsReadRatingAndComment($data);

        $statement = $db->prepare("SELECT review_id, user_id FROM reviews WHERE review_id = :id LIMIT 1");
        $statement->execute([":id" => $reviewId]);
        $review = $statement->fetch();

        if (!$review) {
            reviewsError(404, "Review not found");
        }
        if ((int) $review["user_id"] !== (int) $user["user_id"]) {
            reviewsError(403, "You can only edit your own review");
        }

        $statement = $db->prepare(
            "UPDATE reviews SET rating = :rating, comment = :comment, updated_at = NOW()
             WHERE review_id = :id"
        );
        $statement->execute([":rating" => $rating, ":comment" => $comment, ":id" => $reviewId]);

        reviewsRespond(200, ["status" => "success", "message" => "Your review has been updated"]);
    }

    /* -------------------------------------------------
       DELETE  (owner, or Administrator moderating)
    ------------------------------------------------- */

    if ($method === "DELETE") {
        $user = requireAuth();
        requireRole($user, ["Customer", "Administrator"]);

        $data = reviewsJsonBody();
        $reviewId = reviewsReadId($data, "review_id");

        $statement = $db->prepare("SELECT review_id, user_id FROM reviews WHERE review_id = :id LIMIT 1");
        $statement->execute([":id" => $reviewId]);
        $review = $statement->fetch();

        if (!$review) {
            reviewsError(404, "Review not found");
        }

        $isOwner = (int) $review["user_id"] === (int) $user["user_id"];
        if (!$isOwner && $user["role"] !== "Administrator") {
            reviewsError(403, "You can only delete your own review");
        }

        $statement = $db->prepare("DELETE FROM reviews WHERE review_id = :id");
        $statement->execute([":id" => $reviewId]);

        reviewsRespond(200, [
            "status" => "success",
            "message" => $isOwner ? "Your review has been deleted" : "Review removed",
        ]);
    }

    header("Allow: GET, POST, PUT, DELETE");
    reviewsError(405, "Method not allowed");

} catch (Throwable $error) {
    error_log("Eventify reviews API: " . $error->getMessage());
    reviewsError(500, "Internal server error");
}
