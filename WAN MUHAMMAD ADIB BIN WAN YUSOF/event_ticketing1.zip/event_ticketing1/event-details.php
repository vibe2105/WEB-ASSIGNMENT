<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event details | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<?php $sitePage = 'events'; include __DIR__ . '/partials/site-header.php'; ?>

<section class="event-hero">
    <div class="wrap">
        <a href="events.php" class="back-link">← All events</a>
        <div id="heroContent">
            <p class="muted">Loading event…</p>
        </div>
    </div>
</section>

<main>
    <div class="wrap" id="detailsContainer"></div>
</main>

<?php include __DIR__ . '/partials/site-footer.php'; ?>

<!-- Confirmation used when deleting a review -->
<div class="overlay" id="reviewDeleteModal">
    <div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="reviewDeleteTitle" aria-describedby="reviewDeleteText">
        <h2 id="reviewDeleteTitle">Delete this review?</h2>
        <p id="reviewDeleteText">The review and its rating will be removed permanently.</p>
        <div class="dialog-actions">
            <button type="button" class="btn" id="reviewKeepButton">Keep review</button>
            <button type="button" class="btn btn-danger" id="reviewConfirmDelete">Delete review</button>
        </div>
    </div>
</div>

<script src="js/reviews.js"></script>
<script>
/* =====================================
   GET EVENT ID FROM URL
   Accepts ?id= and ?event_id= so links
   from every page reach the same event.
===================================== */

const params = new URLSearchParams(window.location.search);

const eventId = params.get("id") || params.get("event_id");

const heroContent = document.getElementById("heroContent");

const detailsContainer = document.getElementById("detailsContainer");

/* =====================================
   LOAD EVENT
===================================== */

async function loadEventDetails() {
  if (!eventId) {
    showError("No event was selected.");
    return;
  }

  try {
    const response = await fetch("api/events.php?event_id=" + encodeURIComponent(eventId));
    const result = await response.json();

    if (!response.ok || result.status !== "success") {
      showError(result.message || "Event not found.");
      return;
    }

    displayEvent(result.data);
  } catch (error) {
    console.error(error);
    showError("Unable to connect to the server.");
  }
}

/* =====================================
   DISPLAY EVENT
===================================== */

function displayEvent(event) {
  document.title = event.event_name + " | Eventify";

  const eventDate = new Date(event.event_date + "T00:00:00");

  const formattedDate = eventDate.toLocaleDateString("en-MY", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const day = String(eventDate.getDate()).padStart(2, "0");
  const month = eventDate.toLocaleString("en-US", { month: "short" });

  const startTime = formatTime(event.start_time);
  const endTime = formatTime(event.end_time);

  const price = Number(event.ticket_price);
  const available = Number(event.available_tickets);
  const total = Number(event.total_tickets);
  const sold = Math.max(0, total - available);
  const soldPercent = total > 0 ? Math.round((sold / total) * 100) : 0;

  const status = String(event.status || "");
  const isOpen = status === "Upcoming" || status === "Ongoing";
  const canBook = isOpen && available > 0;

  let closedReason = "";
  if (!isOpen) {
    closedReason = "This event is " + status.toLowerCase() + ", so tickets are no longer on sale.";
  } else if (available <= 0) {
    closedReason = "This event is sold out.";
  }

  heroContent.innerHTML = `
    <div class="event-hero-grid">
      <span class="stamp stamp-lg${isOpen ? "" : " is-past"}">
        <span class="stamp-day">${day}</span>
        <span class="stamp-month">${month}</span>
      </span>
      <div>
        <span class="event-row-cat">${escapeHTML(event.category)}</span>
        <h1>${escapeHTML(event.event_name)}</h1>
        <div class="event-hero-facts">
          <span>${formattedDate}</span>
          <span>${startTime} to ${endTime}</span>
          <span>${escapeHTML(event.venue_name)}, ${escapeHTML(event.location)}</span>
          ${isOpen ? "" : `<span class="badge ${getStatusClass(status)}">${escapeHTML(status)}</span>`}
          <a class="hero-rating" id="heroRating" href="#reviews" hidden></a>
        </div>
      </div>
    </div>
  `;

  detailsContainer.innerHTML = `
    <div class="details-layout">

      <div>
        <section class="details-section">
          <h2>About this event</h2>
          <p>${escapeHTML(event.description || "The organiser hasn't added a description yet.")}</p>
        </section>

        <section class="details-section">
          <h2>When and where</h2>
          <dl class="facts">
            <div><dt>Date</dt><dd>${formattedDate}</dd></div>
            <div><dt>Time</dt><dd>${startTime} to ${endTime}</dd></div>
            <div><dt>Venue</dt><dd>${escapeHTML(event.venue_name)}</dd></div>
            <div><dt>Location</dt><dd>${escapeHTML(event.location)}</dd></div>
            <div><dt>Organised by</dt><dd>${escapeHTML(event.organiser_name)}</dd></div>
            <div><dt>Venue capacity</dt><dd>${Number(event.capacity).toLocaleString()} people</dd></div>
          </dl>
        </section>

        <section class="details-section" id="reviews" aria-labelledby="reviewsTitle">
          <h2 id="reviewsTitle">Reviews</h2>
          <div id="reviewsRoot"><p class="muted">Loading reviews…</p></div>
        </section>
      </div>

      <aside class="ticket-panel" aria-label="Tickets">
        <div class="ticket-panel-top">
          <span>Price per ticket</span>
          <div class="ticket-price">${price === 0 ? "Free" : "RM " + price.toFixed(2)}</div>
        </div>

        <div class="ticket-panel-body">
          <div class="meter">
            <div class="meter-text">
              <strong>${available.toLocaleString()}</strong> of ${total.toLocaleString()} tickets left
            </div>
            <div class="meter-track" role="img" aria-label="${soldPercent}% of tickets sold">
              <div class="meter-fill" style="width:${soldPercent}%"></div>
            </div>
          </div>

          ${
            canBook
              ? `
            <button type="button" class="btn btn-primary btn-lg btn-block" onclick="startBooking(${Number(event.event_id)})">
              Book tickets
            </button>
            <p class="ticket-panel-note">You'll choose how many tickets you need on the next step. Up to 10 per booking.</p>
          `
              : `<p class="ticket-panel-closed">${escapeHTML(closedReason)}</p>`
          }
        </div>
      </aside>

    </div>
  `;

  // Reviews and ratings load separately from api/reviews.php (js/reviews.js).
  EventifyReviews.load(Number(event.event_id));
}

/* =====================================
   BOOKING BUTTON
===================================== */

function startBooking(eventId) {
  window.location.href = "book-ticket.php?event_id=" + eventId;
}

/* =====================================
   STATUS BADGE
===================================== */

function getStatusClass(status) {
  if (status === "Cancelled") return "status-cancelled";
  if (status === "Completed") return "status-completed";
  if (status === "Ongoing") return "status-ongoing";
  return "status-upcoming";
}

/* =====================================
   FORMAT TIME
===================================== */

function formatTime(time) {
  if (!time) {
    return "Unavailable";
  }

  const parts = time.split(":");
  const date = new Date();
  date.setHours(Number(parts[0]));
  date.setMinutes(Number(parts[1]));

  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
}

/* =====================================
   SHOW ERROR
===================================== */

function showError(message) {
  heroContent.innerHTML = `<h1>Event not available</h1>`;

  detailsContainer.innerHTML = `
    <div class="state page-state">
      <h3>We couldn't load this event</h3>
      <p>${escapeHTML(message)}</p>
      <a class="btn" href="events.php">Back to all events</a>
    </div>
  `;
}

/* =====================================
   ESCAPE HTML
===================================== */

function escapeHTML(value) {
  if (value === null || value === undefined) {
    return "";
  }

  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* =====================================
   START PAGE
===================================== */

loadEventDetails();
</script>
<script src="js/auth.js"></script>
</body>
</html>
