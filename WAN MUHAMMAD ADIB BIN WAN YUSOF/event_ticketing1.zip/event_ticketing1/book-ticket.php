<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book tickets | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<?php $sitePage = 'events'; $siteActions = false; include __DIR__ . '/partials/site-header.php'; ?>

<section class="page-band">
    <div class="wrap">
        <a href="events.php" id="backLink" class="back-link">← Back to the event</a>
        <h1>Book tickets</h1>
        <p class="lede">Your tickets are saved to your Eventify account. You'll find them, with a QR code for entry, under My bookings.</p>
    </div>
</section>

<main>
    <div class="wrap" id="bookingContainer">
        <p class="loading-line">Checking your account…</p>
    </div>
</main>

<?php include __DIR__ . '/partials/site-footer.php'; ?>

<script>
/* =========================================
   AUTH
========================================= */

const token = localStorage.getItem("eventify_token");
const storedUser = JSON.parse(localStorage.getItem("eventify_user") || "null");
const params = new URLSearchParams(window.location.search);
const eventId = params.get("event_id");
const bookingContainer = document.getElementById("bookingContainer");
const backLink = document.getElementById("backLink");
const authNavigation = document.getElementById("authNavigation");

let currentEvent = null;
let currentUser = null;

/* =========================================
   INITIALISE
========================================= */

async function initialisePage() {
  if (!token) {
    redirectToLogin();
    return;
  }

  if (!eventId) {
    showError("No event was selected.");
    return;
  }

  backLink.href = "event-details.php?id=" + encodeURIComponent(eventId);

  /* VERIFY JWT */
  try {
    const authResponse = await fetch("auth/me.php", {
      headers: {
        Authorization: "Bearer " + token,
      },
    });

    const authResult = await authResponse.json();

    if (!authResponse.ok || authResult.status !== "success") {
      clearLogin();
      redirectToLogin();
      return;
    }

    currentUser = authResult.user;

    updateNavbar();

    if (currentUser.role !== "Customer") {
      showError("Only customer accounts can book tickets. Sign in with a customer account to continue.");
      return;
    }

    await loadEvent();
  } catch (error) {
    showError("Unable to verify your account.");
  }
}

/* =========================================
   EVENT
========================================= */

async function loadEvent() {
  try {
    const response = await fetch("api/events.php?event_id=" + encodeURIComponent(eventId));
    const result = await response.json();

    if (!response.ok || result.status !== "success") {
      throw new Error(result.message || "Event unavailable");
    }

    currentEvent = result.data;

    displayBookingForm();
  } catch (error) {
    showError(error.message);
  }
}

/* =========================================
   DISPLAY
========================================= */

function displayBookingForm() {
  const eventDate = new Date(currentEvent.event_date + "T00:00:00");

  const formattedDate = eventDate.toLocaleDateString("en-MY", {
    weekday: "short",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const day = String(eventDate.getDate()).padStart(2, "0");
  const month = eventDate.toLocaleString("en-US", { month: "short" });

  const ticketPrice = Number(currentEvent.ticket_price);
  const initial = currentUser.name.charAt(0).toUpperCase();
  const maximum = Math.min(10, Number(currentEvent.available_tickets));

  bookingContainer.innerHTML = `
    <div class="booking-layout">

      <div>
        <section class="booking-step">
          <h2>Event</h2>
          <div class="chosen-event">
            <span class="stamp">
              <span class="stamp-day">${day}</span>
              <span class="stamp-month">${month}</span>
            </span>
            <div>
              <strong>${escapeHTML(currentEvent.event_name)}</strong>
              <span>${formattedDate}, ${escapeHTML(currentEvent.venue_name)}</span>
            </div>
          </div>
        </section>

        <section class="booking-step">
          <h2><label for="quantity">How many tickets?</label></h2>
          <p>Up to ${maximum} for this booking.</p>
          <div class="stepper">
            <button type="button" id="minusBtn" aria-label="One fewer ticket">−</button>
            <input type="number" id="quantity" value="1" min="1" max="${maximum}" inputmode="numeric">
            <button type="button" id="plusBtn" aria-label="One more ticket">+</button>
          </div>
          <p class="stock-note">
            ${Number(currentEvent.available_tickets).toLocaleString()} tickets still available.
          </p>
        </section>

        <section class="booking-step">
          <h2>Booking as</h2>
          <div class="booking-as">
            <span class="avatar" aria-hidden="true">${escapeHTML(initial)}</span>
            <div>
              <strong>${escapeHTML(currentUser.name)}</strong>
              <small>${escapeHTML(currentUser.email || "Customer account")}</small>
            </div>
          </div>
        </section>
      </div>

      <aside class="stub" aria-label="Order summary">
        <div class="stub-head">
          <span>Order summary</span>
          <h2>${escapeHTML(currentEvent.event_name)}</h2>
        </div>

        <div class="stub-rows">
          <div class="stub-row">
            <span>Price per ticket</span>
            <strong>RM ${ticketPrice.toFixed(2)}</strong>
          </div>
          <div class="stub-row">
            <span>Tickets</span>
            <strong id="summaryQuantity">1</strong>
          </div>
        </div>

        <div class="stub-tear" aria-hidden="true"></div>

        <div class="stub-total">
          <span>Total</span>
          <strong id="totalPrice">RM ${ticketPrice.toFixed(2)}</strong>
        </div>

        <div class="stub-actions">
          <button type="button" class="btn btn-primary btn-lg btn-block" id="confirmBtn">
            Confirm booking
          </button>
          <div class="booking-message" id="bookingMessage" role="status"></div>
        </div>
      </aside>

    </div>
  `;

  setupControls();
}

/* =========================================
   QUANTITY
========================================= */

function setupControls() {
  const quantity = document.getElementById("quantity");
  const minus = document.getElementById("minusBtn");
  const plus = document.getElementById("plusBtn");
  const maximum = Math.min(10, Number(currentEvent.available_tickets));

  minus.addEventListener("click", function () {
    let value = Number(quantity.value);

    if (value > 1) {
      quantity.value = value - 1;
      updateTotal();
    }
  });

  plus.addEventListener("click", function () {
    let value = Number(quantity.value);

    if (value < maximum) {
      quantity.value = value + 1;
      updateTotal();
    }
  });

  quantity.addEventListener("input", function () {
    let value = Number(quantity.value);

    if (!Number.isInteger(value) || value < 1) {
      value = 1;
    }

    if (value > maximum) {
      value = maximum;
    }

    quantity.value = value;
    updateTotal();
  });

  document.getElementById("confirmBtn").addEventListener("click", createBooking);
}

/* =========================================
   TOTAL
========================================= */

function updateTotal() {
  const quantity = Number(document.getElementById("quantity").value);
  const total = quantity * Number(currentEvent.ticket_price);

  document.getElementById("summaryQuantity").textContent = quantity;
  document.getElementById("totalPrice").textContent = "RM " + total.toFixed(2);
}

/* =========================================
   CREATE BOOKING
========================================= */

async function createBooking() {
  const quantity = Number(document.getElementById("quantity").value);
  const button = document.getElementById("confirmBtn");
  const message = document.getElementById("bookingMessage");

  button.disabled = true;
  button.textContent = "Confirming…";

  try {
    const response = await fetch("api/bookings.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
      body: JSON.stringify({
        event_id: Number(eventId),
        quantity: quantity,
      }),
    });

    const result = await response.json();

    if (response.status === 401) {
      clearLogin();
      redirectToLogin();
      return;
    }

    if (response.ok && result.status === "success") {
      message.className = "booking-message success";
      message.innerHTML = `
        Booking confirmed. Booking <strong>#${escapeHTML(result.booking_id)}</strong>
        for <strong>${escapeHTML(result.customer)}</strong>,
        total <strong>RM ${escapeHTML(result.total_amount)}</strong>.
        Taking you to My bookings…
      `;

      button.textContent = "Booking confirmed";

      setTimeout(function () {
        window.location.href = "bookings.php";
      }, 1700);
    } else {
      throw new Error(result.message || "Unable to create booking");
    }
  } catch (error) {
    message.className = "booking-message error";
    message.textContent = error.message;
    button.disabled = false;
    button.textContent = "Confirm booking";
  }
}

/* =========================================
   NAVBAR
========================================= */

function updateNavbar() {
  authNavigation.innerHTML = `
    <span class="nav-user">
      ${escapeHTML(currentUser.name)}
      <small>${escapeHTML(currentUser.role)}</small>
    </span>
    <button type="button" class="nav-button" onclick="logout()">Sign out</button>
  `;
}

function logout() {
  clearLogin();
  window.location.href = "login.php";
}

function clearLogin() {
  localStorage.removeItem("eventify_token");
  localStorage.removeItem("eventify_user");
}

/* =========================================
   LOGIN REDIRECT
========================================= */

function redirectToLogin() {
  const returnUrl = encodeURIComponent(window.location.href);
  window.location.href = "login.php?return=" + returnUrl;
}

/* =========================================
   ERROR
========================================= */

function showError(message) {
  bookingContainer.innerHTML = `
    <div class="state page-state">
      <h3>Booking isn't available</h3>
      <p>${escapeHTML(message)}</p>
      <a class="btn" href="events.php">Back to all events</a>
    </div>
  `;
}

/* =========================================
   ESCAPE
========================================= */

function escapeHTML(value) {
  if (value === null || value === undefined) {
    return "";
  }

  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

initialisePage();
</script>
</body>
</html>
