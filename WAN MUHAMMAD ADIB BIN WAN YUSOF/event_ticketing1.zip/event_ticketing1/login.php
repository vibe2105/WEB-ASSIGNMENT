<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in | Eventify</title>
    <link rel="stylesheet" href="css/eventify.css">
</head>
<body>
<div class="auth">
    <aside class="auth-aside">
        <a href="index.php" class="brand" aria-label="Eventify home"><span class="brand-mark" aria-hidden="true"></span>eventify</a>

        <div>
            <h1>Welcome back.</h1>
            <p>Sign in to see your tickets, or to manage events if you're an organiser or administrator.</p>
        </div>

        <ul>
            <li>Customers go straight to the event listing.</li>
            <li>Organisers and administrators go to the staff dashboard.</li>
            <li><a class="auth-back" href="events.php">Just browsing? See what's on without signing in.</a></li>
        </ul>
    </aside>

    <main class="auth-main">
        <div class="auth-form">
            <h2>Sign in</h2>
            <p>Use the email address you registered with.</p>

            <form id="loginForm" novalidate>
                <div class="field">
                    <label for="email">Email address</label>
                    <input type="email" id="email" class="login-input" placeholder="you@example.com" autocomplete="email">
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <div class="input-with-action">
                        <input type="password" id="password" class="login-input" placeholder="Your password" autocomplete="current-password">
                        <button type="button" class="input-action password-toggle" id="passwordToggle" aria-controls="password">Show</button>
                    </div>
                </div>

                <div class="login-message" id="loginMessage" role="status"></div>

                <button type="submit" class="btn btn-primary btn-lg btn-block login-submit" id="loginButton">Sign in</button>
            </form>

            <p class="auth-switch">New to Eventify? <a href="register.php">Create an account</a></p>
        </div>
    </main>
</div>

<script>
/* ==========================================
   ELEMENTS
========================================== */

const loginForm = document.getElementById("loginForm");
const loginButton = document.getElementById("loginButton");
const loginMessage = document.getElementById("loginMessage");
const passwordInput = document.getElementById("password");
const passwordToggle = document.getElementById("passwordToggle");

/* ==========================================
   REGISTER SUCCESS MESSAGE
========================================== */

const params = new URLSearchParams(window.location.search);

if (params.get("registered") === "1") {
  showMessage("Account created. Sign in to continue.", "success");
}

/* ==========================================
   PASSWORD TOGGLE
========================================== */

passwordToggle.addEventListener("click", function () {
  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    passwordToggle.textContent = "Hide";
  } else {
    passwordInput.type = "password";
    passwordToggle.textContent = "Show";
  }
});

/* ==========================================
   LOGIN
========================================== */

loginForm.addEventListener("submit", async function (event) {
  event.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = passwordInput.value;

  if (email === "" || password === "") {
    showMessage("Enter your email address and password.", "error");
    return;
  }

  loginButton.disabled = true;
  loginButton.textContent = "Signing in…";

  try {
    const response = await fetch("auth/login.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: email,
        password: password,
      }),
    });

    const result = await response.json();

    if (response.ok && result.status === "success") {
      /* STORE JWT */
      localStorage.setItem("eventify_token", result.token);

      /* STORE BASIC USER */
      localStorage.setItem("eventify_user", JSON.stringify(result.user));

      showMessage("Signed in. Taking you there now…", "success");
      loginButton.textContent = "Signed in";

      setTimeout(function () {
        /* RETURN TO THE PAGE THAT SENT THEM HERE (e.g. booking or reviews) */
        const returnTo = safeReturnUrl(params.get("return"));

        if (returnTo) {
          window.location.href = returnTo;
          return;
        }

        /* ROLE REDIRECTION */
        if (result.user.role === "Administrator" || result.user.role === "Organiser") {
          window.location.href = "dashboard.php";
        } else {
          window.location.href = "events.php";
        }
      }, 1000);
    } else {
      throw new Error(result.message || "Login failed");
    }
  } catch (error) {
    showMessage(error.message, "error");
    loginButton.disabled = false;
    loginButton.textContent = "Sign in";
  }
});

/* ==========================================
   SAFE RETURN ADDRESS
   Only pages on this same site are allowed, so a
   crafted link can't send users to another website.
========================================== */

function safeReturnUrl(value) {
  if (!value) {
    return null;
  }

  try {
    const url = new URL(value, window.location.href);

    if (url.origin !== window.location.origin || url.pathname.endsWith("/login.php")) {
      return null;
    }

    return url.pathname + url.search + url.hash;
  } catch (error) {
    return null;
  }
}

/* ==========================================
   MESSAGE
========================================== */

function showMessage(message, type) {
  loginMessage.textContent = message;
  loginMessage.className = "login-message " + type;
}
</script>
</body>
</html>
