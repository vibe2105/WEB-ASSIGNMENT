<?php

/* ==========================================
   POST api/send-receipt.php
   Body: { "booking_id": 12 }
   Header: Authorization: Bearer <jwt>

   Sends the receipt for a CONFIRMED booking
   to the email address of the account that
   owns the booking.
========================================== */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/mailer.php';


function receiptResponse($code, $status, $message)
{
    http_response_code($code);

    echo json_encode([
        'status' => $status,
        'message' => $message
    ]);

    exit;
}


function receiptBearerToken()
{
    $header = $_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? '';

    if ($header === '' && function_exists('getallheaders')) {

        foreach (getallheaders() as $name => $value) {

            if (strcasecmp($name, 'Authorization') === 0) {
                $header = $value;
            }
        }
    }

    if (preg_match('/^Bearer\s+(\S+)$/i', $header, $match)) {
        return $match[1];
    }

    return null;
}


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    receiptResponse(405, 'error', 'Method not allowed.');
}


/* ---------- AUTH ---------- */

$token = receiptBearerToken();

if (!$token) {
    receiptResponse(401, 'error', 'Please sign in.');
}

try {
    $payload = verifyJWT($token);
} catch (Throwable $error) {
    error_log('Eventify JWT error: ' . $error->getMessage());
    receiptResponse(500, 'error', 'Server configuration error.');
}

if (!$payload) {
    receiptResponse(401, 'error', 'Your session has expired. Please sign in again.');
}


/* ---------- INPUT ---------- */

$input = json_decode(file_get_contents('php://input'), true);

$bookingId = filter_var(
    $input['booking_id'] ?? null,
    FILTER_VALIDATE_INT,
    ['options' => ['min_range' => 1]]
);

if ($bookingId === false) {
    receiptResponse(400, 'error', 'A valid booking is required.');
}


/* ---------- LOAD BOOKING ---------- */

try {

    $db = (new Database())->getConnection();

    $statement = $db->prepare(
        'SELECT b.booking_id, b.user_id, b.quantity, b.total_amount,
                b.booking_status, b.booking_date,
                e.event_name, e.event_date, e.start_time, e.end_time, e.ticket_price,
                v.venue_name, v.location,
                u.name AS customer_name, u.email AS customer_email
         FROM bookings b
         JOIN events e ON e.event_id = b.event_id
         JOIN venues v ON v.venue_id = e.venue_id
         JOIN users u ON u.user_id = b.user_id
         WHERE b.booking_id = :booking_id
         LIMIT 1'
    );

    $statement->execute([':booking_id' => $bookingId]);

    $booking = $statement->fetch(PDO::FETCH_ASSOC);

} catch (Throwable $error) {

    error_log('Eventify receipt query error: ' . $error->getMessage());

    receiptResponse(500, 'error', 'Unable to load the booking.');
}


/* Same message for "missing" and "not yours" so ids cannot be probed. */
if (!$booking || (int) $booking['user_id'] !== (int) $payload['user_id']) {
    receiptResponse(404, 'error', 'Booking not found.');
}

if ($booking['booking_status'] !== 'Confirmed') {
    receiptResponse(409, 'error', 'Receipts are only available for confirmed bookings.');
}


/* ---------- SEND ---------- */

[$sent, $message] = eventifySendReceipt($booking);

if (!$sent) {
    receiptResponse(502, 'error', $message);
}

receiptResponse(200, 'success', 'Receipt sent to ' . preg_replace('/(?<=.).(?=[^@]*@)/', '*', $booking['customer_email']));
