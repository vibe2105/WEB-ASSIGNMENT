<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | Eventify</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,600;9..144,700;9..144,800&display=swap" rel="stylesheet">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c3f41;
            --ev-teal-soft: #287d78;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #e9553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #183536;
            --ev-muted: #667b79;
            --ev-line: #dce8e3;
            --ev-display: "Fraunces", Georgia, serif;
            --ev-body: "Figtree", Arial, sans-serif;
        }

        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body {
            margin: 0;
            font-family: var(--ev-body);
            color: var(--ev-ink);
            background: var(--ev-paper);
            -webkit-font-smoothing: antialiased;
        }
        a { color: inherit; }
        button, input { font: inherit; }
        .container { width: min(1160px, calc(100% - 48px)); margin-inline: auto; }

        /* Navbar follows Event Details */
        .navbar {
            position: relative;
            z-index: 5;
            background: rgba(255,255,255,.94);
            border-bottom: 1px solid var(--ev-line);
        }
        .nav-container {
            min-height: 82px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 28px;
        }
        .brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: var(--ev-deep);
            font-family: var(--ev-display);
            font-size: 27px;
            font-weight: 800;
            letter-spacing: -.7px;
            white-space: nowrap;
        }
        .brand-icon {
            width: 39px; height: 39px;
            display: grid; place-items: center;
            border-radius: 11px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-family: var(--ev-display);
            font-size: 23px;
        }
        .brand em { color: var(--ev-coral-dark); font-style: normal; }
        .nav-links { display: flex; align-items: center; gap: 30px; }
        .nav-links a {
            color: #58706d;
            font-size: 14px;
            font-weight: 700;
            text-decoration: none;
            transition: color .2s;
        }
        .nav-links a:hover, .nav-links a.active { color: var(--ev-teal-soft); }
        .sign-in {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 43px;
            padding: 0 20px;
            border: 1px solid var(--ev-teal);
            border-radius: 999px;
            color: var(--ev-teal);
            text-decoration: none;
            font-size: 14px;
            font-weight: 800;
            transition: background .2s, color .2s;
        }
        .sign-in:hover { background: var(--ev-teal); color: white; }

        /* New registration layout */
        .register-page {
            position: relative;
            overflow: hidden;
            padding: 64px 0 76px;
            /* Match the deep teal hero background used on Event Details */
            background:
                radial-gradient(circle at 12% 10%, rgba(40,125,120,.38), transparent 34%),
                radial-gradient(circle at 88% 92%, rgba(255,106,77,.10), transparent 28%),
                linear-gradient(135deg, #0d4b4b 0%, #072b2d 72%);
        }
        .register-layout {
            position: relative;
            z-index: 1;
            display: grid;
            grid-template-columns: minmax(0, 1.08fr) minmax(390px, .82fr);
            align-items: center;
            gap: clamp(42px, 7vw, 100px);
        }
        .intro { max-width: 600px; }
        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 9px 14px;
            border: 1px solid #cfe9df;
            border-radius: 999px;
            background: #e7f6ef;
            color: var(--ev-teal);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }
        .eyebrow-mark { color: var(--ev-coral-dark); font-size: 15px; }
        .intro h1 {
            margin: 24px 0 18px;
            color: #ffffff;
            font-family: var(--ev-display);
            font-size: clamp(43px, 5vw, 67px);
            font-weight: 800;
            line-height: 1.04;
            letter-spacing: -2px;
        }
        .intro h1 span { color: var(--ev-mint); font-style: italic; }
        .intro-copy {
            max-width: 490px;
            margin: 0;
            color: #c1ded9;
            font-size: 17px;
            line-height: 1.8;
        }
        .benefits {
            display: grid;
            gap: 17px;
            margin-top: 34px;
        }
        .benefit {
            display: flex;
            align-items: center;
            gap: 14px;
            color: #e0f1ed;
            font-size: 14px;
            font-weight: 600;
        }
        .benefit-icon {
            flex: 0 0 40px;
            width: 40px; height: 40px;
            display: grid;
            place-items: center;
            border-radius: 13px;
            background: rgba(255,255,255,.08);
            border: 1px solid rgba(168,235,211,.22);
            color: var(--ev-mint);
            font-size: 17px;
            box-shadow: 0 5px 14px rgba(7,43,45,.04);
        }
        .intro-note {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-top: 38px;
            padding-top: 20px;
            border-top: 1px solid rgba(168,235,211,.24);
            color: #b4d2cd;
            font-size: 12px;
            line-height: 1.6;
        }
        .intro-note strong { color: var(--ev-mint); }

        .register-card {
            padding: clamp(28px, 3.4vw, 42px);
            border: 1px solid rgba(220,232,227,.95);
            border-radius: 25px;
            background: #fff;
            box-shadow: 0 22px 65px rgba(7,43,45,.10);
        }
        .card-topline {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 20px;
            color: var(--ev-teal-soft);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1.6px;
            text-transform: uppercase;
        }
        .card-topline::before {
            content: "";
            width: 22px; height: 3px;
            border-radius: 99px;
            background: var(--ev-coral);
        }
        .card-header h2 {
            margin: 0;
            color: var(--ev-deep);
            font-family: var(--ev-display);
            font-size: clamp(28px, 3vw, 35px);
            line-height: 1.15;
            letter-spacing: -.7px;
        }
        .card-header p {
            margin: 10px 0 27px;
            color: var(--ev-muted);
            font-size: 14px;
            line-height: 1.65;
        }
        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #294846;
            font-size: 13px;
            font-weight: 800;
        }
        .input-wrapper { position: relative; }
        .input-icon {
            position: absolute;
            top: 50%; left: 15px;
            transform: translateY(-50%);
            color: #7b9993;
            font-size: 16px;
            pointer-events: none;
        }
        .form-input {
            display: block;
            width: 100%;
            height: 51px;
            padding: 0 50px 0 43px;
            border: 1px solid #d9e6e1;
            border-radius: 12px;
            outline: none;
            background: #fbfdfc;
            color: var(--ev-deep);
            font-size: 14px;
            transition: border-color .2s, box-shadow .2s, background .2s;
        }
        .form-input::placeholder { color: #9aadaa; }
        .form-input:focus {
            border-color: var(--ev-teal-soft);
            background: #fff;
            box-shadow: 0 0 0 4px rgba(40,125,120,.12);
        }
        .password-toggle {
            position: absolute;
            top: 50%; right: 13px;
            transform: translateY(-50%);
            border: 0;
            background: transparent;
            color: var(--ev-teal-soft);
            cursor: pointer;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: .6px;
        }
        .password-hint { margin-top: 7px; color: #829692; font-size: 11px; }
        .terms-row {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin: 23px 0;
        }
        .terms-row input {
            flex: 0 0 auto;
            width: 16px; height: 16px;
            margin: 2px 0 0;
            accent-color: var(--ev-teal-soft);
        }
        .terms-row label {
            color: var(--ev-muted);
            font-size: 12px;
            line-height: 1.6;
            cursor: pointer;
        }
        .register-submit {
            width: 100%;
            min-height: 53px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 12px 18px;
            border: 0;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            cursor: pointer;
            font-size: 14px;
            font-weight: 800;
            box-shadow: 0 10px 22px rgba(255,106,77,.20);
            transition: transform .2s, background .2s, box-shadow .2s;
        }
        .register-submit:hover {
            transform: translateY(-2px);
            background: #ff795f;
            box-shadow: 0 14px 27px rgba(255,106,77,.27);
        }
        .register-submit:disabled { opacity: .65; cursor: not-allowed; transform: none; }
        .register-message {
            display: none;
            margin-top: 15px;
            padding: 12px 14px;
            border-radius: 11px;
            font-size: 13px;
            line-height: 1.55;
        }
        .register-message.error {
            display: block;
            color: #a83232;
            background: #fff1ef;
            border: 1px solid #ffd7d0;
        }
        .register-message.success {
            display: block;
            color: #17664f;
            background: #eaf8f1;
            border: 1px solid #ccebdd;
        }
        .login-redirect {
            margin-top: 23px;
            color: var(--ev-muted);
            text-align: center;
            font-size: 13px;
        }
        .login-redirect a {
            margin-left: 4px;
            color: var(--ev-teal-soft);
            font-weight: 800;
            text-decoration: none;
        }
        .login-redirect a:hover { color: var(--ev-coral-dark); text-decoration: underline; }

        .ev-footer {
            color: #b9d3cf;
            background: linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .ev-footer-top {
            display: grid;
            grid-template-columns: minmax(0, 1.6fr) repeat(2, minmax(0, 1fr));
            gap: 48px;
            padding: 45px 0 35px;
        }
        .ev-footer-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            font-family: var(--ev-display);
            font-size: 25px;
            font-weight: 800;
            text-decoration: none;
        }
        .ev-footer-mark {
            width: 36px; height: 36px;
            display: grid; place-items: center;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-size: 19px;
        }
        .ev-footer-brand em { color: var(--ev-coral); font-style: normal; }
        .ev-footer-about { max-width: 330px; margin: 13px 0 0; color: #9fc2bd; font-size: 13px; line-height: 1.7; }
        .ev-footer h3 { margin: 4px 0 15px; color: white; font-family: var(--ev-display); font-size: 18px; }
        .ev-footer ul { display: grid; gap: 10px; margin: 0; padding: 0; list-style: none; }
        .ev-footer li a { color: #b9d3cf; font-size: 13px; text-decoration: none; }
        .ev-footer li a:hover { color: var(--ev-coral); }
        .ev-footer-bottom {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            padding: 18px 0 22px;
            border-top: 1px solid rgba(185,211,207,.18);
            color: #8fb2ad;
            font-size: 11px;
        }

        @media (max-width: 900px) {
            .register-layout { grid-template-columns: 1fr; max-width: 620px; margin-inline: auto; gap: 38px; }
            .intro { text-align: center; margin-inline: auto; }
            .intro-copy { margin-inline: auto; }
            .benefits { max-width: 390px; margin-inline: auto; margin-top: 27px; text-align: left; }
            .intro-note { text-align: left; }
            .register-page { padding: 45px 0 60px; }
        }
        @media (max-width: 640px) {
            .container { width: min(100% - 30px, 560px); }
            .nav-container { min-height: 72px; gap: 12px; }
            .brand { font-size: 23px; }
            .brand-icon { width: 35px; height: 35px; }
            .nav-links { display: none; }
            .sign-in { min-height: 39px; padding: 0 14px; font-size: 12px; }
            .intro h1 { font-size: clamp(39px, 11vw, 52px); letter-spacing: -1.5px; }
            .intro-copy { font-size: 15px; }
            .register-card { padding: 26px 21px; border-radius: 20px; }
            .ev-footer-top { grid-template-columns: 1fr 1fr; gap: 30px 20px; padding: 35px 0 28px; }
            .ev-footer-top > div:first-child { grid-column: 1 / -1; }
            .ev-footer-bottom { flex-direction: column; gap: 7px; }
        }
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { scroll-behavior: auto !important; transition: none !important; }
        }
    </style>
</head>
<body>
<header class="navbar">
    <div class="container nav-container">
        <a href="index.php" class="brand" aria-label="Eventify home">
            <span class="brand-icon">E</span>
            <span>Event<em>ify</em></span>
        </a>
        <nav class="nav-links" aria-label="Main navigation">
            <a href="index.php">Home</a>
            <a href="events.php">Events</a>
            <a href="bookings.php">My Bookings</a>
        </nav>
        <a href="login.php" class="sign-in">Sign In</a>
    </div>
</header>

<main class="register-page">
    <div class="container register-layout">
        <section class="intro">
            <div class="eyebrow"><span class="eyebrow-mark">✦</span> Your Eventify journey starts here</div>
            <h1>Make room for<br>your next <span>memory.</span></h1>
            <p class="intro-copy">
                Create an account to discover exciting events, reserve your tickets
                and keep every booking organised in one place.
            </p>

            <div class="benefits">
                <div class="benefit">
                    <span class="benefit-icon" aria-hidden="true">⌕</span>
                    <span>Explore events and experiences you will love</span>
                </div>
                <div class="benefit">
                    <span class="benefit-icon" aria-hidden="true">✓</span>
                    <span>Book tickets through a simple, convenient process</span>
                </div>
                <div class="benefit">
                    <span class="benefit-icon" aria-hidden="true">▤</span>
                    <span>Keep track of your bookings from one account</span>
                </div>
            </div>

            <div class="intro-note">
                <span aria-hidden="true">✦</span>
                <span><strong>One account, more experiences.</strong><br>Sign up today and make planning your next event easier.</span>
            </div>
        </section>

        <section class="register-card" aria-labelledby="registerTitle">
            <div class="card-topline">Create your account</div>
            <div class="card-header">
                <h2 id="registerTitle">Welcome to Eventify</h2>
                <p>Fill in your details below to get started.</p>
            </div>

            <form id="registerForm" novalidate>
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <div class="input-wrapper">
                        <span class="input-icon" aria-hidden="true">♙</span>
                        <input type="text" id="name" class="form-input" placeholder="Enter your full name" autocomplete="name" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-wrapper">
                        <span class="input-icon" aria-hidden="true">@</span>
                        <input type="email" id="email" class="form-input" placeholder="you@example.com" autocomplete="email" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-wrapper">
                        <span class="input-icon" aria-hidden="true">♢</span>
                        <input type="password" id="password" class="form-input" placeholder="Create a password" autocomplete="new-password" required>
                        <button type="button" class="password-toggle" data-target="password" aria-label="Show password">SHOW</button>
                    </div>
                    <div class="password-hint">Use at least 6 characters.</div>
                </div>

                <div class="form-group">
                    <label for="confirmPassword">Confirm Password</label>
                    <div class="input-wrapper">
                        <span class="input-icon" aria-hidden="true">♢</span>
                        <input type="password" id="confirmPassword" class="form-input" placeholder="Enter your password again" autocomplete="new-password" required>
                        <button type="button" class="password-toggle" data-target="confirmPassword" aria-label="Show confirm password">SHOW</button>
                    </div>
                </div>

                <div class="terms-row">
                    <input type="checkbox" id="terms" required>
                    <label for="terms">I confirm that the information provided is correct and agree to create an Eventify customer account.</label>
                </div>

                <button type="submit" class="register-submit" id="registerButton">Create My Account <span aria-hidden="true">→</span></button>
                <div class="register-message" id="registerMessage" role="status" aria-live="polite"></div>
            </form>

            <div class="login-redirect">Already have an account? <a href="login.php">Sign in</a></div>
        </section>
    </div>
</main>

<footer class="ev-footer">
    <div class="container">
        <div class="ev-footer-top">
            <div>
                <a href="index.php" class="ev-footer-brand">
                    <span class="ev-footer-mark">E</span>
                    <span>Event<em>ify</em></span>
                </a>
                <p class="ev-footer-about">Find events, book tickets and keep every reservation in one place.</p>
            </div>
            <div>
                <h3>Explore</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="events.php">All events</a></li>
                    <li><a href="index.php#how-it-works">How it works</a></li>
                </ul>
            </div>
            <div>
                <h3>Your account</h3>
                <ul>
                    <li><a href="login.php">Sign in</a></li>
                    <li><a href="register.php">Create account</a></li>
                    <li><a href="bookings.php">My bookings</a></li>
                </ul>
            </div>
        </div>
        <div class="ev-footer-bottom">
            <span>© 2026 Eventify</span>
            <span>Event Ticketing &amp; Venue Booking System</span>
        </div>
    </div>
</footer>

<script>
const registerForm = document.getElementById("registerForm");
const registerButton = document.getElementById("registerButton");
const registerMessage = document.getElementById("registerMessage");

document.querySelectorAll(".password-toggle").forEach(button => {
    button.addEventListener("click", function () {
        const target = document.getElementById(this.dataset.target);
        const showPassword = target.type === "password";
        target.type = showPassword ? "text" : "password";
        this.textContent = showPassword ? "HIDE" : "SHOW";
        this.setAttribute("aria-label", (showPassword ? "Hide " : "Show ") + (this.dataset.target === "password" ? "password" : "confirm password"));
    });
});

registerForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const terms = document.getElementById("terms").checked;

    registerMessage.className = "register-message";
    registerMessage.textContent = "";

    if (!name || !email || !password || !confirmPassword) {
        showMessage("Please complete all fields.", "error");
        return;
    }
    if (name.length < 3) {
        showMessage("Please enter your full name.", "error");
        return;
    }
    if (password.length < 6) {
        showMessage("Password must contain at least 6 characters.", "error");
        return;
    }
    if (password !== confirmPassword) {
        showMessage("The passwords do not match.", "error");
        return;
    }
    if (!terms) {
        showMessage("Please confirm the account information before registering.", "error");
        return;
    }

    registerButton.disabled = true;
    registerButton.textContent = "Creating Account...";

    try {
        const response = await fetch("auth/register.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                name: name,
                email: email,
                password: password,
                confirm_password: confirmPassword
            })
        });

        let result;
        try {
            result = await response.json();
        } catch (_) {
            throw new Error("The server returned an invalid response. Please check the registration endpoint.");
        }

        if (response.ok && result.status === "success") {
            showMessage("✓ Account created successfully. You can now sign in.", "success");
            registerForm.reset();
            registerButton.textContent = "Account Created ✓";
            setTimeout(() => {
                window.location.href = "login.php?registered=1";
            }, 1800);
        } else {
            throw new Error(result.message || "Unable to create account.");
        }
    } catch (error) {
        showMessage(error.message || "Unable to connect to the server.", "error");
        registerButton.disabled = false;
        registerButton.textContent = "Create My Account →";
    }
});

function showMessage(message, type) {
    registerMessage.textContent = message;
    registerMessage.className = "register-message " + type;
}
</script>
<script src="js/auth.js"></script>
</body>
</html>