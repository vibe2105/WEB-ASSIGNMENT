<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management Dashboard | Eventify</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body.dash {
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-family: var(--ev-body);
        }

        /* ---------- Top navbar overrides ---------- */
        .dash .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .dash .navbar .brand,
        .dash .navbar .brand span { color: #fff; }
        .dash .navbar .brand-purple { color: var(--ev-coral); }
        .dash .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .dash .navbar .nav-links a { color: #b9d3cf; }
        .dash .navbar .nav-links a:hover,
        .dash .navbar .nav-links a.active { color: #fff; }

        .top-user { font-size: 14px; font-weight: 700; color: #b9d3cf; }
        .top-logout {
            padding: 10px 18px;
            border: none;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 14px var(--ev-body);
            cursor: pointer;
            transition: background .2s;
        }
        .top-logout:hover { background: var(--ev-coral-dark); }

        /* ---------- Layout ---------- */
        .dashboard-layout {
            display: grid;
            grid-template-columns: 250px minmax(0, 1fr);
            min-height: calc(100vh - 78px);
        }

        /* ---------- Sidebar ---------- */
        .dashboard-sidebar {
            padding: 28px 18px;
            color: #fff;
            background: linear-gradient(180deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }

        .sidebar-user {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 2px 12px;
            padding: 14px;
            margin-bottom: 26px;
            border-radius: 14px;
            background: rgba(255, 255, 255, .07);
            border: 1px solid rgba(255, 255, 255, .1);
        }
        .sidebar-avatar {
            grid-row: span 2;
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            border-radius: 50%;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: 20px;
        }
        .sidebar-user small { display: block; width: calc(100% - 56px); color: #9fc2bd; font-size: 13px; }
        .sidebar-user strong { display: block; width: calc(100% - 56px); font-size: 15px; margin-top: -2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .sidebar-section-label {
            margin: 24px 12px 8px;
            color: #7fa8a3;
            font-size: 13px;
            font-weight: 700;
        }

        .sidebar-menu { display: grid; gap: 4px; }
        .sidebar-menu a {
            position: relative;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 14px;
            border-radius: 10px;
            color: #b9d3cf;
            font-size: 15px;
            font-weight: 500;
            text-decoration: none;
            transition: background .15s, color .15s;
        }
        .sidebar-menu a:hover { background: rgba(255, 255, 255, .07); color: #fff; }
        .sidebar-menu a.active { background: rgba(255, 255, 255, .1); color: #fff; font-weight: 700; }
        .sidebar-menu a.active::before {
            content: "";
            position: absolute;
            left: -18px;
            top: 10px;
            bottom: 10px;
            width: 4px;
            border-radius: 0 4px 4px 0;
            background: var(--ev-coral);
        }
        .sidebar-menu-icon { width: 22px; text-align: center; color: var(--ev-mint); font-weight: 700; }

        .sidebar-divider { height: 1px; margin: 22px 0; background: rgba(255, 255, 255, .1); }

        .logout-sidebar {
            width: 100%;
            padding: 12px;
            border: 1.5px solid rgba(255, 255, 255, .22);
            border-radius: 10px;
            background: transparent;
            color: #fff;
            font: 700 15px var(--ev-body);
            cursor: pointer;
            transition: background .2s, color .2s, border-color .2s;
        }
        .logout-sidebar:hover { background: var(--ev-coral); border-color: var(--ev-coral); color: var(--ev-deep); }

        .sidebar-menu a:focus-visible,
        .logout-sidebar:focus-visible,
        .top-logout:focus-visible,
        .management-card:focus-visible,
        .panel-header a:focus-visible {
            outline: 3px solid var(--ev-mint);
            outline-offset: 2px;
        }

        /* ---------- Main ---------- */
        .dashboard-main { padding: 40px 44px 56px; min-width: 0; }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 24px;
            margin-bottom: 30px;
        }
        .dashboard-header h1 {
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: 42px;
            letter-spacing: -1px;
            color: var(--ev-ink);
        }
        .dashboard-header p { margin-top: 6px; color: var(--ev-muted); font-size: 16px; }

        .dashboard-user-chip {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 18px 8px 8px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 999px;
        }
        .chip-avatar {
            width: 40px;
            height: 40px;
            display: grid;
            place-items: center;
            border-radius: 50%;
            background: var(--ev-teal);
            color: #fff;
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: 18px;
        }
        .dashboard-user-chip small { display: block; color: var(--ev-muted); font-size: 12px; }
        .dashboard-user-chip strong { display: block; color: var(--ev-ink); font-size: 14px; }

        /* ---------- Stats strip ---------- */
        .dashboard-stats {
            position: relative;
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            overflow: hidden;
            margin-bottom: 36px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
        }
        .dashboard-stat-card {
            position: relative;
            padding: 26px 28px 24px;
        }
        .dashboard-stat-card + .dashboard-stat-card { border-left: 2px dashed var(--ev-line); }
        .dashboard-stat-card + .dashboard-stat-card::before,
        .dashboard-stat-card + .dashboard-stat-card::after {
            content: "";
            position: absolute;
            left: -12px;
            width: 22px;
            height: 22px;
            border-radius: 50%;
            background: var(--ev-paper);
            border: 1px solid var(--ev-line);
        }
        .dashboard-stat-card + .dashboard-stat-card::before { top: -12px; }
        .dashboard-stat-card + .dashboard-stat-card::after { bottom: -12px; }

        .dashboard-stat-card small { color: var(--ev-muted); font-size: 14px; font-weight: 700; }
        .dashboard-stat-card h2 {
            margin-top: 6px;
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: 40px;
            letter-spacing: -1px;
            color: var(--ev-ink);
        }
        .dashboard-stat-card:last-child h2 { color: var(--ev-coral-dark); }
        .dashboard-stat-card p { margin-top: 4px; color: var(--ev-muted); font-size: 14px; }

        /* ---------- Management ---------- */
        .management-heading { margin: 0 0 16px; }
        .management-heading h2,
        .dash-section-title {
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: 26px;
            letter-spacing: -.4px;
            color: var(--ev-ink);
        }
        .management-heading p { margin-top: 4px; color: var(--ev-muted); font-size: 15px; }

        .management-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 40px;
        }
        .management-grid.organiser-view { grid-template-columns: repeat(2, minmax(0, 1fr)); }

        .management-card {
            display: grid;
            grid-template-columns: auto 1fr auto;
            align-items: center;
            gap: 16px;
            padding: 20px 22px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 18px;
            color: var(--ev-ink);
            text-decoration: none;
            transition: border-color .2s, box-shadow .2s;
        }
        .management-card:hover {
            border-color: var(--ev-teal-soft);
            box-shadow: 0 12px 28px rgba(7, 43, 45, .1);
        }
        .management-card > div:first-child { display: contents; }

        .management-icon {
            width: 50px;
            height: 50px;
            display: grid;
            place-items: center;
            border-radius: 14px;
            background: var(--ev-teal);
            color: var(--ev-mint);
            font-size: 20px;
            font-weight: 700;
        }
        .management-card h3 {
            margin: 0;
            font-family: var(--ev-display);
            font-size: 19px;
            font-weight: 800;
        }
        .management-card p { margin-top: 4px; color: var(--ev-muted); font-size: 14px; line-height: 1.5; }
        .management-card .text-block { min-width: 0; }
        .management-link { display: none; }
        .management-arrow {
            width: 36px;
            height: 36px;
            display: grid;
            place-items: center;
            border-radius: 50%;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-weight: 800;
            transition: transform .2s;
        }
        .management-card:hover .management-arrow { transform: translateX(3px); }

        /* ---------- Panels ---------- */
        .dashboard-content-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 22px; }

        .dashboard-panel {
            overflow: hidden;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
        }
        .panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            padding: 22px 24px;
            border-bottom: 2px dashed var(--ev-line);
        }
        .panel-header h2 { font-family: var(--ev-display); font-size: 22px; font-weight: 800; color: var(--ev-ink); }
        .panel-header span { display: block; margin-top: 3px; color: var(--ev-muted); font-size: 14px; }
        .panel-header a {
            color: var(--ev-teal-soft);
            font-size: 14px;
            font-weight: 700;
            text-decoration: none;
            white-space: nowrap;
        }
        .panel-header a:hover { text-decoration: underline; }

        .dashboard-list { display: grid; }
        .dashboard-row {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 15px 24px;
            border-bottom: 1px solid #e8f0ee;
        }
        .dashboard-row:last-child { border-bottom: none; }
        .dashboard-row .status-pill { margin-left: auto; }

        .row-date, .row-qty {
            flex: none;
            width: 52px;
            height: 52px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            line-height: 1;
        }
        .row-date { background: var(--ev-teal); color: #fff; }
        .row-date b { font-family: var(--ev-display); font-size: 21px; font-weight: 800; }
        .row-date small { margin-top: 3px; font-size: 12px; font-weight: 700; text-transform: uppercase; }
        .row-qty { background: #e4f6ef; color: var(--ev-teal-soft); font-family: var(--ev-display); font-size: 18px; font-weight: 800; }

        .row-content { min-width: 0; }
        .row-content strong {
            display: block;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            font-size: 16px;
            font-weight: 700;
            color: var(--ev-ink);
        }
        .row-content span { display: block; margin-top: 4px; color: var(--ev-muted); font-size: 14px; }

        .status-pill {
            flex-shrink: 0;
            padding: 5px 11px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 700;
        }
        .status-green { color: #0f6446; background: #e4f6ef; }
        .status-red { color: #a1301d; background: #fff1ef; }
        .status-gray { color: #54666a; background: #edf1f0; }

        .empty-data { padding: 46px 24px; text-align: center; color: var(--ev-muted); font-size: 15px; line-height: 1.6; }
        .empty-link { color: var(--ev-teal-soft); font-weight: 700; text-decoration: none; }
        .empty-link:hover { text-decoration: underline; }

        /* ---------- Access denied ---------- */
        .access-denied {
            grid-column: 1 / -1;
            min-height: calc(100vh - 80px);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 30px;
            text-align: center;
        }
        .access-denied-icon {
            width: 72px;
            height: 72px;
            display: grid;
            place-items: center;
            margin-bottom: 20px;
            border-radius: 50%;
            background: #fff1ef;
            color: #a1301d;
            font-family: var(--ev-display);
            font-size: 32px;
            font-weight: 800;
        }
        .access-denied h1 { font-family: var(--ev-display); font-weight: 800; font-size: 34px; color: var(--ev-ink); }
        .access-denied p { max-width: 460px; margin-top: 10px; color: var(--ev-muted); line-height: 1.65; font-size: 16px; }
        .access-denied a {
            margin-top: 22px;
            padding: 13px 22px;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-weight: 700;
            text-decoration: none;
        }
        .access-denied a:hover { background: var(--ev-coral-dark); }

        /* ---------- Responsive ---------- */
        @media (max-width: 1150px) {
            .dashboard-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .dashboard-stat-card:nth-child(3) { border-left: 0; }
            .dashboard-stat-card:nth-child(n+3) { border-top: 2px dashed var(--ev-line); }
            .dashboard-stat-card:nth-child(3)::before,
            .dashboard-stat-card:nth-child(3)::after { display: none; }
            .management-grid,
            .management-grid.organiser-view { grid-template-columns: 1fr; }
        }
        @media (max-width: 900px) {
            .dashboard-layout { grid-template-columns: 1fr; }
            .dashboard-sidebar { display: none; }
            .dashboard-content-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 650px) {
            .dashboard-main { padding: 26px 20px 44px; }
            .dashboard-header { flex-direction: column; align-items: flex-start; }
            .dashboard-header h1 { font-size: 34px; }
            .dashboard-stats { grid-template-columns: 1fr; }
            .dashboard-stat-card + .dashboard-stat-card { border-left: 0; border-top: 2px dashed var(--ev-line); }
            .dashboard-stat-card + .dashboard-stat-card::before,
            .dashboard-stat-card + .dashboard-stat-card::after { display: none; }
        }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
    </style>
</head>

<body class="dash">

<!-- TOP NAVIGATION -->
<header class="navbar">
    <div class="container nav-container">

        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>

        <nav class="nav-links" id="dashboardTopLinks">
            <a href="dashboard.php" class="active">Dashboard</a>
            <a href="manage-events.php">Events</a>
            <a href="manage-venues.php" style="display:none;">Venues</a>
            <a href="manage-bookings.php">Bookings</a>
            <a href="manage-users.php" id="adminUsersTop" style="display:none;">Users</a>
            <a href="events.php">Website</a>
        </nav>

        <div class="nav-actions" id="topNavigation"></div>

    </div>
</header>

<!-- DASHBOARD -->
<div class="dashboard-layout" id="dashboardRoot">

    <!-- SIDEBAR -->
    <aside class="dashboard-sidebar">

        <div class="sidebar-user" id="sidebarUser">
            <div class="sidebar-avatar">E</div>
            <small>Loading</small>
            <strong>Please wait...</strong>
        </div>

        <div class="sidebar-section-label">Management</div>

        <nav class="sidebar-menu">
            <a href="dashboard.php" class="active"><span class="sidebar-menu-icon">◈</span>Dashboard</a>
            <a href="manage-events.php"><span class="sidebar-menu-icon">◇</span>Manage Events</a>
            <a href="manage-venues.php" style="display:none;"><span class="sidebar-menu-icon">⌖</span>Manage Venues</a>
            <a href="manage-bookings.php"><span class="sidebar-menu-icon">▤</span>Manage Bookings</a>
            <a href="manage-users.php" id="adminUsersSidebar" style="display:none;"><span class="sidebar-menu-icon">♙</span>Manage Users</a>
        </nav>

        <div class="sidebar-section-label">Website</div>

        <nav class="sidebar-menu">
            <a href="events.php"><span class="sidebar-menu-icon">→</span>Browse Events</a>
            <a href="index.php"><span class="sidebar-menu-icon">⌂</span>Homepage</a>
        </nav>

        <div class="sidebar-divider"></div>

        <button type="button" class="logout-sidebar" onclick="logout()">Logout</button>

    </aside>

    <!-- MAIN -->
    <main class="dashboard-main">

        <!-- HEADER -->
        <section class="dashboard-header">
            <div>
                <h1>Dashboard</h1>
                <p id="dashboardWelcome">Loading your account...</p>
            </div>

            <div class="dashboard-user-chip" id="dashboardUser">
                <div class="chip-avatar">E</div>
            </div>
        </section>

        <!-- STATISTICS -->
        <section class="dashboard-stats">

            <article class="dashboard-stat-card">
                <small>Events</small>
                <h2 id="totalEvents">—</h2>
                <p id="eventsDescription">Events managed</p>
            </article>

            <article class="dashboard-stat-card">
                <small>Bookings</small>
                <h2 id="totalBookings">—</h2>
                <p>Reservations received</p>
            </article>

            <article class="dashboard-stat-card">
                <small>Confirmed</small>
                <h2 id="confirmedBookings">—</h2>
                <p>Active reservations</p>
            </article>

            <article class="dashboard-stat-card">
                <small>Booking value</small>
                <h2 id="bookingValue">—</h2>
                <p>Confirmed reservations</p>
            </article>

        </section>

        <!-- MANAGEMENT -->
        <section class="management-heading">
            <h2>Management centre</h2>
            <p>Jump straight to the tool you need.</p>
        </section>

        <section class="management-grid">

            <a href="manage-events.php" class="management-card">
                <div><div class="management-icon">◇</div></div>
                <div class="text-block">
                    <h3>Manage Events</h3>
                    <p>Create events and edit prices, dates, status and capacity.</p>
                </div>
                <span class="management-arrow">→</span>
            </a>

            <a href="manage-venues.php" class="management-card" style="display:none;">
                <div><div class="management-icon">⌖</div></div>
                <div class="text-block">
                    <h3>Manage Venues</h3>
                    <p>Maintain venue records, locations, capacities and availability.</p>
                </div>
                <span class="management-arrow">→</span>
            </a>

            <a href="manage-bookings.php" class="management-card">
                <div><div class="management-icon">▤</div></div>
                <div class="text-block">
                    <h3>Manage Bookings</h3>
                    <p>Review reservations and update booking status.</p>
                </div>
                <span class="management-arrow">→</span>
            </a>

        </section>

        <!-- RECENT DATA -->
        <section class="dashboard-content-grid">

            <!-- EVENTS -->
            <article class="dashboard-panel">
                <div class="panel-header">
                    <div>
                        <h2>Upcoming events</h2>
                        <span id="eventPanelSubtitle">Your latest events</span>
                    </div>
                    <a href="manage-events.php">View all</a>
                </div>

                <div class="dashboard-list" id="eventList">
                    <div class="empty-data">Loading events...</div>
                </div>
            </article>

            <!-- BOOKINGS -->
            <article class="dashboard-panel">
                <div class="panel-header">
                    <div>
                        <h2>Recent bookings</h2>
                        <span>Latest customer reservations</span>
                    </div>
                    <a href="manage-bookings.php">View all</a>
                </div>

                <div class="dashboard-list" id="bookingList">
                    <div class="empty-data">Loading bookings...</div>
                </div>
            </article>

        </section>

    </main>

</div>


<script>

/* ==========================================
   AUTH
========================================== */

const token = localStorage.getItem("eventify_token");

let currentUser = null;
let allEvents = [];
let dashboardEvents = [];
let allBookings = [];


/* ==========================================
   START DASHBOARD
========================================== */

async function initialiseDashboard() {

    if (!token) {
        window.location.href = "login.php";
        return;
    }

    try {

        /* VERIFY JWT */
        const authResponse = await fetch("auth/me.php", {
            headers: { Authorization: "Bearer " + token }
        });

        const authResult = await authResponse.json();

        if (!authResponse.ok || authResult.status !== "success") {
            logout();
            return;
        }

        currentUser = authResult.user;

        /* ROLE CHECK */
        if (currentUser.role !== "Administrator" && currentUser.role !== "Organiser") {
            showAccessDenied();
            return;
        }

        updateUserInterface();

        await Promise.all([loadEvents(), loadBookings()]);

        prepareDashboardEvents();
        displayEvents();
        displayBookings();
        updateStatistics();

    } catch (error) {

        console.error("Dashboard error:", error);

        document.getElementById("dashboardRoot").innerHTML = `
            <div class="access-denied">
                <div class="access-denied-icon">!</div>
                <h1>Dashboard unavailable</h1>
                <p>Eventify could not load the management dashboard.</p>
                <a href="login.php">Return to login</a>
            </div>
        `;
    }
}


/* ==========================================
   LOAD EVENTS
========================================== */

async function loadEvents() {

    const response = await fetch("api/events.php");
    const result = await response.json();

    if (!response.ok || result.status !== "success") {
        throw new Error(result.message || "Unable to load events");
    }

    allEvents = result.data;
}


/* ==========================================
   ORGANISER VS ADMIN EVENTS
========================================== */

function prepareDashboardEvents() {

    if (currentUser.role === "Organiser") {

        dashboardEvents = allEvents.filter(
            event => Number(event.organiser_id) === Number(currentUser.user_id)
        );

        document.getElementById("eventsDescription").textContent = "Events organised by you";
        document.getElementById("eventPanelSubtitle").textContent = "Events organised by " + currentUser.name;

    } else {

        dashboardEvents = allEvents;

        document.getElementById("eventsDescription").textContent = "All events in the system";
        document.getElementById("eventPanelSubtitle").textContent = "Latest system events";
    }
}


/* ==========================================
   LOAD BOOKINGS
========================================== */

async function loadBookings() {

    const response = await fetch("api/bookings.php", {
        headers: { Authorization: "Bearer " + token }
    });

    const result = await response.json();

    if (response.status === 401) {
        logout();
        return;
    }

    if (!response.ok || result.status !== "success") {
        throw new Error(result.message || "Unable to load bookings");
    }

    /*
       Bookings API already handles roles:
       Organiser -> own event bookings
       Administrator -> all bookings
    */
    allBookings = result.data;
}


/* ==========================================
   STATISTICS
========================================== */

function updateStatistics() {

    const confirmed = allBookings.filter(
        booking => booking.booking_status === "Confirmed"
    );

    const value = confirmed.reduce(
        (total, booking) => total + Number(booking.total_amount),
        0
    );

    document.getElementById("totalEvents").textContent = dashboardEvents.length;
    document.getElementById("totalBookings").textContent = allBookings.length;
    document.getElementById("confirmedBookings").textContent = confirmed.length;
    document.getElementById("bookingValue").textContent = "RM " + value.toFixed(2);
}


/* ==========================================
   DISPLAY EVENTS
========================================== */

function displayEvents() {

    const container = document.getElementById("eventList");
    container.innerHTML = "";

    const events = [...dashboardEvents]
        .sort((a, b) => new Date(a.event_date) - new Date(b.event_date))
        .slice(0, 5);

    if (events.length === 0) {

        container.innerHTML = `
            <div class="empty-data">
                No events found.<br>
                <a href="manage-events.php" class="empty-link">Create an event</a>
            </div>
        `;

        return;
    }

    events.forEach(event => {

        const date = new Date(event.event_date + "T00:00:00");

        const day = date.toLocaleDateString("en-MY", { day: "2-digit" });
        const month = date.toLocaleDateString("en-MY", { month: "short" });

        const row = document.createElement("div");
        row.className = "dashboard-row";

        row.innerHTML = `
            <div class="row-date"><b>${escapeHTML(day)}</b><small>${escapeHTML(month)}</small></div>

            <div class="row-content">
                <strong>${escapeHTML(event.event_name)}</strong>
                <span>${escapeHTML(event.venue_name)}</span>
            </div>

            <span class="status-pill ${getEventStatusClass(event.status)}">
                ${escapeHTML(event.status)}
            </span>
        `;

        container.appendChild(row);
    });
}


/* ==========================================
   DISPLAY BOOKINGS
========================================== */

function displayBookings() {

    const container = document.getElementById("bookingList");
    container.innerHTML = "";

    const bookings = allBookings.slice(0, 5);

    if (bookings.length === 0) {
        container.innerHTML = `<div class="empty-data">No bookings found.</div>`;
        return;
    }

    bookings.forEach(booking => {

        const statusClass =
            booking.booking_status === "Confirmed" ? "status-green" :
            booking.booking_status === "Cancelled" ? "status-red" :
            "status-gray";

        const row = document.createElement("div");
        row.className = "dashboard-row";

        row.innerHTML = `
            <div class="row-qty">×${escapeHTML(booking.quantity)}</div>

            <div class="row-content">
                <strong>${escapeHTML(booking.customer_name || "Customer")}</strong>
                <span>${escapeHTML(booking.event_name)}, RM ${Number(booking.total_amount).toFixed(2)}</span>
            </div>

            <span class="status-pill ${statusClass}">
                ${escapeHTML(booking.booking_status)}
            </span>
        `;

        container.appendChild(row);
    });
}


/* ==========================================
   USER INTERFACE
========================================== */

function updateUserInterface() {

    const isAdministrator = currentUser.role === "Administrator";

    // The venue catalogue is administered centrally.
    // Organisers can still choose existing venues while creating events.
    document.querySelectorAll('a[href="manage-venues.php"]').forEach(function (link) {
        link.style.display = isAdministrator ? "" : "none";
    });

    const managementGrid = document.querySelector(".management-grid");
    if (managementGrid) {
        managementGrid.classList.toggle("organiser-view", !isAdministrator);
    }

    const adminSidebar = document.getElementById("adminUsersSidebar");
    const adminTopLink = document.getElementById("adminUsersTop");

    if (adminSidebar) {
        adminSidebar.style.display = isAdministrator ? "flex" : "none";
    }

    if (adminTopLink) {
        adminTopLink.style.display = isAdministrator ? "inline-flex" : "none";
    }

    const initial = currentUser.name.charAt(0).toUpperCase();

    document.getElementById("dashboardWelcome").textContent =
        isAdministrator
            ? "Welcome back, " + currentUser.name + ". You have full system access."
            : "Welcome back, " + currentUser.name + ". Manage your events and reservations.";

    document.getElementById("sidebarUser").innerHTML = `
        <div class="sidebar-avatar">${escapeHTML(initial)}</div>
        <small>${escapeHTML(currentUser.role)}</small>
        <strong>${escapeHTML(currentUser.name)}</strong>
    `;

    document.getElementById("dashboardUser").innerHTML = `
        <div class="chip-avatar">${escapeHTML(initial)}</div>
        <div>
            <small>${escapeHTML(currentUser.role)}</small>
            <strong>${escapeHTML(currentUser.name)}</strong>
        </div>
    `;

    document.getElementById("topNavigation").innerHTML = `
        <span class="top-user">${escapeHTML(currentUser.name)}</span>
        <button type="button" class="top-logout" onclick="logout()">Logout</button>
    `;
}


/* ==========================================
   ACCESS DENIED
========================================== */

function showAccessDenied() {

    document.getElementById("dashboardRoot").innerHTML = `
        <div class="access-denied">
            <div class="access-denied-icon">!</div>
            <h1>Access denied</h1>
            <p>
                Your account is registered as a ${escapeHTML(currentUser.role)}.
                Only Administrator and Organiser accounts can access
                Eventify's management dashboard.
            </p>
            <a href="events.php">Return to events</a>
        </div>
    `;
}


/* ==========================================
   EVENT STATUS
========================================== */

function getEventStatusClass(status) {

    if (status === "Upcoming" || status === "Ongoing") {
        return "status-green";
    }

    if (status === "Cancelled") {
        return "status-red";
    }

    return "status-gray";
}


/* ==========================================
   LOGOUT
========================================== */

function logout() {

    localStorage.removeItem("eventify_token");
    localStorage.removeItem("eventify_user");

    window.location.href = "login.php";
}


/* ==========================================
   ESCAPE HTML
========================================== */

function escapeHTML(value) {

    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


/* ==========================================
   START
========================================== */

initialiseDashboard();

</script>

</body>
</html>