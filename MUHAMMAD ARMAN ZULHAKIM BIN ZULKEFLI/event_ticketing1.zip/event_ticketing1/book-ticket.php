<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Tickets | Eventify</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body.booking-page {
            min-height: 100vh;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-family: var(--ev-body);
        }

        /* ---------- Navbar overrides ---------- */
        .booking-page .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .booking-page .navbar .brand,
        .booking-page .navbar .brand span { color: #fff; }
        .booking-page .navbar .brand-purple { color: var(--ev-coral); }
        .booking-page .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .booking-page .navbar .nav-links a { color: #b9d3cf; }
        .booking-page .navbar .nav-links a:hover,
        .booking-page .navbar .nav-links a.active { color: #fff; }
        .top-user { font-size: 14px; font-weight: 700; color: #b9d3cf; }
        .top-logout {
            padding: 10px 18px;
            border: none;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 14px var(--ev-body);
            cursor: pointer;
            transition: background .2s;
        }
        .top-logout:hover { background: var(--ev-coral-dark); }

        /* ---------- Header ---------- */
        .booking-page-header {
            padding: 44px 0 56px;
            color: #fff;
            background:
                radial-gradient(520px 300px at 92% 0%, rgba(255, 106, 77, .24), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .booking-page-header a {
            color: var(--ev-mint);
            font-size: 15px;
            font-weight: 700;
            text-decoration: none;
        }
        .booking-page-header a:hover { text-decoration: underline; }
        .booking-page-header h1 {
            margin-top: 18px;
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: clamp(36px, 4.6vw, 56px);
            letter-spacing: -1.2px;
            line-height: 1.05;
        }
        .booking-page-header p { margin-top: 12px; color: #b9d3cf; font-size: 17px; }

        .booking-section { padding: 44px 0 96px; }

        .booking-layout {
            display: grid;
            grid-template-columns: minmax(0, 1.25fr) minmax(320px, .75fr);
            gap: 32px;
            align-items: start;
        }

        /* ---------- Event ticket ---------- */
        .event-ticket {
            --stub: 120px;
            display: grid;
            grid-template-columns: var(--stub) minmax(0, 1fr);
            background: #fff;
            border-radius: 20px;
            -webkit-mask:
                radial-gradient(circle 13px at var(--stub) 0, #0000 98%, #000) top / 100% 51% no-repeat,
                radial-gradient(circle 13px at var(--stub) 100%, #0000 98%, #000) bottom / 100% 51% no-repeat;
            mask:
                radial-gradient(circle 13px at var(--stub) 0, #0000 98%, #000) top / 100% 51% no-repeat,
                radial-gradient(circle 13px at var(--stub) 100%, #0000 98%, #000) bottom / 100% 51% no-repeat;
        }
        .ticket-wrap { filter: drop-shadow(0 8px 18px rgba(7, 43, 45, .1)); }

        .event-ticket-stub {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 2px;
            padding: 24px 10px;
            color: #fff;
            background: var(--ev-teal);
            border-right: 2px dashed rgba(255, 255, 255, .45);
        }
        .event-ticket-stub small { font-size: 14px; opacity: .85; }
        .event-ticket-stub b { font-family: var(--ev-display); font-size: 46px; font-weight: 800; line-height: 1; }
        .event-ticket-stub span { font-size: 15px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; }

        .event-ticket-main { padding: 26px 30px; min-width: 0; }
        .event-ticket-main h3 {
            font-family: var(--ev-display);
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -.5px;
            color: var(--ev-ink);
            margin-bottom: 18px;
        }
        .ticket-fields { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px 28px; }
        .ticket-fields small { display: block; color: var(--ev-muted); font-size: 13px; }
        .ticket-fields strong { display: block; margin-top: 3px; font-size: 16px; font-weight: 700; color: var(--ev-ink); }

        /* ---------- Quantity ---------- */
        .ticket-card {
            margin-top: 24px;
            padding: 30px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
        }
        .ticket-card h2 {
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -.4px;
            color: var(--ev-ink);
        }
        .ticket-card > p { margin-top: 6px; color: var(--ev-muted); font-size: 15px; }

        .quantity-control { display: flex; align-items: center; gap: 18px; margin-top: 22px; }
        .quantity-control button {
            width: 56px;
            height: 56px;
            border: 1.5px solid var(--ev-line);
            border-radius: 50%;
            background: #fff;
            color: var(--ev-ink);
            font: 500 26px var(--ev-body);
            line-height: 1;
            cursor: pointer;
            transition: background .15s, border-color .15s;
        }
        .quantity-control button:hover { background: var(--ev-paper); border-color: var(--ev-teal-soft); }
        .quantity-control input {
            width: 90px;
            height: 56px;
            border: none;
            border-bottom: 3px solid var(--ev-coral);
            background: transparent;
            outline: none;
            text-align: center;
            color: var(--ev-ink);
            font-family: var(--ev-display);
            font-size: 38px;
            font-weight: 800;
            -moz-appearance: textfield;
        }
        .quantity-control input::-webkit-outer-spin-button,
        .quantity-control input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }

        .availability-note { margin-top: 16px; color: var(--ev-muted); font-size: 14px; }

        .customer-box {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-top: 28px;
            padding-top: 24px;
            border-top: 2px dashed var(--ev-line);
        }
        .customer-avatar {
            width: 46px;
            height: 46px;
            display: grid;
            place-items: center;
            border-radius: 50%;
            background: var(--ev-teal);
            color: #fff;
            font-family: var(--ev-display);
            font-size: 20px;
            font-weight: 800;
        }
        .customer-box small { display: block; color: var(--ev-muted); font-size: 13px; }
        .customer-box strong { font-size: 16px; }

        /* ---------- Summary (receipt) ---------- */
        .summary-card {
            position: sticky;
            top: 104px;
            overflow: hidden;
            color: #fff;
            border-radius: 22px;
            background:
                radial-gradient(360px 220px at 100% 0%, rgba(255, 106, 77, .22), transparent 70%),
                linear-gradient(160deg, var(--ev-teal), var(--ev-deep));
            box-shadow: 0 18px 40px rgba(7, 43, 45, .25);
        }
        .summary-header { padding: 26px 28px 20px; border-bottom: 2px dashed rgba(255, 255, 255, .25); }
        .summary-header h2 { font-family: var(--ev-display); font-size: 26px; font-weight: 800; letter-spacing: -.4px; }
        .summary-header span { display: block; margin-top: 4px; color: #9fc2bd; font-size: 14px; }

        .summary-body { padding: 22px 28px 28px; }

        .summary-row {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            padding: 12px 0;
            font-size: 15px;
        }
        .summary-row span { color: #9fc2bd; }
        .summary-row strong { text-align: right; font-weight: 700; }

        .summary-total {
            display: flex;
            justify-content: space-between;
            align-items: baseline;
            margin-top: 10px;
            padding-top: 18px;
            border-top: 2px dashed rgba(255, 255, 255, .25);
        }
        .summary-total span { color: #b9d3cf; font-size: 16px; }
        .summary-total strong {
            font-family: var(--ev-display);
            font-size: 36px;
            font-weight: 800;
            letter-spacing: -.8px;
            color: var(--ev-mint);
        }

        .confirm-btn {
            width: 100%;
            margin-top: 24px;
            padding: 16px;
            border: none;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 17px var(--ev-body);
            cursor: pointer;
            transition: background .2s, transform .15s;
        }
        .confirm-btn:hover { background: var(--ev-coral-dark); }
        .confirm-btn:active { transform: translateY(1px); }
        .confirm-btn:disabled { opacity: .6; cursor: not-allowed; }

        .booking-message {
            display: none;
            margin-top: 16px;
            padding: 14px 16px;
            border-radius: 12px;
            font-size: 14px;
            line-height: 1.6;
        }
        .booking-message.success { display: block; background: #e4f6ef; color: #0f6446; }
        .booking-message.error { display: block; background: #fff1ef; color: #a1301d; }

        .loading { padding: 80px; text-align: center; color: var(--ev-muted); font-size: 16px; }

        .unavailable-card {
            max-width: 520px;
            margin: 20px auto;
            padding: 40px 32px;
            text-align: center;
            background: #fff;
            border: 1px dashed var(--ev-line);
            border-radius: 20px;
        }
        .unavailable-card h2 { font-family: var(--ev-display); font-size: 28px; font-weight: 800; color: var(--ev-ink); }
        .unavailable-card p { margin-top: 10px; color: var(--ev-muted); font-size: 16px; line-height: 1.6; }
        .unavailable-card a {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 22px;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-weight: 700;
            text-decoration: none;
        }

        .quantity-control button:focus-visible,
        .quantity-control input:focus-visible,
        .confirm-btn:focus-visible,
        .top-logout:focus-visible,
        .booking-page-header a:focus-visible {
            outline: 3px solid var(--ev-mint);
            outline-offset: 3px;
        }

        /* ---------- Responsive ---------- */
        @media (max-width: 850px) {
            .booking-layout { grid-template-columns: 1fr; }
            .summary-card { position: static; }
        }
        @media (max-width: 560px) {
            .ticket-wrap { filter: none; }
            .event-ticket {
                grid-template-columns: 1fr;
                -webkit-mask: none;
                mask: none;
                border: 1px solid var(--ev-line);
            }
            .event-ticket-stub {
                flex-direction: row;
                justify-content: flex-start;
                gap: 10px;
                padding: 14px 22px;
                border-right: 0;
                border-bottom: 2px dashed rgba(255, 255, 255, .45);
            }
            .event-ticket-stub b { font-size: 30px; }
            .ticket-fields { grid-template-columns: 1fr; }
            .ticket-card { padding: 24px 20px; }
        }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
    </style>
</head>

<body class="booking-page">

<header class="navbar">
    <div class="container nav-container">

        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>

        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="events.php">Events</a>
            <a href="bookings.php">My Bookings</a>
        </nav>

        <div class="nav-actions" id="authNavigation"></div>

    </div>
</header>


<section class="booking-page-header">
    <div class="container">

        <a href="#" id="backLink">← Back to event</a>

        <h1>Reserve your tickets.</h1>

        <p>Your booking will be securely linked to your Eventify account.</p>

    </div>
</section>


<main class="booking-section">
    <div class="container">

        <div id="bookingContainer">
            <div class="loading">Checking your account...</div>
        </div>

    </div>
</main>


<footer class="footer">
    <div class="container footer-content">
        <a href="index.php" class="brand footer-brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>
        <p>Event Ticketing &amp; Venue Booking System</p>
        <p class="copyright">© 2026 Eventify</p>
    </div>
</footer>


<script>

/* =========================================
   AUTH
========================================= */

const token = localStorage.getItem("eventify_token");

const storedUser = JSON.parse(localStorage.getItem("eventify_user") || "null");

const params = new URLSearchParams(window.location.search);

const eventId = params.get("event_id");

const bookingContainer = document.getElementById("bookingContainer");
const backLink = document.getElementById("backLink");
const authNavigation = document.getElementById("authNavigation");

let currentEvent = null;
let currentUser = null;


/* =========================================
   INITIALISE
========================================= */

async function initialisePage() {

    if (!token) {
        redirectToLogin();
        return;
    }

    if (!eventId) {
        showError("No event was selected.");
        return;
    }

    backLink.href = "event-details.php?id=" + encodeURIComponent(eventId);

    /* VERIFY JWT */
    try {

        const authResponse = await fetch("auth/me.php", {
            headers: { Authorization: "Bearer " + token }
        });

        const authResult = await authResponse.json();

        if (!authResponse.ok || authResult.status !== "success") {
            clearLogin();
            redirectToLogin();
            return;
        }

        currentUser = authResult.user;

        if (currentUser.role !== "Customer") {
            showError("Only customer accounts can book tickets.");
            return;
        }

        updateNavbar();

        await loadEvent();

    } catch (error) {

        showError("Unable to verify your account.");
    }
}


/* =========================================
   EVENT
========================================= */

async function loadEvent() {

    try {

        const response = await fetch(
            "api/events.php?event_id=" + encodeURIComponent(eventId)
        );

        const result = await response.json();

        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Event unavailable");
        }

        currentEvent = result.data;

        displayBookingForm();

    } catch (error) {

        showError(error.message);
    }
}


/* =========================================
   HELPERS
========================================= */

function formatTime(value) {

    const match = /^(\d{1,2}):(\d{2})/.exec(String(value || ""));

    if (!match) return "";

    const hour = Number(match[1]);

    return ((hour % 12) || 12) + ":" + match[2] + " " + (hour >= 12 ? "PM" : "AM");
}


/* =========================================
   DISPLAY
========================================= */

function displayBookingForm() {

    const eventDate = new Date(currentEvent.event_date + "T00:00:00");

    const day = eventDate.toLocaleDateString("en-MY", { day: "2-digit" });
    const month = eventDate.toLocaleDateString("en-MY", { month: "short" });
    const weekday = eventDate.toLocaleDateString("en-MY", { weekday: "short" });

    const formattedDate = eventDate.toLocaleDateString("en-MY", {
        day: "numeric",
        month: "long",
        year: "numeric"
    });

    const start = formatTime(currentEvent.start_time);
    const end = formatTime(currentEvent.end_time);
    const when = start && end ? start + " to " + end : start;

    const ticketPrice = Number(currentEvent.ticket_price);

    const initial = currentUser.name.charAt(0).toUpperCase();

    bookingContainer.innerHTML = `

        <div class="booking-layout">

            <section>

                <div class="ticket-wrap">
                    <div class="event-ticket">

                        <div class="event-ticket-stub">
                            <small>${escapeHTML(weekday)}</small>
                            <b>${escapeHTML(day)}</b>
                            <span>${escapeHTML(month)}</span>
                        </div>

                        <div class="event-ticket-main">
                            <h3>${escapeHTML(currentEvent.event_name)}</h3>

                            <div class="ticket-fields">
                                <div><small>Date</small><strong>${escapeHTML(formattedDate)}</strong></div>
                                ${when ? `<div><small>Time</small><strong>${escapeHTML(when)}</strong></div>` : ""}
                                <div><small>Venue</small><strong>${escapeHTML(currentEvent.venue_name)}</strong></div>
                                <div><small>Price per ticket</small><strong>RM ${ticketPrice.toFixed(2)}</strong></div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="ticket-card">

                    <h2>How many tickets?</h2>
                    <p>Maximum 10 tickets per booking.</p>

                    <div class="quantity-control">

                        <button type="button" id="minusBtn" aria-label="Fewer tickets">−</button>

                        <input
                            type="number"
                            id="quantity"
                            value="1"
                            min="1"
                            max="10"
                            aria-label="Ticket quantity"
                        >

                        <button type="button" id="plusBtn" aria-label="More tickets">+</button>

                    </div>

                    <div class="availability-note">
                        ${Number(currentEvent.available_tickets).toLocaleString()}
                        tickets currently available.
                    </div>

                    <div class="customer-box">
                        <div class="customer-avatar">${escapeHTML(initial)}</div>
                        <div>
                            <small>Booking as</small>
                            <strong>${escapeHTML(currentUser.name)}</strong>
                        </div>
                    </div>

                </div>

            </section>

            <aside class="summary-card">

                <div class="summary-header">
                    <h2>Booking summary</h2>
                    <span>Check the details before you confirm.</span>
                </div>

                <div class="summary-body">

                    <div class="summary-row">
                        <span>Price per ticket</span>
                        <strong>RM ${ticketPrice.toFixed(2)}</strong>
                    </div>

                    <div class="summary-row">
                        <span>Quantity</span>
                        <strong id="summaryQuantity">1</strong>
                    </div>

                    <div class="summary-row">
                        <span>Event</span>
                        <strong>${escapeHTML(currentEvent.event_name)}</strong>
                    </div>

                    <div class="summary-total">
                        <span>Total</span>
                        <strong id="totalPrice">RM ${ticketPrice.toFixed(2)}</strong>
                    </div>

                    <button type="button" class="confirm-btn" id="confirmBtn">
                        Confirm booking
                    </button>

                    <div class="booking-message" id="bookingMessage"></div>

                </div>

            </aside>

        </div>

    `;

    setupControls();
}


/* =========================================
   QUANTITY
========================================= */

function setupControls() {

    const quantity = document.getElementById("quantity");
    const minus = document.getElementById("minusBtn");
    const plus = document.getElementById("plusBtn");

    const maximum = Math.min(10, Number(currentEvent.available_tickets));

    if (!(maximum >= 1)) {

        const confirmButton = document.getElementById("confirmBtn");

        confirmButton.disabled = true;
        confirmButton.textContent = "Sold out";

        return;
    }

    minus.addEventListener("click", function () {

        let value = Number(quantity.value);

        if (value > 1) {
            quantity.value = value - 1;
            updateTotal();
        }
    });

    plus.addEventListener("click", function () {

        let value = Number(quantity.value);

        if (value < maximum) {
            quantity.value = value + 1;
            updateTotal();
        }
    });

    quantity.addEventListener("input", function () {

        let value = Number(quantity.value);

        if (!Number.isInteger(value) || value < 1) {
            value = 1;
        }

        if (value > maximum) {
            value = maximum;
        }

        quantity.value = value;

        updateTotal();
    });

    document.getElementById("confirmBtn").addEventListener("click", createBooking);
}


/* =========================================
   TOTAL
========================================= */

function updateTotal() {

    const quantity = Number(document.getElementById("quantity").value);

    const total = quantity * Number(currentEvent.ticket_price);

    document.getElementById("summaryQuantity").textContent = quantity;
    document.getElementById("totalPrice").textContent = "RM " + total.toFixed(2);
}


/* =========================================
   CREATE BOOKING
========================================= */

async function createBooking() {

    const quantity = Number(document.getElementById("quantity").value);

    const button = document.getElementById("confirmBtn");
    const message = document.getElementById("bookingMessage");

    button.disabled = true;
    button.textContent = "Confirming...";

    try {

        const response = await fetch("api/bookings.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify({
                event_id: Number(eventId),
                quantity: quantity
            })
        });

        const result = await response.json();

        if (response.status === 401) {
            clearLogin();
            redirectToLogin();
            return;
        }

        if (response.ok && result.status === "success") {

            message.className = "booking-message success";

            message.innerHTML = `
                ✓ Booking confirmed!<br><br>
                Booking ID: <strong>#${escapeHTML(result.booking_id)}</strong><br>
                Customer: <strong>${escapeHTML(result.customer)}</strong><br>
                Total: <strong>RM ${escapeHTML(result.total_amount)}</strong><br><br>
                <span id="receiptStatus">Sending your receipt by email...</span>
            `;

            button.textContent = "Booking confirmed ✓";

            /* Email the receipt. A failure here never undoes the booking. */
            let receiptText = "We couldn't email your receipt. You can resend it from My Bookings.";

            try {

                const receiptResponse = await fetch("api/send-receipt.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: "Bearer " + token
                    },
                    body: JSON.stringify({ booking_id: Number(result.booking_id) })
                });

                const receiptResult = await receiptResponse.json().catch(() => ({}));

                if (receiptResponse.ok && receiptResult.status === "success") {
                    receiptText = "✓ Your receipt has been emailed to you.";
                }

            } catch (receiptError) {
                /* keep the fallback text */
            }

            document.getElementById("receiptStatus").textContent = receiptText;

            setTimeout(function () {
                window.location.href = "bookings.php";
            }, 3000);

        } else {

            throw new Error(result.message || "Unable to create booking");
        }

    } catch (error) {

        message.className = "booking-message error";
        message.textContent = error.message;

        button.disabled = false;
        button.textContent = "Confirm booking";
    }
}


/* =========================================
   NAVBAR
========================================= */

function updateNavbar() {

    authNavigation.innerHTML = `
        <span class="top-user">${escapeHTML(currentUser.name)}</span>
        <button type="button" class="top-logout" onclick="logout()">Logout</button>
    `;
}


function logout() {

    clearLogin();

    window.location.href = "login.php";
}


function clearLogin() {

    localStorage.removeItem("eventify_token");
    localStorage.removeItem("eventify_user");
}


/* =========================================
   LOGIN REDIRECT
========================================= */

function redirectToLogin() {

    const returnUrl = encodeURIComponent(window.location.href);

    window.location.href = "login.php?return=" + returnUrl;
}


/* =========================================
   ERROR
========================================= */

function showError(message) {

    bookingContainer.innerHTML = `
        <div class="unavailable-card">
            <h2>Booking unavailable</h2>
            <p>${escapeHTML(message)}</p>
            <a href="events.php">Back to events</a>
        </div>
    `;
}


/* =========================================
   ESCAPE
========================================= */

function escapeHTML(value) {

    if (value === null || value === undefined) {
        return "";
    }

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


initialisePage();

</script>

</body>
</html>