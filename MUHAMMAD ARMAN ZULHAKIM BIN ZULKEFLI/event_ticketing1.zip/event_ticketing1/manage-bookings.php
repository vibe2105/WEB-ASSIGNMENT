<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bookings | Eventify</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body.management-page {
            min-height: 100vh;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-family: var(--ev-body);
        }

        /* ---------- Navbar overrides ---------- */
        .management-page .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .management-page .navbar .brand,
        .management-page .navbar .brand span { color: #fff; }
        .management-page .navbar .brand-purple { color: var(--ev-coral); }
        .management-page .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .management-page .navbar .nav-links a { color: #b9d3cf; }
        .management-page .navbar .nav-links a:hover,
        .management-page .navbar .nav-links a.active { color: #fff; }
        .top-user { font-size: 14px; font-weight: 700; color: #b9d3cf; }
        .top-logout {
            padding: 9px 18px;
            border: none;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 14px var(--ev-body);
            cursor: pointer;
            transition: background .2s;
        }
        .top-logout:hover { background: var(--ev-coral-dark); }

        /* =====================================
           HERO
        ===================================== */
        .booking-management-hero {
            padding: 56px 0 62px;
            color: #fff;
            background:
                radial-gradient(550px 320px at 90% 0%, rgba(255, 106, 77, .22), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .booking-management-hero .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 999px;
            background: rgba(168, 235, 211, .15);
            color: var(--ev-mint);
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .6px;
        }
        .booking-management-hero h1 {
            margin-top: 12px;
            font-family: var(--ev-display);
            font-size: clamp(34px, 4.2vw, 50px);
            font-weight: 800;
            letter-spacing: -1.2px;
            line-height: 1.05;
            color: #fff;
        }
        .booking-management-hero p {
            margin-top: 8px;
            color: #b9d3cf;
            font-size: 16px;
        }

        /* =====================================
           SECTION
        ===================================== */
        .management-section {
            padding: 40px 0 96px;
        }

        /* =====================================
           STATISTICS
        ===================================== */
        .booking-stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .booking-stat {
            position: relative;
            padding: 24px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(7, 43, 45, .03);
            overflow: hidden;
        }
        .booking-stat::before {
            content: "";
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: var(--ev-teal-soft);
        }
        .booking-stat:nth-child(2)::before { background: var(--ev-coral); }
        .booking-stat:nth-child(3)::before { background: var(--ev-mint); }
        .booking-stat:nth-child(4)::before { background: var(--ev-deep); }

        .booking-stat span {
            color: var(--ev-muted);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .8px;
        }
        .booking-stat strong {
            display: block;
            margin-top: 8px;
            font-family: var(--ev-display);
            font-size: 34px;
            font-weight: 800;
            color: var(--ev-ink);
            letter-spacing: -.6px;
        }

        /* =====================================
           TOOLBAR
        ===================================== */
        .booking-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            padding: 18px 20px;
            margin-bottom: 24px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
            box-shadow: 0 4px 14px rgba(7, 43, 45, .02);
        }
        .booking-toolbar input {
            flex: 1;
            height: 48px;
            padding: 0 16px;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            outline: none;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font: 500 15px var(--ev-body);
            transition: all .2s;
        }
        .booking-toolbar input:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 3px rgba(20, 102, 106, .12);
        }
        .booking-toolbar select {
            min-width: 180px;
            height: 48px;
            padding: 0 14px;
            background: var(--ev-paper);
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            color: var(--ev-ink);
            font: 600 14px var(--ev-body);
            cursor: pointer;
            transition: all .2s;
        }
        .booking-toolbar select:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            outline: none;
        }

        /* =====================================
           TABLE
        ===================================== */
        .booking-table-card {
            overflow: hidden;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 24px;
            box-shadow: 0 14px 36px rgba(7, 43, 45, .05);
        }
        .table-scroll {
            overflow-x: auto;
        }
        .booking-table {
            width: 100%;
            min-width: 1100px;
            border-collapse: collapse;
        }
        .booking-table th {
            padding: 18px 22px;
            text-align: left;
            background: var(--ev-paper);
            color: var(--ev-muted);
            border-bottom: 1px solid var(--ev-line);
            text-transform: uppercase;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: .9px;
        }
        .booking-table td {
            padding: 20px 22px;
            border-bottom: 1px solid var(--ev-line);
            vertical-align: middle;
            font-size: 15px;
            color: var(--ev-ink);
        }
        .booking-table tr:last-child td {
            border-bottom: none;
        }
        .booking-table tbody tr {
            transition: background .15s ease;
        }
        .booking-table tbody tr:hover {
            background: rgba(244, 248, 246, .6);
        }

        .customer-cell strong {
            display: block;
            color: var(--ev-ink);
            font-size: 16px;
            font-weight: 700;
        }
        .customer-cell span {
            display: block;
            color: var(--ev-muted);
            margin-top: 3px;
            font-size: 13px;
        }
        .event-cell {
            max-width: 220px;
        }
        .event-cell strong {
            display: block;
            color: var(--ev-ink);
            font-weight: 700;
        }
        .event-cell span {
            display: block;
            margin-top: 3px;
            color: var(--ev-muted);
            font-size: 13px;
        }

        /* =====================================
           STATUS BADGES
        ===================================== */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 12px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 700;
        }
        .status-badge::before {
            content: "";
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: currentColor;
        }
        .status-confirmed {
            color: #0f6446;
            background: #e4f6ef;
        }
        .status-pending {
            color: #8c5d00;
            background: #fff6df;
        }
        .status-cancelled {
            color: #a1301d;
            background: #fff1ef;
        }

        /* =====================================
           ACTION BUTTONS
        ===================================== */
        .manage-btn {
            padding: 9px 16px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            color: var(--ev-deep);
            background: var(--ev-mint);
            font: 700 13px var(--ev-body);
            transition: all .15s ease;
        }
        .manage-btn:hover {
            background: #93dec5;
            transform: translateY(-1px);
        }
        .empty-bookings {
            padding: 80px 20px;
            text-align: center;
            color: var(--ev-muted);
            font-size: 16px;
        }

        /* =====================================
           MODAL
        ===================================== */
        .modal-overlay {
            position: fixed;
            inset: 0;
            z-index: 5000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(7, 43, 45, .75);
            backdrop-filter: blur(6px);
        }
        .modal-overlay.show {
            display: flex;
        }
        .booking-modal {
            width: min(480px, 100%);
            overflow: hidden;
            background: #fff;
            border-radius: 24px;
            box-shadow: 0 25px 70px rgba(7, 43, 45, .32);
        }
        .booking-modal-header {
            padding: 24px 28px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--ev-line);
        }
        .booking-modal-header span {
            color: var(--ev-teal-soft);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        .booking-modal-header h2 {
            margin-top: 4px;
            font-family: var(--ev-display);
            font-size: 24px;
            font-weight: 800;
            color: var(--ev-ink);
        }
        .close-modal {
            width: 38px;
            height: 38px;
            border: none;
            border-radius: 12px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            cursor: pointer;
            font-size: 20px;
            line-height: 1;
            transition: background .15s;
        }
        .close-modal:hover {
            background: var(--ev-line);
        }
        .booking-modal-body {
            padding: 28px;
        }
        .booking-summary {
            padding: 18px 20px;
            margin-bottom: 22px;
            background: var(--ev-paper);
            border: 1px solid var(--ev-line);
            border-radius: 14px;
        }
        .booking-summary strong {
            display: block;
            font-size: 15px;
            color: var(--ev-ink);
        }
        .booking-summary span {
            display: block;
            margin-top: 6px;
            color: var(--ev-muted);
            font-size: 13px;
            line-height: 1.65;
        }
        .status-field label {
            display: block;
            margin-bottom: 8px;
            color: var(--ev-ink);
            font-size: 13px;
            font-weight: 700;
        }
        .status-field select {
            width: 100%;
            height: 48px;
            padding: 0 16px;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            outline: none;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font: 500 15px var(--ev-body);
            transition: all .2s;
        }
        .status-field select:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 3px rgba(20, 102, 106, .12);
        }
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid var(--ev-line);
        }
        .cancel-modal-btn,
        .save-status-btn {
            padding: 12px 22px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font: 700 15px var(--ev-body);
            transition: background .15s;
        }
        .cancel-modal-btn {
            background: var(--ev-paper);
            color: var(--ev-ink);
        }
        .cancel-modal-btn:hover {
            background: var(--ev-line);
        }
        .save-status-btn {
            background: var(--ev-coral);
            color: var(--ev-deep);
        }
        .save-status-btn:hover {
            background: var(--ev-coral-dark);
        }
        .save-status-btn:disabled {
            opacity: .6;
            cursor: not-allowed;
        }
        .modal-message {
            display: none;
            margin-top: 16px;
            padding: 12px 14px;
            border-radius: 10px;
            font-size: 13px;
            line-height: 1.5;
        }
        .modal-message.error {
            display: block;
            color: #a1301d;
            background: #fff1ef;
        }
        .modal-message.success {
            display: block;
            color: #0f6446;
            background: #e4f6ef;
        }

        /* =====================================
           TOAST NOTIFICATION
        ===================================== */
        .toast {
            position: fixed;
            right: 25px;
            bottom: 25px;
            z-index: 7000;
            min-width: 280px;
            padding: 15px 22px;
            border-radius: 14px;
            color: #fff;
            opacity: 0;
            transform: translateY(40px);
            pointer-events: none;
            transition: .3s;
            font: 700 14px var(--ev-body);
            box-shadow: 0 18px 45px rgba(7, 43, 45, .25);
        }
        .toast.show {
            opacity: 1;
            transform: translateY(0);
        }
        .toast.success { background: #0f6446; }
        .toast.error { background: #a1301d; }

        /* ---------- Footer ---------- */
        .ev-footer { color: #b9d3cf; background: linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%); }
        .ev-footer-top {
            display: grid;
            grid-template-columns: minmax(0, 1.6fr) repeat(2, minmax(0, 1fr));
            gap: 48px;
            padding: 60px 0 44px;
        }
        .ev-footer-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            text-decoration: none;
        }
        .ev-footer-mark {
            width: 38px;
            height: 38px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-size: 20px;
        }
        .ev-footer-brand em { font-style: normal; color: var(--ev-coral); }
        .ev-footer-about { margin-top: 16px; max-width: 340px; font-size: 15px; line-height: 1.65; color: #9fc2bd; }
        .ev-footer h3 { font-family: var(--ev-display); font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 14px; }
        .ev-footer ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 10px; }
        .ev-footer ul a { color: #b9d3cf; font-size: 15px; text-decoration: none; }
        .ev-footer ul a:hover { color: #fff; text-decoration: underline; }
        .ev-footer a:focus-visible { outline: 3px solid var(--ev-mint); outline-offset: 3px; border-radius: 4px; }
        .ev-footer-bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px 24px;
            padding: 22px 0 28px;
            border-top: 2px dashed rgba(255, 255, 255, .2);
            font-size: 14px;
            color: #9fc2bd;
        }

        /* ---------- Responsive ---------- */
        @media (max-width: 900px) {
            .booking-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .booking-toolbar { flex-direction: column; align-items: stretch; }
            .booking-toolbar select { width: 100%; }
            .ev-footer-top { grid-template-columns: 1fr 1fr; }
            .ev-footer-top > div:first-child { grid-column: 1 / -1; }
        }
        @media (max-width: 550px) {
            .booking-stats { grid-template-columns: 1fr; }
            .ev-footer-top { padding: 44px 0 32px; gap: 32px 24px; }
        }
    </style>
</head>
<body class="management-page">

<!-- NAVIGATION -->
<header class="navbar">
    <div class="container nav-container">
        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>
        <nav class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage-events.php">Events</a>
            <a href="manage-venues.php" id="adminVenueLink" style="display: none;">Venues</a>
            <a href="manage-bookings.php" class="active">Bookings</a>
        </nav>
        <div class="nav-actions" id="authNavigation"></div>
    </div>
</header>

<!-- HERO -->
<section class="booking-management-hero">
    <div class="container">
        <span class="eyebrow">RESERVATION MANAGEMENT</span>
        <h1>Manage Bookings</h1>
        <p id="pageDescription">Review and manage customer reservations.</p>
    </div>
</section>

<!-- CONTENT -->
<main class="management-section">
    <div class="container">
        <!-- STATISTICS -->
        <section class="booking-stats">
            <article class="booking-stat">
                <span>Total Bookings</span>
                <strong id="totalBookings">0</strong>
            </article>
            <article class="booking-stat">
                <span>Confirmed</span>
                <strong id="confirmedBookings">0</strong>
            </article>
            <article class="booking-stat">
                <span>Cancelled</span>
                <strong id="cancelledBookings">0</strong>
            </article>
            <article class="booking-stat">
                <span>Confirmed Value</span>
                <strong id="confirmedValue">RM 0.00</strong>
            </article>
        </section>

        <!-- FILTERS -->
        <section class="booking-toolbar">
            <input type="text" id="bookingSearch" placeholder="Search customer, event, venue or booking ID...">
            <select id="bookingStatusFilter">
                <option value="">All Statuses</option>
                <option value="Confirmed">Confirmed</option>
                <option value="Pending">Pending</option>
                <option value="Cancelled">Cancelled</option>
            </select>
        </section>

        <!-- TABLE -->
        <section class="booking-table-card">
            <div class="table-scroll">
                <table class="booking-table">
                    <thead>
                        <tr>
                            <th>Booking</th>
                            <th>Customer</th>
                            <th>Event</th>
                            <th>Tickets</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Booking Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="bookingTableBody">
                        <tr>
                            <td colspan="8" class="empty-bookings">Loading bookings...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</main>

<!-- STATUS MODAL -->
<div class="modal-overlay" id="bookingModal">
    <div class="booking-modal">
        <div class="booking-modal-header">
            <div>
                <span>MANAGE BOOKING</span>
                <h2>Update Status</h2>
            </div>
            <button type="button" class="close-modal" id="closeBookingModal">&times;</button>
        </div>
        <div class="booking-modal-body">
            <div class="booking-summary" id="modalBookingSummary"></div>
            <div class="status-field">
                <label for="newBookingStatus">Booking Status</label>
                <select id="newBookingStatus">
                    <option value="Confirmed">Confirmed</option>
                    <option value="Pending">Pending</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
            </div>
            <div class="modal-message" id="modalMessage"></div>
            <div class="modal-actions">
                <button type="button" class="cancel-modal-btn" id="cancelModalButton">Close</button>
                <button type="button" class="save-status-btn" id="saveStatusButton">Save Status</button>
            </div>
        </div>
    </div>
</div>

<div class="toast" id="toast"></div>

<!-- FOOTER -->
<footer class="ev-footer">
    <div class="container">
        <div class="ev-footer-top">
            <div>
                <a href="index.php" class="ev-footer-brand">
                    <span class="ev-footer-mark">E</span>
                    <span>Event<em>ify</em></span>
                </a>
                <p class="ev-footer-about">
                    Find events, book tickets and keep every reservation in one place.
                </p>
            </div>
            <div>
                <h3>Explore</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="events.php">All events</a></li>
                    <li><a href="index.php#how-it-works">How it works</a></li>
                </ul>
            </div>
            <div>
                <h3>Your account</h3>
                <ul>
                    <li><a href="login.php">Sign in</a></li>
                    <li><a href="register.php">Create account</a></li>
                    <li><a href="bookings.php">My bookings</a></li>
                </ul>
            </div>
        </div>

        <div class="ev-footer-bottom">
            <span>&copy; 2026 Eventify</span>
            <span>Event Ticketing &amp; Venue Booking System</span>
        </div>
    </div>
</footer>

<script>
/* ========================================
   VARIABLES
======================================== */
const token = localStorage.getItem("eventify_token");
let currentUser = null;
let bookings = [];
let selectedBooking = null;

const bookingTableBody = document.getElementById("bookingTableBody");
const bookingModal = document.getElementById("bookingModal");
const modalMessage = document.getElementById("modalMessage");
const saveStatusButton = document.getElementById("saveStatusButton");
const toast = document.getElementById("toast");

/* ========================================
   INITIALISE
======================================== */
async function initialise() {
    if (!token) {
        window.location.href = "login.php";
        return;
    }
    try {
        const response = await fetch("auth/me.php", {
            headers: { Authorization: "Bearer " + token }
        });
        const result = await response.json();
        if (!response.ok || result.status !== "success") {
            logout();
            return;
        }
        currentUser = result.user;
        if (currentUser.role !== "Administrator" && currentUser.role !== "Organiser") {
            alert("You do not have permission to manage bookings.");
            window.location.href = "events.php";
            return;
        }
        updateNavbar();
        if (currentUser.role === "Organiser") {
            document.getElementById("pageDescription").textContent = "Review reservations for the events you organise.";
        }
        await loadBookings();
    } catch (error) {
        showToast("Unable to load booking management.", "error");
    }
}

/* ========================================
   LOAD BOOKINGS
======================================== */
async function loadBookings() {
    const response = await fetch("api/bookings.php", {
        headers: { Authorization: "Bearer " + token }
    });
    const result = await response.json();
    if (response.status === 401) {
        logout();
        return;
    }
    if (!response.ok || result.status !== "success") {
        throw new Error(result.message || "Unable to load bookings");
    }
    bookings = result.data;
    displayBookings(bookings);
    updateStatistics();
}

/* ========================================
   DISPLAY BOOKINGS
======================================== */
function displayBookings(bookingList) {
    bookingTableBody.innerHTML = "";
    if (bookingList.length === 0) {
        bookingTableBody.innerHTML = `
            <tr>
                <td colspan="8" class="empty-bookings">No bookings found.</td>
            </tr>
        `;
        return;
    }
    bookingList.forEach(booking => {
        const eventDate = new Date(booking.event_date + "T00:00:00");
        const eventDateText = eventDate.toLocaleDateString("en-MY", {
            day: "numeric",
            month: "short",
            year: "numeric"
        });
        const bookingDate = new Date(String(booking.booking_date).replace(" ", "T"));
        const bookingDateText = isNaN(bookingDate.getTime())
            ? booking.booking_date
            : bookingDate.toLocaleString("en-MY", {
                day: "numeric",
                month: "short",
                year: "numeric",
                hour: "numeric",
                minute: "2-digit"
            });
        const row = document.createElement("tr");
        row.innerHTML = `
            <td><strong>#${booking.booking_id}</strong></td>
            <td>
                <div class="customer-cell">
                    <strong>${escapeHTML(booking.customer_name || "Customer")}</strong>
                    <span>${escapeHTML(booking.customer_email || "")}</span>
                </div>
            </td>
            <td>
                <div class="event-cell">
                    <strong>${escapeHTML(booking.event_name)}</strong>
                    <span>${eventDateText} • ${escapeHTML(booking.venue_name)}</span>
                </div>
            </td>
            <td>${Number(booking.quantity)}</td>
            <td><strong>RM ${Number(booking.total_amount).toFixed(2)}</strong></td>
            <td>
                <span class="status-badge ${getStatusClass(booking.booking_status)}">
                    ${escapeHTML(booking.booking_status)}
                </span>
            </td>
            <td>${bookingDateText}</td>
            <td>
                <button type="button" class="manage-btn" onclick="openManageBooking(${booking.booking_id})">
                    Manage
                </button>
            </td>
        `;
        bookingTableBody.appendChild(row);
    });
}

function getStatusClass(status) {
    if (status === "Confirmed") return "status-confirmed";
    if (status === "Pending") return "status-pending";
    if (status === "Cancelled") return "status-cancelled";
    return "";
}

/* ========================================
   STATISTICS
======================================== */
function updateStatistics() {
    const confirmed = bookings.filter(b => b.booking_status === "Confirmed");
    const cancelled = bookings.filter(b => b.booking_status === "Cancelled");
    const value = confirmed.reduce((total, b) => total + Number(b.total_amount), 0);

    document.getElementById("totalBookings").textContent = bookings.length;
    document.getElementById("confirmedBookings").textContent = confirmed.length;
    document.getElementById("cancelledBookings").textContent = cancelled.length;
    document.getElementById("confirmedValue").textContent = "RM " + value.toFixed(2);
}

/* ========================================
   SEARCH AND FILTER
======================================== */
document.getElementById("bookingSearch").addEventListener("input", filterBookings);
document.getElementById("bookingStatusFilter").addEventListener("change", filterBookings);

function filterBookings() {
    const search = document.getElementById("bookingSearch").value.toLowerCase();
    const status = document.getElementById("bookingStatusFilter").value;
    const filtered = bookings.filter(booking => {
        const searchText = (
            booking.booking_id + " " +
            (booking.customer_name || "") + " " +
            (booking.customer_email || "") + " " +
            booking.event_name + " " +
            booking.venue_name
        ).toLowerCase();
        const searchMatch = searchText.includes(search);
        const statusMatch = status === "" || booking.booking_status === status;
        return searchMatch && statusMatch;
    });
    displayBookings(filtered);
}

/* ========================================
   OPEN MANAGE MODAL
======================================== */
function openManageBooking(bookingId) {
    selectedBooking = bookings.find(b => Number(b.booking_id) === Number(bookingId));
    if (!selectedBooking) return;

    document.getElementById("modalBookingSummary").innerHTML = `
        <strong>Booking #${selectedBooking.booking_id} — ${escapeHTML(selectedBooking.event_name)}</strong>
        <span>
            Customer: ${escapeHTML(selectedBooking.customer_name || "Customer")}<br>
            Quantity: ${selectedBooking.quantity} ticket(s)<br>
            Total: RM ${Number(selectedBooking.total_amount).toFixed(2)}
        </span>
    `;
    const statusSelect = document.getElementById("newBookingStatus");
    statusSelect.value = selectedBooking.booking_status;

    clearModalMessage();
    bookingModal.classList.add("show");
}

/* ========================================
   SAVE STATUS
======================================== */
saveStatusButton.addEventListener("click", async function () {
    if (!selectedBooking) return;
    const newStatus = document.getElementById("newBookingStatus").value;
    saveStatusButton.disabled = true;
    saveStatusButton.textContent = "Saving...";

    try {
        const response = await fetch("api/bookings.php", {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify({
                booking_id: Number(selectedBooking.booking_id),
                booking_status: newStatus
            })
        });
        const result = await response.json();
        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Failed to update booking status");
        }
        showToast("Booking status updated successfully!", "success");
        closeModal();
        await loadBookings();
    } catch (error) {
        showModalMessage(error.message, "error");
    } finally {
        saveStatusButton.disabled = false;
        saveStatusButton.textContent = "Save Status";
    }
});

/* ========================================
   MODAL CONTROLS & HELPERS
======================================== */
document.getElementById("closeBookingModal").addEventListener("click", closeModal);
document.getElementById("cancelModalButton").addEventListener("click", closeModal);

function closeModal() {
    bookingModal.classList.remove("show");
    selectedBooking = null;
}

function showModalMessage(msg, type) {
    modalMessage.textContent = msg;
    modalMessage.className = "modal-message " + type;
}

function clearModalMessage() {
    modalMessage.textContent = "";
    modalMessage.className = "modal-message";
}

function showToast(message, type) {
    toast.textContent = message;
    toast.className = "toast " + type + " show";
    setTimeout(() => {
        toast.className = "toast";
    }, 3500);
}

function updateNavbar() {
    const authNav = document.getElementById("authNavigation");
    if (authNav && currentUser) {
        authNav.innerHTML = `
            <span class="top-user">${escapeHTML(currentUser.name)}</span>
            <button type="button" class="top-logout" onclick="logout()">Logout</button>
        `;
    }
    if (currentUser && currentUser.role === "Administrator") {
        const venueLink = document.getElementById("adminVenueLink");
        if (venueLink) venueLink.style.display = "inline-block";
    }
}

function logout() {
    localStorage.removeItem("eventify_token");
    localStorage.removeItem("eventify_user");
    window.location.href = "login.php";
}

function escapeHTML(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

initialise();
</script>

</body>
</html>