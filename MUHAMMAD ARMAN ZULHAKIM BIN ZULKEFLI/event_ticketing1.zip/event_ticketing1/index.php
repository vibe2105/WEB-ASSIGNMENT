<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Discover, explore and book amazing events with Eventify.">
    <title>Eventify | Discover Experiences Worth Remembering</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Home-specific styles. Shared navbar structure still comes from css/style.css. */
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body.home {
            background: var(--ev-paper);
            font-family: var(--ev-body);
            color: var(--ev-ink);
        }

        /* ---------- Navbar colour overrides ---------- */
        .home .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .home .navbar .brand,
        .home .navbar .brand span { color: #fff; }
        .home .navbar .brand-purple { color: var(--ev-coral); }
        .home .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .home .navbar .nav-links a { color: #b9d3cf; }
        .home .navbar .nav-links a:hover,
        .home .navbar .nav-links a.active { color: #fff; }
        .home .navbar .sign-in { color: #fff; }
        .home .navbar .nav-button {
            background: transparent;
            color: #fff;
            border: 1.5px solid rgba(255, 255, 255, .35);
            box-shadow: none;
        }
        .home .navbar .nav-button:hover {
            background: var(--ev-coral);
            border-color: var(--ev-coral);
            color: var(--ev-deep);
        }

        /* ---------- Buttons ---------- */
        .home-primary-button, .home-secondary-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 16px 26px;
            border-radius: 12px;
            font: 700 16px var(--ev-body);
            text-decoration: none;
            transition: background .2s, transform .15s;
        }
        .home-primary-button { background: var(--ev-coral); color: var(--ev-deep); }
        .home-primary-button:hover { background: var(--ev-coral-dark); }
        .home-secondary-button {
            color: #fff;
            border: 1.5px solid rgba(255, 255, 255, .35);
        }
        .home-secondary-button:hover { background: rgba(255, 255, 255, .1); }
        .home-primary-button:active, .home-secondary-button:active { transform: translateY(1px); }
        .home-primary-button:focus-visible,
        .home-secondary-button:focus-visible,
        .home-event-card:focus-visible,
        .home-view-link:focus-visible {
            outline: 3px solid var(--ev-mint);
            outline-offset: 3px;
        }

        /* ---------- Hero ---------- */
        .home-hero {
            position: relative;
            overflow: hidden;
            color: #fff;
            background:
                radial-gradient(600px 420px at 88% 20%, rgba(255, 106, 77, .24), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .home-hero-inner {
            display: grid;
            grid-template-columns: 1.1fr .9fr;
            align-items: center;
            gap: 60px;
            padding-top: 100px;
            padding-bottom: 115px;
            min-height: 560px;
        }
        .home-hero h1 {
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: clamp(42px, 5.2vw, 74px);
            line-height: 1.04;
            letter-spacing: -1.6px;
            max-width: 700px;
            color: #fff;
        }
        .home-hero h1 span { display: block; color: var(--ev-mint); }
        .home-hero-intro {
            margin-top: 24px;
            max-width: 500px;
            color: #b9d3cf;
            font-size: 18px;
            line-height: 1.65;
        }
        .home-hero-actions { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 34px; }

        .home-hero-stats { display: flex; align-items: center; gap: 26px; margin-top: 48px; }
        .home-hero-stats strong {
            display: block;
            font-family: var(--ev-display);
            font-size: 32px;
            font-weight: 800;
            color: #fff;
        }
        .home-hero-stats small { color: #9fc2bd; font-size: 14px; }
        .home-stat-separator { height: 36px; width: 1px; background: rgba(255, 255, 255, .22); }

        /* ---------- Hero ticket ---------- */
        .home-visual { position: relative; width: min(100%, 440px); margin-inline: auto; }
        .home-ticket {
            --stub: 262px;
            position: relative;
            padding: 26px 26px 28px;
            background: #fff;
            color: var(--ev-ink);
            border-radius: 22px;
            transform: rotate(3deg);
            box-shadow: 0 30px 70px rgba(2, 18, 19, .45);
            -webkit-mask:
                radial-gradient(circle 13px at 0 var(--stub), #0000 98%, #000) left / 51% 100% no-repeat,
                radial-gradient(circle 13px at 100% var(--stub), #0000 98%, #000) right / 51% 100% no-repeat;
            mask:
                radial-gradient(circle 13px at 0 var(--stub), #0000 98%, #000) left / 51% 100% no-repeat,
                radial-gradient(circle 13px at 100% var(--stub), #0000 98%, #000) right / 51% 100% no-repeat;
        }
        .home-visual { filter: drop-shadow(0 30px 40px rgba(2, 18, 19, .4)); }
        .home-ticket { box-shadow: none; }
        .home-ticket-art {
            height: 190px;
            border-radius: 14px;
            position: relative;
            overflow: hidden;
            display: grid;
            place-items: center;
            background: linear-gradient(135deg, var(--ev-teal-soft), var(--ev-teal));
        }
        .home-ticket-art::before, .home-ticket-art::after {
            content: "";
            position: absolute;
            border-radius: 50%;
        }
        .home-ticket-art::before { width: 230px; height: 230px; right: -60px; top: -90px; background: var(--ev-coral); opacity: .92; }
        .home-ticket-art::after { width: 150px; height: 150px; left: -40px; bottom: -70px; background: var(--ev-mint); opacity: .85; }
        .home-ticket-symbol {
            position: relative;
            z-index: 1;
            font-family: var(--ev-display);
            font-size: 76px;
            font-weight: 800;
            color: #fff;
            line-height: 1;
        }
        .home-ticket-live {
            display: inline-block;
            margin-top: 18px;
            padding: 6px 12px;
            border-radius: 999px;
            background: #e4f6ef;
            color: var(--ev-teal-soft);
            font-size: 13px;
            font-weight: 700;
        }
        .home-ticket h2 {
            margin: 18px 0 6px;
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -.5px;
            color: var(--ev-ink);
        }
        .home-ticket p { color: var(--ev-muted); font-size: 14px; line-height: 1.5; }
        .home-ticket-bottom {
            margin-top: 22px;
            padding-top: 20px;
            border-top: 2px dashed var(--ev-line);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .home-ticket-bottom small { display: block; margin-bottom: 3px; font-size: 12px; color: var(--ev-muted); }
        .home-ticket-bottom strong { font-size: 16px; color: var(--ev-ink); }
        .home-ticket-number {
            font-family: var(--ev-display);
            font-size: 24px;
            font-weight: 800;
            color: var(--ev-coral-dark);
        }

        .home-floating {
            position: absolute;
            z-index: 2;
            padding: 12px 18px;
            background: var(--ev-mint);
            color: var(--ev-deep);
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            box-shadow: 0 14px 30px rgba(2, 18, 19, .3);
        }
        .home-floating b { font-weight: 700; }
        .home-floating-left { left: -34px; top: 20%; transform: rotate(-7deg); }
        .home-floating-right { right: -26px; bottom: 14%; transform: rotate(-5deg); }

        /* ---------- Sections ---------- */
        .home-section { padding: 84px 0; }
        .home-section-heading {
            display: flex;
            justify-content: space-between;
            align-items: end;
            gap: 24px;
            margin-bottom: 34px;
        }
        .home-section-heading h2 {
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: clamp(30px, 3.4vw, 42px);
            letter-spacing: -.9px;
            color: var(--ev-ink);
        }
        .home-section-heading p { margin-top: 8px; color: var(--ev-muted); font-size: 16px; }
        .home-view-link {
            color: var(--ev-teal-soft);
            font-size: 15px;
            font-weight: 700;
            white-space: nowrap;
            text-decoration: none;
        }
        .home-view-link:hover { text-decoration: underline; }

        /* ---------- Event cards ---------- */
        .home-event-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 22px; }

        .home-event-card {
            display: block;
            overflow: hidden;
            border-radius: 18px;
            background: #fff;
            border: 1px solid var(--ev-line);
            color: inherit;
            text-decoration: none;
            transition: border-color .2s, box-shadow .2s;
        }
        .home-event-card:hover {
            border-color: var(--ev-teal-soft);
            box-shadow: 0 14px 34px rgba(7, 43, 45, .12);
        }

        .home-event-banner {
            position: relative;
            height: 168px;
            display: grid;
            place-items: center;
            overflow: hidden;
            color: #fff;
            background: linear-gradient(130deg, var(--ev-teal), var(--ev-teal-soft));
        }
        .home-event-banner::after {
            content: "";
            position: absolute;
            width: 210px;
            height: 210px;
            right: -60px;
            top: -90px;
            border-radius: 50%;
            background: rgba(255, 255, 255, .1);
        }
        .home-event-card:nth-child(3n+2) .home-event-banner { background: linear-gradient(130deg, #c9442b, var(--ev-coral)); }
        .home-event-card:nth-child(3n+3) .home-event-banner { background: linear-gradient(130deg, #1f7a68, #3fb69a); }

        .home-event-glyph {
            font-family: var(--ev-display);
            font-size: 52px;
            font-weight: 800;
            opacity: .9;
        }

        .home-event-date {
            position: absolute;
            z-index: 1;
            bottom: 12px;
            right: 12px;
            min-width: 54px;
            padding: 7px 10px;
            border-radius: 10px;
            background: #fff;
            color: var(--ev-ink);
            text-align: center;
            line-height: 1.1;
        }
        .home-event-date strong { display: block; font-family: var(--ev-display); font-size: 22px; font-weight: 800; }
        .home-event-date small { color: var(--ev-coral-dark); font-weight: 700; font-size: 11px; text-transform: uppercase; }

        .home-event-info { padding: 22px 22px 20px; }

        .home-event-category {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 999px;
            background: #e4f6ef;
            color: var(--ev-teal-soft);
            font-size: 12px;
            font-weight: 700;
        }
        .home-event-info h3 {
            margin: 12px 0 8px;
            font-family: var(--ev-display);
            font-size: 21px;
            font-weight: 800;
            letter-spacing: -.3px;
            color: var(--ev-ink);
        }
        .home-event-location { color: var(--ev-muted); font-size: 14px; line-height: 1.55; }

        .home-event-foot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 18px;
            padding-top: 16px;
            border-top: 1px solid var(--ev-line);
        }
        .home-event-foot strong { color: var(--ev-ink); font-size: 16px; }
        .home-event-foot span { color: var(--ev-coral-dark); font-size: 14px; font-weight: 700; }

        .home-event-empty {
            grid-column: 1 / -1;
            padding: 44px;
            background: #fff;
            border: 1px dashed var(--ev-line);
            border-radius: 16px;
            color: var(--ev-muted);
            text-align: center;
        }
        .home-event-empty a { color: var(--ev-teal-soft); font-weight: 700; }

        /* ---------- How it works ---------- */
        .home-how { background: #fff; border-top: 1px solid var(--ev-line); border-bottom: 1px solid var(--ev-line); }
        .home-steps { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 22px; }
        .home-step {
            padding: 28px;
            border-radius: 18px;
            background: var(--ev-paper);
            border: 1px solid var(--ev-line);
        }
        .home-step-number {
            display: grid;
            place-items: center;
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-family: var(--ev-display);
            font-size: 20px;
            font-weight: 800;
        }
        .home-step h3 {
            margin: 22px 0 8px;
            font-family: var(--ev-display);
            font-size: 22px;
            font-weight: 800;
            color: var(--ev-ink);
        }
        .home-step p { font-size: 15px; line-height: 1.65; color: var(--ev-muted); }

        /* ---------- CTA ---------- */
        .home-cta-wrap { padding: 80px 0 96px; }
        .home-cta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 28px;
            padding: 44px 50px;
            border-radius: 24px;
            color: #fff;
            background:
                radial-gradient(420px 260px at 100% 0%, rgba(255, 106, 77, .28), transparent 70%),
                linear-gradient(150deg, var(--ev-teal), var(--ev-deep));
        }
        .home-cta h2 {
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: clamp(26px, 3.2vw, 38px);
            letter-spacing: -.6px;
            color: #fff;
        }
        .home-cta p { margin-top: 8px; color: #b9d3cf; font-size: 16px; }

        /* ---------- Footer ---------- */
        .home-footer { padding: 26px 0; background: var(--ev-deep); }
        .home-footer-inner {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            font-size: 14px;
            color: #9fc2bd;
        }

        /* ---------- Responsive ---------- */
        @media (max-width: 1050px) {
            .home-hero-inner { grid-template-columns: 1fr; padding-top: 76px; gap: 70px; }
            .home-visual { width: min(80%, 420px); }
            .home-event-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 680px) {
            .home-hero-inner { padding-top: 60px; padding-bottom: 76px; gap: 48px; }
            .home-hero h1 { letter-spacing: -1px; }
            .home-visual { width: 88%; }
            .home-floating { display: none; }
            .home-hero-stats { gap: 18px; }
            .home-section { padding: 60px 0; }
            .home-section-heading { align-items: start; flex-direction: column; }
            .home-event-grid, .home-steps { grid-template-columns: 1fr; }
            .home-cta { flex-direction: column; align-items: flex-start; padding: 34px 26px; }
            .home-footer-inner { flex-direction: column; text-align: center; }
        }
        @media (prefers-reduced-motion: reduce) {
            * { transition: none !important; }
        }
    </style>
</head>
<body class="home">
    <header class="navbar">
        <div class="container nav-container">
            <a href="index.php" class="brand" aria-label="Eventify homepage">
                <div class="brand-icon">E</div>
                <span>Event<span class="brand-purple">ify</span></span>
            </a>
            <nav class="nav-links" aria-label="Main navigation">
                <a href="index.php" class="active">Home</a>
                <a href="events.php">Events</a>
                <a href="bookings.php">My Bookings</a>
            </nav>
            <!-- auth.js replaces these guest links when a valid JWT exists. -->
            <div class="nav-actions" id="authNavigation">
                <a href="login.php" class="sign-in">Sign In</a>
                <a href="register.php" class="nav-button">Create Account</a>
            </div>
        </div>
    </header>

    <main>
        <section class="home-hero">
            <div class="container home-hero-inner">
                <div>
                    <h1>Great moments.<span>Unforgettable experiences.</span></h1>
                    <p class="home-hero-intro">
                        Discover concerts, workshops, festivals and technology showcases.
                        Find the events you love and reserve your spot with Eventify.
                    </p>
                    <div class="home-hero-actions">
                        <a class="home-primary-button" href="events.php">Explore events</a>
                        <a class="home-secondary-button" href="#how-it-works">How it works</a>
                    </div>
                    <div class="home-hero-stats" aria-label="Eventify live totals">
                        <div><strong id="homeEventCount">—</strong><small>Events</small></div>
                        <div class="home-stat-separator"></div>
                        <div><strong id="homeVenueCount">—</strong><small>Venues</small></div>
                        <div class="home-stat-separator"></div>
                        <div><strong>24/7</strong><small>Event discovery</small></div>
                    </div>
                </div>
                <div class="home-visual" aria-hidden="true">
                    <div class="home-floating home-floating-left"><b>Discover</b> something new</div>
                    <div class="home-ticket">
                        <div class="home-ticket-art"><div class="home-ticket-symbol">E</div></div>
                        <div class="home-ticket-live">The Eventify experience</div>
                        <h2>Make your next memory.</h2>
                        <p>All your favourite moments, all in one place.</p>
                        <div class="home-ticket-bottom">
                            <div><small>Your next adventure</small><strong>Starts here</strong></div>
                            <div class="home-ticket-number">E / 26</div>
                        </div>
                    </div>
                    <div class="home-floating home-floating-right"><b>Easy</b> ticket booking</div>
                </div>
            </div>
        </section>

        <section class="home-section" id="featured-events">
            <div class="container">
                <div class="home-section-heading">
                    <div>
                        <h2>Coming up next</h2>
                        <p>Take a look at what's happening and find your next experience.</p>
                    </div>
                    <a class="home-view-link" href="events.php">View all events</a>
                </div>
                <div class="home-event-grid" id="homeFeaturedEvents" aria-live="polite">
                    <div class="home-event-empty">Loading upcoming events...</div>
                </div>
            </div>
        </section>

        <section class="home-section home-how" id="how-it-works">
            <div class="container">
                <div class="home-section-heading">
                    <div>
                        <h2>Easy from start to finish</h2>
                        <p>Everything you need to find events and manage your reservations.</p>
                    </div>
                </div>
                <div class="home-steps">
                    <article class="home-step"><div class="home-step-number">1</div><h3>Discover</h3><p>Explore upcoming events and find one that matches your interests.</p></article>
                    <article class="home-step"><div class="home-step-number">2</div><h3>Book your spot</h3><p>Choose the event and reserve your tickets with your customer account.</p></article>
                    <article class="home-step"><div class="home-step-number">3</div><h3>Manage bookings</h3><p>View booking details and keep track of your reservations in one place.</p></article>
                </div>
            </div>
        </section>

        <section class="home-cta-wrap">
            <div class="container">
                <div class="home-cta">
                    <div><h2>Ready to make some memories?</h2><p>Explore what's on and find an experience worth remembering.</p></div>
                    <a class="home-primary-button" href="events.php">Browse events</a>
                </div>
            </div>
        </section>
    </main>

    <footer class="home-footer">
        <div class="container home-footer-inner">
            <span>© 2026 Eventify. Event Ticketing &amp; Venue Booking System.</span>
            <span>Made for extraordinary experiences.</span>
        </div>
    </footer>

    <script>
    (function () {
        const featuredContainer = document.getElementById('homeFeaturedEvents');

        function escapeHTML(value) {
            return String(value ?? '')
                .replaceAll('&', '&amp;')
                .replaceAll('<', '&lt;')
                .replaceAll('>', '&gt;')
                .replaceAll('"', '&quot;')
                .replaceAll("'", '&#039;');
        }

        function formatPrice(value) {
            const price = Number(value);
            return Number.isFinite(price) ? 'RM ' + price.toFixed(2) : 'Price unavailable';
        }

        function formatDate(isoDate) {
            const date = new Date(String(isoDate) + 'T00:00:00');
            if (Number.isNaN(date.getTime())) return { day: '—', month: 'DATE' };
            return {
                day: date.toLocaleDateString('en-MY', { day: '2-digit' }),
                month: date.toLocaleDateString('en-MY', { month: 'short' })
            };
        }

        function displayFeatured(events) {
            const today = new Date();
            const todayString = today.getFullYear() + '-' +
                String(today.getMonth() + 1).padStart(2, '0') + '-' +
                String(today.getDate()).padStart(2, '0');

            const upcoming = events
                .filter(event => event.status === 'Upcoming' && String(event.event_date) >= todayString)
                .sort((a, b) => (String(a.event_date) + String(a.start_time)).localeCompare(String(b.event_date) + String(b.start_time)))
                .slice(0, 3);

            if (!upcoming.length) {
                featuredContainer.innerHTML = '<div class="home-event-empty">No upcoming events are available right now. Please check back soon.</div>';
                return;
            }

            const glyphs = ['✦', '{ }', '♫'];
            featuredContainer.innerHTML = upcoming.map((event, index) => {
                const eventId = Number(event.event_id);
                const safeId = Number.isSafeInteger(eventId) && eventId > 0 ? eventId : 0;
                const date = formatDate(event.event_date);
                const venue = event.venue_name || 'Venue to be confirmed';
                return `
                    <a href="${safeId ? 'event-details.php?event_id=' + safeId : 'events.php'}" class="home-event-card">
                        <div class="home-event-banner">
                            <span class="home-event-glyph">${glyphs[index % glyphs.length]}</span>
                            <span class="home-event-date"><strong>${escapeHTML(date.day)}</strong><small>${escapeHTML(date.month)}</small></span>
                        </div>
                        <div class="home-event-info">
                            <span class="home-event-category">${escapeHTML(event.category || 'Event')}</span>
                            <h3>${escapeHTML(event.event_name)}</h3>
                            <p class="home-event-location">${escapeHTML(venue)}${event.location ? ', ' + escapeHTML(event.location) : ''}</p>
                            <div class="home-event-foot"><strong>${formatPrice(event.ticket_price)}</strong><span>View event</span></div>
                        </div>
                    </a>`;
            }).join('');
        }

        async function loadHomeData() {
            const results = await Promise.allSettled([
                fetch('api/events.php').then(async response => {
                    if (!response.ok) throw new Error('Events request failed');
                    return response.json();
                }),
                fetch('api/venues.php').then(async response => {
                    if (!response.ok) throw new Error('Venues request failed');
                    return response.json();
                })
            ]);

            const [eventsResult, venuesResult] = results;
            if (eventsResult.status === 'fulfilled' &&
                eventsResult.value.status === 'success' &&
                Array.isArray(eventsResult.value.data)) {
                const events = eventsResult.value.data;
                document.getElementById('homeEventCount').textContent = events.length;
                displayFeatured(events);
            } else {
                featuredContainer.innerHTML = '<div class="home-event-empty">Events could not be loaded. <a href="events.php">Visit the Events page</a></div>';
            }

            if (venuesResult.status === 'fulfilled' &&
                venuesResult.value.status === 'success' &&
                Array.isArray(venuesResult.value.data)) {
                document.getElementById('homeVenueCount').textContent = venuesResult.value.data.length;
            }
        }

        loadHomeData().catch(() => {
            featuredContainer.innerHTML = '<div class="home-event-empty">Could not load events. Please try again later.</div>';
        });
    })();
    </script>
    <script src="js/auth.js"></script>
</body>
</html>