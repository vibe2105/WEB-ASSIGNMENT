<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Details | Eventify</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body.details-page {
            min-height: 100vh;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-family: var(--ev-body);
        }

        /* ---------- Navbar overrides ---------- */
        .details-page .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .details-page .navbar .brand,
        .details-page .navbar .brand span { color: #fff; }
        .details-page .navbar .brand-purple { color: var(--ev-coral); }
        .details-page .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .details-page .navbar .nav-links a { color: #b9d3cf; }
        .details-page .navbar .nav-links a:hover,
        .details-page .navbar .nav-links a.active { color: #fff; }
        .details-page .navbar .sign-in { color: #fff; }
        .details-page .navbar .nav-button {
            background: transparent;
            color: #fff;
            border: 1.5px solid rgba(255, 255, 255, .35);
            box-shadow: none;
        }
        .details-page .navbar .nav-button:hover {
            background: var(--ev-coral);
            border-color: var(--ev-coral);
            color: var(--ev-deep);
        }

        /* ---------- Hero ---------- */
        .details-hero {
            color: #fff;
            background:
                radial-gradient(560px 340px at 92% 0%, rgba(255, 106, 77, .24), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .details-hero-content { padding: 40px 0 56px; }

        .back-link {
            display: inline-block;
            margin-bottom: 30px;
            color: var(--ev-mint);
            font-size: 15px;
            font-weight: 700;
            text-decoration: none;
        }
        .back-link:hover { text-decoration: underline; }

        .hero-row {
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto;
            align-items: end;
            gap: 32px;
        }

        .details-category {
            display: inline-block;
            padding: 5px 13px;
            border-radius: 999px;
            background: rgba(168, 235, 211, .16);
            color: var(--ev-mint);
            font-size: 14px;
            font-weight: 700;
        }

        .details-title {
            margin-top: 16px;
            max-width: 780px;
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: clamp(36px, 5.4vw, 66px);
            line-height: 1.04;
            letter-spacing: -1.4px;
            color: #fff;
        }

        .details-short-info { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 24px; }
        .details-short-info div {
            padding: 8px 14px;
            border-radius: 999px;
            background: rgba(255, 255, 255, .08);
            border: 1px solid rgba(255, 255, 255, .14);
            color: #d3e5e2;
            font-size: 15px;
        }

        .hero-date {
            width: 120px;
            padding: 18px 10px;
            border-radius: 20px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            text-align: center;
            line-height: 1;
        }
        .hero-date small { display: block; font-size: 14px; font-weight: 700; }
        .hero-date b { display: block; margin: 6px 0 4px; font-family: var(--ev-display); font-size: 56px; font-weight: 800; }
        .hero-date span { font-size: 16px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; }

        /* ---------- Content ---------- */
        .details-content { padding: 48px 0 90px; }

        .details-layout {
            display: grid;
            grid-template-columns: minmax(0, 1.5fr) minmax(310px, .8fr);
            gap: 36px;
            align-items: start;
        }

        .details-main-card {
            padding: 34px 36px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 22px;
        }

        .detail-section + .detail-section {
            margin-top: 34px;
            padding-top: 34px;
            border-top: 2px dashed var(--ev-line);
        }
        .detail-section h2 {
            margin-bottom: 14px;
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: 28px;
            letter-spacing: -.5px;
            color: var(--ev-ink);
        }
        .detail-description { color: var(--ev-muted); font-size: 17px; line-height: 1.75; }
        .detail-description strong { color: var(--ev-ink); }

        .detail-info-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 22px 32px; }
        .detail-info-box { padding-left: 16px; border-left: 4px solid var(--ev-coral); }
        .detail-info-box:nth-child(3n+2) { border-left-color: var(--ev-teal-soft); }
        .detail-info-box:nth-child(3n+3) { border-left-color: var(--ev-mint); }
        .detail-info-box span { display: block; margin-bottom: 4px; color: var(--ev-muted); font-size: 14px; }
        .detail-info-box strong { font-size: 17px; font-weight: 700; line-height: 1.45; color: var(--ev-ink); }

        /* availability meter */
        .meter { margin: 18px 0 14px; height: 12px; border-radius: 999px; background: var(--ev-paper); border: 1px solid var(--ev-line); overflow: hidden; }
        .meter > div { height: 100%; border-radius: 999px; background: var(--ev-teal-soft); }
        .meter.low > div { background: var(--ev-coral); }

        /* ---------- Booking ticket ---------- */
        .booking-card {
            --stub: 124px;
            position: sticky;
            top: 104px;
            filter: drop-shadow(0 18px 30px rgba(7, 43, 45, .18));
        }
        .booking-card-inner {
            background: #fff;
            border-radius: 22px;
            overflow: hidden;
            -webkit-mask:
                radial-gradient(circle 14px at 0 var(--stub), #0000 98%, #000) left / 51% 100% no-repeat,
                radial-gradient(circle 14px at 100% var(--stub), #0000 98%, #000) right / 51% 100% no-repeat;
            mask:
                radial-gradient(circle 14px at 0 var(--stub), #0000 98%, #000) left / 51% 100% no-repeat,
                radial-gradient(circle 14px at 100% var(--stub), #0000 98%, #000) right / 51% 100% no-repeat;
        }
        .booking-card-top {
            height: var(--stub);
            padding: 0 30px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            color: #fff;
            background: linear-gradient(150deg, var(--ev-teal), var(--ev-deep));
            border-bottom: 2px dashed rgba(255, 255, 255, .4);
        }
        .booking-card-top span { color: #9fc2bd; font-size: 15px; margin-bottom: 4px; }
        .booking-price {
            font-family: var(--ev-display);
            font-size: 42px;
            font-weight: 800;
            letter-spacing: -1px;
            color: var(--ev-mint);
            line-height: 1.1;
        }

        .booking-card-body { padding: 14px 30px 30px; }

        .booking-row {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            padding: 13px 0;
            border-bottom: 1px solid #e8f0ee;
            font-size: 15px;
        }
        .booking-row span { color: var(--ev-muted); }
        .booking-row strong { text-align: right; font-weight: 700; color: var(--ev-ink); }

        .availability {
            margin-top: 18px;
            padding: 12px 14px;
            border-radius: 12px;
            background: #e4f6ef;
            color: #0f6446;
            font-size: 15px;
            font-weight: 700;
            text-align: center;
        }
        .availability.warn { background: #fff1ef; color: #a1301d; }

        .book-now-btn {
            width: 100%;
            margin-top: 16px;
            padding: 16px;
            border: none;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 17px var(--ev-body);
            cursor: pointer;
            transition: background .2s, transform .15s;
        }
        .book-now-btn:hover { background: var(--ev-coral-dark); }
        .book-now-btn:active { transform: translateY(1px); }
        .book-now-btn:disabled { background: var(--ev-line); color: var(--ev-muted); cursor: not-allowed; }

        .booking-note { margin-top: 12px; color: var(--ev-muted); font-size: 14px; text-align: center; }

        /* ---------- States ---------- */
        .loading-detail, .detail-error {
            min-height: 260px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            text-align: center;
            color: var(--ev-muted);
            font-size: 16px;
        }
        .details-hero .loading-detail { min-height: 120px; align-items: flex-start; text-align: left; color: #b9d3cf; }
        .detail-error h2 { font-family: var(--ev-display); font-size: 30px; font-weight: 800; color: var(--ev-ink); }
        .detail-error a { color: var(--ev-teal-soft); font-weight: 700; }

        .book-now-btn:focus-visible,
        .back-link:focus-visible {
            outline: 3px solid var(--ev-mint);
            outline-offset: 3px;
        }

        /* ---------- Footer ---------- */
        .ev-footer { color: #b9d3cf; background: linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%); }
        .ev-footer-top {
            display: grid;
            grid-template-columns: minmax(0, 1.6fr) repeat(2, minmax(0, 1fr));
            gap: 48px;
            padding: 60px 0 44px;
        }
        .ev-footer-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            text-decoration: none;
        }
        .ev-footer-mark {
            width: 38px;
            height: 38px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-size: 20px;
        }
        .ev-footer-brand em { font-style: normal; color: var(--ev-coral); }
        .ev-footer-about { margin-top: 16px; max-width: 340px; font-size: 15px; line-height: 1.65; color: #9fc2bd; }
        .ev-footer h3 { font-family: var(--ev-display); font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 14px; }
        .ev-footer ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 10px; }
        .ev-footer ul a { color: #b9d3cf; font-size: 15px; text-decoration: none; }
        .ev-footer ul a:hover { color: #fff; text-decoration: underline; }
        .ev-footer a:focus-visible { outline: 3px solid var(--ev-mint); outline-offset: 3px; border-radius: 4px; }
        .ev-footer-bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px 24px;
            padding: 22px 0 28px;
            border-top: 2px dashed rgba(255, 255, 255, .2);
            font-size: 14px;
            color: #9fc2bd;
        }

        /* ---------- Responsive ---------- */
        @media (max-width: 900px) {
            .details-layout { grid-template-columns: 1fr; }
            .booking-card { position: static; }
            .ev-footer-top { grid-template-columns: 1fr 1fr; }
            .ev-footer-top > div:first-child { grid-column: 1 / -1; }
        }
        @media (max-width: 640px) {
            .hero-row { grid-template-columns: 1fr; gap: 24px; }
            .hero-date { order: -1; width: auto; display: inline-flex; align-items: baseline; gap: 10px; padding: 12px 18px; justify-self: start; border-radius: 14px; }
            .hero-date b { margin: 0; font-size: 34px; }
            .detail-info-grid { grid-template-columns: 1fr; }
            .details-main-card { padding: 26px 22px; }
            .ev-footer-top { padding: 44px 0 32px; gap: 32px 24px; }
        }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
    </style>
</head>

<body class="details-page">

<!-- NAVIGATION -->
<header class="navbar">
    <div class="container nav-container">

        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>

        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="events.php" class="active">Events</a>
            <a href="bookings.php">My Bookings</a>
        </nav>

        <div class="nav-actions" id="authNavigation">
            <a href="login.php" class="sign-in">Sign In</a>
            <a href="register.php" class="nav-button">Create Account</a>
        </div>

    </div>
</header>


<!-- HERO -->
<section class="details-hero">
    <div class="container details-hero-content">

        <a href="events.php" class="back-link">← Back to events</a>

        <div id="heroContent">
            <div class="loading-detail">Loading event details...</div>
        </div>

    </div>
</section>


<!-- EVENT INFORMATION -->
<main class="details-content">
    <div class="container">

        <div id="detailsContainer">
            <div class="loading-detail">Loading event information...</div>
        </div>

    </div>
</main>


<!-- FOOTER -->
<footer class="ev-footer">
    <div class="container">

        <div class="ev-footer-top">

            <div>
                <a href="index.php" class="ev-footer-brand">
                    <span class="ev-footer-mark">E</span>
                    <span>Event<em>ify</em></span>
                </a>
                <p class="ev-footer-about">
                    Find events, book tickets and keep every reservation in one place.
                </p>
            </div>

            <div>
                <h3>Explore</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="events.php">All events</a></li>
                    <li><a href="index.php#how-it-works">How it works</a></li>
                </ul>
            </div>

            <div>
                <h3>Your account</h3>
                <ul>
                    <li><a href="login.php">Sign in</a></li>
                    <li><a href="register.php">Create account</a></li>
                    <li><a href="bookings.php">My bookings</a></li>
                </ul>
            </div>

        </div>

        <div class="ev-footer-bottom">
            <span>© 2026 Eventify</span>
            <span>Event Ticketing &amp; Venue Booking System</span>
        </div>

    </div>
</footer>


<script>

/* =====================================
   GET EVENT ID FROM URL
   (accepts ?event_id=5 and the older ?id=5)
===================================== */

const params = new URLSearchParams(window.location.search);

const eventId = params.get("event_id") || params.get("id");

const heroContent = document.getElementById("heroContent");
const detailsContainer = document.getElementById("detailsContainer");


/* =====================================
   LOAD EVENT
===================================== */

async function loadEventDetails() {

    if (!eventId) {
        showError("No event was selected.");
        return;
    }

    try {

        const response = await fetch(
            "api/events.php?event_id=" + encodeURIComponent(eventId)
        );

        const result = await response.json();

        if (!response.ok || result.status !== "success") {
            showError(result.message || "Event not found.");
            return;
        }

        displayEvent(result.data);

    } catch (error) {

        console.error(error);

        showError("Unable to connect to the server.");
    }
}


/* =====================================
   DISPLAY EVENT
===================================== */

function displayEvent(event) {

    document.title = event.event_name + " | Eventify";

    const eventDate = new Date(event.event_date + "T00:00:00");

    const formattedDate = eventDate.toLocaleDateString("en-MY", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric"
    });

    const heroWeekday = eventDate.toLocaleDateString("en-MY", { weekday: "short" });
    const heroDay = eventDate.toLocaleDateString("en-MY", { day: "2-digit" });
    const heroMonth = eventDate.toLocaleDateString("en-MY", { month: "short" });

    const startTime = formatTime(event.start_time);
    const endTime = formatTime(event.end_time);

    const available = Number(event.available_tickets);
    const total = Number(event.total_tickets);

    const soldOut = !(available > 0);
    const closed = event.status === "Cancelled" || event.status === "Completed";
    const canBook = !soldOut && !closed;

    const percentLeft = total > 0
        ? Math.max(0, Math.min(100, Math.round((available / total) * 100)))
        : 0;

    const isLow = percentLeft <= 20;

    let availabilityText = "✓ Tickets are currently available";
    let availabilityClass = "availability";
    let buttonLabel = "Book ticket";
    let noteText = "You will confirm your ticket quantity before booking.";

    if (closed) {
        availabilityText = "This event is " + String(event.status).toLowerCase();
        availabilityClass += " warn";
        buttonLabel = "Booking closed";
        noteText = "Booking is not available for this event.";
    } else if (soldOut) {
        availabilityText = "Sold out";
        availabilityClass += " warn";
        buttonLabel = "Sold out";
        noteText = "All tickets for this event have been booked.";
    }

    heroContent.innerHTML = `

        <div class="hero-row">

            <div>

                <span class="details-category">${escapeHTML(event.category)}</span>

                <h1 class="details-title">${escapeHTML(event.event_name)}</h1>

                <div class="details-short-info">
                    <div>${escapeHTML(formattedDate)}</div>
                    <div>${escapeHTML(event.venue_name)}</div>
                    <div>${escapeHTML(event.status)}</div>
                </div>

            </div>

            <div class="hero-date" aria-hidden="true">
                <small>${escapeHTML(heroWeekday)}</small>
                <b>${escapeHTML(heroDay)}</b>
                <span>${escapeHTML(heroMonth)}</span>
            </div>

        </div>

    `;

    detailsContainer.innerHTML = `

        <div class="details-layout">

            <!-- LEFT CONTENT -->
            <section class="details-main-card">

                <div class="detail-section">

                    <h2>About this event</h2>

                    <p class="detail-description">
                        ${escapeHTML(
                            event.description ||
                            "No description is currently available for this event."
                        )}
                    </p>

                </div>

                <div class="detail-section">

                    <h2>When &amp; where</h2>

                    <div class="detail-info-grid">

                        <div class="detail-info-box">
                            <span>Date</span>
                            <strong>${escapeHTML(formattedDate)}</strong>
                        </div>

                        <div class="detail-info-box">
                            <span>Time</span>
                            <strong>${escapeHTML(startTime)} to ${escapeHTML(endTime)}</strong>
                        </div>

                        <div class="detail-info-box">
                            <span>Venue</span>
                            <strong>${escapeHTML(event.venue_name)}</strong>
                        </div>

                        <div class="detail-info-box">
                            <span>Location</span>
                            <strong>${escapeHTML(event.location)}</strong>
                        </div>

                        <div class="detail-info-box">
                            <span>Organised by</span>
                            <strong>${escapeHTML(event.organiser_name)}</strong>
                        </div>

                        <div class="detail-info-box">
                            <span>Venue capacity</span>
                            <strong>${Number(event.capacity).toLocaleString()} people</strong>
                        </div>

                    </div>

                </div>

                <div class="detail-section">

                    <h2>Availability</h2>

                    <div class="meter ${isLow ? "low" : ""}" role="img"
                         aria-label="${percentLeft}% of tickets remaining">
                        <div style="width:${percentLeft}%"></div>
                    </div>

                    <p class="detail-description">
                        This event currently has
                        <strong>${available.toLocaleString()}</strong>
                        tickets available out of
                        <strong>${total.toLocaleString()}</strong>
                        total tickets.
                    </p>

                </div>

            </section>

            <!-- BOOKING CARD -->
            <aside class="booking-card">

                <div class="booking-card-inner">

                    <div class="booking-card-top">
                        <span>Ticket price</span>
                        <div class="booking-price">RM ${Number(event.ticket_price).toFixed(2)}</div>
                    </div>

                    <div class="booking-card-body">

                        <div class="booking-row">
                            <span>Event</span>
                            <strong>${escapeHTML(event.event_name)}</strong>
                        </div>

                        <div class="booking-row">
                            <span>Date</span>
                            <strong>${escapeHTML(formattedDate)}</strong>
                        </div>

                        <div class="booking-row">
                            <span>Venue</span>
                            <strong>${escapeHTML(event.venue_name)}</strong>
                        </div>

                        <div class="booking-row">
                            <span>Available</span>
                            <strong>${available.toLocaleString()} tickets</strong>
                        </div>

                        <div class="${availabilityClass}">${escapeHTML(availabilityText)}</div>

                        <button
                            type="button"
                            class="book-now-btn"
                            ${canBook ? "" : "disabled"}
                            onclick="startBooking(${Number(event.event_id)})"
                        >
                            ${escapeHTML(buttonLabel)}
                        </button>

                        <p class="booking-note">${escapeHTML(noteText)}</p>

                    </div>

                </div>

            </aside>

        </div>

    `;
}


/* =====================================
   BOOKING BUTTON
===================================== */

function startBooking(eventId) {

    window.location.href = "book-ticket.php?event_id=" + eventId;
}


/* =====================================
   FORMAT TIME
===================================== */

function formatTime(time) {

    const match = /^(\d{1,2}):(\d{2})/.exec(String(time || ""));

    if (!match) {
        return "Unavailable";
    }

    const hour = Number(match[1]);

    return ((hour % 12) || 12) + ":" + match[2] + " " + (hour >= 12 ? "PM" : "AM");
}


/* =====================================
   SHOW ERROR
===================================== */

function showError(message) {

    heroContent.innerHTML = `
        <h1 class="details-title">Event unavailable</h1>
    `;

    detailsContainer.innerHTML = `
        <div class="detail-error">
            <h2>We couldn't load this event.</h2>
            <p>${escapeHTML(message)}</p>
            <a href="events.php">← Return to events</a>
        </div>
    `;
}


/* =====================================
   ESCAPE HTML
===================================== */

function escapeHTML(value) {

    if (value === null || value === undefined) {
        return "";
    }

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


/* =====================================
   START PAGE
===================================== */

loadEventDetails();

</script>

<script src="js/auth.js"></script>

</body>
</html>