<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In | Eventify</title>
 
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;700&display=swap" rel="stylesheet">
 
    <link rel="stylesheet" href="css/style.css">
 
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }
 
        .login-page {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background: var(--ev-paper);
            font-family: var(--ev-body);
        }
 
        /* ---------- Navbar (colour overrides only, markup unchanged) ---------- */
        .login-page .navbar {
            background: var(--ev-deep);
            border: 0;
            box-shadow: none;
            position: relative;
        }
        .login-page .navbar .brand,
        .login-page .navbar .brand span { color: #fff; }
        .login-page .navbar .brand-purple { color: var(--ev-coral); }
        .login-page .navbar .brand-icon {
            background: var(--ev-coral);
            color: var(--ev-deep);
        }
        .login-page .navbar .nav-links a { color: #b9d3cf; }
        .login-page .navbar .nav-links a:hover { color: #fff; }
        .login-page .navbar .nav-button {
            background: transparent;
            color: #fff;
            border: 1.5px solid rgba(255, 255, 255, .35);
            box-shadow: none;
        }
        .login-page .navbar .nav-button:hover {
            background: var(--ev-coral);
            border-color: var(--ev-coral);
            color: var(--ev-deep);
        }
 
        /* ---------- Split layout ---------- */
        .login-split {
            flex: 1;
            display: grid;
            grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr);
        }
 
        /* ---------- Left: what's coming up ---------- */
        .login-showcase {
            position: relative;
            padding: 72px 64px 72px max(32px, calc((100vw - 1180px) / 2));
            color: #fff;
            background:
                radial-gradient(520px 380px at 100% 0%, rgba(255, 106, 77, .22), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
 
        .login-showcase h1 {
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: clamp(38px, 4.6vw, 62px);
            line-height: 1.06;
            letter-spacing: -1.2px;
            max-width: 560px;
        }
 
        .login-showcase > p {
            margin-top: 18px;
            max-width: 440px;
            color: #b9d3cf;
            font-size: 17px;
            line-height: 1.65;
        }
 
        .coming-up {
            list-style: none;
            margin: 44px 0 0;
            padding: 0;
            max-width: 520px;
            display: grid;
            gap: 12px;
        }
 
        .coming-up li {
            display: grid;
            grid-template-columns: 64px 1fr auto;
            align-items: center;
            gap: 18px;
            padding: 12px 18px 12px 12px;
            border-radius: 16px;
            background: rgba(255, 255, 255, .07);
            border: 1px solid rgba(255, 255, 255, .1);
        }
 
        .event-date {
            width: 64px;
            height: 64px;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            line-height: 1;
        }
 
        .event-date b {
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
        }
 
        .event-date small {
            margin-top: 3px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: .5px;
        }
 
        .event-info strong {
            display: block;
            font-size: 16px;
            font-weight: 700;
        }
 
        .event-info span {
            display: block;
            margin-top: 3px;
            color: #9fc2bd;
            font-size: 13px;
        }
 
        .event-price {
            color: var(--ev-mint);
            font-weight: 700;
            font-size: 15px;
            white-space: nowrap;
        }
 
        /* ---------- Right: form ---------- */
        .login-panel {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 56px 32px;
            background: #fff;
        }
 
        .login-card {
            width: 100%;
            max-width: 400px;
        }
 
        .login-card h2 {
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: 38px;
            letter-spacing: -.8px;
            color: var(--ev-ink);
        }
 
        .login-card > p {
            margin-top: 8px;
            color: var(--ev-muted);
            font-size: 15px;
        }
 
        #loginForm { margin-top: 32px; }
 
        .login-form-group { margin-bottom: 20px; }
 
        .login-form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--ev-ink);
            font-size: 14px;
            font-weight: 700;
        }
 
        .login-input-wrap { position: relative; }
 
        .login-input {
            width: 100%;
            height: 54px;
            padding: 0 70px 0 16px;
            border: 1.5px solid var(--ev-line);
            border-radius: 12px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font: 500 16px var(--ev-body);
            outline: none;
            transition: border-color .2s, box-shadow .2s, background .2s;
        }
 
        .login-input::placeholder { color: #98aaac; }
 
        .login-input:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 4px rgba(20, 102, 106, .15);
        }
 
        .password-toggle {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            padding: 8px 12px;
            border: none;
            border-radius: 8px;
            background: transparent;
            color: var(--ev-teal-soft);
            font: 700 14px var(--ev-body);
            cursor: pointer;
        }
 
        .password-toggle:hover { background: rgba(20, 102, 106, .1); }
 
        .password-toggle:focus-visible,
        .login-submit:focus-visible,
        .register-link a:focus-visible {
            outline: 3px solid var(--ev-teal-soft);
            outline-offset: 2px;
        }
 
        .login-submit {
            width: 100%;
            height: 56px;
            margin-top: 6px;
            border: none;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 17px var(--ev-body);
            cursor: pointer;
            transition: background .2s, transform .15s;
        }
 
        .login-submit:hover { background: var(--ev-coral-dark); }
        .login-submit:active { transform: translateY(1px); }
        .login-submit:disabled { opacity: .6; cursor: not-allowed; }
 
        /* ---------- Messages ---------- */
        .login-message {
            display: none;
            margin-top: 16px;
            padding: 13px 15px;
            border-radius: 10px;
            font-size: 14px;
            line-height: 1.5;
        }
 
        .login-message.error {
            display: block;
            background: #fff1ef;
            border: 1px solid #ffd2ca;
            color: #a1301d;
        }
 
        .login-message.success {
            display: block;
            background: #e9f8f1;
            border: 1px solid #c3e9d8;
            color: #0f6446;
        }
 
        .register-link {
            margin-top: 28px;
            padding-top: 24px;
            border-top: 1px solid var(--ev-line);
            text-align: center;
            color: var(--ev-muted);
            font-size: 15px;
        }
 
        .register-link a {
            color: var(--ev-teal-soft);
            font-weight: 700;
            text-decoration: none;
        }
 
        .register-link a:hover { text-decoration: underline; }
 
        /* ---------- Responsive ---------- */
        @media (max-width: 960px) {
            .login-split { grid-template-columns: 1fr; }
 
            .login-showcase {
                padding: 44px 28px 40px;
                text-align: center;
                align-items: center;
            }
            .login-showcase > p { margin-left: auto; margin-right: auto; }
            .coming-up { display: none; }
            .login-panel { padding: 44px 24px 56px; }
        }
 
        @media (prefers-reduced-motion: reduce) {
            * { transition: none !important; }
        }
    </style>
</head>
 
<body class="login-page">
 
<!-- NAVBAR -->
<header class="navbar">
    <div class="container nav-container">
 
        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>
 
        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="events.php">Events</a>
            <a href="bookings.php">My Bookings</a>
        </nav>
 
        <div class="nav-actions">
            <a href="register.php" class="nav-button">Create Account</a>
        </div>
 
    </div>
</header>
 
<!-- LOGIN -->
<main class="login-split">
 
    <section class="login-showcase">
        <h1>Good seats go fast. Sign in and pick yours.</h1>
 
        <p>
            Book tickets, track your bookings and see what is
            happening near you, all from one account.
        </p>
 
        <ul class="coming-up" aria-label="Upcoming events">
            <li>
                <div class="event-date"><b>10</b><small>NOV</small></div>
                <div class="event-info">
                    <strong>Tech Innovation Expo 2026</strong>
                    <span>Grand Convention Hall, Kuala Lumpur</span>
                </div>
                <div class="event-price">RM 50</div>
            </li>
            <li>
                <div class="event-date"><b>01</b><small>DEC</small></div>
                <div class="event-info">
                    <strong>Music Festival 2026</strong>
                    <span>Event Arena A, Bukit Jalil</span>
                </div>
                <div class="event-price">RM 100</div>
            </li>
            <li>
                <div class="event-date"><b>20</b><small>DEC</small></div>
                <div class="event-info">
                    <strong>Food Festival Malaysia</strong>
                    <span>Outdoor Event Space, Putrajaya</span>
                </div>
                <div class="event-price">RM 10</div>
            </li>
        </ul>
    </section>
 
    <section class="login-panel">
        <div class="login-card">
 
            <h2>Sign in</h2>
            <p>Use the email and password for your Eventify account.</p>
 
            <form id="loginForm" novalidate>
 
                <div class="login-form-group">
                    <label for="email">Email address</label>
                    <div class="login-input-wrap">
                        <input
                            type="email"
                            id="email"
                            class="login-input"
                            placeholder="you@example.com"
                            autocomplete="email"
                        >
                    </div>
                </div>
 
                <div class="login-form-group">
                    <label for="password">Password</label>
                    <div class="login-input-wrap">
                        <input
                            type="password"
                            id="password"
                            class="login-input"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                        >
                        <button type="button" class="password-toggle" id="passwordToggle">Show</button>
                    </div>
                </div>
 
                <button type="submit" class="login-submit" id="loginButton">Sign in</button>
 
                <div class="login-message" id="loginMessage" role="alert"></div>
 
            </form>
 
            <div class="register-link">
                New to Eventify?
                <a href="register.php">Create an account</a>
            </div>
 
        </div>
    </section>
 
</main>
 
 
<script>
 
/* ==========================================
   ELEMENTS
========================================== */
 
const loginForm = document.getElementById("loginForm");
const loginButton = document.getElementById("loginButton");
const loginMessage = document.getElementById("loginMessage");
const passwordInput = document.getElementById("password");
const passwordToggle = document.getElementById("passwordToggle");
 
 
/* ==========================================
   REGISTER SUCCESS MESSAGE
========================================== */
 
const params = new URLSearchParams(window.location.search);
 
if (params.get("registered") === "1") {
    showMessage("✓ Account created successfully. Please sign in.", "success");
}
 
 
/* ==========================================
   PASSWORD TOGGLE
========================================== */
 
passwordToggle.addEventListener("click", function () {
 
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        passwordToggle.textContent = "Hide";
    } else {
        passwordInput.type = "password";
        passwordToggle.textContent = "Show";
    }
 
});
 
 
/* ==========================================
   LOGIN
========================================== */
 
loginForm.addEventListener("submit", async function (event) {
 
    event.preventDefault();
 
    const email = document.getElementById("email").value.trim();
    const password = passwordInput.value;
 
    if (email === "" || password === "") {
        showMessage("Please enter your email and password.", "error");
        return;
    }
 
    loginButton.disabled = true;
    loginButton.textContent = "Signing in...";
 
    try {
 
        const response = await fetch("auth/login.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: email, password: password })
        });
 
        const result = await response.json();
 
        if (response.ok && result.status === "success") {
 
            /* STORE JWT */
            localStorage.setItem("eventify_token", result.token);
 
            /* STORE BASIC USER */
            localStorage.setItem("eventify_user", JSON.stringify(result.user));
 
            showMessage("✓ Signed in. Redirecting...", "success");
            loginButton.textContent = "Signed in ✓";
 
            setTimeout(function () {
 
                /* ROLE REDIRECTION */
                if (
                    result.user.role === "Administrator" ||
                    result.user.role === "Organiser"
                ) {
                    window.location.href = "dashboard.php";
                } else {
                    window.location.href = "events.php";
                }
 
            }, 1000);
 
        } else {
            throw new Error(result.message || "Login failed");
        }
 
    } catch (error) {
 
        showMessage(error.message, "error");
        loginButton.disabled = false;
        loginButton.textContent = "Sign in";
 
    }
 
});
 
 
/* ==========================================
   MESSAGE
========================================== */
 
function showMessage(message, type) {
    loginMessage.textContent = message;
    loginMessage.className = "login-message " + type;
}
 
</script>
 
<script src="js/auth.js"></script>
 
</body>
</html>