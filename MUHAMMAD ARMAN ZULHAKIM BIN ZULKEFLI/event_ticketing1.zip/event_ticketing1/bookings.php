<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings | Eventify</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body.bookings-page {
            min-height: 100vh;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-family: var(--ev-body);
        }

        /* ---------- Navbar overrides ---------- */
        .bookings-page .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .bookings-page .navbar .brand,
        .bookings-page .navbar .brand span { color: #fff; }
        .bookings-page .navbar .brand-purple { color: var(--ev-coral); }
        .bookings-page .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .bookings-page .navbar .nav-links a { color: #b9d3cf; }
        .bookings-page .navbar .nav-links a:hover,
        .bookings-page .navbar .nav-links a.active { color: #fff; }
        .top-user { font-size: 14px; font-weight: 700; color: #b9d3cf; }
        .top-logout {
            padding: 10px 18px;
            border: none;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 14px var(--ev-body);
            cursor: pointer;
            transition: background .2s;
        }
        .top-logout:hover { background: var(--ev-coral-dark); }

        /* ---------- Header ---------- */
        .bookings-hero {
            padding: 54px 0 58px;
            color: #fff;
            background:
                radial-gradient(520px 300px at 92% 0%, rgba(255, 106, 77, .24), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .bookings-hero h1 {
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: clamp(36px, 4.6vw, 56px);
            letter-spacing: -1.2px;
            line-height: 1.05;
        }
        .bookings-hero p { margin-top: 12px; color: #b9d3cf; font-size: 17px; }

        .bookings-section { padding: 36px 0 90px; }

        /* ---------- Tabs ---------- */
        .bookings-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 26px;
        }
        .booking-tabs { display: flex; flex-wrap: wrap; gap: 8px; }
        .booking-tab {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 16px;
            border: 1.5px solid var(--ev-line);
            border-radius: 999px;
            background: #fff;
            color: var(--ev-ink);
            font: 500 15px var(--ev-body);
            cursor: pointer;
            transition: background .15s, border-color .15s;
        }
        .booking-tab:hover { border-color: var(--ev-teal-soft); }
        .booking-tab small {
            min-width: 22px;
            padding: 1px 7px;
            border-radius: 999px;
            background: var(--ev-paper);
            color: var(--ev-muted);
            font-size: 13px;
            font-weight: 700;
            text-align: center;
        }
        .booking-tab[aria-pressed="true"] {
            background: var(--ev-deep);
            border-color: var(--ev-deep);
            color: #fff;
            font-weight: 700;
        }
        .booking-tab[aria-pressed="true"] small { background: var(--ev-coral); color: var(--ev-deep); }

        .booking-count { color: var(--ev-muted); font-size: 15px; }
        .booking-count strong { font-family: var(--ev-display); font-size: 22px; font-weight: 800; color: var(--ev-ink); }

        .booking-tab:focus-visible,
        .receipt-btn:focus-visible,
        .cancel-btn:focus-visible,
        .browse-btn:focus-visible,
        .modal-actions button:focus-visible,
        .top-logout:focus-visible {
            outline: 3px solid var(--ev-teal-soft);
            outline-offset: 2px;
        }

        /* ---------- Booking pass ---------- */
        .bookings-grid { display: grid; gap: 20px; }

        .booking-item {
            filter: drop-shadow(0 8px 18px rgba(7, 43, 45, .1));
        }
        .booking-item.cancelled { opacity: .7; }

        .booking-pass {
            --stub: 250px;
            display: grid;
            grid-template-columns: minmax(0, 1fr) var(--stub);
            background: #fff;
            border-radius: 20px;
            -webkit-mask:
                radial-gradient(circle 13px at calc(100% - var(--stub)) 0, #0000 98%, #000) top / 100% 51% no-repeat,
                radial-gradient(circle 13px at calc(100% - var(--stub)) 100%, #0000 98%, #000) bottom / 100% 51% no-repeat;
            mask:
                radial-gradient(circle 13px at calc(100% - var(--stub)) 0, #0000 98%, #000) top / 100% 51% no-repeat,
                radial-gradient(circle 13px at calc(100% - var(--stub)) 100%, #0000 98%, #000) bottom / 100% 51% no-repeat;
        }

        .booking-info { padding: 26px 30px; min-width: 0; }

        .booking-top { display: flex; flex-wrap: wrap; align-items: center; gap: 12px; }
        .booking-id { color: var(--ev-muted); font-size: 14px; font-weight: 500; }

        .status {
            padding: 4px 11px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 700;
        }
        .confirmed { color: #0f6446; background: #e4f6ef; }
        .cancelled-status { color: #a1301d; background: #fff1ef; }
        .pending { color: #7a5a00; background: #fff4d6; }

        .booking-info h3 {
            margin: 12px 0 20px;
            font-family: var(--ev-display);
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -.5px;
            color: var(--ev-ink);
        }

        .booking-details {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, auto));
            justify-content: start;
            gap: 14px 40px;
        }
        .booking-details div small { display: block; color: var(--ev-muted); font-size: 13px; }
        .booking-details div strong { display: block; margin-top: 3px; font-size: 16px; font-weight: 700; color: var(--ev-ink); }

        .booking-side {
            padding: 24px 26px;
            border-left: 2px dashed var(--ev-line);
            display: flex;
            flex-direction: column;
            justify-content: center;
            gap: 4px;
        }
        .booking-side small { color: var(--ev-muted); font-size: 14px; }
        .booking-side > strong {
            font-family: var(--ev-display);
            font-size: 30px;
            font-weight: 800;
            letter-spacing: -.5px;
            color: var(--ev-ink);
        }
        .cancelled .booking-side > strong { text-decoration: line-through; color: var(--ev-muted); }

        .receipt-btn {
            display: block;
            width: 100%;
            margin-top: 14px;
            padding: 12px 14px;
            border: 0;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 15px var(--ev-body);
            cursor: pointer;
            transition: background .2s;
        }
        .receipt-btn:hover { background: var(--ev-coral-dark); }
        .receipt-btn:disabled { opacity: .7; cursor: not-allowed; }

        .cancel-btn {
            margin-top: 10px;
            padding: 10px 14px;
            border: 1.5px solid #f2c6bd;
            border-radius: 12px;
            background: transparent;
            color: #a1301d;
            font: 700 14px var(--ev-body);
            cursor: pointer;
            transition: background .2s;
        }
        .cancel-btn:hover { background: #fff1ef; }

        /* ---------- Empty state ---------- */
        .empty-state {
            min-height: 260px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            text-align: center;
            background: #fff;
            border: 1px dashed var(--ev-line);
            border-radius: 20px;
            color: var(--ev-muted);
            font-size: 16px;
        }
        .empty-state h3 { margin-bottom: 6px; font-family: var(--ev-display); font-size: 26px; font-weight: 800; color: var(--ev-ink); }
        .browse-btn {
            margin-top: 18px;
            padding: 13px 22px;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-weight: 700;
            text-decoration: none;
        }
        .browse-btn:hover { background: var(--ev-coral-dark); }

        /* ---------- Cancel modal ---------- */
        .modal {
            position: fixed;
            inset: 0;
            z-index: 5000;
            display: none;
            align-items: center;
            justify-content: center;
            background: rgba(4, 22, 23, .7);
            backdrop-filter: blur(5px);
        }
        .modal.show { display: flex; }
        .modal-card {
            width: min(420px, 90%);
            padding: 32px;
            text-align: center;
            background: #fff;
            border-radius: 22px;
        }
        .modal-card h2 { font-family: var(--ev-display); font-size: 28px; font-weight: 800; color: var(--ev-ink); }
        .modal-card p { margin-top: 10px; color: var(--ev-muted); font-size: 15px; line-height: 1.6; }
        .modal-actions { display: flex; gap: 10px; margin-top: 26px; }
        .modal-actions button {
            flex: 1;
            padding: 13px;
            border: none;
            border-radius: 12px;
            font: 700 15px var(--ev-body);
            cursor: pointer;
        }
        .modal-actions button:disabled { opacity: .6; cursor: not-allowed; }
        .keep-btn { background: var(--ev-paper); color: var(--ev-ink); }
        .keep-btn:hover { background: #e6efec; }
        .confirm-cancel { background: #c24329; color: #fff; }
        .confirm-cancel:hover { background: #a93820; }

        /* ---------- Responsive ---------- */
        @media (max-width: 800px) {
            .booking-item { filter: none; }
            .booking-pass {
                grid-template-columns: 1fr;
                -webkit-mask: none;
                mask: none;
                border: 1px solid var(--ev-line);
            }
            .booking-side {
                border-left: 0;
                border-top: 2px dashed var(--ev-line);
            }
            .booking-details { grid-template-columns: repeat(2, minmax(0, auto)); }
        }
        @media (max-width: 480px) {
            .booking-info { padding: 22px 20px; }
            .booking-side { padding: 20px; }
            .booking-details { grid-template-columns: 1fr; }
        }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
    </style>
</head>

<body class="bookings-page">

<header class="navbar">
    <div class="container nav-container">

        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>

        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="events.php">Events</a>
            <a href="bookings.php" class="active">My Bookings</a>
        </nav>

        <div class="nav-actions" id="authNavigation"></div>

    </div>
</header>


<section class="bookings-hero">
    <div class="container">
        <h1>My bookings</h1>
        <p id="welcomeText">Loading your reservations...</p>
    </div>
</section>


<main class="bookings-section">
    <div class="container">

        <div class="bookings-header">

            <div class="booking-tabs" id="bookingTabs" role="group" aria-label="Filter bookings by status" hidden>
                <button type="button" class="booking-tab" data-filter="all" aria-pressed="true">All <small id="countAll">0</small></button>
                <button type="button" class="booking-tab" data-filter="Confirmed" aria-pressed="false">Confirmed <small id="countConfirmed">0</small></button>
                <button type="button" class="booking-tab" data-filter="Pending" aria-pressed="false">Pending <small id="countPending">0</small></button>
                <button type="button" class="booking-tab" data-filter="Cancelled" aria-pressed="false">Cancelled <small id="countCancelled">0</small></button>
            </div>

            <div class="booking-count">
                <strong id="bookingCount">0</strong> bookings
            </div>

        </div>

        <div class="bookings-grid" id="bookingsGrid">
            <div class="empty-state">Loading your bookings...</div>
        </div>

    </div>
</main>


<footer class="footer">
    <div class="container footer-content">
        <a href="index.php" class="brand footer-brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>
        <p>Event Ticketing &amp; Venue Booking System</p>
        <p class="copyright">© 2026 Eventify</p>
    </div>
</footer>


<div class="modal" id="cancelModal">
    <div class="modal-card">
        <h2>Cancel booking?</h2>
        <p>Your tickets will be returned to the event's availability.</p>

        <div class="modal-actions">
            <button class="keep-btn" id="keepBtn">Keep booking</button>
            <button class="confirm-cancel" id="confirmCancel">Yes, cancel</button>
        </div>
    </div>
</div>


<script>

const token = localStorage.getItem("eventify_token");

const authNavigation = document.getElementById("authNavigation");
const bookingsGrid = document.getElementById("bookingsGrid");
const bookingCount = document.getElementById("bookingCount");
const welcomeText = document.getElementById("welcomeText");
const modal = document.getElementById("cancelModal");
const keepBtn = document.getElementById("keepBtn");
const confirmCancel = document.getElementById("confirmCancel");
const bookingTabs = document.getElementById("bookingTabs");

let currentUser = null;
let selectedBooking = null;
let allBookings = [];
let activeFilter = "all";


/* ====================================================
   EMAIL RECEIPT (confirmed bookings only)
   The backend checks JWT and booking ownership, then
   sends the receipt to the email on your account.
==================================================== */
async function emailReceipt(bookingId, button) {

    const originalText = button.textContent;

    button.disabled = true;
    button.textContent = "Sending...";

    try {

        const response = await fetch("api/send-receipt.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify({ booking_id: bookingId })
        });

        const result = await response.json().catch(() => ({}));

        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Unable to send the receipt");
        }

        button.textContent = "Receipt sent ✓";

        setTimeout(function () {
            button.textContent = originalText;
            button.disabled = false;
        }, 3000);

    } catch (error) {

        alert(error.message);

        button.textContent = originalText;
        button.disabled = false;
    }
}


/* ========================================
   INIT
======================================== */

async function initialise() {

    if (!token) {
        window.location.href = "login.php";
        return;
    }

    try {

        const response = await fetch("auth/me.php", {
            headers: { Authorization: "Bearer " + token }
        });

        const result = await response.json();

        if (!response.ok || result.status !== "success") {
            logout();
            return;
        }

        currentUser = result.user;

        updateNavbar();

        welcomeText.textContent =
            "Welcome back, " + currentUser.name + ". Here are your reservations.";

        await loadBookings();

    } catch (error) {

        bookingsGrid.innerHTML = `
            <div class="empty-state">Unable to verify your account.</div>
        `;
    }
}


/* ========================================
   LOAD BOOKINGS
======================================== */

async function loadBookings() {

    try {

        const response = await fetch("api/bookings.php", {
            headers: { Authorization: "Bearer " + token }
        });

        const result = await response.json();

        if (response.status === 401) {
            logout();
            return;
        }

        if (!response.ok || result.status !== "success") {
            throw new Error(result.message);
        }

        displayBookings(result.data);

    } catch (error) {

        bookingsGrid.innerHTML = `
            <div class="empty-state">
                <h3>Unable to load bookings</h3>
                <p>${escapeHTML(error.message)}</p>
            </div>
        `;
    }
}


/* ========================================
   DISPLAY
======================================== */

function displayBookings(bookings) {

    allBookings = bookings;

    bookingCount.textContent = bookings.length;

    if (bookings.length === 0) {

        bookingTabs.hidden = true;

        bookingsGrid.innerHTML = `
            <div class="empty-state">
                <h3>No bookings yet</h3>
                <p>Find your next experience.</p>
                <a href="events.php" class="browse-btn">Browse events</a>
            </div>
        `;

        return;
    }

    bookingTabs.hidden = false;

    updateTabCounts();
    renderBookings();
}


function updateTabCounts() {

    const count = status => allBookings.filter(b => b.booking_status === status).length;

    document.getElementById("countAll").textContent = allBookings.length;
    document.getElementById("countConfirmed").textContent = count("Confirmed");
    document.getElementById("countPending").textContent = count("Pending");
    document.getElementById("countCancelled").textContent = count("Cancelled");
}


bookingTabs.addEventListener("click", function (event) {

    const tab = event.target.closest(".booking-tab");

    if (!tab) return;

    activeFilter = tab.dataset.filter;

    bookingTabs.querySelectorAll(".booking-tab").forEach(function (button) {
        button.setAttribute("aria-pressed", String(button === tab));
    });

    renderBookings();
});


function renderBookings() {

    bookingsGrid.innerHTML = "";

    const bookings = activeFilter === "all"
        ? allBookings
        : allBookings.filter(b => b.booking_status === activeFilter);

    if (bookings.length === 0) {

        bookingsGrid.innerHTML = `
            <div class="empty-state">
                <h3>Nothing here</h3>
                <p>You have no ${escapeHTML(activeFilter.toLowerCase())} bookings.</p>
            </div>
        `;

        return;
    }

    bookings.forEach(booking => {

        const date = new Date(booking.event_date + "T00:00:00");

        const fullDate = date.toLocaleDateString("en-MY", {
            day: "numeric",
            month: "short",
            year: "numeric"
        });

        const cancelled = booking.booking_status === "Cancelled";

        let statusClass = "pending";

        if (booking.booking_status === "Confirmed") {
            statusClass = "confirmed";
        }

        if (cancelled) {
            statusClass = "cancelled-status";
        }

        const bookingId = Number(booking.booking_id);
        const quantity = Number(booking.quantity);

        const card = document.createElement("article");

        card.className = "booking-item" + (cancelled ? " cancelled" : "");

        card.innerHTML = `
            <div class="booking-pass">

                <div class="booking-info">

                    <div class="booking-top">
                        <span class="status ${statusClass}">${escapeHTML(booking.booking_status)}</span>
                        <span class="booking-id">Booking #${bookingId}</span>
                    </div>

                    <h3>${escapeHTML(booking.event_name)}</h3>

                    <div class="booking-details">
                        <div><small>Date</small><strong>${escapeHTML(fullDate)}</strong></div>
                        <div><small>Venue</small><strong>${escapeHTML(booking.venue_name)}</strong></div>
                        <div><small>Tickets</small><strong>${quantity}</strong></div>
                    </div>

                </div>

                <div class="booking-side">

                    <small>Total</small>

                    <strong>RM ${Number(booking.total_amount).toFixed(2)}</strong>

                    ${booking.booking_status === "Confirmed" ? `
                        <button class="receipt-btn" type="button"
                            onclick="emailReceipt(${bookingId}, this)">
                            Email receipt
                        </button>
                    ` : ""}

                    ${!cancelled ? `
                        <button class="cancel-btn" type="button"
                            onclick="openCancel(${bookingId})">
                            Cancel booking
                        </button>
                    ` : ""}

                </div>

            </div>
        `;

        bookingsGrid.appendChild(card);
    });
}


/* ========================================
   CANCEL
======================================== */

function openCancel(bookingId) {

    selectedBooking = bookingId;

    modal.classList.add("show");
}


keepBtn.addEventListener("click", function () {

    selectedBooking = null;

    modal.classList.remove("show");
});


confirmCancel.addEventListener("click", async function () {

    if (!selectedBooking) {
        return;
    }

    confirmCancel.disabled = true;
    confirmCancel.textContent = "Cancelling...";

    try {

        const response = await fetch("api/bookings.php", {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify({ booking_id: selectedBooking })
        });

        const result = await response.json();

        if (!response.ok || result.status !== "success") {
            throw new Error(result.message);
        }

        modal.classList.remove("show");

        selectedBooking = null;

        await loadBookings();

    } catch (error) {

        alert(error.message);

    } finally {

        confirmCancel.disabled = false;
        confirmCancel.textContent = "Yes, cancel";
    }
});


/* ========================================
   NAVBAR
======================================== */

function updateNavbar() {

    authNavigation.innerHTML = `
        <span class="top-user">${escapeHTML(currentUser.name)}</span>
        <button type="button" class="top-logout" onclick="logout()">Logout</button>
    `;
}


function logout() {

    localStorage.removeItem("eventify_token");
    localStorage.removeItem("eventify_user");

    window.location.href = "login.php";
}


/* ========================================
   ESCAPE
======================================== */

function escapeHTML(value) {

    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


initialise();

</script>

</body>
</html>