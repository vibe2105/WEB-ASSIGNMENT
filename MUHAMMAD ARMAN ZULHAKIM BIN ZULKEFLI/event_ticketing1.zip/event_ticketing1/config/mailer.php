<?php

/* ==========================================
   EVENTIFY MAILER (booking receipts)

   Requires PHPMailer in lib/PHPMailer/src/
   and these keys in config/local.php:

     EVENTIFY_SMTP_HOST
     EVENTIFY_SMTP_PORT
     EVENTIFY_SMTP_USER
     EVENTIFY_SMTP_PASS
     EVENTIFY_MAIL_FROM
     EVENTIFY_MAIL_FROM_NAME   (optional)
========================================== */

require_once __DIR__ . '/settings.php';

require_once __DIR__ . '/../lib/PHPMailer/src/Exception.php';
require_once __DIR__ . '/../lib/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../lib/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as MailException;


/* ==========================================
   HELPERS
========================================== */

function eventifyMailEscape($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}


function eventifyFormatTime($time)
{
    if (!preg_match('/^(\d{1,2}):(\d{2})/', (string) $time, $m)) {
        return '';
    }

    $hour = (int) $m[1];

    return (($hour % 12) ?: 12) . ':' . $m[2] . ' ' . ($hour >= 12 ? 'PM' : 'AM');
}


/* ==========================================
   BUILD RECEIPT BODY
   $b = row with booking, event, venue and
   customer columns (see api/send-receipt.php)

   Email clients ignore most modern CSS, so
   this uses tables and inline styles only.
========================================== */

function eventifyReceiptHtml(array $b)
{
    $e = 'eventifyMailEscape';

    $dateStamp = strtotime($b['event_date']);

    $weekday = date('D', $dateStamp);
    $day = date('d', $dateStamp);
    $month = strtoupper(date('M', $dateStamp));
    $fullDate = date('l, j F Y', $dateStamp);

    $start = eventifyFormatTime($b['start_time']);
    $end = eventifyFormatTime($b['end_time']);
    $time = $start && $end ? $start . ' to ' . $end : $start;

    $quantity = (int) $b['quantity'];
    $price = number_format((float) $b['ticket_price'], 2);
    $total = number_format((float) $b['total_amount'], 2);

    $bookedOn = $b['booking_date']
        ? date('j M Y, g:i A', strtotime($b['booking_date']))
        : '';

    $venue = (string) $b['venue_name'];
    $address = (string) $b['location'];

    $serif = "Georgia,'Times New Roman',serif";
    $sans = "Arial,Helvetica,sans-serif";

    $detailRow = function ($label, $value) use ($e, $sans) {

        if ($value === '' || $value === null) {
            return '';
        }

        return '<tr>'
            . '<td style="padding:7px 0;font-family:' . $sans . ';font-size:14px;color:#5f7577;">' . $e($label) . '</td>'
            . '<td align="right" style="padding:7px 0;font-family:' . $sans . ';font-size:14px;font-weight:bold;color:#12292b;">' . $e($value) . '</td>'
            . '</tr>';
    };

    $html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
        . '<title>Eventify receipt</title></head>'
        . '<body style="margin:0;padding:0;background:#f4f8f6;">'

        // hidden preview text shown in the inbox list
        . '<div style="display:none;max-height:0;overflow:hidden;opacity:0;">'
        . 'Your booking for ' . $e($b['event_name']) . ' is confirmed. Receipt #' . (int) $b['booking_id'] . '.</div>'

        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f8f6;padding:28px 12px;"><tr><td align="center">'
        . '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:18px;overflow:hidden;">'

        // ---------- header ----------
        . '<tr><td style="background:#072b2d;padding:26px 32px;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
        . '<td style="font-family:' . $serif . ';font-size:28px;font-weight:bold;color:#ffffff;">Event<span style="color:#ff6a4d;">ify</span></td>'
        . '<td align="right" style="font-family:' . $sans . ';font-size:13px;color:#a8ebd3;">Booking receipt<br>'
        . '<span style="font-family:' . $serif . ';font-size:20px;font-weight:bold;color:#ffffff;">#' . (int) $b['booking_id'] . '</span></td>'
        . '</tr></table></td></tr>'

        // ---------- greeting ----------
        . '<tr><td style="padding:30px 32px 6px;">'
        . '<span style="display:inline-block;padding:5px 12px;border-radius:20px;background:#e4f6ef;font-family:' . $sans . ';font-size:13px;font-weight:bold;color:#0f6446;">&#10003; ' . $e($b['booking_status']) . '</span>'
        . '<h1 style="margin:14px 0 8px;font-family:' . $serif . ';font-size:30px;line-height:1.2;color:#12292b;">You\'re going, ' . $e(strtok((string) $b['customer_name'], ' ')) . '!</h1>'
        . '<p style="margin:0;font-family:' . $sans . ';font-size:15px;line-height:1.6;color:#5f7577;">Your tickets are booked. Keep this receipt and show it at the entrance if asked.</p>'
        . '</td></tr>'

        // ---------- event block ----------
        . '<tr><td style="padding:22px 32px 0;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #d5e2df;border-radius:14px;"><tr>'
        . '<td width="92" align="center" bgcolor="#0c4a4d" style="background:#0c4a4d;border-radius:14px 0 0 14px;padding:18px 8px;">'
        . '<div style="font-family:' . $sans . ';font-size:13px;color:#a8ebd3;">' . $e($weekday) . '</div>'
        . '<div style="font-family:' . $serif . ';font-size:38px;font-weight:bold;line-height:1.1;color:#ffffff;">' . $e($day) . '</div>'
        . '<div style="font-family:' . $sans . ';font-size:14px;font-weight:bold;letter-spacing:1px;color:#ff6a4d;">' . $e($month) . '</div>'
        . '</td>'
        . '<td style="padding:18px 22px;border-left:2px dashed #d5e2df;">'
        . '<div style="font-family:' . $serif . ';font-size:22px;font-weight:bold;line-height:1.25;color:#12292b;">' . $e($b['event_name']) . '</div>'
        . '<div style="margin-top:8px;font-family:' . $sans . ';font-size:14px;line-height:1.6;color:#5f7577;">' . $e($fullDate)
        . ($time !== '' ? '<br>' . $e($time) : '') . '</div>'
        . '</td></tr></table></td></tr>'

        // ---------- venue block ----------
        . '<tr><td style="padding:18px 32px 0;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f8f6;border-radius:14px;"><tr>'
        . '<td style="padding:18px 22px;">'
        . '<div style="font-family:' . $sans . ';font-size:13px;color:#5f7577;">Where</div>'
        . '<div style="margin-top:4px;font-family:' . $serif . ';font-size:20px;font-weight:bold;color:#12292b;">' . $e($venue) . '</div>'
        . '<div style="margin-top:4px;font-family:' . $sans . ';font-size:14px;line-height:1.5;color:#5f7577;">' . $e($address) . '</div>'
        . '</td></tr></table></td></tr>'

        // ---------- itemised ----------
        . '<tr><td style="padding:26px 32px 0;">'
        . '<div style="font-family:' . $serif . ';font-size:18px;font-weight:bold;color:#12292b;padding-bottom:10px;border-bottom:2px dashed #d5e2df;">Order summary</div>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:6px;">'
        . '<tr>'
        . '<td style="padding:10px 0;font-family:' . $sans . ';font-size:13px;color:#5f7577;">Item</td>'
        . '<td align="center" style="padding:10px 0;font-family:' . $sans . ';font-size:13px;color:#5f7577;">Qty</td>'
        . '<td align="right" style="padding:10px 0;font-family:' . $sans . ';font-size:13px;color:#5f7577;">Price</td>'
        . '<td align="right" style="padding:10px 0;font-family:' . $sans . ';font-size:13px;color:#5f7577;">Amount</td>'
        . '</tr>'
        . '<tr>'
        . '<td style="padding:12px 0;border-top:1px solid #e8f0ee;font-family:' . $sans . ';font-size:15px;font-weight:bold;color:#12292b;">Event ticket</td>'
        . '<td align="center" style="padding:12px 0;border-top:1px solid #e8f0ee;font-family:' . $sans . ';font-size:15px;color:#12292b;">' . $quantity . '</td>'
        . '<td align="right" style="padding:12px 0;border-top:1px solid #e8f0ee;font-family:' . $sans . ';font-size:15px;color:#12292b;">RM ' . $e($price) . '</td>'
        . '<td align="right" style="padding:12px 0;border-top:1px solid #e8f0ee;font-family:' . $sans . ';font-size:15px;font-weight:bold;color:#12292b;">RM ' . $e($total) . '</td>'
        . '</tr></table>'

        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:12px;background:#072b2d;border-radius:14px;"><tr>'
        . '<td style="padding:18px 22px;font-family:' . $sans . ';font-size:15px;color:#b9d3cf;">Total</td>'
        . '<td align="right" style="padding:18px 22px;font-family:' . $serif . ';font-size:30px;font-weight:bold;color:#a8ebd3;">RM ' . $e($total) . '</td>'
        . '</tr></table>'
        . '</td></tr>'

        // ---------- booking details ----------
        . '<tr><td style="padding:26px 32px 0;">'
        . '<div style="font-family:' . $serif . ';font-size:18px;font-weight:bold;color:#12292b;padding-bottom:6px;border-bottom:2px dashed #d5e2df;">Booking details</div>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:6px;">'
        . $detailRow('Booking number', '#' . (int) $b['booking_id'])
        . $detailRow('Booked on', $bookedOn)
        . $detailRow('Name', (string) $b['customer_name'])
        . $detailRow('Email', (string) $b['customer_email'])
        . $detailRow('Status', (string) $b['booking_status'])
        . '</table></td></tr>'

        // ---------- note ----------
        . '<tr><td style="padding:22px 32px 30px;">'
        . '<p style="margin:0;font-family:' . $sans . ';font-size:13px;line-height:1.6;color:#5f7577;">You can see all your reservations anytime under <strong>My Bookings</strong> on Eventify. If any detail looks wrong, please contact the event organiser.</p>'
        . '</td></tr>'

        // ---------- footer ----------
        . '<tr><td align="center" style="background:#072b2d;padding:20px 32px;">'
        . '<div style="font-family:' . $serif . ';font-size:18px;font-weight:bold;color:#ffffff;">Event<span style="color:#ff6a4d;">ify</span></div>'
        . '<div style="margin-top:6px;font-family:' . $sans . ';font-size:12px;color:#9fc2bd;">Event Ticketing &amp; Venue Booking System</div>'
        . '</td></tr>'

        . '</table></td></tr></table></body></html>';

    return $html;
}


function eventifyReceiptText(array $b)
{
    $date = date('l, j F Y', strtotime($b['event_date']));

    $start = eventifyFormatTime($b['start_time']);
    $end = eventifyFormatTime($b['end_time']);
    $time = $start && $end ? $start . ' to ' . $end : $start;

    return "EVENTIFY BOOKING RECEIPT\n"
        . "========================\n\n"
        . 'Hi ' . $b['customer_name'] . ",\n"
        . "Your booking is confirmed.\n\n"
        . 'Booking number: #' . (int) $b['booking_id'] . "\n\n"
        . 'EVENT' . "\n"
        . $b['event_name'] . "\n"
        . $date . ($time !== '' ? ', ' . $time : '') . "\n\n"
        . 'WHERE' . "\n"
        . $b['venue_name'] . "\n"
        . $b['location'] . "\n"
        . "\n"
        . 'ORDER' . "\n"
        . (int) $b['quantity'] . ' x RM ' . number_format((float) $b['ticket_price'], 2) . "\n"
        . 'Total: RM ' . number_format((float) $b['total_amount'], 2) . "\n\n"
        . 'Status: ' . $b['booking_status'] . "\n\n"
        . "Keep this email as proof of your booking.\n";
}


/* ==========================================
   SEND RECEIPT
   Returns [bool success, string message]
========================================== */

function eventifySendReceipt(array $booking)
{
    $host = (string) eventifySetting('EVENTIFY_SMTP_HOST', '');
    $port = (int) eventifySetting('EVENTIFY_SMTP_PORT', 587);
    $user = (string) eventifySetting('EVENTIFY_SMTP_USER', '');
    $pass = (string) eventifySetting('EVENTIFY_SMTP_PASS', '');
    $from = (string) eventifySetting('EVENTIFY_MAIL_FROM', $user);
    $fromName = (string) eventifySetting('EVENTIFY_MAIL_FROM_NAME', 'Eventify');

    if ($host === '' || $user === '' || $pass === '' || str_starts_with($pass, 'PASTE_')) {
        return [false, 'Email is not configured on the server.'];
    }

    if (!filter_var($booking['customer_email'], FILTER_VALIDATE_EMAIL)) {
        return [false, 'Your account does not have a valid email address.'];
    }

    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();
        $mail->Host = $host;
        $mail->Port = $port;
        $mail->SMTPAuth = true;
        $mail->Username = $user;
        $mail->Password = $pass;
        $mail->SMTPSecure = $port === 465
            ? PHPMailer::ENCRYPTION_SMTPS
            : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Timeout = 12;
        $mail->CharSet = 'UTF-8';

        $mail->setFrom($from, $fromName);
        $mail->addAddress($booking['customer_email'], $booking['customer_name']);

        $mail->isHTML(true);
        $mail->Subject = 'Your Eventify receipt #' . (int) $booking['booking_id'] . ' - ' . $booking['event_name'];
        $mail->Body = eventifyReceiptHtml($booking);
        $mail->AltBody = eventifyReceiptText($booking);

        $mail->send();

        return [true, 'Receipt sent.'];

    } catch (MailException $error) {

        // Details go to the server log only, never to the browser.
        error_log('Eventify mail error: ' . $mail->ErrorInfo);

        return [false, 'The receipt email could not be sent.'];
    }
}