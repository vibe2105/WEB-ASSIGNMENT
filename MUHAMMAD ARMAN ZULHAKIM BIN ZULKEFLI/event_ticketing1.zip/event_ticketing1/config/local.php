<?php
// Copy to config/local.php, then set your own 64-character random JWT secret.
// NEVER commit local.php to GitHub or share it with teammates.
return [
    'EVENTIFY_TICKET_SECRET' => 'b4c2e4d631d6b8b68299c9863f797c41a75a9c538c9aad0d8bd92f475b1691d3',
    'EVENTIFY_JWT_SECRET' => '38ad51e0f35b78f7774cf6f472d79773804959077e24d77a18e913d7e67dfc6f',
    'EVENTIFY_INTERNAL_API_KEY' => 'f7a291501110668651cfe324cd4dc1858a79887396595f1dabc11413756224e9',
    'EVENTIFY_DB_HOST' => '127.0.0.1',
    'EVENTIFY_DB_NAME' => 'event_ticketing_db',
    'EVENTIFY_DB_USER' => 'root', // local XAMPP only
    'EVENTIFY_DB_PASSWORD' => '', // local XAMPP only
    'EVENTIFY_SMTP_HOST' => 'smtp.gmail.com',
    'EVENTIFY_SMTP_PORT' => 587,
    'EVENTIFY_SMTP_USER' => 'zulhakimareman@gmail.com',
    'EVENTIFY_SMTP_PASS' => 'paaljwawqnfwqmba',
    'EVENTIFY_MAIL_FROM' => 'zulhakimareman@gmail.com',
];
