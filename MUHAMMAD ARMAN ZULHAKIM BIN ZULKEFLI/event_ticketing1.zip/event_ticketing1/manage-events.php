<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Events | Eventify</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body.events-mgmt-page {
            min-height: 100vh;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-family: var(--ev-body);
        }

        /* ---------- NAVBAR OVERRIDES ---------- */
        .events-mgmt-page .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .events-mgmt-page .navbar .brand,
        .events-mgmt-page .navbar .brand span { color: #fff; }
        .events-mgmt-page .navbar .brand-purple { color: var(--ev-coral); }
        .events-mgmt-page .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .events-mgmt-page .navbar .nav-links a { color: #b9d3cf; }
        .events-mgmt-page .navbar .nav-links a:hover,
        .events-mgmt-page .navbar .nav-links a.active { color: #fff; }
        .top-user { font-size: 14px; font-weight: 700; color: #b9d3cf; }
        .top-logout {
            padding: 9px 18px;
            border: none;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 14px var(--ev-body);
            cursor: pointer;
            transition: background .2s;
        }
        .top-logout:hover { background: var(--ev-coral-dark); }

        /* ---------- HERO SECTION ---------- */
        .management-hero {
            padding: 56px 0 62px;
            color: #fff;
            background:
                radial-gradient(550px 320px at 90% 0%, rgba(255, 106, 77, .22), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .management-hero-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 28px;
            flex-wrap: wrap;
        }
        .hero-title-group .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 999px;
            background: rgba(168, 235, 211, .15);
            color: var(--ev-mint);
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .6px;
        }
        .management-hero h1 {
            margin-top: 12px;
            font-family: var(--ev-display);
            font-size: clamp(34px, 4.2vw, 50px);
            font-weight: 800;
            letter-spacing: -1.2px;
            line-height: 1.05;
            color: #fff;
        }
        .management-hero p {
            margin-top: 8px;
            color: #b9d3cf;
            font-size: 16px;
        }
        .create-event-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border: none;
            padding: 14px 24px;
            border-radius: 14px;
            color: var(--ev-deep);
            background: var(--ev-coral);
            cursor: pointer;
            font: 700 15px var(--ev-body);
            box-shadow: 0 10px 24px rgba(255, 106, 77, .3);
            transition: all .2s ease;
        }
        .create-event-btn:hover {
            background: var(--ev-coral-dark);
            transform: translateY(-2px);
            box-shadow: 0 14px 28px rgba(255, 106, 77, .38);
        }

        /* ---------- STATS CARDS ---------- */
        .management-section {
            padding: 40px 0 96px;
        }
        .management-stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .management-stat {
            position: relative;
            padding: 24px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(7, 43, 45, .03);
            overflow: hidden;
        }
        .management-stat::before {
            content: "";
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: var(--ev-teal-soft);
        }
        .management-stat:nth-child(2)::before { background: var(--ev-coral); }
        .management-stat:nth-child(3)::before { background: var(--ev-mint); }
        .management-stat:nth-child(4)::before { background: var(--ev-deep); }

        .management-stat span {
            color: var(--ev-muted);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .8px;
        }
        .management-stat strong {
            display: block;
            margin-top: 8px;
            font-family: var(--ev-display);
            font-size: 34px;
            font-weight: 800;
            color: var(--ev-ink);
            letter-spacing: -.6px;
        }

        /* ---------- TOOLBAR & FILTERS ---------- */
        .management-toolbar {
            padding: 18px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 24px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
            box-shadow: 0 4px 14px rgba(7, 43, 45, .02);
        }
        .search-box-wrapper {
            position: relative;
            flex: 1;
        }
        .management-toolbar input {
            width: 100%;
            height: 48px;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            padding: 0 16px;
            outline: none;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font: 500 15px var(--ev-body);
            transition: all .2s;
        }
        .management-toolbar input:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 3px rgba(20, 102, 106, .12);
        }
        .filter-select-wrapper {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .management-toolbar select {
            height: 48px;
            min-width: 180px;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            padding: 0 14px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font: 600 14px var(--ev-body);
            cursor: pointer;
            transition: all .2s;
        }
        .management-toolbar select:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            outline: none;
        }

        /* ---------- TABLE LAYOUT ---------- */
        .event-management-card {
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 14px 36px rgba(7, 43, 45, .05);
        }
        .table-wrapper {
            overflow-x: auto;
        }
        .event-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 980px;
        }
        .event-table th {
            padding: 18px 22px;
            background: var(--ev-paper);
            color: var(--ev-muted);
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .9px;
            text-align: left;
            border-bottom: 1px solid var(--ev-line);
        }
        .event-table td {
            padding: 20px 22px;
            border-bottom: 1px solid var(--ev-line);
            font-size: 15px;
            color: var(--ev-ink);
            vertical-align: middle;
        }
        .event-table tr:last-child td {
            border-bottom: none;
        }
        .event-table tbody tr {
            transition: background .15s ease;
        }
        .event-table tbody tr:hover {
            background: rgba(244, 248, 246, .6);
        }

        .event-name-block strong {
            display: block;
            color: var(--ev-ink);
            font-size: 16px;
            font-weight: 700;
            line-height: 1.3;
        }
        .category-badge {
            display: inline-block;
            margin-top: 5px;
            padding: 2px 9px;
            border-radius: 6px;
            background: var(--ev-paper);
            color: var(--ev-teal-soft);
            border: 1px solid var(--ev-line);
            font-size: 12px;
            font-weight: 600;
        }

        .date-info strong {
            display: block;
            color: var(--ev-ink);
            font-size: 15px;
        }
        .date-info span {
            color: var(--ev-muted);
            font-size: 13px;
        }

        .status-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 12px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 700;
        }
        .status-pill::before {
            content: "";
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: currentColor;
        }
        .status-upcoming { color: #0f6446; background: #e4f6ef; }
        .status-ongoing { color: #1a56db; background: #eff6ff; }
        .status-completed { color: var(--ev-muted); background: var(--ev-paper); }
        .status-cancelled { color: #a1301d; background: #fff1ef; }

        .action-buttons {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .edit-btn,
        .delete-btn {
            padding: 9px 16px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font: 700 13px var(--ev-body);
            transition: all .15s ease;
        }
        .edit-btn {
            color: var(--ev-deep);
            background: var(--ev-mint);
        }
        .edit-btn:hover {
            background: #93dec5;
            transform: translateY(-1px);
        }
        .delete-btn {
            color: #a1301d;
            background: #fff1ef;
            border: 1px solid #f2c6bd;
        }
        .delete-btn:hover {
            background: #fde8e4;
            transform: translateY(-1px);
        }
        .empty-events {
            padding: 80px 20px;
            text-align: center;
            color: var(--ev-muted);
            font-size: 16px;
        }

        /* ---------- MODALS ---------- */
        .modal-overlay {
            position: fixed;
            inset: 0;
            z-index: 5000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(7, 43, 45, .75);
            backdrop-filter: blur(6px);
        }
        .modal-overlay.show {
            display: flex;
        }
        .event-modal {
            width: min(800px, 100%);
            max-height: 90vh;
            overflow-y: auto;
            background: #fff;
            border-radius: 24px;
            box-shadow: 0 25px 70px rgba(7, 43, 45, .32);
        }
        .modal-header {
            padding: 24px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--ev-line);
        }
        .modal-header span {
            color: var(--ev-teal-soft);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        .modal-header h2 {
            margin-top: 4px;
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            color: var(--ev-ink);
        }
        .modal-close {
            width: 38px;
            height: 38px;
            border: none;
            border-radius: 12px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            cursor: pointer;
            font-size: 20px;
            line-height: 1;
            transition: background .15s;
        }
        .modal-close:hover {
            background: var(--ev-line);
        }
        .event-form {
            padding: 30px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }
        .form-field.full {
            grid-column: 1 / -1;
        }
        .form-field label {
            display: block;
            margin-bottom: 8px;
            color: var(--ev-ink);
            font-size: 13px;
            font-weight: 700;
        }
        .form-field input,
        .form-field select,
        .form-field textarea {
            width: 100%;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            outline: none;
            font: 500 15px var(--ev-body);
            transition: all .2s;
        }
        .form-field input,
        .form-field select {
            height: 48px;
            padding: 0 16px;
        }
        .form-field textarea {
            min-height: 110px;
            padding: 14px;
            resize: vertical;
        }
        .form-field input:focus,
        .form-field select:focus,
        .form-field textarea:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 3px rgba(20, 102, 106, .12);
        }
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 28px;
            padding-top: 22px;
            border-top: 1px solid var(--ev-line);
        }
        .cancel-modal-btn,
        .save-event-btn {
            padding: 12px 22px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font: 700 15px var(--ev-body);
            transition: background .15s;
        }
        .cancel-modal-btn {
            background: var(--ev-paper);
            color: var(--ev-ink);
        }
        .cancel-modal-btn:hover {
            background: var(--ev-line);
        }
        .save-event-btn {
            background: var(--ev-coral);
            color: var(--ev-deep);
        }
        .save-event-btn:hover {
            background: var(--ev-coral-dark);
        }
        .save-event-btn:disabled {
            opacity: .6;
            cursor: not-allowed;
        }
        .form-message {
            display: none;
            padding: 13px;
            margin-top: 16px;
            border-radius: 10px;
            font-size: 13px;
            line-height: 1.5;
        }
        .form-message.error {
            display: block;
            color: #a1301d;
            background: #fff1ef;
        }
        .form-message.success {
            display: block;
            color: #0f6446;
            background: #e4f6ef;
        }

        /* DELETE MODAL */
        .delete-modal {
            width: min(420px, 100%);
            padding: 32px;
            background: #fff;
            border-radius: 24px;
            text-align: center;
            box-shadow: 0 25px 70px rgba(7, 43, 45, .3);
        }
        .delete-icon {
            width: 60px;
            height: 60px;
            display: grid;
            place-items: center;
            margin: 0 auto;
            border-radius: 50%;
            color: #a1301d;
            background: #fff1ef;
            font-size: 24px;
            font-weight: 800;
        }
        .delete-modal h2 {
            margin-top: 18px;
            font-family: var(--ev-display);
            font-size: 24px;
            font-weight: 800;
            color: var(--ev-ink);
        }
        .delete-modal p {
            color: var(--ev-muted);
            margin-top: 8px;
            font-size: 15px;
            line-height: 1.6;
        }
        .delete-actions {
            display: flex;
            gap: 12px;
            margin-top: 26px;
        }
        .delete-actions button {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font: 700 15px var(--ev-body);
            transition: background .15s;
        }
        .cancel-delete {
            background: var(--ev-paper);
            color: var(--ev-ink);
        }
        .cancel-delete:hover {
            background: var(--ev-line);
        }
        .confirm-delete {
            background: #c34848;
            color: white;
        }
        .confirm-delete:hover {
            background: #a93a3a;
        }

        /* ---------- TOAST NOTIFICATION ---------- */
        .toast {
            position: fixed;
            z-index: 7000;
            right: 25px;
            bottom: 25px;
            padding: 15px 22px;
            min-width: 280px;
            border-radius: 14px;
            color: #fff;
            font: 700 14px var(--ev-body);
            box-shadow: 0 18px 45px rgba(7, 43, 45, .25);
            opacity: 0;
            transform: translateY(40px);
            pointer-events: none;
            transition: .3s;
        }
        .toast.show {
            opacity: 1;
            transform: translateY(0);
        }
        .toast.success { background: #0f6446; }
        .toast.error { background: #a1301d; }

        /* ---------- FOOTER ---------- */
        .ev-footer { color: #b9d3cf; background: linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%); }
        .ev-footer-top {
            display: grid;
            grid-template-columns: minmax(0, 1.6fr) repeat(2, minmax(0, 1fr));
            gap: 48px;
            padding: 60px 0 44px;
        }
        .ev-footer-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            text-decoration: none;
        }
        .ev-footer-mark {
            width: 38px;
            height: 38px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-size: 20px;
        }
        .ev-footer-brand em { font-style: normal; color: var(--ev-coral); }
        .ev-footer-about { margin-top: 16px; max-width: 340px; font-size: 15px; line-height: 1.65; color: #9fc2bd; }
        .ev-footer h3 { font-family: var(--ev-display); font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 14px; }
        .ev-footer ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 10px; }
        .ev-footer ul a { color: #b9d3cf; font-size: 15px; text-decoration: none; }
        .ev-footer ul a:hover { color: #fff; text-decoration: underline; }
        .ev-footer a:focus-visible { outline: 3px solid var(--ev-mint); outline-offset: 3px; border-radius: 4px; }
        .ev-footer-bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px 24px;
            padding: 22px 0 28px;
            border-top: 2px dashed rgba(255, 255, 255, .2);
            font-size: 14px;
            color: #9fc2bd;
        }

        /* ---------- RESPONSIVE ---------- */
        @media (max-width: 900px) {
            .management-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .management-toolbar { flex-direction: column; align-items: stretch; }
            .filter-select-wrapper { width: 100%; }
            .management-toolbar select { flex: 1; }
            .form-grid { grid-template-columns: 1fr; }
            .form-field.full { grid-column: auto; }
            .ev-footer-top { grid-template-columns: 1fr 1fr; }
            .ev-footer-top > div:first-child { grid-column: 1 / -1; }
        }
        @media (max-width: 600px) {
            .management-hero-content { flex-direction: column; align-items: flex-start; }
            .create-event-btn { width: 100%; justify-content: center; }
            .management-stats { grid-template-columns: 1fr; }
            .ev-footer-top { padding: 44px 0 32px; gap: 32px 24px; }
        }
    </style>
</head>
<body class="events-mgmt-page">

<!-- NAVBAR -->
<header class="navbar">
    <div class="container nav-container">
        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>
        <nav class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage-events.php" class="active">Manage Events</a>
            <a href="events.php">View Website</a>
        </nav>
        <div class="nav-actions" id="authNavigation"></div>
    </div>
</header>

<!-- HERO HEADER -->
<section class="management-hero">
    <div class="container management-hero-content">
        <div class="hero-title-group">
            <span class="eyebrow">EVENT MANAGEMENT</span>
            <h1>Manage Events</h1>
            <p>Create, edit and maintain your Eventify event catalogue.</p>
        </div>
        <button type="button" class="create-event-btn" id="createEventButton">
            <span>+</span> Create New Event
        </button>
    </div>
</section>

<!-- MAIN CONTENT -->
<main class="management-section">
    <div class="container">
        <!-- STATS CARDS -->
        <section class="management-stats">
            <article class="management-stat">
                <span>Total Events</span>
                <strong id="totalEvents">0</strong>
            </article>
            <article class="management-stat">
                <span>Upcoming</span>
                <strong id="upcomingEvents">0</strong>
            </article>
            <article class="management-stat">
                <span>Total Tickets</span>
                <strong id="totalTickets">0</strong>
            </article>
            <article class="management-stat">
                <span>Available Tickets</span>
                <strong id="availableTickets">0</strong>
            </article>
        </section>

        <!-- TOOLBAR -->
        <section class="management-toolbar">
            <div class="search-box-wrapper">
                <input type="text" id="eventSearch" placeholder="Search event name, venue or category...">
            </div>
            <div class="filter-select-wrapper">
                <select id="statusFilter">
                    <option value="">All Statuses</option>
                    <option value="Upcoming">Upcoming</option>
                    <option value="Ongoing">Ongoing</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
            </div>
        </section>

        <!-- TABLE CARD -->
        <section class="event-management-card">
            <div class="table-wrapper">
                <table class="event-table">
                    <thead>
                        <tr>
                            <th>Event &amp; Category</th>
                            <th>Date &amp; Time</th>
                            <th>Venue</th>
                            <th>Tickets Available</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="eventTableBody">
                        <tr>
                            <td colspan="7" class="empty-events">Loading events...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</main>

<!-- CREATE / EDIT MODAL -->
<div class="modal-overlay" id="eventModal">
    <div class="event-modal">
        <div class="modal-header">
            <div>
                <span id="modalEyebrow">CREATE EVENT</span>
                <h2 id="modalTitle">New Event</h2>
            </div>
            <button type="button" class="modal-close" id="closeEventModal">&times;</button>
        </div>
        <form class="event-form" id="eventForm">
            <input type="hidden" id="eventId">
            <div class="form-grid">
                <div class="form-field full">
                    <label for="eventName">Event Name</label>
                    <input type="text" id="eventName" placeholder="e.g. Asia Tech Summit 2026" required>
                </div>
                <div class="form-field">
                    <label for="category">Category</label>
                    <select id="category" required>
                        <option value="">Select category</option>
                        <option value="Technology">Technology</option>
                        <option value="Workshop">Workshop</option>
                        <option value="Music">Music</option>
                        <option value="Seminar">Seminar</option>
                        <option value="Food">Food</option>
                        <option value="Conference">Conference</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="venue">Venue</label>
                    <select id="venue" required>
                        <option value="">Loading venues...</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="eventDate">Event Date</label>
                    <input type="date" id="eventDate" required>
                </div>
                <div class="form-field">
                    <label for="status">Status</label>
                    <select id="status" required>
                        <option value="Upcoming">Upcoming</option>
                        <option value="Ongoing">Ongoing</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </div>
                <div class="form-field">
                    <label for="startTime">Start Time</label>
                    <input type="time" id="startTime" required>
                </div>
                <div class="form-field">
                    <label for="endTime">End Time</label>
                    <input type="time" id="endTime" required>
                </div>
                <div class="form-field">
                    <label for="ticketPrice">Ticket Price (RM)</label>
                    <input type="number" id="ticketPrice" min="0" step="0.01" placeholder="0.00" required>
                </div>
                <div class="form-field">
                    <label for="totalTicketCount">Total Tickets Capacity</label>
                    <input type="number" id="totalTicketCount" min="1" placeholder="100" required>
                </div>
                <div class="form-field full">
                    <label for="description">Event Description</label>
                    <textarea id="description" placeholder="Provide event details, agenda or guest speaker info..."></textarea>
                </div>
            </div>
            <div class="form-message" id="formMessage"></div>
            <div class="modal-actions">
                <button type="button" class="cancel-modal-btn" id="cancelEventModal">Cancel</button>
                <button type="submit" class="save-event-btn" id="saveEventButton">Create Event</button>
            </div>
        </form>
    </div>
</div>

<!-- DELETE MODAL -->
<div class="modal-overlay" id="deleteModal">
    <div class="delete-modal">
        <div class="delete-icon">!</div>
        <h2>Delete Event?</h2>
        <p>This action cannot be undone. All associated reservations for this event will be impacted.</p>
        <div class="delete-actions">
            <button type="button" class="cancel-delete" id="cancelDeleteButton">Cancel</button>
            <button type="button" class="confirm-delete" id="confirmDeleteButton">Delete Event</button>
        </div>
    </div>
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<!-- FOOTER -->
<footer class="ev-footer">
    <div class="container">
        <div class="ev-footer-top">
            <div>
                <a href="index.php" class="ev-footer-brand">
                    <span class="ev-footer-mark">E</span>
                    <span>Event<em>ify</em></span>
                </a>
                <p class="ev-footer-about">
                    Find events, book tickets and keep every reservation in one place.
                </p>
            </div>
            <div>
                <h3>Explore</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="events.php">All events</a></li>
                    <li><a href="index.php#how-it-works">How it works</a></li>
                </ul>
            </div>
            <div>
                <h3>Your account</h3>
                <ul>
                    <li><a href="login.php">Sign in</a></li>
                    <li><a href="register.php">Create account</a></li>
                    <li><a href="bookings.php">My bookings</a></li>
                </ul>
            </div>
        </div>

        <div class="ev-footer-bottom">
            <span>&copy; 2026 Eventify</span>
            <span>Event Ticketing &amp; Venue Booking System</span>
        </div>
    </div>
</footer>

<script>
/* ========================================
   VARIABLES & DOM ELEMENTS
======================================== */
const token = localStorage.getItem("eventify_token");
let currentUser = null;
let events = [];
let venues = [];
let selectedEventId = null;
let isEditMode = false;

const eventTableBody = document.getElementById("eventTableBody");
const eventModal = document.getElementById("eventModal");
const deleteModal = document.getElementById("deleteModal");
const eventForm = document.getElementById("eventForm");
const formMessage = document.getElementById("formMessage");
const saveEventButton = document.getElementById("saveEventButton");
const toast = document.getElementById("toast");

/* ========================================
   INITIALISE
======================================== */
async function initialise() {
    if (!token) {
        window.location.href = "login.php";
        return;
    }
    try {
        const response = await fetch("auth/me.php", {
            headers: { Authorization: "Bearer " + token }
        });
        const result = await response.json();
        if (!response.ok || result.status !== "success") {
            logout();
            return;
        }
        currentUser = result.user;
        if (currentUser.role !== "Administrator" && currentUser.role !== "Organiser") {
            alert("You do not have permission to manage events.");
            window.location.href = "events.php";
            return;
        }
        updateNavbar();
        await loadVenues();
        await loadEvents();
    } catch (error) {
        showToast("Unable to load management dashboard.", "error");
    }
}

/* ========================================
   LOAD DATA
======================================== */
async function loadVenues() {
    try {
        const response = await fetch("api/venues.php", {
            headers: { Authorization: "Bearer " + token }
        });
        const result = await response.json();
        if (response.ok && result.status === "success") {
            venues = result.data || [];
            const venueSelect = document.getElementById("venue");
            venueSelect.innerHTML = '<option value="">Select venue</option>';
            venues.forEach(v => {
                const opt = document.createElement("option");
                opt.value = v.venue_id;
                opt.textContent = v.venue_name + (v.capacity ? ` (Cap: ${v.capacity})` : "");
                venueSelect.appendChild(opt);
            });
        }
    } catch (e) {
        console.error("Failed to load venues", e);
    }
}

async function loadEvents() {
    try {
        const response = await fetch("api/events.php", {
            headers: { Authorization: "Bearer " + token }
        });
        const result = await response.json();
        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Failed to load events");
        }
        events = result.data || [];
        displayEvents(events);
        updateStatistics();
    } catch (error) {
        eventTableBody.innerHTML = `<tr><td colspan="7" class="empty-events">${escapeHTML(error.message)}</td></tr>`;
    }
}

/* ========================================
   DISPLAY & STATISTICS
======================================== */
function displayEvents(eventList) {
    eventTableBody.innerHTML = "";
    if (eventList.length === 0) {
        eventTableBody.innerHTML = `<tr><td colspan="7" class="empty-events">No events found matching your filter.</td></tr>`;
        return;
    }
    eventList.forEach(ev => {
        const dateObj = new Date(ev.event_date + "T00:00:00");
        const dateText = isNaN(dateObj.getTime()) ? ev.event_date : dateObj.toLocaleDateString("en-MY", { day: "numeric", month: "short", year: "numeric" });
        const timeText = (ev.start_time ? ev.start_time.substring(0, 5) : "") + (ev.end_time ? " - " + ev.end_time.substring(0, 5) : "");
        const statusClass = getStatusClass(ev.status);

        const row = document.createElement("tr");
        row.innerHTML = `
            <td>
                <div class="event-name-block">
                    <strong>${escapeHTML(ev.event_name)}</strong>
                    <span class="category-badge">${escapeHTML(ev.category || "General")}</span>
                </div>
            </td>
            <td>
                <div class="date-info">
                    <strong>${dateText}</strong>
                    <span>${timeText}</span>
                </div>
            </td>
            <td>${escapeHTML(ev.venue_name || "N/A")}</td>
            <td><strong>${Number(ev.available_tickets ?? ev.total_tickets ?? 0)}</strong> / ${Number(ev.total_tickets ?? 0)}</td>
            <td><strong>RM ${Number(ev.ticket_price || 0).toFixed(2)}</strong></td>
            <td><span class="status-pill ${statusClass}">${escapeHTML(ev.status || "Upcoming")}</span></td>
            <td>
                <div class="action-buttons">
                    <button type="button" class="edit-btn" onclick="openEditEvent(${ev.event_id})">Edit</button>
                    <button type="button" class="delete-btn" onclick="openDeleteModal(${ev.event_id})">Delete</button>
                </div>
            </td>
        `;
        eventTableBody.appendChild(row);
    });
}

function getStatusClass(status) {
    if (status === "Upcoming") return "status-upcoming";
    if (status === "Ongoing") return "status-ongoing";
    if (status === "Completed") return "status-completed";
    if (status === "Cancelled") return "status-cancelled";
    return "";
}

function updateStatistics() {
    const totalEvents = events.length;
    const upcoming = events.filter(e => e.status === "Upcoming").length;
    const totalTickets = events.reduce((sum, e) => sum + Number(e.total_tickets || 0), 0);
    const availableTickets = events.reduce((sum, e) => sum + Number(e.available_tickets ?? e.total_tickets ?? 0), 0);

    document.getElementById("totalEvents").textContent = totalEvents;
    document.getElementById("upcomingEvents").textContent = upcoming;
    document.getElementById("totalTickets").textContent = totalTickets;
    document.getElementById("availableTickets").textContent = availableTickets;
}

/* ========================================
   SEARCH & FILTER
======================================== */
document.getElementById("eventSearch").addEventListener("input", filterEvents);
document.getElementById("statusFilter").addEventListener("change", filterEvents);

function filterEvents() {
    const search = document.getElementById("eventSearch").value.toLowerCase();
    const status = document.getElementById("statusFilter").value;

    const filtered = events.filter(ev => {
        const text = (ev.event_name + " " + (ev.venue_name || "") + " " + (ev.category || "")).toLowerCase();
        const matchesSearch = text.includes(search);
        const matchesStatus = status === "" || ev.status === status;
        return matchesSearch && matchesStatus;
    });
    displayEvents(filtered);
}

/* ========================================
   MODAL CONTROLS (CREATE / EDIT)
======================================== */
document.getElementById("createEventButton").addEventListener("click", () => {
    isEditMode = false;
    document.getElementById("modalEyebrow").textContent = "CREATE EVENT";
    document.getElementById("modalTitle").textContent = "New Event";
    saveEventButton.textContent = "Create Event";
    eventForm.reset();
    document.getElementById("eventId").value = "";
    clearFormMessage();
    eventModal.classList.add("show");
});

document.getElementById("closeEventModal").addEventListener("click", () => eventModal.classList.remove("show"));
document.getElementById("cancelEventModal").addEventListener("click", () => eventModal.classList.remove("show"));

function openEditEvent(id) {
    const ev = events.find(item => Number(item.event_id) === Number(id));
    if (!ev) return;

    isEditMode = true;
    document.getElementById("modalEyebrow").textContent = "EDIT EVENT";
    document.getElementById("modalTitle").textContent = "Edit Event Details";
    saveEventButton.textContent = "Save Changes";

    document.getElementById("eventId").value = ev.event_id;
    document.getElementById("eventName").value = ev.event_name || "";
    document.getElementById("category").value = ev.category || "";
    document.getElementById("venue").value = ev.venue_id || "";
    document.getElementById("eventDate").value = ev.event_date || "";
    document.getElementById("status").value = ev.status || "Upcoming";
    document.getElementById("startTime").value = ev.start_time || "";
    document.getElementById("endTime").value = ev.end_time || "";
    document.getElementById("ticketPrice").value = ev.ticket_price || "";
    document.getElementById("totalTicketCount").value = ev.total_tickets || "";
    document.getElementById("description").value = ev.description || "";

    clearFormMessage();
    eventModal.classList.add("show");
}

eventForm.addEventListener("submit", async function(e) {
    e.preventDefault();
    saveEventButton.disabled = true;
    saveEventButton.textContent = "Saving...";

    const payload = {
        event_name: document.getElementById("eventName").value,
        category: document.getElementById("category").value,
        venue_id: document.getElementById("venue").value,
        event_date: document.getElementById("eventDate").value,
        status: document.getElementById("status").value,
        start_time: document.getElementById("startTime").value,
        end_time: document.getElementById("endTime").value,
        ticket_price: document.getElementById("ticketPrice").value,
        total_tickets: document.getElementById("totalTicketCount").value,
        description: document.getElementById("description").value
    };

    const eventId = document.getElementById("eventId").value;
    if (isEditMode && eventId) {
        payload.event_id = Number(eventId);
    }

    try {
        const response = await fetch("api/events.php", {
            method: isEditMode ? "PUT" : "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify(payload)
        });
        const result = await response.json();
        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Failed to save event");
        }

        showToast(isEditMode ? "Event updated successfully!" : "Event created successfully!", "success");
        eventModal.classList.remove("show");
        await loadEvents();
    } catch (error) {
        showFormMessage(error.message, "error");
    } finally {
        saveEventButton.disabled = false;
        saveEventButton.textContent = isEditMode ? "Save Changes" : "Create Event";
    }
});

/* ========================================
   DELETE MODAL
======================================== */
function openDeleteModal(id) {
    selectedEventId = id;
    deleteModal.classList.add("show");
}

document.getElementById("cancelDeleteButton").addEventListener("click", () => {
    selectedEventId = null;
    deleteModal.classList.remove("show");
});

document.getElementById("confirmDeleteButton").addEventListener("click", async () => {
    if (!selectedEventId) return;
    const deleteBtn = document.getElementById("confirmDeleteButton");
    deleteBtn.disabled = true;
    deleteBtn.textContent = "Deleting...";

    try {
        const response = await fetch("api/events.php", {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify({ event_id: Number(selectedEventId) })
        });
        const result = await response.json();
        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Failed to delete event");
        }

        showToast("Event deleted successfully", "success");
        deleteModal.classList.remove("show");
        selectedEventId = null;
        await loadEvents();
    } catch (error) {
        showToast(error.message, "error");
    } finally {
        deleteBtn.disabled = false;
        deleteBtn.textContent = "Delete Event";
    }
});

/* ========================================
   HELPERS & NAVBAR
======================================== */
function updateNavbar() {
    const authNav = document.getElementById("authNavigation");
    if (authNav && currentUser) {
        authNav.innerHTML = `
            <span class="top-user">${escapeHTML(currentUser.name)}</span>
            <button type="button" class="top-logout" onclick="logout()">Logout</button>
        `;
    }
}

function logout() {
    localStorage.removeItem("eventify_token");
    localStorage.removeItem("eventify_user");
    window.location.href = "login.php";
}

function showToast(message, type) {
    toast.textContent = message;
    toast.className = "toast " + type + " show";
    setTimeout(() => { toast.className = "toast"; }, 3500);
}

function showFormMessage(msg, type) {
    formMessage.textContent = msg;
    formMessage.className = "form-message " + type;
}

function clearFormMessage() {
    formMessage.textContent = "";
    formMessage.className = "form-message";
}

function escapeHTML(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

initialise();
</script>

</body>
</html>