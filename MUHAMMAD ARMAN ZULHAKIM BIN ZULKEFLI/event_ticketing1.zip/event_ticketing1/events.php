<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discover Events | Eventify</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body.events-page {
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-family: var(--ev-body);
        }

        /* ---------- Navbar colour overrides ---------- */
        .events-page .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .events-page .navbar .brand,
        .events-page .navbar .brand span { color: #fff; }
        .events-page .navbar .brand-purple { color: var(--ev-coral); }
        .events-page .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .events-page .navbar .nav-links a { color: #b9d3cf; }
        .events-page .navbar .nav-links a:hover,
        .events-page .navbar .nav-links a.active { color: #fff; }
        .events-page .navbar .sign-in { color: #fff; }
        .events-page .navbar .nav-button {
            background: transparent;
            color: #fff;
            border: 1.5px solid rgba(255, 255, 255, .35);
            box-shadow: none;
        }
        .events-page .navbar .nav-button:hover {
            background: var(--ev-coral);
            border-color: var(--ev-coral);
            color: var(--ev-deep);
        }

        /* ---------- Page header ---------- */
        .ev-head {
            color: #fff;
            background:
                radial-gradient(520px 300px at 92% 0%, rgba(255, 106, 77, .24), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .ev-head-inner {
            padding: 56px 0 60px;
            display: flex;
            justify-content: space-between;
            align-items: end;
            gap: 24px;
        }
        .ev-head h1 {
            font-family: var(--ev-display);
            font-weight: 800;
            font-size: clamp(36px, 4.6vw, 58px);
            line-height: 1.05;
            letter-spacing: -1.2px;
            max-width: 640px;
        }
        .ev-head p { margin-top: 14px; color: #b9d3cf; font-size: 17px; max-width: 460px; line-height: 1.6; }
        .event-count {
            flex: none;
            padding: 14px 20px;
            border-radius: 14px;
            background: rgba(255, 255, 255, .08);
            border: 1px solid rgba(255, 255, 255, .14);
            color: #b9d3cf;
            font-size: 15px;
        }
        .event-count span {
            display: inline-block;
            margin-right: 4px;
            font-family: var(--ev-display);
            font-size: 30px;
            font-weight: 800;
            color: var(--ev-mint);
            vertical-align: middle;
        }

        /* ---------- Layout ---------- */
        .ev-layout {
            display: grid;
            grid-template-columns: 290px minmax(0, 1fr);
            gap: 44px;
            align-items: start;
            padding: 48px 0 80px;
        }

        /* ---------- Sidebar ---------- */
        .ev-side {
            position: sticky;
            top: 96px;
            padding: 24px;
            background: #fff;
            border: 1px solid var(--ev-line);
            border-radius: 18px;
        }
        .ev-side h2 {
            font-family: var(--ev-display);
            font-size: 20px;
            font-weight: 800;
            color: var(--ev-ink);
            margin-bottom: 12px;
        }
        .ev-side-block + .ev-side-block { margin-top: 26px; }

        .search-input-wrapper { position: relative; }
        .search-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-52%);
            font-size: 20px;
            color: #8fa5a7;
            pointer-events: none;
        }
        #searchInput {
            width: 100%;
            height: 48px;
            padding: 0 14px 0 40px;
            border: 1.5px solid var(--ev-line);
            border-radius: 12px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font: 500 15px var(--ev-body);
            outline: none;
            transition: border-color .2s, box-shadow .2s, background .2s;
        }
        #searchInput::placeholder { color: #98aaac; }
        #searchInput:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 4px rgba(20, 102, 106, .15);
        }

        .search-button {
            width: 100%;
            height: 46px;
            margin-top: 10px;
            border: none;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 15px var(--ev-body);
            cursor: pointer;
            transition: background .2s;
        }
        .search-button:hover { background: var(--ev-coral-dark); }

        .cat-list { display: grid; gap: 6px; }
        .cat-chip {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            padding: 11px 14px;
            border: 1.5px solid transparent;
            border-radius: 12px;
            background: transparent;
            color: var(--ev-ink);
            font: 500 15px var(--ev-body);
            text-align: left;
            cursor: pointer;
            transition: background .15s;
        }
        .cat-chip:hover { background: var(--ev-paper); }
        .cat-chip small {
            min-width: 26px;
            padding: 2px 8px;
            border-radius: 999px;
            background: var(--ev-paper);
            color: var(--ev-muted);
            font-size: 13px;
            font-weight: 700;
            text-align: center;
        }
        .cat-chip[aria-pressed="true"] {
            background: var(--ev-deep);
            color: #fff;
            font-weight: 700;
        }
        .cat-chip[aria-pressed="true"] small { background: var(--ev-coral); color: var(--ev-deep); }

        .reset-link {
            margin-top: 22px;
            padding: 0;
            border: none;
            background: none;
            color: var(--ev-teal-soft);
            font: 700 14px var(--ev-body);
            cursor: pointer;
        }
        .reset-link:hover { text-decoration: underline; }

        .cat-chip:focus-visible,
        .search-button:focus-visible,
        .reset-link:focus-visible,
        .ticket-row:focus-visible,
        .empty-state button:focus-visible {
            outline: 3px solid var(--ev-teal-soft);
            outline-offset: 2px;
        }

        /* ---------- Month groups ---------- */
        .month-group + .month-group { margin-top: 38px; }

        .month-title {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 16px;
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -.4px;
            color: var(--ev-ink);
        }
        .month-title::after {
            content: "";
            flex: 1;
            height: 2px;
            background: repeating-linear-gradient(90deg, var(--ev-line) 0 8px, transparent 8px 14px);
        }

        .ticket-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 16px; }
        .ticket-list li { filter: drop-shadow(0 6px 14px rgba(7, 43, 45, .09)); transition: filter .2s; }
        .ticket-list li:hover { filter: drop-shadow(0 10px 20px rgba(7, 43, 45, .16)); }

        /* ---------- Ticket row ---------- */
        .ticket-row {
            --stub: 112px;
            display: grid;
            grid-template-columns: var(--stub) minmax(0, 1fr) auto;
            align-items: stretch;
            background: #fff;
            border-radius: 18px;
            color: inherit;
            text-decoration: none;
            -webkit-mask:
                radial-gradient(circle 12px at var(--stub) 0, #0000 98%, #000) top / 100% 51% no-repeat,
                radial-gradient(circle 12px at var(--stub) 100%, #0000 98%, #000) bottom / 100% 51% no-repeat;
            mask:
                radial-gradient(circle 12px at var(--stub) 0, #0000 98%, #000) top / 100% 51% no-repeat,
                radial-gradient(circle 12px at var(--stub) 100%, #0000 98%, #000) bottom / 100% 51% no-repeat;
        }

        .ticket-stub {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 2px;
            padding: 18px 10px;
            color: #fff;
            border-radius: 18px 0 0 18px;
            background: var(--ev-teal);
            border-right: 2px dashed rgba(255, 255, 255, .45);
        }
        .tone-1 .ticket-stub { background: #c9442b; }
        .tone-2 .ticket-stub { background: #1f7a68; }
        .ticket-row.is-muted .ticket-stub { background: #7f9496; }
        .ticket-stub small { font-size: 13px; font-weight: 500; opacity: .85; }
        .ticket-stub b { font-family: var(--ev-display); font-size: 40px; font-weight: 800; line-height: 1; }
        .ticket-stub span { font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; }

        .ticket-main { padding: 20px 24px; min-width: 0; }
        .ticket-tags { display: flex; flex-wrap: wrap; gap: 8px; }
        .chip {
            padding: 4px 10px;
            border-radius: 999px;
            background: #e4f6ef;
            color: var(--ev-teal-soft);
            font-size: 12px;
            font-weight: 700;
        }
        .chip.status { background: #fff1ef; color: #a1301d; }
        .ticket-main h4 {
            margin: 10px 0 8px;
            font-family: var(--ev-display);
            font-size: 23px;
            font-weight: 800;
            letter-spacing: -.3px;
            color: var(--ev-ink);
        }
        .ticket-meta { color: var(--ev-muted); font-size: 14px; line-height: 1.6; }

        .ticket-side {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            justify-content: center;
            gap: 4px;
            padding: 20px 26px 20px 20px;
            text-align: right;
        }
        .ticket-side strong { font-family: var(--ev-display); font-size: 24px; font-weight: 800; color: var(--ev-ink); }
        .ticket-side small { color: var(--ev-muted); font-size: 13px; }
        .ticket-side small.low { color: var(--ev-coral-dark); font-weight: 700; }
        .ticket-go {
            margin-top: 10px;
            padding: 9px 16px;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-size: 14px;
            font-weight: 700;
            transition: background .2s;
        }
        .ticket-row:hover .ticket-go { background: var(--ev-coral-dark); }
        .ticket-row.is-muted .ticket-go { background: var(--ev-line); color: var(--ev-muted); }

        /* ---------- States ---------- */
        .loading-events, .empty-state {
            padding: 52px 28px;
            text-align: center;
            color: var(--ev-muted);
            background: #fff;
            border: 1px dashed var(--ev-line);
            border-radius: 18px;
            font-size: 16px;
        }
        .empty-state h3 { font-family: var(--ev-display); font-size: 24px; font-weight: 800; color: var(--ev-ink); margin-bottom: 8px; }
        .empty-state button {
            margin-top: 18px;
            padding: 11px 20px;
            border: none;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 15px var(--ev-body);
            cursor: pointer;
        }

        /* ---------- CTA + footer ---------- */
        .events-cta { padding: 0 0 80px; }
        .cta-box {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 28px;
            padding: 42px 50px;
            border-radius: 24px;
            color: #fff;
            background:
                radial-gradient(420px 260px at 100% 0%, rgba(255, 106, 77, .28), transparent 70%),
                linear-gradient(150deg, var(--ev-teal), var(--ev-deep));
        }
        .cta-box h2 { font-family: var(--ev-display); font-weight: 800; font-size: clamp(26px, 3vw, 36px); letter-spacing: -.6px; color: #fff; }
        .cta-box p { margin-top: 8px; color: #b9d3cf; font-size: 16px; }
        .cta-button {
            flex: none;
            padding: 16px 26px;
            border-radius: 12px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font: 700 16px var(--ev-body);
            text-decoration: none;
            transition: background .2s;
        }
        .cta-button:hover { background: var(--ev-coral-dark); }

        /* ---------- Footer ---------- */
        .ev-footer {
            color: #b9d3cf;
            background: linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .ev-footer-top {
            display: grid;
            grid-template-columns: minmax(0, 1.6fr) repeat(2, minmax(0, 1fr));
            gap: 48px;
            padding: 60px 0 44px;
        }
        .ev-footer-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            text-decoration: none;
        }
        .ev-footer-mark {
            width: 38px;
            height: 38px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-size: 20px;
        }
        .ev-footer-brand em { font-style: normal; color: var(--ev-coral); }
        .ev-footer-about { margin-top: 16px; max-width: 340px; font-size: 15px; line-height: 1.65; color: #9fc2bd; }

        .ev-footer h3 { font-family: var(--ev-display); font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 14px; }
        .ev-footer ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 10px; }
        .ev-footer ul a { color: #b9d3cf; font-size: 15px; text-decoration: none; }
        .ev-footer ul a:hover { color: #fff; text-decoration: underline; }
        .ev-footer a:focus-visible { outline: 3px solid var(--ev-mint); outline-offset: 3px; border-radius: 4px; }

        .ev-footer-bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px 24px;
            padding: 22px 0 28px;
            border-top: 2px dashed rgba(255, 255, 255, .2);
            font-size: 14px;
            color: #9fc2bd;
        }

        /* ---------- Responsive ---------- */
        @media (max-width: 980px) {
            .ev-layout { grid-template-columns: 1fr; gap: 28px; padding-top: 32px; }
            .ev-side { position: static; }
            .cat-list { display: flex; flex-wrap: wrap; gap: 8px; }
            .cat-chip { width: auto; gap: 10px; border-color: var(--ev-line); border-radius: 999px; padding: 9px 14px; }
            .ev-head-inner { flex-direction: column; align-items: flex-start; }
            .ev-footer-top { grid-template-columns: 1fr 1fr; }
            .ev-footer-top > div:first-child { grid-column: 1 / -1; }
        }
        @media (max-width: 640px) {
            .ticket-row {
                grid-template-columns: 1fr;
                -webkit-mask: none;
                mask: none;
                border: 1px solid var(--ev-line);
            }
            .ticket-list li { filter: none; }
            .ticket-stub {
                flex-direction: row;
                gap: 10px;
                justify-content: flex-start;
                padding: 12px 20px;
                border-radius: 17px 17px 0 0;
                border-right: 0;
                border-bottom: 2px dashed rgba(255, 255, 255, .45);
            }
            .ticket-stub b { font-size: 28px; }
            .ticket-side {
                flex-direction: row;
                flex-wrap: wrap;
                align-items: center;
                justify-content: space-between;
                padding: 0 24px 20px;
                text-align: left;
            }
            .ticket-go { margin-top: 0; }
            .cta-box { flex-direction: column; align-items: flex-start; padding: 32px 26px; }
            .ev-footer-top { padding: 44px 0 32px; gap: 32px 24px; }
        }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
    </style>
</head>

<body class="events-page">

<!-- NAVIGATION -->
<header class="navbar">
    <div class="container nav-container">

        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>

        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="events.php" class="active">Events</a>
            <a href="bookings.php">My Bookings</a>
        </nav>

        <div class="nav-actions" id="authNavigation">
            <a href="login.php" class="sign-in">Sign In</a>
            <a href="register.php" class="nav-button">Create Account</a>
        </div>

    </div>
</header>


<!-- PAGE HEADER -->
<section class="ev-head">
    <div class="container ev-head-inner">
        <div>
            <h1>Find something worth remembering.</h1>
            <p>Concerts, workshops, seminars and festivals. Pick a date, grab a ticket.</p>
        </div>
        <div class="event-count"><span id="eventCount">0</span> events found</div>
    </div>
</section>


<!-- EVENTS -->
<main class="container ev-layout">

    <aside class="ev-side" aria-label="Filter events">

        <div class="ev-side-block">
            <h2>Search</h2>
            <div class="search-input-wrapper">
                <span class="search-icon">⌕</span>
                <input
                    type="text"
                    id="searchInput"
                    placeholder="Event, venue or place"
                    autocomplete="off"
                    aria-label="Search events"
                >
            </div>
            <button type="button" class="search-button" id="searchButton">Search events</button>
        </div>

        <div class="ev-side-block">
            <h2>Category</h2>
            <div class="cat-list" id="categoryChips"></div>

            <!-- Kept for compatibility; the chips above control it. -->
            <select id="categoryFilter" hidden>
                <option value="">All Categories</option>
                <option value="Technology">Technology</option>
                <option value="Workshop">Workshop</option>
                <option value="Music">Music</option>
                <option value="Seminar">Seminar</option>
                <option value="Food">Food</option>
            </select>

            <button type="button" class="reset-link" id="resetFilters">Clear filters</button>
        </div>

    </aside>

    <section aria-live="polite">
        <div id="eventGrid">
            <div class="loading-events">Loading events...</div>
        </div>
    </section>

</main>


<!-- CALL TO ACTION -->
<section class="events-cta">
    <div class="container">
        <div class="cta-box">
            <div>
                <h2>Your next experience starts here.</h2>
                <p>Create your account and start booking today.</p>
            </div>
            <a href="register.php" class="cta-button">Get started</a>
        </div>
    </div>
</section>


<!-- FOOTER -->
<footer class="ev-footer">
    <div class="container">

        <div class="ev-footer-top">

            <div>
                <a href="index.php" class="ev-footer-brand">
                    <span class="ev-footer-mark">E</span>
                    <span>Event<em>ify</em></span>
                </a>
                <p class="ev-footer-about">
                    Find events, book tickets and keep every reservation in one place.
                </p>
            </div>

            <div>
                <h3>Explore</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="events.php">All events</a></li>
                    <li><a href="index.php#how-it-works">How it works</a></li>
                </ul>
            </div>

            <div>
                <h3>Your account</h3>
                <ul>
                    <li><a href="login.php">Sign in</a></li>
                    <li><a href="register.php">Create account</a></li>
                    <li><a href="bookings.php">My bookings</a></li>
                </ul>
            </div>

        </div>

        <div class="ev-footer-bottom">
            <span>© 2026 Eventify</span>
            <span>Event Ticketing &amp; Venue Booking System</span>
        </div>

    </div>
</footer>


<script>
(function () {

    const grid = document.getElementById('eventGrid');
    const countEl = document.getElementById('eventCount');
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const categorySelect = document.getElementById('categoryFilter');
    const chipsBox = document.getElementById('categoryChips');
    const resetButton = document.getElementById('resetFilters');

    let allEvents = [];

    function esc(value) {
        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function price(value) {
        const n = Number(value);
        return Number.isFinite(n) ? 'RM ' + n.toFixed(2) : 'Price unavailable';
    }

    function time(t) {
        const m = /^(\d{1,2}):(\d{2})/.exec(String(t || ''));
        if (!m) return '';
        const h = Number(m[1]);
        return ((h % 12) || 12) + ':' + m[2] + ' ' + (h >= 12 ? 'PM' : 'AM');
    }

    function parseDate(iso) {
        const d = new Date(String(iso) + 'T00:00:00');
        return Number.isNaN(d.getTime()) ? null : d;
    }

    function tone(category) {
        let sum = 0;
        for (const ch of String(category || '')) sum += ch.charCodeAt(0);
        return sum % 3;
    }

    function sortKey(e) {
        return String(e.event_date) + ' ' + String(e.start_time || '');
    }

    /* ---------- Category chips ---------- */

    function buildCategories() {
        const names = new Set(
            Array.from(categorySelect.options).map(o => o.value).filter(Boolean)
        );
        allEvents.forEach(e => { if (e.category) names.add(e.category); });

        categorySelect.innerHTML = '<option value="">All Categories</option>' +
            Array.from(names).map(n => '<option value="' + esc(n) + '">' + esc(n) + '</option>').join('');

        renderChips();
    }

    function renderChips() {
        const current = categorySelect.value;
        const counts = {};
        allEvents.forEach(e => { counts[e.category] = (counts[e.category] || 0) + 1; });

        const items = [{ value: '', label: 'All events', count: allEvents.length }]
            .concat(Array.from(categorySelect.options)
                .filter(o => o.value)
                .map(o => ({ value: o.value, label: o.value, count: counts[o.value] || 0 })));

        chipsBox.innerHTML = items.map(item =>
            '<button type="button" class="cat-chip" data-value="' + esc(item.value) +
            '" aria-pressed="' + (item.value === current) + '">' +
            '<span>' + esc(item.label) + '</span><small>' + item.count + '</small></button>'
        ).join('');
    }

    chipsBox.addEventListener('click', function (event) {
        const chip = event.target.closest('.cat-chip');
        if (!chip) return;
        categorySelect.value = chip.dataset.value;
        renderChips();
        render();
    });

    /* ---------- Render ---------- */

    function render() {
        const q = searchInput.value.trim().toLowerCase();
        const cat = categorySelect.value;

        const list = allEvents
            .filter(e => !cat || e.category === cat)
            .filter(e => {
                if (!q) return true;
                return [e.event_name, e.description, e.venue_name, e.location, e.category]
                    .some(v => String(v || '').toLowerCase().includes(q));
            })
            .sort((a, b) => sortKey(a).localeCompare(sortKey(b)));

        countEl.textContent = list.length;

        if (!list.length) {
            grid.innerHTML =
                '<div class="empty-state"><h3>No events match</h3>' +
                '<p>Try a different keyword or category.</p>' +
                '<button type="button" id="emptyReset">Clear filters</button></div>';
            document.getElementById('emptyReset').addEventListener('click', resetAll);
            return;
        }

        const groups = new Map();
        list.forEach(e => {
            const d = parseDate(e.event_date);
            const key = d ? d.getFullYear() + '-' + d.getMonth() : 'unknown';
            const label = d ? d.toLocaleDateString('en-MY', { month: 'long', year: 'numeric' }) : 'Date to be confirmed';
            if (!groups.has(key)) groups.set(key, { label: label, items: [] });
            groups.get(key).items.push(e);
        });

        grid.innerHTML = Array.from(groups.values()).map(group =>
            '<section class="month-group"><h3 class="month-title">' + esc(group.label) + '</h3>' +
            '<ul class="ticket-list">' + group.items.map(ticketRow).join('') + '</ul></section>'
        ).join('');
    }

    function ticketRow(e) {
        const id = Number(e.event_id);
        const safeId = Number.isSafeInteger(id) && id > 0 ? id : 0;
        const d = parseDate(e.event_date);
        const day = d ? d.toLocaleDateString('en-MY', { day: '2-digit' }) : '—';
        const month = d ? d.toLocaleDateString('en-MY', { month: 'short' }) : '';
        const weekday = d ? d.toLocaleDateString('en-MY', { weekday: 'short' }) : '';

        const start = time(e.start_time);
        const end = time(e.end_time);
        const when = start && end ? start + ' to ' + end : start;

        const place = [e.venue_name, e.location].filter(Boolean).join(', ') || 'Venue to be confirmed';

        const left = e.available_tickets === undefined || e.available_tickets === null
            ? null : Number(e.available_tickets);
        const soldOut = left !== null && Number.isFinite(left) && left <= 0;
        const notUpcoming = e.status && e.status !== 'Upcoming';
        const muted = soldOut || notUpcoming;

        let leftText = '';
        if (soldOut) leftText = '<small class="low">Sold out</small>';
        else if (left !== null && Number.isFinite(left)) {
            leftText = '<small' + (left <= 20 ? ' class="low"' : '') + '>' + left + ' tickets left</small>';
        }

        return '<li><a class="ticket-row tone-' + tone(e.category) + (muted ? ' is-muted' : '') +
            '" href="' + (safeId ? 'event-details.php?event_id=' + safeId : 'events.php') + '">' +
            '<div class="ticket-stub"><small>' + esc(weekday) + '</small><b>' + esc(day) + '</b><span>' + esc(month) + '</span></div>' +
            '<div class="ticket-main">' +
                '<div class="ticket-tags"><span class="chip">' + esc(e.category || 'Event') + '</span>' +
                (notUpcoming ? '<span class="chip status">' + esc(e.status) + '</span>' : '') + '</div>' +
                '<h4>' + esc(e.event_name) + '</h4>' +
                '<p class="ticket-meta">' + (when ? esc(when) + '<br>' : '') + esc(place) + '</p>' +
            '</div>' +
            '<div class="ticket-side"><strong>' + price(e.ticket_price) + '</strong>' + leftText +
                '<span class="ticket-go">' + (muted ? 'View details' : 'View event') + '</span></div>' +
            '</a></li>';
    }

    /* ---------- Controls ---------- */

    function resetAll() {
        searchInput.value = '';
        categorySelect.value = '';
        renderChips();
        render();
    }

    searchButton.addEventListener('click', render);
    searchInput.addEventListener('input', render);
    searchInput.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') { event.preventDefault(); render(); }
    });
    categorySelect.addEventListener('change', function () { renderChips(); render(); });
    resetButton.addEventListener('click', resetAll);

    /* ---------- Load ---------- */

    async function load() {
        try {
            const response = await fetch('api/events.php');
            if (!response.ok) throw new Error('Request failed');
            const result = await response.json();
            if (result.status !== 'success' || !Array.isArray(result.data)) throw new Error('Bad response');

            allEvents = result.data;
            buildCategories();
            render();
        } catch (error) {
            countEl.textContent = '0';
            grid.innerHTML = '<div class="empty-state"><h3>Events could not be loaded</h3>' +
                '<p>Check that Apache and MySQL are running, then refresh the page.</p></div>';
        }
    }

    load();

})();
</script>

<script src="js/auth.js"></script>

</body>
</html>