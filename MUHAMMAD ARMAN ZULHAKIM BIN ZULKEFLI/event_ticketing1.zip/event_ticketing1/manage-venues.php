<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Venues | Eventify</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body {
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-family: var(--ev-body);
            min-height: 100vh;
        }

        /* ======================================
           NAVBAR OVERRIDES
        ====================================== */
        .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .navbar .brand, .navbar .brand span { color: #fff; }
        .navbar .brand-purple { color: var(--ev-coral); }
        .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .navbar .nav-links a { color: #b9d3cf; }
        .navbar .nav-links a:hover, .navbar .nav-links a.active { color: #fff; }

        /* ======================================
           HERO
        ====================================== */
        .venue-hero {
            padding: 56px 0 62px;
            color: white;
            background:
                radial-gradient(550px 320px at 90% 0%, rgba(255, 106, 77, .22), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .venue-hero-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 28px;
            flex-wrap: wrap;
        }
        .venue-hero .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 999px;
            background: rgba(168, 235, 211, .15);
            color: var(--ev-mint);
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .6px;
        }
        .venue-hero h1 {
            font-family: var(--ev-display);
            font-size: clamp(34px, 4.2vw, 50px);
            font-weight: 800;
            letter-spacing: -1.2px;
            line-height: 1.05;
            margin-top: 12px;
            color: #fff;
        }
        .venue-hero p {
            color: #b9d3cf;
            font-size: 16px;
            margin-top: 8px;
        }
        .new-venue-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 14px 24px;
            border: none;
            border-radius: 14px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            cursor: pointer;
            font: 700 15px var(--ev-body);
            box-shadow: 0 10px 24px rgba(255, 106, 77, .3);
            transition: all .2s ease;
        }
        .new-venue-btn:hover {
            background: var(--ev-coral-dark);
            transform: translateY(-2px);
            box-shadow: 0 14px 28px rgba(255, 106, 77, .38);
        }

        /* ======================================
           CONTENT & STATS
        ====================================== */
        .venue-section {
            padding: 40px 0 96px;
        }
        .venue-stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .venue-stat {
            position: relative;
            padding: 24px;
            background: white;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(7, 43, 45, .03);
            overflow: hidden;
        }
        .venue-stat::before {
            content: "";
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: var(--ev-teal-soft);
        }
        .venue-stat:nth-child(2)::before { background: var(--ev-coral); }
        .venue-stat:nth-child(3)::before { background: var(--ev-mint); }
        .venue-stat:nth-child(4)::before { background: var(--ev-deep); }

        .venue-stat span {
            color: var(--ev-muted);
            font-size: 12px;
            font-weight: 700;
            letter-spacing: .8px;
            text-transform: uppercase;
        }
        .venue-stat strong {
            display: block;
            margin-top: 8px;
            font-family: var(--ev-display);
            font-size: 34px;
            font-weight: 800;
            color: var(--ev-ink);
            letter-spacing: -.6px;
        }

        /* ======================================
           TOOLBAR
        ====================================== */
        .venue-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            padding: 18px 20px;
            margin-bottom: 24px;
            background: white;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
            box-shadow: 0 4px 14px rgba(7, 43, 45, .02);
        }
        .venue-toolbar input {
            flex: 1;
            height: 48px;
            padding: 0 16px;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            outline: none;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font: 500 15px var(--ev-body);
            transition: all .2s;
        }
        .venue-toolbar input:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 3px rgba(20, 102, 106, .12);
        }
        .venue-toolbar select {
            min-width: 180px;
            height: 48px;
            padding: 0 14px;
            background: var(--ev-paper);
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            color: var(--ev-ink);
            font: 600 14px var(--ev-body);
            cursor: pointer;
            transition: all .2s;
        }
        .venue-toolbar select:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            outline: none;
        }

        /* ======================================
           CARDS GRID
        ====================================== */
        .venue-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 24px;
        }
        .venue-card {
            overflow: hidden;
            background: white;
            border: 1px solid var(--ev-line);
            border-radius: 22px;
            box-shadow: 0 12px 30px rgba(7, 43, 45, .04);
            transition: all .25s ease;
        }
        .venue-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(7, 43, 45, .08);
        }
        .venue-cover {
            height: 145px;
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background:
                radial-gradient(circle at 75% 20%, rgba(168, 235, 211, .3), transparent 40%),
                linear-gradient(135deg, var(--ev-deep), var(--ev-teal));
        }
        .venue-symbol {
            color: rgba(255,255,255,.85);
            font-size: 38px;
            font-weight: 800;
        }
        .venue-status {
            position: absolute;
            left: 15px;
            top: 15px;
            padding: 5px 12px;
            border-radius: 100px;
            font-size: 11px;
            font-weight: 700;
            backdrop-filter: blur(8px);
        }
        .venue-available {
            color: #0f6446;
            background: rgba(228, 246, 239, .85);
            border: 1px solid rgba(15, 100, 70, .2);
        }
        .venue-unavailable {
            color: #a1301d;
            background: rgba(255, 241, 239, .85);
            border: 1px solid rgba(161, 48, 29, .2);
        }
        .venue-content {
            padding: 24px;
        }
        .venue-content h3 {
            min-height: 48px;
            font-family: var(--ev-display);
            font-size: 20px;
            font-weight: 800;
            line-height: 1.35;
            color: var(--ev-ink);
        }
        .venue-location {
            color: var(--ev-muted);
            font-size: 13px;
            margin-top: 6px;
            min-height: 30px;
        }
        .venue-information {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-top: 18px;
        }
        .venue-info-box {
            padding: 12px 14px;
            background: var(--ev-paper);
            border: 1px solid var(--ev-line);
            border-radius: 12px;
        }
        .venue-info-box small {
            display: block;
            color: var(--ev-muted);
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: .6px;
            font-weight: 700;
        }
        .venue-info-box strong {
            display: block;
            margin-top: 4px;
            font-size: 15px;
            color: var(--ev-ink);
        }
        .venue-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            padding-top: 18px;
            border-top: 1px solid var(--ev-line);
        }
        .venue-actions button {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font: 700 13px var(--ev-body);
            transition: background .15s;
        }
        .venue-edit {
            color: var(--ev-deep);
            background: var(--ev-mint);
        }
        .venue-edit:hover {
            background: #93dec5;
        }
        .venue-delete {
            color: #a1301d;
            background: #fff1ef;
            border: 1px solid #f2c6bd;
        }
        .venue-delete:hover {
            background: #fde8e4;
        }
        .empty-venues {
            grid-column: 1 / -1;
            min-height: 260px;
            display: flex;
            justify-content: center;
            align-items: center;
            background: white;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
            color: var(--ev-muted);
            font-size: 16px;
        }

        /* ======================================
           MODAL
        ====================================== */
        .modal-overlay {
            position: fixed;
            inset: 0;
            z-index: 5000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(7, 43, 45, .75);
            backdrop-filter: blur(6px);
        }
        .modal-overlay.show {
            display: flex;
        }
        .venue-modal {
            width: min(560px, 100%);
            background: white;
            border-radius: 24px;
            box-shadow: 0 25px 70px rgba(7, 43, 45, .32);
            overflow: hidden;
        }
        .venue-modal-header {
            padding: 24px 28px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--ev-line);
        }
        .venue-modal-header span {
            color: var(--ev-teal-soft);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        .venue-modal-header h2 {
            margin-top: 4px;
            font-family: var(--ev-display);
            font-size: 24px;
            font-weight: 800;
            color: var(--ev-ink);
        }
        .close-modal {
            width: 38px;
            height: 38px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-size: 20px;
            line-height: 1;
            transition: background .15s;
        }
        .close-modal:hover {
            background: var(--ev-line);
        }
        .venue-form {
            padding: 28px;
        }
        .venue-form-group {
            margin-bottom: 18px;
        }
        .venue-form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--ev-ink);
            font-size: 13px;
            font-weight: 700;
        }
        .venue-form-group input,
        .venue-form-group select {
            width: 100%;
            height: 48px;
            padding: 0 16px;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            outline: none;
            font: 500 15px var(--ev-body);
            transition: all .2s;
        }
        .venue-form-group input:focus,
        .venue-form-group select:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 3px rgba(20, 102, 106, .12);
        }
        .venue-form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .venue-form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid var(--ev-line);
        }
        .venue-cancel-btn,
        .venue-save-btn {
            padding: 12px 22px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font: 700 15px var(--ev-body);
            transition: background .15s;
        }
        .venue-cancel-btn {
            background: var(--ev-paper);
            color: var(--ev-ink);
        }
        .venue-cancel-btn:hover {
            background: var(--ev-line);
        }
        .venue-save-btn {
            background: var(--ev-coral);
            color: var(--ev-deep);
        }
        .venue-save-btn:hover {
            background: var(--ev-coral-dark);
        }
        .venue-save-btn:disabled {
            opacity: .6;
            cursor: not-allowed;
        }
        .form-message {
            display: none;
            padding: 13px;
            margin-bottom: 18px;
            border-radius: 10px;
            font-size: 13px;
            line-height: 1.5;
        }
        .form-message.error {
            display: block;
            color: #a1301d;
            background: #fff1ef;
        }
        .form-message.success {
            display: block;
            color: #0f6446;
            background: #e4f6ef;
        }

        /* DELETE MODAL */
        .delete-modal {
            width: min(420px, 100%);
            padding: 32px;
            text-align: center;
            background: white;
            border-radius: 24px;
            box-shadow: 0 25px 70px rgba(7, 43, 45, .3);
        }
        .delete-modal-icon {
            width: 60px;
            height: 60px;
            display: grid;
            place-items: center;
            margin: 0 auto;
            border-radius: 50%;
            background: #fff1ef;
            color: #a1301d;
            font-size: 24px;
            font-weight: 800;
        }
        .delete-modal h2 {
            margin-top: 18px;
            font-family: var(--ev-display);
            font-size: 24px;
            font-weight: 800;
            color: var(--ev-ink);
        }
        .delete-modal p {
            margin-top: 8px;
            color: var(--ev-muted);
            font-size: 15px;
            line-height: 1.6;
        }
        .delete-buttons {
            display: flex;
            gap: 12px;
            margin-top: 26px;
        }
        .delete-buttons button {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font: 700 15px var(--ev-body);
            transition: background .15s;
        }
        .confirm-delete {
            background: #c34848;
            color: white;
        }
        .confirm-delete:hover {
            background: #a93a3a;
        }

        /* TOAST */
        .toast {
            position: fixed;
            z-index: 7000;
            right: 25px;
            bottom: 25px;
            min-width: 280px;
            padding: 15px 22px;
            color: white;
            border-radius: 14px;
            opacity: 0;
            transform: translateY(40px);
            pointer-events: none;
            box-shadow: 0 18px 45px rgba(7, 43, 45, .25);
            transition: .3s;
            font: 700 14px var(--ev-body);
        }
        .toast.show {
            opacity: 1;
            transform: translateY(0);
        }
        .toast.success { background: #0f6446; }
        .toast.error { background: #a1301d; }

        /* FOOTER */
        .ev-footer { color: #b9d3cf; background: linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%); margin-top: auto; }
        .ev-footer-top {
            display: grid;
            grid-template-columns: minmax(0, 1.6fr) repeat(2, minmax(0, 1fr));
            gap: 48px;
            padding: 60px 0 44px;
        }
        .ev-footer-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            text-decoration: none;
        }
        .ev-footer-mark {
            width: 38px;
            height: 38px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-size: 20px;
        }
        .ev-footer-brand em { font-style: normal; color: var(--ev-coral); }
        .ev-footer-about { margin-top: 16px; max-width: 340px; font-size: 15px; line-height: 1.65; color: #9fc2bd; }
        .ev-footer h3 { font-family: var(--ev-display); font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 14px; }
        .ev-footer ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 10px; }
        .ev-footer ul a { color: #b9d3cf; font-size: 15px; text-decoration: none; }
        .ev-footer ul a:hover { color: #fff; text-decoration: underline; }
        .ev-footer-bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px 24px;
            padding: 22px 0 28px;
            border-top: 2px dashed rgba(255, 255, 255, .2);
            font-size: 14px;
            color: #9fc2bd;
        }

        @media (max-width: 950px) {
            .venue-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .venue-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .ev-footer-top { grid-template-columns: 1fr 1fr; }
            .ev-footer-top > div:first-child { grid-column: 1 / -1; }
        }
        @media (max-width: 650px) {
            .venue-hero-content { flex-direction: column; align-items: flex-start; }
            .new-venue-btn { width: 100%; justify-content: center; }
            .venue-grid, .venue-stats, .venue-form-grid { grid-template-columns: 1fr; }
            .venue-toolbar { flex-direction: column; align-items: stretch; }
            .venue-toolbar input, .venue-toolbar select { width: 100%; }
            .ev-footer-top { padding: 44px 0 32px; gap: 32px 24px; }
        }

        body.venue-access-pending .venue-hero,
        body.venue-access-pending .venue-section {
            visibility: hidden;
        }
    </style>
</head>
<body class="venue-access-pending">

<!-- NAVBAR -->
<header class="navbar">
    <div class="container nav-container">
        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>
        <nav class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage-events.php">Manage Events</a>
            <a href="manage-venues.php" class="active">Manage Venues</a>
            <a href="events.php">Website</a>
        </nav>
        <div class="nav-actions" id="authNavigation"></div>
    </div>
</header>

<!-- HERO -->
<section class="venue-hero">
    <div class="container venue-hero-content">
        <div>
            <span class="eyebrow">VENUE MANAGEMENT</span>
            <h1>Manage Venues</h1>
            <p>Create and maintain locations used by your events.</p>
        </div>
        <button type="button" class="new-venue-btn" id="newVenueButton">
            <span>+</span> Add New Venue
        </button>
    </div>
</section>

<!-- CONTENT -->
<main class="venue-section">
    <div class="container">
        <!-- STATS -->
        <section class="venue-stats">
            <article class="venue-stat">
                <span>Total Venues</span>
                <strong id="totalVenues">0</strong>
            </article>
            <article class="venue-stat">
                <span>Available</span>
                <strong id="availableVenues">0</strong>
            </article>
            <article class="venue-stat">
                <span>Unavailable</span>
                <strong id="unavailableVenues">0</strong>
            </article>
            <article class="venue-stat">
                <span>Total Capacity</span>
                <strong id="totalCapacity">0</strong>
            </article>
        </section>

        <!-- SEARCH -->
        <section class="venue-toolbar">
            <input type="text" id="venueSearch" placeholder="Search venue name or location...">
            <select id="venueStatusFilter">
                <option value="">All Statuses</option>
                <option value="Available">Available</option>
                <option value="Unavailable">Unavailable</option>
            </select>
        </section>

        <!-- VENUES GRID -->
        <section class="venue-grid" id="venueGrid">
            <div class="empty-venues">Loading venues...</div>
        </section>
    </div>
</main>

<!-- CREATE / EDIT MODAL -->
<div class="modal-overlay" id="venueModal">
    <div class="venue-modal">
        <div class="venue-modal-header">
            <div>
                <span id="venueModalEyebrow">CREATE VENUE</span>
                <h2 id="venueModalTitle">New Venue</h2>
            </div>
            <button type="button" class="close-modal" id="closeVenueModal">&times;</button>
        </div>
        <form class="venue-form" id="venueForm">
            <input type="hidden" id="venueId">
            <div class="form-message" id="venueFormMessage"></div>
            <div class="venue-form-group">
                <label for="venueName">Venue Name</label>
                <input type="text" id="venueName" placeholder="Example: Eventify Convention Centre" required>
            </div>
            <div class="venue-form-group">
                <label for="venueLocation">Location</label>
                <input type="text" id="venueLocation" placeholder="Example: Kuala Lumpur" required>
            </div>
            <div class="venue-form-grid">
                <div class="venue-form-group">
                    <label for="venueCapacity">Capacity</label>
                    <input type="number" id="venueCapacity" min="1" placeholder="500" required>
                </div>
                <div class="venue-form-group">
                    <label for="venueStatus">Status</label>
                    <select id="venueStatus" required>
                        <option value="Available">Available</option>
                        <option value="Unavailable">Unavailable</option>
                    </select>
                </div>
            </div>
            <div class="venue-form-actions">
                <button type="button" class="venue-cancel-btn" id="cancelVenueButton">Cancel</button>
                <button type="submit" class="venue-save-btn" id="saveVenueButton">Create Venue</button>
            </div>
        </form>
    </div>
</div>

<!-- DELETE MODAL -->
<div class="modal-overlay" id="deleteVenueModal">
    <div class="delete-modal">
        <div class="delete-modal-icon">!</div>
        <h2>Delete Venue?</h2>
        <p id="deleteVenueText">The venue will be permanently removed.</p>
        <div class="delete-buttons">
            <button type="button" class="venue-cancel-btn" id="keepVenueButton">Keep Venue</button>
            <button type="button" class="confirm-delete" id="confirmVenueDelete">Delete Venue</button>
        </div>
    </div>
</div>

<div class="toast" id="toast"></div>

<!-- FOOTER -->
<footer class="ev-footer">
    <div class="container">
        <div class="ev-footer-top">
            <div>
                <a href="index.php" class="ev-footer-brand">
                    <span class="ev-footer-mark">E</span>
                    <span>Event<em>ify</em></span>
                </a>
                <p class="ev-footer-about">
                    Find events, book tickets and keep every reservation in one place.
                </p>
            </div>
            <div>
                <h3>Explore</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="events.php">All events</a></li>
                    <li><a href="index.php#how-it-works">How it works</a></li>
                </ul>
            </div>
            <div>
                <h3>Your account</h3>
                <ul>
                    <li><a href="login.php">Sign in</a></li>
                    <li><a href="register.php">Create account</a></li>
                    <li><a href="bookings.php">My bookings</a></li>
                </ul>
            </div>
        </div>

        <div class="ev-footer-bottom">
            <span>&copy; 2026 Eventify</span>
            <span>Event Ticketing &amp; Venue Booking System</span>
        </div>
    </div>
</footer>

<script>
/* =========================================
   VARIABLES
========================================= */
const token = localStorage.getItem("eventify_token");
let currentUser = null;
let venues = [];
let formMode = "create";
let deleteVenueId = null;

const venueGrid = document.getElementById("venueGrid");
const venueModal = document.getElementById("venueModal");
const deleteVenueModal = document.getElementById("deleteVenueModal");
const venueForm = document.getElementById("venueForm");
const formMessage = document.getElementById("venueFormMessage");
const saveVenueButton = document.getElementById("saveVenueButton");
const toast = document.getElementById("toast");

/* =========================================
   INITIALISE
========================================= */
async function initialise() {
    if (!token) {
        window.location.href = "login.php";
        return;
    }
    try {
        const authResponse = await fetch("auth/me.php", {
            headers: { Authorization: "Bearer " + token }
        });
        const authResult = await authResponse.json();
        if (!authResponse.ok || authResult.status !== "success") {
            logout();
            return;
        }
        currentUser = authResult.user;
        if (currentUser.role !== "Administrator") {
            alert("Only Administrators can manage venues.");
            window.location.replace(
                currentUser.role === "Organiser" ? "dashboard.php" : "events.php"
            );
            return;
        }

        document.body.classList.remove("venue-access-pending");
        updateNavbar();
        await loadVenues();
    } catch (error) {
        showToast("Unable to load venue management.", "error");
    }
}

/* =========================================
   LOAD VENUES
========================================= */
async function loadVenues() {
    const response = await fetch("api/venues.php");
    const result = await response.json();
    if (!response.ok || result.status !== "success") {
        throw new Error(result.message || "Unable to load venues");
    }
    venues = result.data;
    displayVenues(venues);
    updateStats();
}

/* =========================================
   DISPLAY
========================================= */
function displayVenues(venueList) {
    venueGrid.innerHTML = "";
    if (venueList.length === 0) {
        venueGrid.innerHTML = `
            <div class="empty-venues">
                No venues found matching your filter.
            </div>
        `;
        return;
    }
    venueList.forEach(venue => {
        const available = venue.status === "Available";
        const card = document.createElement("article");
        card.className = "venue-card";
        card.innerHTML = `
            <div class="venue-cover">
                <span class="venue-status ${available ? "venue-available" : "venue-unavailable"}">
                    ${escapeHTML(venue.status)}
                </span>
                <div class="venue-symbol">⌖</div>
            </div>
            <div class="venue-content">
                <h3>${escapeHTML(venue.venue_name)}</h3>
                <p class="venue-location">⌖ ${escapeHTML(venue.location)}</p>
                <div class="venue-information">
                    <div class="venue-info-box">
                        <small>Capacity</small>
                        <strong>${Number(venue.capacity).toLocaleString()}</strong>
                    </div>
                    <div class="venue-info-box">
                        <small>Events</small>
                        <strong>${Number(venue.event_count)}</strong>
                    </div>
                </div>
                <div class="venue-actions">
                    <button type="button" class="venue-edit" onclick="editVenue(${venue.venue_id})">Edit Venue</button>
                    <button type="button" class="venue-delete" onclick="askDeleteVenue(${venue.venue_id})">Delete</button>
                </div>
            </div>
        `;
        venueGrid.appendChild(card);
    });
}

/* =========================================
   STATS
========================================= */
function updateStats() {
    const available = venues.filter(v => v.status === "Available").length;
    const unavailable = venues.filter(v => v.status === "Unavailable").length;
    const capacity = venues.reduce((total, v) => total + Number(v.capacity), 0);

    document.getElementById("totalVenues").textContent = venues.length;
    document.getElementById("availableVenues").textContent = available;
    document.getElementById("unavailableVenues").textContent = unavailable;
    document.getElementById("totalCapacity").textContent = capacity.toLocaleString();
}

/* =========================================
   CREATE
========================================= */
document.getElementById("newVenueButton").addEventListener("click", openCreateVenue);

function openCreateVenue() {
    formMode = "create";
    venueForm.reset();
    document.getElementById("venueId").value = "";
    document.getElementById("venueModalEyebrow").textContent = "CREATE VENUE";
    document.getElementById("venueModalTitle").textContent = "New Venue";
    saveVenueButton.textContent = "Create Venue";
    clearFormMessage();
    venueModal.classList.add("show");
}

/* =========================================
   EDIT
========================================= */
function editVenue(venueId) {
    const venue = venues.find(item => Number(item.venue_id) === Number(venueId));
    if (!venue) return;

    formMode = "edit";
    document.getElementById("venueId").value = venue.venue_id;
    document.getElementById("venueName").value = venue.venue_name;
    document.getElementById("venueLocation").value = venue.location;
    document.getElementById("venueCapacity").value = venue.capacity;
    document.getElementById("venueStatus").value = venue.status;

    document.getElementById("venueModalEyebrow").textContent = "EDIT VENUE";
    document.getElementById("venueModalTitle").textContent = "Update Venue";
    saveVenueButton.textContent = "Save Changes";
    clearFormMessage();
    venueModal.classList.add("show");
}

/* =========================================
   SAVE CREATE / EDIT
========================================= */
venueForm.addEventListener("submit", async function (event) {
    event.preventDefault();
    const payload = {
        venue_name: document.getElementById("venueName").value.trim(),
        location: document.getElementById("venueLocation").value.trim(),
        capacity: Number(document.getElementById("venueCapacity").value),
        status: document.getElementById("venueStatus").value
    };

    if (formMode === "edit") {
        payload.venue_id = Number(document.getElementById("venueId").value);
    }

    saveVenueButton.disabled = true;
    saveVenueButton.textContent = formMode === "create" ? "Creating..." : "Saving...";

    try {
        const response = await fetch("api/venues.php", {
            method: formMode === "create" ? "POST" : "PUT",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify(payload)
        });
        const result = await response.json();

        if (response.status === 401) {
            logout();
            return;
        }
        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Unable to save venue");
        }

        showFormMessage(result.message, "success");
        await loadVenues();
        setTimeout(function () {
            venueModal.classList.remove("show");
            showToast(result.message, "success");
        }, 600);
    } catch (error) {
        showFormMessage(error.message, "error");
    } finally {
        saveVenueButton.disabled = false;
        saveVenueButton.textContent = formMode === "create" ? "Create Venue" : "Save Changes";
    }
});

/* =========================================
   DELETE
========================================= */
function askDeleteVenue(venueId) {
    deleteVenueId = venueId;
    const venue = venues.find(item => Number(item.venue_id) === Number(venueId));
    document.getElementById("deleteVenueText").textContent = venue
        ? `Delete "${venue.venue_name}"? A venue assigned to an event cannot be deleted.`
        : "Delete this venue?";
    deleteVenueModal.classList.add("show");
}

document.getElementById("confirmVenueDelete").addEventListener("click", async function () {
    if (!deleteVenueId) return;
    this.disabled = true;
    this.textContent = "Deleting...";

    try {
        const response = await fetch("api/venues.php", {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify({ venue_id: deleteVenueId })
        });
        const result = await response.json();

        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Unable to delete venue");
        }

        deleteVenueModal.classList.remove("show");
        deleteVenueId = null;
        await loadVenues();
        showToast(result.message, "success");
    } catch (error) {
        deleteVenueModal.classList.remove("show");
        showToast(error.message, "error");
    } finally {
        this.disabled = false;
        this.textContent = "Delete Venue";
    }
});

/* =========================================
   SEARCH
========================================= */
document.getElementById("venueSearch").addEventListener("input", filterVenues);
document.getElementById("venueStatusFilter").addEventListener("change", filterVenues);

function filterVenues() {
    const search = document.getElementById("venueSearch").value.toLowerCase();
    const status = document.getElementById("venueStatusFilter").value;

    const filtered = venues.filter(venue => {
        const searchText = (venue.venue_name + " " + venue.location).toLowerCase();
        const searchMatch = searchText.includes(search);
        const statusMatch = status === "" || venue.status === status;
        return searchMatch && statusMatch;
    });
    displayVenues(filtered);
}

/* =========================================
   MODAL CONTROLS
========================================= */
function closeVenueModal() {
    venueModal.classList.remove("show");
}

document.getElementById("closeVenueModal").addEventListener("click", closeVenueModal);
document.getElementById("cancelVenueButton").addEventListener("click", closeVenueModal);
document.getElementById("keepVenueButton").addEventListener("click", function () {
    deleteVenueId = null;
    deleteVenueModal.classList.remove("show");
});

/* =========================================
   FORM MESSAGE & HELPERS
========================================= */
function clearFormMessage() {
    formMessage.className = "form-message";
    formMessage.textContent = "";
}

function showFormMessage(message, type) {
    formMessage.textContent = message;
    formMessage.className = "form-message " + type;
}

function updateNavbar() {
    document.getElementById("authNavigation").innerHTML = `
        <span class="top-user" style="color:#b9d3cf; font-size:14px; font-weight:700;">
            ${escapeHTML(currentUser.name)}
            <small style="color:#9fc2bd;">(${escapeHTML(currentUser.role)})</small>
        </span>
        <button type="button" class="top-logout" onclick="logout()" style="padding:9px 16px; border:none; border-radius:10px; background:var(--ev-coral); color:var(--ev-deep); font:700 14px var(--ev-body); cursor:pointer;">
            Logout
        </button>
    `;
}

function logout() {
    localStorage.removeItem("eventify_token");
    localStorage.removeItem("eventify_user");
    window.location.href = "login.php";
}

function showToast(message, type) {
    toast.textContent = message;
    toast.className = "toast " + type + " show";
    setTimeout(function () {
        toast.classList.remove("show");
    }, 3500);
}

function escapeHTML(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

initialise();
</script>

</body>
</html>