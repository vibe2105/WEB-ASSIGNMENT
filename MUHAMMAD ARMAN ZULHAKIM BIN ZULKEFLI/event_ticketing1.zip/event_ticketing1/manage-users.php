<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Eventify</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,800&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --ev-deep: #072b2d;
            --ev-teal: #0c4a4d;
            --ev-teal-soft: #14666a;
            --ev-coral: #ff6a4d;
            --ev-coral-dark: #f0553a;
            --ev-mint: #a8ebd3;
            --ev-paper: #f4f8f6;
            --ev-ink: #12292b;
            --ev-muted: #5f7577;
            --ev-line: #d5e2df;
            --ev-display: "Fraunces", Georgia, "Times New Roman", serif;
            --ev-body: "Figtree", system-ui, -apple-system, "Segoe UI", sans-serif;
        }

        body {
            background: var(--ev-paper);
            color: var(--ev-ink);
            font-family: var(--ev-body);
            min-height: 100vh;
        }

        /* ======================================
           NAVBAR OVERRIDES
        ====================================== */
        .navbar { background: var(--ev-deep); border: 0; box-shadow: none; }
        .navbar .brand, .navbar .brand span { color: #fff; }
        .navbar .brand-purple { color: var(--ev-coral); }
        .navbar .brand-icon { background: var(--ev-coral); color: var(--ev-deep); }
        .navbar .nav-links a { color: #b9d3cf; }
        .navbar .nav-links a:hover, .navbar .nav-links a.active { color: #fff; }

        /* ======================================
           HERO
        ====================================== */
        .users-hero {
            padding: 56px 0 62px;
            color: white;
            background:
                radial-gradient(550px 320px at 90% 0%, rgba(255, 106, 77, .22), transparent 70%),
                linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%);
        }
        .users-hero-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 28px;
            flex-wrap: wrap;
        }
        .users-hero .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 999px;
            background: rgba(168, 235, 211, .15);
            color: var(--ev-mint);
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .6px;
        }
        .users-hero h1 {
            margin-top: 12px;
            font-family: var(--ev-display);
            font-size: clamp(34px, 4.2vw, 50px);
            font-weight: 800;
            letter-spacing: -1.2px;
            line-height: 1.05;
            color: #fff;
        }
        .users-hero p {
            margin-top: 8px;
            color: #b9d3cf;
            font-size: 16px;
        }
        .add-user-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 14px 24px;
            border: none;
            border-radius: 14px;
            color: var(--ev-deep);
            background: var(--ev-coral);
            cursor: pointer;
            font: 700 15px var(--ev-body);
            box-shadow: 0 10px 24px rgba(255, 106, 77, .3);
            transition: all .2s ease;
        }
        .add-user-btn:hover {
            background: var(--ev-coral-dark);
            transform: translateY(-2px);
            box-shadow: 0 14px 28px rgba(255, 106, 77, .38);
        }

        /* ======================================
           CONTENT
        ====================================== */
        .users-section {
            padding: 40px 0 96px;
        }
        .user-stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .user-stat {
            position: relative;
            padding: 24px;
            background: white;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(7, 43, 45, .03);
            overflow: hidden;
        }
        .user-stat::before {
            content: "";
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: var(--ev-teal-soft);
        }
        .user-stat:nth-child(2)::before { background: var(--ev-coral); }
        .user-stat:nth-child(3)::before { background: var(--ev-mint); }
        .user-stat:nth-child(4)::before { background: var(--ev-deep); }

        .user-stat span {
            color: var(--ev-muted);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .8px;
        }
        .user-stat strong {
            display: block;
            margin-top: 8px;
            font-family: var(--ev-display);
            font-size: 34px;
            font-weight: 800;
            color: var(--ev-ink);
            letter-spacing: -.6px;
        }

        /* ======================================
           TOOLBAR
        ====================================== */
        .user-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            padding: 18px 20px;
            margin-bottom: 24px;
            background: white;
            border: 1px solid var(--ev-line);
            border-radius: 20px;
            box-shadow: 0 4px 14px rgba(7, 43, 45, .02);
        }
        .user-toolbar input {
            flex: 1;
            height: 48px;
            padding: 0 16px;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            outline: none;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font: 500 15px var(--ev-body);
            transition: all .2s;
        }
        .user-toolbar input:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 3px rgba(20, 102, 106, .12);
        }
        .user-toolbar select {
            min-width: 180px;
            height: 48px;
            padding: 0 14px;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            font: 600 14px var(--ev-body);
            cursor: pointer;
            transition: all .2s;
        }
        .user-toolbar select:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            outline: none;
        }

        /* ======================================
           TABLE
        ====================================== */
        .users-table-card {
            overflow: hidden;
            background: white;
            border: 1px solid var(--ev-line);
            border-radius: 24px;
            box-shadow: 0 14px 36px rgba(7, 43, 45, .05);
        }
        .table-scroll {
            overflow-x: auto;
        }
        .users-table {
            width: 100%;
            min-width: 950px;
            border-collapse: collapse;
        }
        .users-table th {
            padding: 18px 22px;
            background: var(--ev-paper);
            color: var(--ev-muted);
            text-align: left;
            text-transform: uppercase;
            letter-spacing: .9px;
            font-size: 11px;
            font-weight: 700;
            border-bottom: 1px solid var(--ev-line);
        }
        .users-table td {
            padding: 20px 22px;
            vertical-align: middle;
            border-bottom: 1px solid var(--ev-line);
            font-size: 15px;
            color: var(--ev-ink);
        }
        .users-table tr:last-child td {
            border-bottom: none;
        }
        .users-table tbody tr {
            transition: background .15s ease;
        }
        .users-table tbody tr:hover {
            background: rgba(244, 248, 246, .6);
        }
        .user-cell {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .table-avatar {
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            flex-shrink: 0;
            border-radius: 12px;
            color: var(--ev-deep);
            background: var(--ev-mint);
            font-weight: 800;
            font-size: 16px;
        }
        .user-cell strong {
            display: block;
            color: var(--ev-ink);
            font-size: 16px;
            font-weight: 700;
        }
        .user-cell span {
            display: block;
            margin-top: 3px;
            color: var(--ev-muted);
            font-size: 13px;
        }

        /* ======================================
           ROLE
        ====================================== */
        .role-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 12px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 700;
        }
        .role-badge::before {
            content: "";
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: currentColor;
        }
        .role-admin {
            color: #1a56db;
            background: #eff6ff;
        }
        .role-organiser {
            color: #0c4a4d;
            background: #e4f6ef;
        }
        .role-customer {
            color: #0f6446;
            background: #e4f6ef;
        }

        /* ======================================
           ACTIONS
        ====================================== */
        .user-actions {
            display: flex;
            gap: 8px;
        }
        .edit-user-btn,
        .delete-user-btn {
            padding: 9px 16px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font: 700 13px var(--ev-body);
            transition: all .15s ease;
        }
        .edit-user-btn {
            color: var(--ev-deep);
            background: var(--ev-mint);
        }
        .edit-user-btn:hover {
            background: #93dec5;
            transform: translateY(-1px);
        }
        .delete-user-btn {
            color: #a1301d;
            background: #fff1ef;
            border: 1px solid #f2c6bd;
        }
        .delete-user-btn:hover {
            background: #fde8e4;
            transform: translateY(-1px);
        }
        .empty-users {
            padding: 80px 20px;
            text-align: center;
            color: var(--ev-muted);
            font-size: 16px;
        }

        /* ======================================
           MODAL
        ====================================== */
        .modal-overlay {
            position: fixed;
            inset: 0;
            z-index: 5000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(7, 43, 45, .75);
            backdrop-filter: blur(6px);
        }
        .modal-overlay.show {
            display: flex;
        }
        .user-modal {
            width: min(580px, 100%);
            max-height: 90vh;
            overflow-y: auto;
            background: white;
            border-radius: 24px;
            box-shadow: 0 25px 70px rgba(7, 43, 45, .32);
        }
        .user-modal-header {
            padding: 24px 28px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--ev-line);
        }
        .user-modal-header span {
            color: var(--ev-teal-soft);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        .user-modal-header h2 {
            margin-top: 4px;
            font-family: var(--ev-display);
            font-size: 24px;
            font-weight: 800;
            color: var(--ev-ink);
        }
        .close-modal {
            width: 38px;
            height: 38px;
            border: none;
            border-radius: 12px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            cursor: pointer;
            font-size: 20px;
            line-height: 1;
            transition: background .15s;
        }
        .close-modal:hover {
            background: var(--ev-line);
        }
        .user-form {
            padding: 28px;
        }
        .form-group {
            margin-bottom: 18px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--ev-ink);
            font-size: 13px;
            font-weight: 700;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            height: 48px;
            padding: 0 16px;
            border: 1px solid var(--ev-line);
            border-radius: 12px;
            background: var(--ev-paper);
            color: var(--ev-ink);
            outline: none;
            font: 500 15px var(--ev-body);
            transition: all .2s;
        }
        .form-group input:focus,
        .form-group select:focus {
            background: #fff;
            border-color: var(--ev-teal-soft);
            box-shadow: 0 0 0 3px rgba(20, 102, 106, .12);
        }
        .password-note {
            margin-top: 6px;
            color: var(--ev-muted);
            font-size: 12px;
            line-height: 1.5;
        }
        .form-message {
            display: none;
            margin-bottom: 18px;
            padding: 13px;
            border-radius: 10px;
            font-size: 13px;
        }
        .form-message.error {
            display: block;
            color: #a1301d;
            background: #fff1ef;
        }
        .form-message.success {
            display: block;
            color: #0f6446;
            background: #e4f6ef;
        }
        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 20px;
            border-top: 1px solid var(--ev-line);
        }
        .cancel-btn,
        .save-user-btn {
            padding: 12px 22px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font: 700 15px var(--ev-body);
            transition: background .15s;
        }
        .cancel-btn {
            background: var(--ev-paper);
            color: var(--ev-ink);
        }
        .cancel-btn:hover {
            background: var(--ev-line);
        }
        .save-user-btn {
            color: var(--ev-deep);
            background: var(--ev-coral);
        }
        .save-user-btn:hover {
            background: var(--ev-coral-dark);
        }
        .save-user-btn:disabled {
            opacity: .6;
            cursor: not-allowed;
        }

        /* ======================================
           DELETE MODAL
        ====================================== */
        .delete-modal {
            width: min(420px, 100%);
            padding: 32px;
            text-align: center;
            background: white;
            border-radius: 24px;
            box-shadow: 0 25px 70px rgba(7, 43, 45, .3);
        }
        .delete-icon {
            width: 60px;
            height: 60px;
            display: grid;
            place-items: center;
            margin: 0 auto;
            border-radius: 50%;
            color: #a1301d;
            background: #fff1ef;
            font-size: 24px;
            font-weight: 800;
        }
        .delete-modal h2 {
            margin-top: 18px;
            font-family: var(--ev-display);
            font-size: 24px;
            font-weight: 800;
            color: var(--ev-ink);
        }
        .delete-modal p {
            margin-top: 8px;
            color: var(--ev-muted);
            font-size: 15px;
            line-height: 1.6;
        }
        .delete-buttons {
            display: flex;
            gap: 12px;
            margin-top: 26px;
        }
        .delete-buttons button {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font: 700 15px var(--ev-body);
            transition: background .15s;
        }
        .confirm-delete {
            background: #c34848;
            color: white;
        }
        .confirm-delete:hover {
            background: #a93a3a;
        }

        /* ======================================
           TOAST
        ====================================== */
        .toast {
            position: fixed;
            z-index: 7000;
            right: 25px;
            bottom: 25px;
            min-width: 280px;
            padding: 15px 22px;
            color: white;
            border-radius: 14px;
            opacity: 0;
            transform: translateY(40px);
            pointer-events: none;
            transition: .3s;
            font: 700 14px var(--ev-body);
            box-shadow: 0 18px 45px rgba(7, 43, 45, .25);
        }
        .toast.show {
            opacity: 1;
            transform: translateY(0);
        }
        .toast.success { background: #0f6446; }
        .toast.error { background: #a1301d; }

        /* ======================================
           FOOTER
        ====================================== */
        .ev-footer { color: #b9d3cf; background: linear-gradient(170deg, var(--ev-teal) 0%, var(--ev-deep) 100%); margin-top: auto; }
        .ev-footer-top {
            display: grid;
            grid-template-columns: minmax(0, 1.6fr) repeat(2, minmax(0, 1fr));
            gap: 48px;
            padding: 60px 0 44px;
        }
        .ev-footer-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            font-family: var(--ev-display);
            font-size: 26px;
            font-weight: 800;
            text-decoration: none;
        }
        .ev-footer-mark {
            width: 38px;
            height: 38px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: var(--ev-coral);
            color: var(--ev-deep);
            font-size: 20px;
        }
        .ev-footer-brand em { font-style: normal; color: var(--ev-coral); }
        .ev-footer-about { margin-top: 16px; max-width: 340px; font-size: 15px; line-height: 1.65; color: #9fc2bd; }
        .ev-footer h3 { font-family: var(--ev-display); font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 14px; }
        .ev-footer ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 10px; }
        .ev-footer ul a { color: #b9d3cf; font-size: 15px; text-decoration: none; }
        .ev-footer ul a:hover { color: #fff; text-decoration: underline; }
        .ev-footer-bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px 24px;
            padding: 22px 0 28px;
            border-top: 2px dashed rgba(255, 255, 255, .2);
            font-size: 14px;
            color: #9fc2bd;
        }

        @media (max-width: 900px) {
            .user-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .user-toolbar { flex-direction: column; align-items: stretch; }
            .user-toolbar select { width: 100%; }
            .ev-footer-top { grid-template-columns: 1fr 1fr; }
            .ev-footer-top > div:first-child { grid-column: 1 / -1; }
        }
        @media (max-width: 600px) {
            .users-hero-content { flex-direction: column; align-items: flex-start; }
            .add-user-btn { width: 100%; justify-content: center; }
            .user-stats { grid-template-columns: 1fr; }
            .ev-footer-top { padding: 44px 0 32px; gap: 32px 24px; }
        }
    </style>
</head>
<body>

<!-- NAVIGATION -->
<header class="navbar">
    <div class="container nav-container">
        <a href="index.php" class="brand">
            <div class="brand-icon">E</div>
            <span>Event<span class="brand-purple">ify</span></span>
        </a>
        <nav class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="manage-events.php">Events</a>
            <a href="manage-venues.php">Venues</a>
            <a href="manage-bookings.php">Bookings</a>
            <a href="manage-users.php" class="active">Users</a>
        </nav>
        <div class="nav-actions" id="authNavigation"></div>
    </div>
</header>

<!-- HERO -->
<section class="users-hero">
    <div class="container users-hero-content">
        <div>
            <span class="eyebrow">ADMINISTRATION</span>
            <h1>Manage Users</h1>
            <p>Manage customer, organiser and administrator accounts.</p>
        </div>
        <button type="button" class="add-user-btn" id="addUserButton">
            <span>+</span> Create User
        </button>
    </div>
</section>

<!-- CONTENT -->
<main class="users-section">
    <div class="container">
        <!-- STATS -->
        <section class="user-stats">
            <article class="user-stat">
                <span>Total Users</span>
                <strong id="totalUsers">0</strong>
            </article>
            <article class="user-stat">
                <span>Customers</span>
                <strong id="customerCount">0</strong>
            </article>
            <article class="user-stat">
                <span>Organisers</span>
                <strong id="organiserCount">0</strong>
            </article>
            <article class="user-stat">
                <span>Administrators</span>
                <strong id="adminCount">0</strong>
            </article>
        </section>

        <!-- TOOLBAR -->
        <section class="user-toolbar">
            <input type="text" id="userSearch" placeholder="Search name, email or user ID...">
            <select id="roleFilter">
                <option value="">All Roles</option>
                <option value="Administrator">Administrator</option>
                <option value="Organiser">Organiser</option>
                <option value="Customer">Customer</option>
            </select>
        </section>

        <!-- TABLE -->
        <section class="users-table-card">
            <div class="table-scroll">
                <table class="users-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Events</th>
                            <th>Bookings</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="userTableBody">
                        <tr>
                            <td colspan="6" class="empty-users">Loading users...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</main>

<!-- CREATE / EDIT MODAL -->
<div class="modal-overlay" id="userModal">
    <div class="user-modal">
        <div class="user-modal-header">
            <div>
                <span id="modalEyebrow">CREATE USER</span>
                <h2 id="modalTitle">New User</h2>
            </div>
            <button type="button" class="close-modal" id="closeUserModal">&times;</button>
        </div>
        <form class="user-form" id="userForm">
            <input type="hidden" id="userId">
            <div class="form-message" id="formMessage"></div>
            <div class="form-group">
                <label for="userName">Full Name</label>
                <input type="text" id="userName" placeholder="Enter full name" required>
            </div>
            <div class="form-group">
                <label for="userEmail">Email Address</label>
                <input type="email" id="userEmail" placeholder="example@email.com" required>
            </div>
            <div class="form-group">
                <label for="userRole">Role</label>
                <select id="userRole" required>
                    <option value="Customer">Customer</option>
                    <option value="Organiser">Organiser</option>
                    <option value="Administrator">Administrator</option>
                </select>
            </div>
            <div class="form-group">
                <label for="userPassword">Password</label>
                <input type="password" id="userPassword" placeholder="Enter password">
                <p class="password-note" id="passwordNote">Minimum 6 characters.</p>
            </div>
            <div class="form-actions">
                <button type="button" class="cancel-btn" id="cancelUserButton">Cancel</button>
                <button type="submit" class="save-user-btn" id="saveUserButton">Create User</button>
            </div>
        </form>
    </div>
</div>

<!-- DELETE MODAL -->
<div class="modal-overlay" id="deleteModal">
    <div class="delete-modal">
        <div class="delete-icon">!</div>
        <h2>Delete User?</h2>
        <p id="deleteText">This account will be permanently deleted.</p>
        <div class="delete-buttons">
            <button type="button" class="cancel-btn" id="keepUserButton">Keep User</button>
            <button type="button" class="confirm-delete" id="confirmDeleteButton">Delete User</button>
        </div>
    </div>
</div>

<div class="toast" id="toast"></div>

<!-- FOOTER -->
<footer class="ev-footer">
    <div class="container">
        <div class="ev-footer-top">
            <div>
                <a href="index.php" class="ev-footer-brand">
                    <span class="ev-footer-mark">E</span>
                    <span>Event<em>ify</em></span>
                </a>
                <p class="ev-footer-about">
                    Find events, book tickets and keep every reservation in one place.
                </p>
            </div>
            <div>
                <h3>Explore</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="events.php">All events</a></li>
                    <li><a href="index.php#how-it-works">How it works</a></li>
                </ul>
            </div>
            <div>
                <h3>Your account</h3>
                <ul>
                    <li><a href="login.php">Sign in</a></li>
                    <li><a href="register.php">Create account</a></li>
                    <li><a href="bookings.php">My bookings</a></li>
                </ul>
            </div>
        </div>

        <div class="ev-footer-bottom">
            <span>&copy; 2026 Eventify</span>
            <span>Event Ticketing &amp; Venue Booking System</span>
        </div>
    </div>
</footer>

<script>
/* ======================================
   VARIABLES
====================================== */
const token = localStorage.getItem("eventify_token");
let currentUser = null;
let users = [];
let formMode = "create";
let selectedDeleteId = null;

const userTableBody = document.getElementById("userTableBody");
const userModal = document.getElementById("userModal");
const deleteModal = document.getElementById("deleteModal");
const userForm = document.getElementById("userForm");
const formMessage = document.getElementById("formMessage");
const saveUserButton = document.getElementById("saveUserButton");
const toast = document.getElementById("toast");

/* ======================================
   INITIALISE
====================================== */
async function initialise() {
    if (!token) {
        window.location.href = "login.php";
        return;
    }
    try {
        const response = await fetch("auth/me.php", {
            headers: { Authorization: "Bearer " + token }
        });
        const result = await response.json();
        if (!response.ok || result.status !== "success") {
            logout();
            return;
        }
        currentUser = result.user;

        if (currentUser.role !== "Administrator") {
            alert("Administrator access is required.");
            window.location.href = currentUser.role === "Organiser" ? "dashboard.php" : "events.php";
            return;
        }

        updateNavbar();
        await loadUsers();
    } catch (error) {
        showToast("Unable to load user management.", "error");
    }
}

/* ======================================
   LOAD USERS
====================================== */
async function loadUsers() {
    const response = await fetch("api/users.php", {
        headers: { Authorization: "Bearer " + token }
    });
    const result = await response.json();
    if (response.status === 401) {
        logout();
        return;
    }
    if (!response.ok || result.status !== "success") {
        throw new Error(result.message || "Unable to load users");
    }
    users = result.data;
    displayUsers(users);
    updateStatistics();
}

/* ======================================
   DISPLAY USERS
====================================== */
function displayUsers(userList) {
    userTableBody.innerHTML = "";
    if (userList.length === 0) {
        userTableBody.innerHTML = `
            <tr>
                <td colspan="6" class="empty-users">No users found matching your filter.</td>
            </tr>
        `;
        return;
    }

    userList.forEach(user => {
        const initial = String(user.name).charAt(0).toUpperCase();
        const joined = new Date(String(user.created_at).replace(" ", "T"));
        const joinedText = isNaN(joined.getTime())
            ? user.created_at
            : joined.toLocaleDateString("en-MY", { day: "numeric", month: "short", year: "numeric" });

        const row = document.createElement("tr");
        row.innerHTML = `
            <td>
                <div class="user-cell">
                    <div class="table-avatar">${initial}</div>
                    <div>
                        <strong>${escapeHTML(user.name)}</strong>
                        <span>#${user.user_id} • ${escapeHTML(user.email)}</span>
                    </div>
                </div>
            </td>
            <td>
                <span class="role-badge ${getRoleClass(user.role)}">
                    ${escapeHTML(user.role)}
                </span>
            </td>
            <td><strong>${Number(user.event_count)}</strong></td>
            <td><strong>${Number(user.booking_count)}</strong></td>
            <td>${joinedText}</td>
            <td>
                <div class="user-actions">
                    <button type="button" class="edit-user-btn" onclick="editUser(${user.user_id})">Edit</button>
                    ${Number(user.user_id) !== Number(currentUser.user_id) ? `
                        <button type="button" class="delete-user-btn" onclick="askDelete(${user.user_id})">Delete</button>
                    ` : ""}
                </div>
            </td>
        `;
        userTableBody.appendChild(row);
    });
}

/* ======================================
   STATISTICS
====================================== */
function updateStatistics() {
    const customers = users.filter(u => u.role === "Customer").length;
    const organisers = users.filter(u => u.role === "Organiser").length;
    const administrators = users.filter(u => u.role === "Administrator").length;

    document.getElementById("totalUsers").textContent = users.length;
    document.getElementById("customerCount").textContent = customers;
    document.getElementById("organiserCount").textContent = organisers;
    document.getElementById("adminCount").textContent = administrators;
}

/* ======================================
   SEARCH
====================================== */
document.getElementById("userSearch").addEventListener("input", filterUsers);
document.getElementById("roleFilter").addEventListener("change", filterUsers);

function filterUsers() {
    const search = document.getElementById("userSearch").value.toLowerCase();
    const role = document.getElementById("roleFilter").value;

    const filtered = users.filter(user => {
        const text = (user.user_id + " " + user.name + " " + user.email).toLowerCase();
        const searchMatch = text.includes(search);
        const roleMatch = role === "" || user.role === role;
        return searchMatch && roleMatch;
    });
    displayUsers(filtered);
}

/* ======================================
   CREATE USER
====================================== */
document.getElementById("addUserButton").addEventListener("click", openCreateUser);

function openCreateUser() {
    formMode = "create";
    userForm.reset();
    document.getElementById("userId").value = "";
    document.getElementById("modalEyebrow").textContent = "CREATE USER";
    document.getElementById("modalTitle").textContent = "New User";
    document.getElementById("passwordNote").textContent = "Password is required. Minimum 6 characters.";
    document.getElementById("userPassword").required = true;
    saveUserButton.textContent = "Create User";
    clearMessage();
    userModal.classList.add("show");
}

/* ======================================
   EDIT USER
====================================== */
function editUser(userId) {
    const user = users.find(item => Number(item.user_id) === Number(userId));
    if (!user) return;

    formMode = "edit";
    document.getElementById("userId").value = user.user_id;
    document.getElementById("userName").value = user.name;
    document.getElementById("userEmail").value = user.email;
    document.getElementById("userRole").value = user.role;
    document.getElementById("userPassword").value = "";
    document.getElementById("userPassword").required = false;
    document.getElementById("passwordNote").textContent = "Leave blank to keep the existing password. Enter at least 6 characters to reset it.";
    document.getElementById("modalEyebrow").textContent = "EDIT USER";
    document.getElementById("modalTitle").textContent = "Update User";
    saveUserButton.textContent = "Save Changes";
    clearMessage();
    userModal.classList.add("show");
}

/* ======================================
   SAVE USER
====================================== */
userForm.addEventListener("submit", async function (event) {
    event.preventDefault();
    const password = document.getElementById("userPassword").value;
    const payload = {
        name: document.getElementById("userName").value.trim(),
        email: document.getElementById("userEmail").value.trim(),
        role: document.getElementById("userRole").value,
        password: password
    };

    if (formMode === "edit") {
        payload.user_id = Number(document.getElementById("userId").value);
    }

    if (formMode === "create" && password.length < 6) {
        showMessage("Password must contain at least 6 characters.", "error");
        return;
    }
    if (formMode === "edit" && password !== "" && password.length < 6) {
        showMessage("New password must contain at least 6 characters.", "error");
        return;
    }

    saveUserButton.disabled = true;
    saveUserButton.textContent = formMode === "create" ? "Creating..." : "Saving...";

    try {
        const response = await fetch("api/users.php", {
            method: formMode === "create" ? "POST" : "PUT",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify(payload)
        });
        const result = await response.json();

        if (response.status === 401) {
            logout();
            return;
        }
        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Unable to save user");
        }

        showMessage(result.message, "success");
        await loadUsers();
        setTimeout(function () {
            userModal.classList.remove("show");
            showToast(result.message, "success");
        }, 600);
    } catch (error) {
        showMessage(error.message, "error");
    } finally {
        saveUserButton.disabled = false;
        saveUserButton.textContent = formMode === "create" ? "Create User" : "Save Changes";
    }
});

/* ======================================
   DELETE
====================================== */
function askDelete(userId) {
    selectedDeleteId = userId;
    const user = users.find(item => Number(item.user_id) === Number(userId));
    document.getElementById("deleteText").textContent = user
        ? `Delete "${user.name}"? Accounts linked to events or bookings cannot be deleted.`
        : "Delete this user?";
    deleteModal.classList.add("show");
}

document.getElementById("confirmDeleteButton").addEventListener("click", async function () {
    if (!selectedDeleteId) return;
    this.disabled = true;
    this.textContent = "Deleting...";

    try {
        const response = await fetch("api/users.php", {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },
            body: JSON.stringify({ user_id: selectedDeleteId })
        });
        const result = await response.json();

        if (!response.ok || result.status !== "success") {
            throw new Error(result.message || "Unable to delete user");
        }

        deleteModal.classList.remove("show");
        selectedDeleteId = null;
        await loadUsers();
        showToast(result.message, "success");
    } catch (error) {
        deleteModal.classList.remove("show");
        showToast(error.message, "error");
    } finally {
        this.disabled = false;
        this.textContent = "Delete User";
    }
});

/* ======================================
   MODALS
====================================== */
function closeUserModal() {
    userModal.classList.remove("show");
}

document.getElementById("closeUserModal").addEventListener("click", closeUserModal);
document.getElementById("cancelUserButton").addEventListener("click", closeUserModal);
document.getElementById("keepUserButton").addEventListener("click", function () {
    selectedDeleteId = null;
    deleteModal.classList.remove("show");
});

/* ======================================
   MESSAGES
====================================== */
function clearMessage() {
    formMessage.className = "form-message";
    formMessage.textContent = "";
}

function showMessage(message, type) {
    formMessage.textContent = message;
    formMessage.className = "form-message " + type;
}

/* ======================================
   ROLE CLASS
====================================== */
function getRoleClass(role) {
    if (role === "Administrator") return "role-admin";
    if (role === "Organiser") return "role-organiser";
    return "role-customer";
}

/* ======================================
   NAVBAR
====================================== */
function updateNavbar() {
    document.getElementById("authNavigation").innerHTML = `
        <span class="top-user" style="color:#b9d3cf; font-size:14px; font-weight:700;">
            ${escapeHTML(currentUser.name)}
            <small style="color:#9fc2bd;">(Administrator)</small>
        </span>
        <button type="button" class="top-logout" onclick="logout()" style="padding:9px 16px; border:none; border-radius:10px; background:var(--ev-coral); color:var(--ev-deep); font:700 14px var(--ev-body); cursor:pointer;">
            Logout
        </button>
    `;
}

/* ======================================
   LOGOUT
====================================== */
function logout() {
    localStorage.removeItem("eventify_token");
    localStorage.removeItem("eventify_user");
    window.location.href = "login.php";
}

/* ======================================
   TOAST
====================================== */
function showToast(message, type) {
    toast.textContent = message;
    toast.className = "toast " + type + " show";
    setTimeout(function () {
        toast.classList.remove("show");
    }, 3500);
}

/* ======================================
   ESCAPE
====================================== */
function escapeHTML(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

/* ======================================
   START
====================================== */
initialise();
</script>

</body>
</html>